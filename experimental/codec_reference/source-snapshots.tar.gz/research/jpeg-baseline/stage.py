"""Stage one canonical baseline and pinned inputs; no remote compiler invocation."""
from pathlib import Path
import hashlib, io, json, os, re, shlex, subprocess, tarfile

root = Path(__file__).resolve().parent
tag = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['codec-jpeg-cpu'])
binary = tag / 'experimental/codec_reference/research/jpeg-baseline/jpeg_baseline'
qualified = json.loads((root / 'qualified.json').read_text())
assert qualified['source_sha256'] == hashlib.sha256((root / 'jpeg_baseline.cc').read_bytes()).hexdigest()
symbols = subprocess.check_output(['llvm-nm', '-n', str(binary)], text=True)
(root / 'symbols.txt').write_text(symbols)
selected = []
main = None
for line in symbols.splitlines():
    parts = line.split()
    if len(parts) != 3 or parts[1].lower() != 't':
        continue
    address, _, name = parts
    if name == 'main': main = int(address, 16)
    if re.fullmatch(r'jsimd_(idct_islow|ycc_rgb_convert|h2v2_fancy_upsample)_(avx2|sse2)', name) or re.fullmatch(r'decode_mcu(?:_DC_first|_AC_first|_DC_refine|_AC_refine)?(?:\.llvm\.\d+)?', name):
        selected.append({'name': name, 'address': int(address, 16)})
assert main and len(selected) >= 10
commands = ['set pagination off', 'set confirm off', 'set startup-with-shell off',
            'set disable-randomization on', 'starti', f'set $bias = (long)&main - {main}']
for i, symbol in enumerate(selected, 1):
    commands += [f'break *($bias + {symbol["address"]})', 'commands', 'silent',
                 f'printf "JPEG_ROUTE {symbol["name"]} %p\\n", $pc', f'disable {i}', 'continue', 'end']
commands += ['continue']
(root / 'routes.gdb').write_text('\n'.join(commands) + '\n')
(root / 'selected-symbols.json').write_text(json.dumps(selected, indent=2) + '\n')
assembly = subprocess.check_output(['llvm-objdump', '-d', '--no-show-raw-insn', str(binary)], text=True)
functions = []
for match in re.finditer(r'^([0-9a-f]+) <([^>]+)>:\n(.*?)(?=^[0-9a-f]+ <|\Z)', assembly, re.M | re.S):
    functions.append((match[2], match[0]))
# Keep complete assembly families, including NASM local-label regions.
prefixes = {s['name'] for s in selected}
(root / 'selected-native.s').write_text(''.join(text for name, text in functions
    if any(name == prefix or name.startswith(prefix + '.') for prefix in prefixes)))
if (root / 'remote.json').exists():
    previous = json.loads((root / 'remote.json').read_text())
    assert not previous['retired'] and previous['host'] == 'hrx-gorgon-3'
    remote = previous['directory']
    verify = 'from pathlib import Path; import json,hashlib,sys; root=Path(sys.argv[1]); m=json.loads((root/"manifest.json").read_text()); assert all(hashlib.sha256((root/n).read_bytes()).hexdigest()==v["sha256"] for n,v in m["files"].items())'
    subprocess.run(['ssh', previous['host'], shlex.join(['python3', '-c', verify, remote])], check=True)
else:
    remote = subprocess.check_output(['ssh', 'hrx-gorgon-3', 'mktemp -d /tmp/codec-jpeg-cpu.XXXXXXXX'], text=True).strip()
files = {'jpeg_baseline': binary, 'run.py': root / 'run.py', 'routes.gdb': root / 'routes.gdb',
         'machine-state.py': root.parent / 'scan/ordered-oracle/run.py'}
files.update({'inputs/' + p.name: p for p in (root / 'inputs').glob('*.jpg')})
manifest = {'host': 'hrx-gorgon-3', 'directory': remote, 'retired': False,
            'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
            'configuration': '--config=opt', 'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
            'source_sha256': qualified['source_sha256'], 'files': {}}
payload = io.BytesIO()
with tarfile.open(fileobj=payload, mode='w', dereference=True) as archive:
    for name, path in files.items():
        archive.add(path, arcname=name, recursive=False)
        manifest['files'][name] = {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
(root / 'remote.json').write_text(json.dumps(manifest, indent=2) + '\n')
subprocess.run(['ssh', manifest['host'], shlex.join(['tar', '-xf', '-', '-C', remote])], input=payload.getvalue(), check=True)
subprocess.run(['scp', str(root / 'remote.json'), manifest['host'] + ':' + remote + '/manifest.json'], check=True)
print(json.dumps({'directory': remote, 'binary_bytes': binary.stat().st_size, 'symbols': len(selected)}))
