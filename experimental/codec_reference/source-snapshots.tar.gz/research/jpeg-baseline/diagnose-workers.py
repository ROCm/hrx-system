from pathlib import Path
import json,subprocess,time,os
root=Path(__file__).resolve().parent
os.chdir(root)
p=subprocess.Popen(['taskset','-c','4-7','./jpeg_baseline','bench','16','4','30','inputs/synthetic-1024.jpg.progressive.jpg'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
samples=[]
while p.poll() is None:
 row={'time':time.monotonic(),'tasks':[]}
 for path in Path(f'/proc/{p.pid}/task').glob('*'):
  try:
   stat=path.joinpath('stat').read_text(); rest=stat[stat.rfind(')')+2:].split();status=path.joinpath('status').read_text()
   row['tasks'].append({'id':path.name,'comm':path.joinpath('comm').read_text().strip(),'state':rest[0],'utime':int(rest[11]),'stime':int(rest[12]),'cpu':int(rest[36]),'affinity':next(l for l in status.splitlines() if l.startswith('Cpus_allowed_list:'))})
  except (FileNotFoundError,ProcessLookupError):pass
 samples.append(row);time.sleep(.1)
out,err=p.communicate();assert p.returncode==0 and not err,(p.returncode,err)
cgroup=Path('/proc/self/cgroup').read_text().strip();groups=[]
path=Path('/sys/fs/cgroup')/cgroup.split('::')[-1].lstrip('/')
while path != Path('/sys/fs'):
 for name in ['cpu.max','cpuset.cpus.effective']:
  if (path/name).is_file():groups.append([str(path/name),(path/name).read_text().strip()])
 path=path.parent
Path('worker-diagnostic.json').write_text(json.dumps({'lease':os.environ['BENCHMARK_LOCK_LEASE_ID'],'samples':samples,'row':json.loads(out),'cgroups':groups},indent=2)+'\n')
print('diagnostic samples',len(samples))
