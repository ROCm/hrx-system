"""Retain window medians and logical byte counts without inventing traffic."""
from pathlib import Path
import json
import statistics

root = Path(__file__).resolve().parent
rows = []
for phase in ['small', 'large', 'scale']:
    values = json.loads((root / (phase + '-rows.json')).read_text())
    for key in sorted({(tuple(v['images']), v['batch'], v['workers']) for v in values}):
        windows = [v for v in values if (tuple(v['images']), v['batch'], v['workers']) == key]
        medians = [v['median_batch_ns'] for v in windows]
        median = statistics.median(medians)
        rows.append({'phase': phase, 'images': key[0], 'batch': key[1], 'workers': key[2],
                     'window_medians_ns': medians, 'median_batch_ns': median,
                     'images_per_second': key[1] * 1e9 / median,
                     'compressed_bytes_per_batch': windows[0]['compressed_bytes'],
                     'rgb_bytes_per_batch': windows[0]['rgb_bytes'],
                     'logical_rgb_GB_per_second': windows[0]['rgb_bytes'] / median})
for phase in ['small', 'large', 'scale']:
    before = json.loads((root / (phase + '-state-before.json')).read_text())
    after = json.loads((root / (phase + '-state-after.json')).read_text())
    assert before['lease'] and before['lease'] == after['lease']
    for value in [before, after]:
        assert value['governor'] == 'performance' and int(value['personality'], 16) & 0x40000
        assert not value['kfd_processes'] and not value['drm'] and value['gpu_busy'] == 0
manifest = json.loads((root / 'remote.json').read_text())
native = json.loads((root / 'qualified-native.json').read_text())
assert native['binary_sha256'] == manifest['binary_sha256']
(root / 'summary.json').write_text(json.dumps({'commit': manifest['commit'],
    'source_sha256': manifest['source_sha256'], 'binary_sha256': manifest['binary_sha256'],
    'configuration': manifest['configuration'], 'broker_held': True,
    'boundary': 'complete queued CPU batch, one final release wait',
    'repetitions_per_window': 9, 'warmups_per_window': 2,
    'input_residency': 'warm; homogeneous jobs share immutable compressed input',
    'output_residency': 'one distinct preallocated RGB buffer per job', 'rows': rows}, indent=2) + '\n')
print('| Input/process | Batch | Serial ms | Four workers ms |')
print('| --- | ---: | ---: | ---: |')
for row in rows:
    if row['workers'] != 0:
        continue
    parallel = next(v for v in rows if v['phase'] == row['phase'] and v['images'] == row['images'] and v['workers'] == 4)
    bounds = parallel['window_medians_ns']
    print(f"| {row['images'][0]} | {row['batch']} | {row['median_batch_ns']/1e6:.3f} | "
          f"{min(bounds)/1e6:.3f}–{max(bounds)/1e6:.3f} |")
