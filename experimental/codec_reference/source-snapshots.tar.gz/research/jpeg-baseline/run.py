"""Qualify native routes or measure whole CPU batches under the broker."""
from pathlib import Path
import ast, hashlib, json, os, re, statistics, subprocess, sys

root = Path(__file__).resolve().parent
os.chdir(root)
tree = ast.parse(Path('machine-state.py').read_text())
state_node = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'state')
exec(compile(ast.Module(body=[state_node], type_ignores=[]), 'machine-state.py', 'exec'))
manifest = json.loads(Path('manifest.json').read_text())
assert hashlib.sha256(Path('jpeg_baseline').read_bytes()).hexdigest() == manifest['binary_sha256']
for name, entry in manifest['files'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == entry['sha256'], name
phase = sys.argv[1]
assert phase in ['qualify', 'small', 'large', 'scale']
before = state()
Path(phase + '-state-before.json').write_text(json.dumps(before, indent=2) + '\n')
assert before['governor'] == 'performance' and int(before['personality'], 16) & 0x40000
assert not before['kfd_processes'] and not before['drm'] and before['gpu_busy'] == 0
assert not any(k.startswith('JSIMD_') for k in os.environ)
with Path(phase + '-host.txt').open('w') as output:
    for command in [['lscpu'], ['ps', '-eo', 'pid,comm,pcpu,args', '--sort=-pcpu'], ['vmstat', '1', '3']]:
        subprocess.run(command, stdout=output, stderr=subprocess.STDOUT, check=True)

if phase == 'qualify':
    arguments = ['./jpeg_baseline', 'qualify', *map(str, sorted(Path('inputs').glob('*.jpg')))]
    with Path('native-qualified.log').open('w') as output:
        subprocess.run(['taskset', '-c', '4', *arguments], stdout=output, stderr=subprocess.STDOUT, check=True)
    arguments = ['./jpeg_baseline', 'qualify', 'inputs/012mp-bus.jpg.r0.jpg',
                 'inputs/012mp-bus.jpg.r64.jpg', 'inputs/synthetic-256.jpg.progressive.jpg',
                 'inputs/006mp-cathedral.jpg.r0.jpg']
    with Path('native-routes.log').open('w') as output:
        subprocess.run(['taskset', '-c', '4', '/opt/rocm/bin/rocgdb', '--batch', '-x', 'routes.gdb', '--args', *arguments],
                       stdout=output, stderr=subprocess.STDOUT, check=True)
    log = Path('native-routes.log').read_text()
    required = ['jsimd_idct_islow_avx2', 'jsimd_ycc_rgb_convert_avx2', 'jsimd_h2v2_fancy_upsample_avx2']
    assert all('JPEG_ROUTE ' + name + ' ' in log for name in required), log[-4000:]
    assert 'exited normally' in log
    Path('qualified-native.json').write_text(json.dumps({'binary_sha256': manifest['binary_sha256'],
        'routes': re.findall(r'^JPEG_ROUTE (\S+) (\S+)', log, re.M), 'inputs': 16}, indent=2) + '\n')
else:
    routes = json.loads(Path('qualified-native.json').read_text())
    assert routes['binary_sha256'] == manifest['binary_sha256']
    rows = []
    if phase == 'small':
        cases = [(name, 16) for name in ['synthetic-256.jpg', 'synthetic-1024.jpg']]
        worker_order = [0, 4, 1, 4, 0]
    elif phase == 'large':
        cases = [(name, 4) for name in ['006mp-cathedral.jpg', '012mp-bus.jpg']]
        worker_order = [0, 4, 1, 4, 0]
    else:
        cases = [('012mp-bus.jpg', 16)]
        worker_order = [4, 16, 4, 16, 4]
    for name, batch in cases:
        for suffix in ['.r0.jpg', '.r64.jpg', '.progressive.jpg']:
            if phase == 'scale' and suffix != '.r0.jpg': continue
            for window, workers in enumerate(worker_order):
                cpus = '4' if workers <= 1 else '4-7' if workers == 4 else '0-15'
                arguments = ['taskset', '-c', cpus, './jpeg_baseline', 'bench', str(batch), str(workers), '9', 'inputs/' + name + suffix]
                result = subprocess.run(arguments, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
                assert not result.stderr, result.stderr
                row, = [json.loads(line) for line in result.stdout.splitlines()]
                assert row['kind'] == 'timing' and row['full_rgb_and_guards'] and len(row['batch_ns']) == 9
                row.update({'window': window, 'cpus': cpus, 'median_batch_ns': statistics.median(row['batch_ns'])})
                rows.append(row)
                Path(phase + '-rows.json').write_text(json.dumps(rows, indent=2) + '\n')
                print(json.dumps({k: row[k] for k in ['images', 'workers', 'batch', 'window', 'median_batch_ns']}), flush=True)
Path(phase + '-state-after.json').write_text(json.dumps(state(), indent=2) + '\n')
