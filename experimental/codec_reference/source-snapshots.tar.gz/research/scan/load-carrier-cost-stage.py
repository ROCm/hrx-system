"""Stage exactly two leased compiler artifacts and run the locked comparison."""
from pathlib import Path
import hashlib
import io
import json
import os
import shlex
import subprocess
import tarfile

notes = Path(__file__).resolve().parent
roots = {k: Path(v) for k, v in json.loads(os.environ['BUREAU_TAG_ROOTS']).items()}
manifest = notes / 'load-carrier-cost-artifacts.json'
assert not manifest.exists()
files = {'compile-' + name: roots['scan-load-' + name] / 'loom/src/loom/tools/loom-compile/loom-compile'
         for name in ['baseline', 'candidate']}
for filename, module in [('scan', 'scan_kernels'), ('storage-disjoint', 'storage_disjoint_kernels'),
                         ('short-length', 'short_length_kernels'), ('uniform', 'uniform_count_compare')]:
    relative = 'experimental/codec_reference/research/scan/' + module + '.loombc'
    baseline = roots['scan-load-baseline'] / relative
    candidate = roots['scan-load-candidate'] / relative
    assert baseline.read_bytes() == candidate.read_bytes()
    files[filename + '.loombc'] = baseline
for count in [32, 512, 65537, 2097152, 16777216]:
    files[f'config-{count}.json'] = notes / f'compare-config-{count}.json'
files['run.py'] = notes / 'load-carrier-cost-run.py'
files['expected-native.json'] = notes / 'compare-rebase-1881-native-identity.json'

def remote(args, **kwargs):
    return subprocess.run(['ssh', '-o', 'BatchMode=yes', 'hrx-gorgon-3', shlex.join([str(a) for a in args])],
                          check=True, **kwargs)

directory = remote(['mktemp', '-d', '/tmp/loom-load-carrier-cost.XXXXXXXX'], text=True, capture_output=True).stdout.strip()
payload = io.BytesIO()
with tarfile.open(fileobj=payload, mode='w', dereference=True) as archive:
    for name, path in files.items():
        archive.add(path, arcname=name, recursive=False)
remote(['tar', '-xf', '-', '-C', directory], input=payload.getvalue(), capture_output=True)
identities = {name: {'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'bytes': p.stat().st_size}
              for name, p in files.items()}
for line in remote(['sha256sum', *[directory + '/' + name for name in files]], capture_output=True, text=True).stdout.splitlines():
    digest, name = line.split(maxsplit=1)
    assert identities[Path(name).name]['sha256'] == digest
record = {'baseline_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
          'candidate_sources': json.loads((notes / 'load-carrier-cost-stash.json').read_text())['files'],
          'remote_directory': directory, 'files': identities, 'build_flags': '--config=opt',
          'tags': {name: str(root) for name, root in roots.items()}}
manifest.write_text(json.dumps(record, indent=2) + '\n')
print(directory, flush=True)
remote(['/home/benvanik/.dotfiles/bin/benchmark-lock', '--label', 'codec-load-carrier-compile', '--', 'python3', directory + '/run.py'])
result = remote(['cat', directory + '/compile-cost.json'], capture_output=True).stdout
(notes / 'load-carrier-compile-cost.json').write_bytes(result)
print('Retained structured cost and identity evidence.', flush=True)
