// Development-only matched whole-device ordered scan comparison.
#include <hip/hip_runtime.h>
#include <rocprim/device/device_scan.hpp>

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>

struct Affine {
  // Multiplicative coefficient modulo 2^32.
  uint32_t scale;
  // Additive coefficient modulo 2^32.
  uint32_t offset;
};
static_assert(sizeof(Affine) == 8);

struct Compose {
  __host__ __device__ Affine operator()(Affine left, Affine right) const {
    return {right.scale * left.scale, right.scale * left.offset + right.offset};
  }
};

static void check(hipError_t error, const char* expression) {
  if (error != hipSuccess) {
    std::fprintf(stderr, "%s: %s\n", expression, hipGetErrorString(error));
    std::exit(1);
  }
}
#define HIP(expression) check((expression), #expression)

static void equal(Affine actual, Affine expected, const char* kind, size_t index) {
  if (actual.scale != expected.scale || actual.offset != expected.offset) {
    std::fprintf(stderr, "%s mismatch at %zu: {%u,%u} != {%u,%u}\n", kind, index,
                 actual.scale, actual.offset, expected.scale, expected.offset);
    std::exit(1);
  }
}

int main(int argc, char** argv) {
  if (argc != 6) {
    std::fprintf(stderr, "usage: ordered count submissions distribution {check|trace|measure} {normal|diagnostic|force|reverse}\n");
    return 1;
  }
  const size_t count = std::strtoull(argv[1], nullptr, 10);
  const unsigned submissions = std::strtoul(argv[2], nullptr, 10);
  const unsigned distribution = std::strtoul(argv[3], nullptr, 10);
  const std::string phase = argv[4];
  const std::string profile = argv[5];
  const bool diagnostic = profile != "normal";
  if (count > (1u << 24) || !submissions || distribution > 2 ||
      (phase != "check" && phase != "trace" && phase != "measure") ||
      (profile != "normal" && profile != "diagnostic" && profile != "force" && profile != "reverse") ||
      (phase == "measure" && diagnostic) ||
      ((profile == "force" || profile == "reverse") && count > 65537)) return 1;
  constexpr unsigned chain = 32;
  constexpr unsigned threads = 256;
  constexpr unsigned tile = threads * 16;
  constexpr Affine canary = {0x735ab192u, 0x16d9438fu};
  const Affine initial = {5, uint32_t(count * 17u + 0xf7654321u)};
  const unsigned groups = (count + tile - 1) / tile;
  const unsigned scan_groups = std::max(groups, 1u);
  const unsigned reset_groups = std::max((groups + threads - 1) / threads, 1u);
  const size_t bytes = (count + 16) * sizeof(Affine);
  const size_t state_bytes = (groups + 16) * sizeof(uint32_t);
  const size_t summary_bytes = (groups + 16) * sizeof(Affine);
  std::vector<Affine> host_input(count + 16, canary);
  std::vector<Affine> host_output(count + 16, canary);
  std::vector<Affine> host_aggregates(groups + 16, canary);
  std::vector<Affine> host_prefixes(groups + 16, canary);
  std::vector<uint32_t> host_states(groups + 16, canary.scale);
  std::vector<uint32_t> host_counters(groups * 3 + 16, canary.scale);
  std::vector<uint32_t> host_schedule(3 + 16, canary.scale);
  for (size_t i = 0; i < count; ++i) {
    uint32_t scale = distribution == 0 ? 1u : (uint32_t(i * 13 + 5) | 1u);
    if (distribution == 2 && (i % 67 == 0 || i % 129 == 0)) scale = 0;
    host_input[i] = {scale, uint32_t(i * 104729 + 0xfedcba98u)};
  }
  hipStream_t stream;
  HIP(hipStreamCreate(&stream));
  Affine *input, *output, *seed, *aggregates, *prefixes;
  uint32_t *length, *states, *schedule, *counters;
  HIP(hipMalloc(&input, bytes));
  HIP(hipMalloc(&output, bytes));
  HIP(hipMalloc(&seed, sizeof(initial)));
  HIP(hipMalloc(&length, sizeof(uint32_t)));
  HIP(hipMalloc(&states, state_bytes));
  HIP(hipMalloc(&aggregates, summary_bytes));
  HIP(hipMalloc(&prefixes, summary_bytes));
  HIP(hipMalloc(&schedule, host_schedule.size() * sizeof(uint32_t)));
  HIP(hipMalloc(&counters, host_counters.size() * sizeof(uint32_t)));
  const uint32_t runtime_count = count;
  HIP(hipMemcpyAsync(input, host_input.data(), bytes, hipMemcpyHostToDevice, stream));
  HIP(hipMemcpyAsync(seed, &initial, sizeof(initial), hipMemcpyHostToDevice, stream));
  HIP(hipMemcpyAsync(length, &runtime_count, sizeof(runtime_count), hipMemcpyHostToDevice, stream));
  size_t scratch_bytes = 0;
  HIP(rocprim::exclusive_scan(nullptr, scratch_bytes, input, output, initial,
                             count, Compose{}, stream));
  void* scratch = nullptr;
  HIP(hipMalloc(&scratch, scratch_bytes));
  HIP(hipStreamSynchronize(stream));
  hipModule_t modules[3];
  hipFunction_t kernels[3];
  const char* entries[] = {"reset_states", "scan_device", "scan_coalesced"};
  for (unsigned entry = 0; entry < 3; ++entry) {
    HIP(hipModuleLoad(&modules[entry], (profile + "-" + entries[entry] + ".hsaco").c_str()));
    HIP(hipModuleGetFunction(&kernels[entry], modules[entry], entries[entry]));
  }
  void* reset_arguments[] = {&length, &states, &schedule};
  void* scan_arguments[] = {&length, &input, &seed, &output, &states, &aggregates, &prefixes, &counters};
  hipGraph_t graphs[3];
  hipGraphExec_t executables[3];
  const char* names[] = {"rocprim", "original", "coalesced"};
  for (unsigned variant = 0; variant < 3; ++variant) {
    HIP(hipStreamBeginCapture(stream, hipStreamCaptureModeThreadLocal));
    for (unsigned operation = 0; operation < chain; ++operation) {
      if (variant == 0) {
        HIP(rocprim::exclusive_scan(scratch, scratch_bytes, input, output, initial,
                                   count, Compose{}, stream));
      } else {
        HIP(hipModuleLaunchKernel(kernels[0], reset_groups, 1, 1, threads, 1, 1, 0, stream, reset_arguments, nullptr));
        HIP(hipModuleLaunchKernel(kernels[variant], scan_groups, 1, 1, threads, 1, 1, 0, stream, scan_arguments, nullptr));
      }
    }
    HIP(hipStreamEndCapture(stream, &graphs[variant]));
    size_t node_count = 0;
    HIP(hipGraphGetNodes(graphs[variant], nullptr, &node_count));
    std::vector<hipGraphNode_t> nodes(node_count);
    HIP(hipGraphGetNodes(graphs[variant], nodes.data(), &node_count));
    for (auto node : nodes) {
      hipGraphNodeType type;
      HIP(hipGraphNodeGetType(node, &type));
      if (type != hipGraphNodeTypeKernel) {
        std::fprintf(stderr, "unexpected %s graph node type: %u\n", names[variant], unsigned(type));
        return 1;
      }
    }
    const unsigned expected_nodes = variant != 0 ? chain * 2 : count == 0 ? 0 : count <= tile ? chain : chain * 2;
    if (node_count != expected_nodes) return 1;
    HIP(hipGraphInstantiate(&executables[variant], graphs[variant], nullptr, nullptr, 0));
    std::printf("{\"kind\":\"identity\",\"variant\":\"%s\",\"count\":%zu,\"distribution\":%u,\"profile\":\"%s\",\"initial\":[%u,%u],\"scratch_payload_bytes\":%zu,\"graph_scans\":32,\"kernel_nodes\":%zu,\"groups\":%u,\"reset_groups\":%u,\"threads\":256,\"items\":16,\"input\":\"%p\",\"output\":\"%p\"}\n",
                 names[variant], count, distribution, profile.c_str(), initial.scale, initial.offset,
                 variant == 0 ? scratch_bytes : size_t(groups) * 20 + 12, node_count,
                 scan_groups, reset_groups, input, output);
  }
  auto reset = [&] {
    std::fill(host_output.begin(), host_output.end(), canary);
    HIP(hipMemcpyAsync(output, host_output.data(), bytes, hipMemcpyHostToDevice, stream));
    std::fill(host_states.begin(), host_states.end(), canary.scale);
    std::fill(host_aggregates.begin(), host_aggregates.end(), canary);
    std::fill(host_prefixes.begin(), host_prefixes.end(), canary);
    std::fill(host_counters.begin(), host_counters.end(), canary.scale);
    std::fill(host_schedule.begin(), host_schedule.end(), canary.scale);
    HIP(hipMemcpyAsync(states, host_states.data(), state_bytes, hipMemcpyHostToDevice, stream));
    HIP(hipMemcpyAsync(aggregates, host_aggregates.data(), summary_bytes, hipMemcpyHostToDevice, stream));
    HIP(hipMemcpyAsync(prefixes, host_prefixes.data(), summary_bytes, hipMemcpyHostToDevice, stream));
    HIP(hipMemcpyAsync(counters, host_counters.data(), host_counters.size() * sizeof(uint32_t), hipMemcpyHostToDevice, stream));
    HIP(hipMemcpyAsync(schedule, host_schedule.data(), host_schedule.size() * sizeof(uint32_t), hipMemcpyHostToDevice, stream));
  };
  auto verify = [&](unsigned variant) {
    HIP(hipMemcpyAsync(host_output.data(), output, bytes, hipMemcpyDeviceToHost, stream));
    if (variant != 0) {
      HIP(hipMemcpyAsync(host_states.data(), states, state_bytes, hipMemcpyDeviceToHost, stream));
      HIP(hipMemcpyAsync(host_aggregates.data(), aggregates, summary_bytes, hipMemcpyDeviceToHost, stream));
      HIP(hipMemcpyAsync(host_prefixes.data(), prefixes, summary_bytes, hipMemcpyDeviceToHost, stream));
      HIP(hipMemcpyAsync(host_schedule.data(), schedule, host_schedule.size() * sizeof(uint32_t), hipMemcpyDeviceToHost, stream));
      HIP(hipMemcpyAsync(host_counters.data(), counters, host_counters.size() * sizeof(uint32_t), hipMemcpyDeviceToHost, stream));
    }
    HIP(hipStreamSynchronize(stream));
    uint32_t scale = initial.scale;
    uint32_t offset = initial.offset;
    uint32_t aggregate_scale = 1;
    uint32_t aggregate_offset = 0;
    for (size_t i = 0; i < host_output.size(); ++i) {
      equal(host_output[i], i < count ? Affine{scale, offset} : canary, names[variant], i);
      if (i < count) {
        // Separate scalar recurrence with explicit modulo reduction.
        scale = uint32_t(uint64_t(scale) * host_input[i].scale);
        offset = uint32_t(uint64_t(offset) * host_input[i].scale + host_input[i].offset);
        aggregate_scale = uint32_t(uint64_t(aggregate_scale) * host_input[i].scale);
        aggregate_offset = uint32_t(uint64_t(aggregate_offset) * host_input[i].scale + host_input[i].offset);
        if ((i + 1) % tile == 0 || i + 1 == count) {
          if (variant != 0) {
            equal(host_aggregates[i / tile], {aggregate_scale, aggregate_offset}, "aggregate", i / tile);
            equal(host_prefixes[i / tile], {scale, offset}, "published prefix", i / tile);
          }
          aggregate_scale = 1;
          aggregate_offset = 0;
        }
      }
    }
    if (variant != 0) {
      for (size_t i = 0; i < host_states.size(); ++i) {
        if (host_states[i] != (i < groups ? 2u : canary.scale)) {
          std::fprintf(stderr, "state/guard mismatch at %zu\n", i);
          std::exit(1);
        }
        if (i >= groups) {
          equal(host_aggregates[i], canary, "aggregate guard", i);
          equal(host_prefixes[i], canary, "prefix guard", i);
        }
      }
      for (size_t i = 0; i < host_schedule.size(); ++i) {
        if (host_schedule[i] != (i == 0 ? groups : i < 3 ? 1u : canary.scale)) {
          std::fprintf(stderr, "schedule/guard mismatch at %zu\n", i);
          std::exit(1);
        }
      }
      uint64_t windows = 0, helpers = 0, terms = 0;
      for (size_t i = 0; i < host_counters.size(); ++i) {
        if ((!diagnostic || i >= groups * 3) && host_counters[i] != canary.scale) {
          std::fprintf(stderr, "diagnostic guard mismatch at %zu\n", i);
          std::exit(1);
        }
      }
      if (diagnostic) {
        for (unsigned group = 0; group < groups; ++group) {
          const unsigned w = host_counters[group * 3];
          const unsigned h = host_counters[group * 3 + 1];
          const unsigned t = host_counters[group * 3 + 2];
          if (w > (group + 31) / 32 || h > t || t > group ||
              (group != 0 && (w == 0 || t == 0)) ||
              (profile == "force" && (h != group || t != group || w != (group + 31) / 32))) {
            std::fprintf(stderr, "progress counters invalid for group %u: %u/%u/%u\n", group, w, h, t);
            std::exit(1);
          }
          windows += w;
          helpers += h;
          terms += t;
        }
        std::printf("{\"kind\":\"diagnostics\",\"count\":%zu,\"profile\":\"%s\",\"variant\":\"%s\",\"groups\":%u,\"windows\":%llu,\"recomputations\":%llu,\"terms\":%llu}\n",
                     count, profile.c_str(), names[variant], groups, (unsigned long long)windows,
                     (unsigned long long)helpers, (unsigned long long)terms);
      }
    }
  };
  for (unsigned variant = 0; variant < 3; ++variant) {
    reset();
    HIP(hipGraphLaunch(executables[variant], stream));
    verify(variant);
  }
  if (phase == "measure") {
    const unsigned order[] = {0, 1, 2, 0, 2, 1, 0};
    for (unsigned window = 0; window < 7; ++window) {
      const unsigned variant = order[window];
      reset();
      for (unsigned warmup = 0; warmup < 10; ++warmup) HIP(hipGraphLaunch(executables[variant], stream));
      HIP(hipStreamSynchronize(stream));
      std::vector<double> samples;
      for (unsigned sample = 0; sample < 9; ++sample) {
        const auto start = std::chrono::steady_clock::now();
        for (unsigned submission = 0; submission < submissions; ++submission) {
          HIP(hipGraphLaunch(executables[variant], stream));
        }
        HIP(hipStreamSynchronize(stream));
        const double elapsed = std::chrono::duration<double, std::nano>(
                                   std::chrono::steady_clock::now() - start).count();
        const double per_scan = elapsed / (submissions * double(chain));
        samples.push_back(per_scan);
        std::printf("{\"kind\":\"sample\",\"variant\":\"%s\",\"count\":%zu,\"window\":%u,\"sample\":%u,\"submissions\":%u,\"elapsed_ns\":%.3f,\"per_scan_ns\":%.3f}\n",
                     names[variant], count, window, sample, submissions, elapsed, per_scan);
      }
      verify(variant);
      std::sort(samples.begin(), samples.end());
      std::printf("{\"kind\":\"summary\",\"variant\":\"%s\",\"count\":%zu,\"window\":%u,\"median_per_scan_ns\":%.3f}\n",
                   names[variant], count, window, samples[4]);
    }
  }
  for (unsigned variant = 0; variant < 3; ++variant) {
    HIP(hipGraphExecDestroy(executables[variant]));
    HIP(hipGraphDestroy(graphs[variant]));
    HIP(hipModuleUnload(modules[variant]));
  }
  HIP(hipFree(scratch));
  HIP(hipFree(counters));
  HIP(hipFree(schedule));
  HIP(hipFree(prefixes));
  HIP(hipFree(aggregates));
  HIP(hipFree(states));
  HIP(hipFree(length));
  HIP(hipFree(seed));
  HIP(hipFree(output));
  HIP(hipFree(input));
  HIP(hipStreamDestroy(stream));
  return 0;
}
