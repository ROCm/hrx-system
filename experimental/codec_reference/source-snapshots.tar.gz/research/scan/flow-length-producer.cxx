#include <loomcxx/kernel.h>
#include <loomcxx/index.h>
#include <loomcxx/predicate.h>

[[loom::config("scan.capacity"), loom::where(
    loom::predicate::range(1, 16777216))]]
extern const loom::type::index capacity;

static loom::kernel::configuration configure_length_probe() {
  return {{1, 1, 1}, {1, 1, 1}};
}

[[loom::kernel(configure_length_probe)]]
void capture_prior_length(const unsigned* length, unsigned* output) {
  length = loom::buffer::assume::memory_space<loom::memory_space::constant>(length);
  unsigned extent = static_cast<unsigned>(static_cast<long long>(capacity));
  // One observation follows all sixteen output guards in this fixture.
  output[extent + 16] = length[0];
}

[[loom::kernel(configure_length_probe)]]
void publish_input_length(const unsigned* input, unsigned* length) {
  unsigned extent = static_cast<unsigned>(static_cast<long long>(capacity));
  // The caller places the next count immediately after the logical input span.
  length[0] = input[extent];
}
