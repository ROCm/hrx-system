"""Compile matched leaf configurations and retain native-code attribution."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

sdk = Path('/home/ben/tools/rocm-sdk-10.0.0-gfx1151/lib/python3.14/site-packages/_rocm_sdk_core/lib/llvm/bin')
base = json.loads(Path('address-config.json').read_text())
results = []
for variant in ('baseline', 'immutable'):
    config = json.loads(json.dumps(base))
    config['scan']['fused_prefix'] = False
    config_path = Path(variant + '-config.json')
    config_path.write_text(json.dumps(config, indent=2) + '\n')
    module = 'immutable_length_scan' if variant == 'immutable' else 'natural_scan'
    for target in ('gfx1151', 'gfx942'):
        name = variant + '-' + target
        artifact = Path(name + '.hsaco')
        subprocess.run(['./compile', module + '.loombc', '--target=amdgpu:' + target,
                        '--root=scan_lookback', '--config-file=' + str(config_path),
                        '--output=' + str(artifact)], check=True)
        assembly = subprocess.check_output([sdk / 'llvm-objdump', '-d', artifact], text=True)
        metadata = subprocess.check_output([sdk / 'llvm-readelf', '-n', '-S', artifact], text=True)
        Path(name + '.s').write_text(assembly)
        Path(name + '.metadata.txt').write_text(metadata)
        text_row = re.search(r'\]\s+\.text\s+PROGBITS\s+\S+\s+\S+\s+([0-9a-fA-F]+)', metadata)
        assert text_row, metadata
        row = {'variant': variant, 'target': target, 'source': module,
               'artifact': str(artifact), 'sha256': hashlib.sha256(artifact.read_bytes()).hexdigest(),
               'text_bytes': int(text_row[1], 16), 'artifact_bytes': artifact.stat().st_size,
               'barriers': len(re.findall(r'^\s+s_barrier\s', assembly, re.MULTILINE))}
        for field in ('group_segment_fixed_size', 'private_segment_fixed_size',
                      'sgpr_count', 'vgpr_count', 'wavefront_size'):
            found = re.search(r'\.' + field + r':\s+(\d+)', metadata)
            assert found, field
            row[field] = int(found[1])
        results.append(row)
        print(json.dumps(row), flush=True)
Path('immutable-length-native-code.json').write_text(json.dumps(results, indent=2) + '\n')
