"""Check rebased scan output against the published and measured native images."""
from pathlib import Path
import hashlib
import json
import subprocess
import tempfile

root = Path.cwd()
notes = root / 'experimental/codec_reference/research/scan'
compiler = root / 'bazel-bin/loom/src/loom/tools/loom-compile/loom-compile'
modules = root / 'bazel-bin/experimental/codec_reference/research/scan'
prior = json.loads((notes / 'compare-publication-native-identity.json').read_text())
module_names = {
    'smem-512': 'short_length_kernels',
    'uniform': 'uniform_count_compare',
    '65537': 'storage_disjoint_kernels',
}
results = []
with tempfile.TemporaryDirectory(prefix='loom-compare-rebase-') as scratch:
    for row in prior['rows']:
        label, entry = row['label'], row['entry']
        source = modules / (module_names.get(label, 'scan_kernels') + '.loombc')
        output = Path(scratch) / 'native.hsaco'
        arguments = [str(compiler), str(source), '--target=amdgpu:gfx1151',
                     '--root=' + entry, '--output=' + str(output)]
        if label != 'uniform':
            count = '512' if label == 'smem-512' else label
            arguments.append('--config-file=' + str(notes / ('compare-config-' + count + '.json')))
        subprocess.run(arguments, check=True)
        digest = hashlib.sha256(output.read_bytes()).hexdigest()
        result = {'label': label, 'entry': entry, 'sha256': digest,
                  'prior_sha256': row['sha256'], 'identical': digest == row['sha256'],
                  'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest()}
        results.append(result)
        print(label, entry, 'identical:', result['identical'], flush=True)
record = {'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
          'compiler_sha256': hashlib.sha256(compiler.read_bytes()).hexdigest(),
          'rows': results}
(notes / 'compare-rebase-1881-native-identity.json').write_text(json.dumps(record, indent=2) + '\n')
assert all(row['identical'] for row in results)
