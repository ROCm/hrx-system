from pathlib import Path
import hashlib,json,re,subprocess
sdk=Path('/home/ben/tools/rocm-sdk-10.0.0-gfx1151/lib/python3.14/site-packages/_rocm_sdk_devel/llvm/bin')
c=json.loads(Path('address-config.json').read_text());c['scan']['packed_state']=True
Path('reset-config.json').write_text(json.dumps(c)+'\n');rows=[]
Path('reset-native').mkdir(exist_ok=True)
for entry in ['scan_lookback','scan_single','reset_states']:
 p=Path('reset-native')/(entry+'.hsaco')
 subprocess.run(['./compile','reset.loombc','--target=amdgpu:gfx1151','--root='+entry,'--config-file=reset-config.json','--output='+str(p)],check=True)
 assembly=subprocess.check_output([sdk/'llvm-objdump','-d',p],text=True);metadata=subprocess.check_output([sdk/'llvm-readelf','-n','-S',p],text=True)
 Path('reset-native-'+entry+'.s').write_text(assembly);Path('reset-native-'+entry+'.metadata.txt').write_text(metadata)
 digest=hashlib.sha256(p.read_bytes()).hexdigest()
 if entry!='reset_states': assert p.read_bytes()==(Path('wait-control')/p.name).read_bytes()
 row={'entry':entry,'sha256':digest,'instructions':len(re.findall(r'//\s*[0-9a-fA-F]+:',assembly)),'text_bytes':int(re.search(r'\]\s+\.text\s+PROGBITS\s+\S+\s+\S+\s+([0-9a-fA-F]+)',metadata)[1],16)}
 for field in ['group_segment_fixed_size','private_segment_fixed_size','sgpr_count','vgpr_count','wavefront_size']:row[field]=int(re.search(r'\.'+field+r':\s+(\d+)',metadata)[1])
 rows.append(row)
Path('reset-parallel-native.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
subprocess.run(['/home/ben/tools/rocm-sdk-10.0.0-gfx1151/bin/hipcc','-std=c++20','-O3','--offload-arch=gfx1151','reset-native-hip.cpp','-o','wait-compare'],check=True)
