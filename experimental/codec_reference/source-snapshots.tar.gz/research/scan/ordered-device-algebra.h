#pragma once
#include "ordered-algebra.h"
#include <loomcxx/atomic.h>
#include <loomcxx/scalar.h>
#include <loomcxx/vector.h>

using Pair = unsigned __attribute__((ext_vector_type(2)));
using Values = unsigned __attribute__((ext_vector_type(16)));
using Block = unsigned __attribute__((ext_vector_type(32)));

static LOOM_FORCE_INLINE Pair combine(Pair left, Pair right) {
  Affine result = compose({left[0], left[1]}, {right[0], right[1]});
  return {result.scale, result.offset};
}

static LOOM_FORCE_INLINE Pair read_pair(const Affine* source) {
  auto view = loom::buffer::view<2>(reinterpret_cast<const unsigned*>(source),
                                   {}, loom::encoding::layout::dense<1>());
  return loom::vector::load<Pair>(view, {0});
}

static LOOM_FORCE_INLINE void write_pair(Pair value, Affine* destination) {
  auto view = loom::buffer::view<2>(reinterpret_cast<unsigned*>(destination),
                                   {}, loom::encoding::layout::dense<1>());
  loom::vector::store(value, view, {0});
}

static LOOM_FORCE_INLINE void local_barrier() {
  loom::kernel::barrier<loom::memory_space::workgroup,
      loom::atomic::scope::workgroup, loom::atomic::ordering::acq_rel>();
}

static LOOM_FORCE_INLINE Pair wave_inclusive(Pair value) {
  unsigned width = loom::kernel::subgroup::size();
  [[loom::unroll]]
  for (unsigned level = 0; level < 6; ++level) {
    unsigned distance = 1u << level;
    if (distance < width) {
      auto previous = loom::kernel::subgroup::shuffle_up(value, distance, width);
      if (previous.valid) value = combine(previous.value, value);
    }
  }
  return value;
}

static LOOM_FORCE_INLINE Pair reverse_window(Pair value) {
  unsigned width = loom::kernel::subgroup::size();
  [[loom::unroll]]
  for (unsigned level = 0; level < 6; ++level) {
    unsigned distance = 1u << level;
    if (distance < width) {
      auto previous = loom::kernel::subgroup::shuffle_down(value, distance, width);
      if (previous.valid) value = combine(previous.value, value);
    }
  }
  return loom::kernel::subgroup::broadcast(value, 0u);
}

struct Prefix {
  // Product of all earlier thread sequences in the workgroup.
  Pair exclusive;
  // Product of every thread sequence in the workgroup.
  Pair total;
};

static LOOM_FORCE_INLINE Prefix group_prefix(Pair value) {
  unsigned width = loom::kernel::subgroup::size();
  unsigned lane = loom::kernel::subgroup::lane_id();
  unsigned subgroup = loom::kernel::subgroup::id();
  unsigned subgroups = loom::kernel::workgroup::size.x / width;
  Pair inclusive = wave_inclusive(value);
  auto predecessor = loom::kernel::subgroup::shuffle_up(inclusive, 1u, width);
  Pair exclusive = {1, 0};
  if (predecessor.valid) exclusive = predecessor.value;
  if (subgroups == 1) {
    return {exclusive, loom::kernel::subgroup::broadcast(inclusive, width - 1)};
  }
  auto* totals = loom::buffer::alloca<Affine, loom::memory_space::workgroup>(subgroups);
  if (lane == width - 1) write_pair(inclusive, totals + subgroup);
  local_barrier();
  Pair total = {1, 0};
  if (lane < subgroups) total = read_pair(totals + lane);
  total = wave_inclusive(total);
  Pair group_total = loom::kernel::subgroup::broadcast(total, subgroups - 1);
  Pair earlier = loom::kernel::subgroup::broadcast(
      total, (subgroup + width - 1) % width);
  if (subgroup == 0) earlier = {1, 0};
  return {combine(earlier, exclusive), group_total};
}

struct Publication {
  // Zero is unavailable, one is an aggregate, and two is a completed prefix.
  unsigned state;
  // Immutable payload selected by the acquired state, or the identity for zero.
  Pair value;
};

static LOOM_FORCE_INLINE Publication observe(const unsigned* states,
    const Affine* aggregates, const Affine* prefixes, unsigned position) {
  unsigned state = loom::view::atomic::load<loom::atomic::ordering::acquire,
      loom::atomic::scope::device>(states + position);
  Pair value = {1, 0};
  if (state == 1) value = read_pair(aggregates + position);
  if (state == 2) value = read_pair(prefixes + position);
  return {state, value};
}

static LOOM_FORCE_INLINE void publish(unsigned state, Pair value,
    unsigned position, unsigned* states, Affine* payload) {
  write_pair(value, payload + position);
  loom::view::atomic::store<loom::atomic::ordering::release,
      loom::atomic::scope::device>(state, states + position);
}

static LOOM_FORCE_INLINE unsigned first_matching_lane(bool predicate) {
  unsigned width = loom::kernel::subgroup::size();
  unsigned long long mask = loom::kernel::subgroup::vote::ballot(predicate);
  unsigned lane = static_cast<unsigned>(loom::scalar::cttzi(mask));
  return lane < width ? lane : width;
}

static LOOM_FORCE_INLINE Pair recompute(const Affine* input, unsigned count,
                                        unsigned predecessor, unsigned tile) {
  unsigned width = loom::kernel::subgroup::size();
  unsigned lane = loom::kernel::subgroup::lane_id();
  unsigned terms = tile / width;
  unsigned begin = predecessor * tile + lane * terms;
  Pair partial = {1, 0};
  for (unsigned index = 0; index < terms; ++index) {
    Pair value = {1, 0};
    if (begin + index < count) value = read_pair(input + begin + index);
    partial = combine(partial, value);
  }
  partial = wave_inclusive(partial);
  return loom::kernel::subgroup::broadcast(partial, width - 1);
}
