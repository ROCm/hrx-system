#include <array>
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <chrono>
#include <filesystem>
#include <string>
#include <vector>
#include "iree/async/frontier_tracker.h"
#include "iree/async/util/proactor_pool.h"
#include "iree/base/tooling/flags.h"
#include "iree/hal/drivers/init.h"
#include "iree/testing/gtest.h"
#include "iree/testing/status_matchers.h"
#include "iree/tooling/device_profiling.h"
#include "loom/serve/runtime/program/command.h"
#include "loom/serve/runtime/execution/execution.h"
#include "loom/serve/runtime/host/host.h"
#include "loom/serve/runtime/program/jit.h"
#include "loom/serve/testing/compiler.h"
#include "loomc/sanitizer.h"
IREE_FLAG(string, scan_device, "amdgpu", "Device under qualification.");
IREE_FLAG(int32_t, scan_threads, 128, "Workitems for controlled dispatch comparison; zero uses target query.");
IREE_FLAG(int32_t, scan_items, 4, "Values held by each invocation.");
IREE_FLAG(int32_t, scan_refresh_rounds, 4, "Finite parallel refresh attempts before recomputation.");
IREE_FLAG(int32_t, scan_chain_length, 1, "Whole operations recorded in one command.");
IREE_FLAG(bool, scan_device_asan, false, "Enable access assertions in compiled device kernels.");
IREE_FLAG(bool, scan_redundant, false, "Use independent input reductions to remove inter-group state.");
IREE_FLAG(bool, scan_fused_prefix, false, "Share local scan and total computation.");
IREE_FLAG(bool, scan_diagnostics, false, "Record per-tile carry observations outside timing.");
IREE_FLAG(bool, scan_packed_state, false, "Publish state and value in one atomic word.");
IREE_FLAG(bool, scan_lookback, false, "Use bounded recomputation look-back.");
IREE_FLAG(bool, scan_force_fallback, false, "Recompute all predecessors for bounded correctness.");
IREE_FLAG(bool, scan_reverse_schedule, false, "Map physical workgroups to reverse logical tiles.");
IREE_FLAG(bool, scan_indirect, true, "Use device-produced grids instead of capacity grids.");
IREE_FLAG(int32_t, scan_count, 2097152, "Capacity and benchmark input length.");
IREE_FLAG(int32_t, scan_iterations, 200, "Fixed measured repetitions per sample.");
IREE_FLAG(string, scan_source, "", "Offline-produced scan bytecode.");
IREE_FLAG(bool, scan_describe_program, false, "Print actual command grids and packed arguments before execution.");
IREE_FLAG(string, scan_runtime, "serve", "Replay policy: serve, hal-default, hal-local, or hal-local-single.");
namespace {
iree_hal_queue_t* SelectQueue(iree_hal_device_t* device,
                              iree_hal_queue_family_role_flags_t role) {
  const auto* queues =
      iree_hal_device_spec_queues(iree_hal_device_spec(device));
  for (iree_host_size_t i = 0; i < queues->family_count; ++i) {
    const auto& family = queues->families[i];
    if (family.provisioned_queue_count &&
        iree_all_bits_set(family.role_flags, role)) {
      return iree_hal_device_queue(device, i, 0);
    }
  }
  return nullptr;
}

class ScanTest : public ::testing::Test {
 protected:
  void SetUp() override {
    ASSERT_GT(FLAG_scan_count, 0);
    if (FLAG_scan_redundant) ASSERT_LE(FLAG_scan_count, 65537);
    ASSERT_GE(FLAG_scan_refresh_rounds, 0);
    ASSERT_LE(FLAG_scan_refresh_rounds, 64);
    ASSERT_GT(FLAG_scan_chain_length, 0);
    ASSERT_LE(FLAG_scan_chain_length, 32);
    ASSERT_LE(FLAG_scan_count, 16777216);
    ASSERT_TRUE(FLAG_scan_threads == 0 || FLAG_scan_threads == 32 || FLAG_scan_threads == 64 ||
                FLAG_scan_threads == 128 || FLAG_scan_threads == 256);
    ASSERT_TRUE(FLAG_scan_items == 1 || FLAG_scan_items == 2 || FLAG_scan_items == 4 || FLAG_scan_items == 8 || FLAG_scan_items == 16);
    if (!FLAG_scan_lookback && FLAG_scan_threads) {
      const uint64_t tile = uint64_t(FLAG_scan_threads) * FLAG_scan_items;
      ASSERT_LE(uint64_t(FLAG_scan_count), tile * tile * tile);
    }
    if (FLAG_scan_force_fallback || FLAG_scan_reverse_schedule) ASSERT_LE(FLAG_scan_count, 65537);
    if (FLAG_scan_packed_state) ASSERT_TRUE(FLAG_scan_lookback);
    if (FLAG_scan_diagnostics) {
      ASSERT_TRUE(FLAG_scan_lookback);
      ASSERT_GT(FLAG_scan_threads, 0);
      ASSERT_GT(FLAG_scan_count, FLAG_scan_threads * FLAG_scan_items);
    }
    const std::string runtime = FLAG_scan_runtime;
    ASSERT_TRUE(runtime == "serve" || runtime == "hal-default" ||
                runtime == "hal-local" || runtime == "hal-local-single");
    IREE_ASSERT_OK(CreateDevice());
    auto* dispatch =
        SelectQueue(device_, IREE_HAL_QUEUE_FAMILY_ROLE_FLAG_DISPATCH);
    auto* transfer =
        SelectQueue(device_, IREE_HAL_QUEUE_FAMILY_ROLE_FLAG_TRANSFER);
    ASSERT_NE(dispatch, nullptr);
    ASSERT_NE(transfer, nullptr);
    dispatch_queue_ = dispatch;
    if (runtime != "serve") {
      iree_hal_semaphore_flags_t flags = IREE_HAL_SEMAPHORE_FLAG_DEFAULT;
      if (runtime == "hal-local" || runtime == "hal-local-single") {
        flags = IREE_HAL_SEMAPHORE_FLAG_DEVICE_LOCAL;
      }
      if (runtime == "hal-local-single") {
        flags |= IREE_HAL_SEMAPHORE_FLAG_SINGLE_PRODUCER;
      }
      IREE_ASSERT_OK(iree_hal_semaphore_create(device_,
          IREE_HAL_QUEUE_FAMILY_AFFINITY_ANY, 0, flags, &private_semaphore_));
    }
    const auto* family = iree_hal_queue_family(dispatch);
    const auto* transfer_family = iree_hal_queue_family(transfer);
    const iree_hal_pool_family_access_t families[] = {
        {.family = family,
         .usage = IREE_HAL_BUFFER_USAGE_STORAGE |
                  IREE_HAL_BUFFER_USAGE_TRANSFER |
                  IREE_HAL_BUFFER_USAGE_DISPATCH_INDIRECT_PARAMETERS},
        {.family = transfer_family, .usage = IREE_HAL_BUFFER_USAGE_TRANSFER},
    };
    const iree_hal_pool_scope_t scope = {
        .family_count = family == transfer_family ? 1u : 2u,
        .families = families,
    };
    const iree_hal_slab_pool_options_t pool_options = {};
    IREE_ASSERT_OK(iree_hal_slab_pool_create(group_, scope, &pool_options,
                                             host_allocator_, &storage_pool_));
    iree_hal_asan_pool_options_t asan_options = {};
    const auto* sanitizer =
        iree_hal_device_spec_sanitizer(iree_hal_device_spec(device_));
    if (FLAG_scan_device_asan) {
      ASSERT_TRUE(iree_any_bit_set(sanitizer->flags, IREE_HAL_DEVICE_SANITIZER_FLAG_ASAN));
    }
    if (iree_any_bit_set(sanitizer->flags,
                         IREE_HAL_DEVICE_SANITIZER_FLAG_ASAN)) {
      asan_options = sanitizer->asan.pool_options;
    }
    IREE_ASSERT_OK(loom_serve_workspace_create(
        group_, storage_pool_, &asan_options, host_allocator_, &workspace_));
    IREE_ASSERT_OK(loom_serve_execution_create(dispatch, transfer, workspace_,
                                               host_allocator_, &execution_));
    directory_ = std::filesystem::path(FLAG_scan_source).parent_path().string();
    filename_ = std::filesystem::path(FLAG_scan_source).filename().string();
    const iree_string_view_t providers[] = {iree_make_cstring_view(filename_.c_str())};
    const loom_serve_sources_t sources = {
      .base_directory = iree_make_cstring_view(directory_.c_str()),
      .count = 1, .values = providers};
    const loomc_sanitizer_options_t kernel_sanitizer = {
      .type = LOOMC_STRUCTURE_TYPE_SANITIZER_OPTIONS,
      .structure_size = sizeof(loomc_sanitizer_options_t),
      .checks = LOOMC_SANITIZER_CHECK_ACCESS,
      .reporting_mode = LOOMC_SANITIZER_REPORTING_MODE_DEFAULT};
    IREE_ASSERT_OK(loom_serve_jit_allocate(device_, dispatch, host_, &sources,
      FLAG_scan_device_asan ? &kernel_sanitizer : nullptr,
      &compilation_, host_allocator_, &jit_));
  }
  void TearDown() override {
    if (private_semaphore_) {
      IREE_EXPECT_OK(iree_hal_semaphore_wait(private_semaphore_, private_value_,
          iree_infinite_timeout(), IREE_ASYNC_WAIT_FLAG_NONE));
      iree_hal_semaphore_release(private_semaphore_);
    }
    if (execution_) IREE_EXPECT_OK(loom_serve_execution_drain(execution_));
    IREE_EXPECT_OK(iree_hal_end_profiling_from_flags(profiling_));
    profiling_ = nullptr;
    for (auto& row : rows_) for (auto* buffer : row.buffers) iree_hal_buffer_release(buffer);
    for (auto* command : commands_) iree_hal_command_buffer_release(command);
    loom_serve_jit_free(jit_);
    loom_serve_execution_release(execution_);
    loom_serve_workspace_release(workspace_);
    iree_hal_pool_release(storage_pool_);
    iree_hal_device_group_release(group_);
    iree_hal_device_release(device_);
    iree_async_frontier_tracker_release(frontier_tracker_);
    loom_serve_host_release(host_);
  }
  iree_status_t CreateDevice() {
    iree_hal_driver_registry_t* registry = nullptr;
    IREE_RETURN_IF_ERROR(
        iree_hal_driver_registry_allocate(host_allocator_, &registry));
    iree_status_t status = iree_hal_register_all_available_drivers(registry);
    if (iree_status_is_ok(status)) {
      status = loom_serve_test_host_create(2, host_allocator_, &host_);
    }
    if (iree_status_is_ok(status)) {
      auto params = iree_hal_device_create_params_default();
      params.proactor_pool = loom_serve_host_proactor_pool(host_);
      status = iree_hal_create_device(registry, iree_make_cstring_view(FLAG_scan_device), &params,
                                      host_allocator_, &device_);
    }
    iree_hal_driver_registry_free(registry);
    if (iree_status_is_ok(status)) {
      status = iree_async_frontier_tracker_create(
          iree_async_frontier_tracker_options_default(), host_allocator_,
          &frontier_tracker_);
    }
    if (iree_status_is_ok(status)) {
      status = iree_hal_device_group_create_from_device(
          device_, frontier_tracker_, host_allocator_, &group_);
    }
    return status;
  }

  void Prepare(bool compact = false) {
    compact_ = compact;
    bool retain_profile_metadata = false;
    IREE_ASSERT_OK(iree_hal_profiling_from_flags_requires_retained_command_buffer_metadata(
        &retain_profile_metadata));
    for (unsigned mode = 0; mode < 4; ++mode) {
      const std::string json = "{\"scan.chain_length\":" + std::to_string(FLAG_scan_chain_length) + ",\"scan.capacity\":" + std::to_string(kCapacity) + ",\"scan.threads\":" + std::to_string(FLAG_scan_threads) + ",\"scan.items\":" + std::to_string(FLAG_scan_items) +
        ",\"scan.redundant\":" + std::string(FLAG_scan_redundant ? "true" : "false") +
        ",\"scan.refresh_rounds\":" + std::to_string(FLAG_scan_refresh_rounds) +
        ",\"scan.fused_prefix\":" + (FLAG_scan_fused_prefix ? "true" : "false") +
        ",\"scan.diagnostics\":" + (FLAG_scan_diagnostics ? "true" : "false") +
        ",\"scan.packed_state\":" + (FLAG_scan_packed_state ? "true" : "false") +
        ",\"scan.lookback\":" + (FLAG_scan_lookback ? "true" : "false") +
        ",\"scan.force_fallback\":" + (FLAG_scan_force_fallback ? "true" : "false") +
        ",\"scan.reverse_schedule\":" + (FLAG_scan_reverse_schedule ? "true" : "false") + ",\"scan.inclusive\":" +
        std::string((mode & 1) ? "true" : "false") + ",\"scan.reverse\":" +
        std::string((mode & 2) ? "true" : "false") + ",\"scan.compact\":" + (compact ? "true" : "false") + ",\"scan.portable\":" +
        (std::string(FLAG_scan_device) == "vulkan" ? "true" : "false") + ",\"scan.indirect\":" + (FLAG_scan_indirect ? "true" : "false") + "}";
      const loomc_config_options_t config = {
        .json_object = loomc_make_cstring_view(json.c_str())};
      loom_serve_jit_stage_t* stage = nullptr;
      const char* entry = compact ? (FLAG_scan_chain_length > 1 ? "compact_chain" : "compact") : (FLAG_scan_chain_length > 1 ? "scan_chain" : "scan");
      IREE_ASSERT_OK(loom_serve_jit_compile(jit_, iree_make_cstring_view(entry), &config, &stage));
      const auto* program = loom_serve_jit_stage_program(stage);
      scratch_bytes_ = program->requirements.transient.required_byte_length;
      binding_count_ = program->requirements.rebindable_binding_count;
      if (FLAG_scan_describe_program && mode == 0 && !compact) {
        std::printf("program capacity=%zu scratch=%zu bindings=%zu\n",
                    kCapacity, scratch_bytes_, binding_count_);
        for (uint32_t command_index = 0;
             command_index < program->commands.count; ++command_index) {
          const auto command = loom_cmd_program_command_at(program, command_index);
          ASSERT_EQ(loom_cmd_program_command_kind_base(command.kind),
                    LOOM_CMD_PROGRAM_COMMAND_KIND_DISPATCH_DIRECT);
          const auto& launch = command.payload.dispatch_direct;
          const auto schema = loom_cmd_program_entry_schema_at(
              program, command.argument_schema_index);
          const auto arguments = loom_cmd_program_command_argument_data(program, &command);
          std::printf("dispatch index=%u kind=%u entry=%u grid=%u,%u,%u arguments=%u payload=",
                      command_index, static_cast<unsigned>(command.kind),
                      launch.entry_index, launch.workgroup_count_x,
                      launch.workgroup_count_y, launch.workgroup_count_z,
                      schema.argument_count);
          for (size_t position = 0; position < arguments.data_length; ++position) {
            std::printf("%02x", arguments.data[position]);
          }
          std::printf("\n");
        }
      }
      EXPECT_EQ(binding_count_, (compact ? 5u : 3u) + (scratch_bytes_ ? 1u : 0u));
      if (scratch_bytes_) {
        EXPECT_EQ(program->requirements.transient.binding_index, binding_count_ - 1);
        lengths_[binding_count_ - 1] = scratch_bytes_;
      }
      std::printf("mode=%u scratch=%zu commands=%u entries=%u\n", mode,
        scratch_bytes_, program->commands.count, program->requirements.entry_count);
      auto status = loom_serve_jit_stage_record(stage,
        iree_hal_queue_family(SelectQueue(device_, IREE_HAL_QUEUE_FAMILY_ROLE_FLAG_DISPATCH)),
        retain_profile_metadata ? IREE_HAL_COMMAND_BUFFER_MODE_RETAIN_PROFILE_METADATA
                                : IREE_HAL_COMMAND_BUFFER_MODE_DEFAULT,
        nullptr, nullptr, &commands_[mode]);
      loom_serve_jit_stage_free(stage);
      IREE_ASSERT_OK(status);
    }
    // Recorded commands retain their executable products after compiler release.
    loom_serve_jit_free(jit_);
    jit_ = nullptr;
    for (auto& row : rows_) {
      for (size_t i = 0; i < binding_count_; ++i) {
        IREE_ASSERT_OK(iree_hal_pool_allocate_buffer(storage_pool_,
          iree_hal_make_pool_reservation_request(lengths_[i], 16),
          iree_infinite_timeout(), &row.buffers[i]));
      }
      row.input.resize(kCapacity + 16);
      row.output.resize(OutputElements());
      row.consumed.resize(kCapacity + 16);
      row.initial.assign(OutputElements(), kCanary);
      for (size_t i = 0; i < row.input.size(); ++i) row.input[i] = uint32_t(i * 104729 + 0xfedcba98u);
    }
  }
  // Imports upload and feedback frontiers before a private replay chain.
  // Every signal on the private timeline has this one logical producer.
  iree_status_t ImportExecution() {
    if (!private_semaphore_) return iree_ok_status();
    const auto frontier = loom_serve_execution_frontier(execution_);
    iree_hal_semaphore_t* semaphores[] = {private_semaphore_,
        frontier.semaphores[0], frontier.semaphores[1]};
    uint64_t values[] = {private_value_, frontier.values[0], frontier.values[1]};
    uint64_t next_value = private_value_ + 1;
    iree_status_t result = iree_hal_queue_barrier(dispatch_queue_,
        {3, semaphores, values}, {1, &private_semaphore_, &next_value}, nullptr,
        IREE_HAL_QUEUE_BARRIER_FLAG_NONE);
    if (iree_status_is_ok(result)) private_value_ = next_value;
    return result;
  }
  iree_status_t JoinRuntime() {
    if (!private_semaphore_) return iree_ok_status();
    return loom_serve_execution_barrier(execution_,
        {1, &private_semaphore_, &private_value_});
  }
  iree_status_t Submit(iree_hal_command_buffer_t* command,
                      iree_hal_buffer_binding_table_t bindings,
                      uint64_t* out_value) {
    if (!private_semaphore_) {
      return loom_serve_execution_execute(execution_, command, bindings,
                                           out_value);
    }
    uint64_t next_value = private_value_ + 1;
    iree_status_t result = iree_hal_queue_execute(dispatch_queue_,
        {1, &private_semaphore_, &private_value_},
        {1, &private_semaphore_, &next_value}, command, bindings,
        IREE_HAL_QUEUE_EXECUTE_FLAG_NONE);
    if (iree_status_is_ok(result)) {
      private_value_ = next_value;
      *out_value = next_value;
    }
    return result;
  }
  iree_status_t Wait(uint64_t value) {
    return private_semaphore_
        ? iree_hal_semaphore_wait(private_semaphore_, value,
              iree_infinite_timeout(), IREE_ASYNC_WAIT_FLAG_NONE)
        : loom_serve_execution_wait(execution_, value);
  }
  void Enqueue(size_t index, unsigned mode) {
    auto& row = rows_[index];
    const void* sources[] = {&row.length, row.input.data(), row.initial.data()};
    std::array<iree_hal_transfer_operation_t, 3> uploads = {};
    for (size_t i = 0; i < uploads.size(); ++i) {
      uploads[i].type = IREE_HAL_TRANSFER_OPERATION_TYPE_UPLOAD;
      uploads[i].upload.source = sources[i];
      uploads[i].upload.target_buffer = row.buffers[i];
      uploads[i].upload.length = lengths_[i];
    }
    uint64_t completion = 0;
    if (compact_) {
      iree_hal_transfer_operation_t clear = {};
      clear.type = IREE_HAL_TRANSFER_OPERATION_TYPE_UPLOAD;
      clear.upload.source = row.initial.data();
      clear.upload.target_buffer = row.buffers[4];
      clear.upload.length = lengths_[4];
      IREE_ASSERT_OK(loom_serve_execution_transfer(execution_, 1, &clear, &completion));
    }
    IREE_ASSERT_OK(loom_serve_execution_transfer(execution_, uploads.size(), uploads.data(), &completion));
    std::array<iree_hal_buffer_binding_t, 6> bindings = {};
    for (size_t i = 0; i < binding_count_; ++i) bindings[i] = {row.buffers[i], 0, lengths_[i]};
    IREE_ASSERT_OK(ImportExecution());
    // Repeated submissions share scratch, with only queue dependencies between them.
    for (unsigned repeat = 0; repeat < 3; ++repeat) {
      IREE_ASSERT_OK(Submit(commands_[mode],
        {binding_count_, bindings.data()}, &completion));
    }
    IREE_ASSERT_OK(JoinRuntime());
    ASSERT_NO_FATAL_FAILURE(Download(index));
  }
  void Download(size_t index) {
    auto& row = rows_[index];
    iree_hal_transfer_operation_t download = {};
    download.type = IREE_HAL_TRANSFER_OPERATION_TYPE_DOWNLOAD;
    download.download.source_buffer = row.buffers[2];
    download.download.target = row.output.data();
    download.download.length = lengths_[2];
    IREE_ASSERT_OK(loom_serve_execution_feedback(execution_, 1, &download, &row.completion));
    if (compact_) {
      download.download.source_buffer = row.buffers[4];
      download.download.target = row.consumed.data();
      IREE_ASSERT_OK(loom_serve_execution_feedback(execution_, 1, &download, &row.completion));
      download.download.source_buffer = row.buffers[3];
      download.download.target = row.selected.data();
      download.download.length = lengths_[3];
      IREE_ASSERT_OK(loom_serve_execution_feedback(execution_, 1, &download, &row.completion));
    }
  }
  void VerifyCompact(size_t index, unsigned mode) {
    auto& row = rows_[index];
    IREE_ASSERT_OK(loom_serve_execution_feedback_wait(execution_, row.completion));
    std::vector<uint32_t> expected;
    for (size_t i = 0; i < row.length; ++i) {
      size_t position = (mode & 2) ? row.length - 1 - i : i;
      if (row.input[position] & 1) expected.push_back(row.input[position]);
    }
    ASSERT_EQ(row.selected[3], expected.size());
    for (size_t i = 0; i < expected.size(); ++i) {
      ASSERT_EQ(row.output[i], expected[i]) << "mode=" << mode << " length=" << row.length << " position=" << i;
      ASSERT_EQ(row.consumed[i], uint32_t(expected[i] * 3 + 7));
    }
    for (size_t i = expected.size(); i < row.output.size(); ++i) {
      ASSERT_EQ(row.output[i], kCanary);
      ASSERT_EQ(row.consumed[i], kCanary);
    }
  }
  void Verify(size_t index, unsigned mode) {
    auto& row = rows_[index];
    IREE_ASSERT_OK(loom_serve_execution_feedback_wait(execution_, row.completion));
    uint32_t accumulator = 0;
    for (size_t i = 0; i < row.length; ++i) {
      size_t position = (mode & 2) ? row.length - 1 - i : i;
      uint32_t expected = accumulator;
      accumulator += row.input[position];
      if (mode & 1) expected = accumulator;
      ASSERT_EQ(row.output[position], expected) << "mode=" << mode << " length=" << row.length << " position=" << position;
    }
    for (size_t i = row.length; i < kCapacity + 16; ++i) ASSERT_EQ(row.output[i], kCanary) << "guard=" << i;
  }
  const size_t kCapacity = FLAG_scan_count;
  size_t OutputElements() const {
    const size_t tile = size_t(FLAG_scan_threads) * FLAG_scan_items;
    return kCapacity + 16 + (FLAG_scan_diagnostics ? 4 * ((kCapacity + tile - 1) / tile) : 0);
  }
  static constexpr uint32_t kCanary = 0x735ab192;
  size_t binding_count_ = 0;
  size_t scratch_bytes_ = 0;
  bool compact_ = false;
  std::array<size_t, 6> lengths_ = {4, (kCapacity + 16) * 4, OutputElements() * 4, 16, (kCapacity + 16) * 4, 0};
  struct Row {
    std::array<iree_hal_buffer_t*, 6> buffers = {};
    uint32_t length = 0;
    std::vector<uint32_t> input, output, initial, consumed;
    std::array<uint32_t, 4> selected = {};
    uint64_t completion = 0;
  };
  std::array<Row, 2> rows_;
  iree_allocator_t host_allocator_ = iree_allocator_system();
  loom_serve_compilation_report_t compilation_ = {};
  loom_serve_host_t* host_ = nullptr;
  iree_async_frontier_tracker_t* frontier_tracker_ = nullptr;
  iree_hal_device_t* device_ = nullptr;
  iree_hal_device_group_t* group_ = nullptr;
  iree_hal_pool_t* storage_pool_ = nullptr;
  loom_serve_workspace_t* workspace_ = nullptr;
  loom_serve_execution_t* execution_ = nullptr;
  // Borrowed dispatch queue retained by the device and execution domain.
  iree_hal_queue_t* dispatch_queue_ = nullptr;
  // Owned application-private completion timeline for direct HAL variants.
  iree_hal_semaphore_t* private_semaphore_ = nullptr;
  // Last successfully accepted signal on the private completion timeline.
  uint64_t private_value_ = 0;
  // Owned profiling session, ended after completion even if a diagnostic fails.
  iree_hal_profiling_from_flags_t* profiling_ = nullptr;
  std::string directory_, filename_;
  loom_serve_jit_t* jit_ = nullptr;
  std::array<iree_hal_command_buffer_t*, 4> commands_ = {};
};
TEST_F(ScanTest, DeviceWidePrefixes) {
  ASSERT_NO_FATAL_FAILURE(Prepare());
  std::vector<uint32_t> lengths = {0, 1, 31, 32, 127, 128, 511, 512, 513, 65535, 65536, 65537, 262143, 262144, 262145, 1048593, 2097152};
  std::erase_if(lengths, [&](uint32_t length) { return length > kCapacity; });
  lengths.push_back(kCapacity);
  if (lengths.size() % 2) lengths.push_back(kCapacity);
  for (unsigned mode = 0; mode < 4; ++mode) {
    for (size_t i = 0; i < std::size(lengths); i += 2) {
      rows_[0].length = lengths[i];
      rows_[1].length = lengths[i + 1];
      ASSERT_NO_FATAL_FAILURE(Enqueue(0, mode));
      ASSERT_NO_FATAL_FAILURE(Enqueue(1, mode));
      ASSERT_NO_FATAL_FAILURE(Verify(0, mode));
      ASSERT_NO_FATAL_FAILURE(Verify(1, mode));
    }
  }
}
TEST_F(ScanTest, StableCompactIndirectConsumer) {
  ASSERT_NO_FATAL_FAILURE(Prepare(true));
  std::vector<uint32_t> lengths = {0, 1, 127, 511, 512, 513, 65535, 65537, 262143, 262144, 262145, 1048593, 2097152};
  std::erase_if(lengths, [&](uint32_t length) { return length > kCapacity; });
  lengths.push_back(kCapacity);
  if (lengths.size() % 2) lengths.push_back(kCapacity);
  for (unsigned mode = 0; mode < 4; ++mode) {
    for (unsigned distribution = 0; distribution < 4; ++distribution) {
      for (auto& row : rows_) for (size_t i = 0; i < row.input.size(); ++i) {
        bool selected = distribution == 0 ? false : distribution == 1 ? true : distribution == 2 ? (i % 17 == 0) : ((i / 71) % 5 == 0);
        row.input[i] = (uint32_t(i * 104729) & ~1u) | selected;
      }
      for (size_t i = 0; i < std::size(lengths); i += 2) {
        rows_[0].length = lengths[i]; rows_[1].length = lengths[i + 1];
        ASSERT_NO_FATAL_FAILURE(Enqueue(0, mode));
        ASSERT_NO_FATAL_FAILURE(Enqueue(1, mode));
        ASSERT_NO_FATAL_FAILURE(VerifyCompact(0, mode));
        ASSERT_NO_FATAL_FAILURE(VerifyCompact(1, mode));
      }
    }
  }
}
TEST_F(ScanTest, CapacityBoundaries) {
  ASSERT_NO_FATAL_FAILURE(Prepare());
  for (unsigned mode = 0; mode < 4; ++mode) {
    rows_[0].length = kCapacity - 1;
    rows_[1].length = kCapacity;
    ASSERT_NO_FATAL_FAILURE(Enqueue(0, mode));
    ASSERT_NO_FATAL_FAILURE(Enqueue(1, mode));
    ASSERT_NO_FATAL_FAILURE(Verify(0, mode));
    ASSERT_NO_FATAL_FAILURE(Verify(1, mode));
  }
}
TEST_F(ScanTest, DISABLED_CarryDiagnostics) {
  ASSERT_TRUE(FLAG_scan_diagnostics);
  ASSERT_NO_FATAL_FAILURE(Prepare());
  auto& row = rows_[0];
  row.length = kCapacity;
  for (size_t i = 0; i < row.input.size(); ++i) row.input[i] = (i * 104729 + 12345) % 7 == 0;
  const size_t tile = size_t(FLAG_scan_threads) * FLAG_scan_items;
  const size_t groups = (kCapacity + tile - 1) / tile;
  for (unsigned sample = 0; sample < 9; ++sample) {
    ASSERT_NO_FATAL_FAILURE(Enqueue(0, 0));
    ASSERT_NO_FATAL_FAILURE(Verify(0, 0));
    std::printf("{\"implementation\":\"loom-carry-diagnostics\",\"count\":%zu,\"threads\":%d,\"items\":%d,\"sample\":%u,\"tiles\":[", kCapacity, FLAG_scan_threads, FLAG_scan_items, sample);
    for (size_t group = 0; group < groups; ++group) {
      const uint32_t* counters = row.output.data() + kCapacity + 16 + group * 4;
      if (FLAG_scan_force_fallback) {
        ASSERT_EQ(counters[0], (group + 31) / 32);
        ASSERT_EQ(counters[1], group);
        ASSERT_EQ(counters[2], group);
        ASSERT_EQ(counters[3], group);
      }
      std::printf("%s[%u,%u,%u,%u]", group ? "," : "", counters[0], counters[1], counters[2], counters[3]);
    }
    std::printf("]}\n");
  }
}
TEST_F(ScanTest, DISABLED_ProfileScan) {
  ASSERT_FALSE(FLAG_scan_diagnostics);
  ASSERT_NO_FATAL_FAILURE(Prepare());
  auto& row = rows_[0];
  row.length = kCapacity;
  for (size_t i = 0; i < row.input.size(); ++i) row.input[i] = (i * 104729 + 12345) % 7 == 0;
  ASSERT_NO_FATAL_FAILURE(Enqueue(0, 0));
  ASSERT_NO_FATAL_FAILURE(Verify(0, 0));
  std::array<iree_hal_buffer_binding_t, 6> bindings = {};
  for (size_t i = 0; i < binding_count_; ++i) bindings[i] = {row.buffers[i], 0, lengths_[i]};
  uint64_t completion = 0;
  for (unsigned i = 0; i < 10; ++i) {
    IREE_ASSERT_OK(Submit(commands_[0],
      {binding_count_, bindings.data()}, &completion));
  }
  IREE_ASSERT_OK(Wait(completion));
  IREE_ASSERT_OK(iree_hal_begin_profiling_from_flags(device_, host_allocator_, &profiling_));
  ASSERT_NE(profiling_, nullptr);
  for (unsigned i = 0; i < 20; ++i) {
    IREE_ASSERT_OK(Submit(commands_[0],
      {binding_count_, bindings.data()}, &completion));
  }
  IREE_ASSERT_OK(Wait(completion));
  auto* completed_profile = profiling_;
  profiling_ = nullptr;
  IREE_ASSERT_OK(iree_hal_end_profiling_from_flags(completed_profile));
  ASSERT_NO_FATAL_FAILURE(Verify(0, 0));
}

TEST_F(ScanTest, DISABLED_BenchmarkScan) {
  ASSERT_FALSE(FLAG_scan_diagnostics);
  ASSERT_NO_FATAL_FAILURE(Prepare());
  auto& row = rows_[0];
  row.length = kCapacity;
  for (size_t i = 0; i < row.input.size(); ++i) row.input[i] = (i * 104729 + 12345) % 7 == 0;
  ASSERT_NO_FATAL_FAILURE(Enqueue(0, 0));
  ASSERT_NO_FATAL_FAILURE(Verify(0, 0));
  std::array<iree_hal_buffer_binding_t, 6> bindings = {};
  for (size_t i = 0; i < binding_count_; ++i) bindings[i] = {row.buffers[i], 0, lengths_[i]};
  uint64_t completion = 0;
  for (unsigned i = 0; i < 10; ++i) {
    IREE_ASSERT_OK(Submit(commands_[0],
      {binding_count_, bindings.data()}, &completion));
  }
  IREE_ASSERT_OK(Wait(completion));
  ASSERT_GT(FLAG_scan_iterations, 0);
  ASSERT_GT(FLAG_scan_chain_length, 1);
  std::vector<double> samples;
  const double operations =
      double(FLAG_scan_iterations) * FLAG_scan_chain_length;
  for (unsigned repetition = 0; repetition < 9; ++repetition) {
    const auto start = std::chrono::steady_clock::now();
    for (int i = 0; i < FLAG_scan_iterations; ++i) {
      IREE_ASSERT_OK(Submit(commands_[0],
        {binding_count_, bindings.data()}, &completion));
    }
    IREE_ASSERT_OK(Wait(completion));
    const double elapsed = std::chrono::duration<double, std::nano>(
        std::chrono::steady_clock::now() - start).count();
    samples.push_back(elapsed / operations);
    std::printf("{\"implementation\":\"loom\",\"count\":%zu,\"threads\":%d,\"items\":%d,\"batch_scans\":%d,\"submissions\":%d,\"sample\":%u,\"elapsed_ns\":%.3f,\"per_scan_ns\":%.3f}\n",
        kCapacity, FLAG_scan_threads, FLAG_scan_items, FLAG_scan_chain_length,
        FLAG_scan_iterations, repetition, elapsed, samples.back());
  }
  std::sort(samples.begin(), samples.end());
  std::printf("{\"implementation\":\"loom\",\"count\":%zu,\"threads\":%d,\"items\":%d,\"batch_scans\":%d,\"submissions\":%d,\"scratch_bytes\":%zu,\"median_per_scan_ns\":%.3f}\n",
      kCapacity, FLAG_scan_threads, FLAG_scan_items, FLAG_scan_chain_length,
      FLAG_scan_iterations, scratch_bytes_, samples[4]);
  IREE_ASSERT_OK(JoinRuntime());
  ASSERT_NO_FATAL_FAILURE(Download(0));
  ASSERT_NO_FATAL_FAILURE(Verify(0, 0));
}
}  // namespace
