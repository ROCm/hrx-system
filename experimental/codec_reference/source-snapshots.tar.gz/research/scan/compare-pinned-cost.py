"""Fixed-core, balanced-order process cost for the exact scan compiler inputs."""
from pathlib import Path
import hashlib
import json
import os
import resource
import subprocess
import time
os.chdir(Path(__file__).resolve().parent)
assert os.environ['BENCHMARK_LOCK_LEASE_ID']
cpu = min(os.sched_getaffinity(0))
os.sched_setaffinity(0, {cpu})
cases = [('32',32,'scan.loombc'),('512',512,'scan.loombc'),('65537',65537,'storage-disjoint.loombc'),('2097152',2097152,'scan.loombc'),('16777216',16777216,'scan.loombc'),('smem-512',512,'short-length.loombc')]
rows=[]
for label,count,source in cases:
    entry='scan_single' if count <=512 else 'scan_lookback'
    for repeat in range(-4,40):
        for variant in (['baseline','candidate'] if repeat%2==0 else ['candidate','baseline']):
            before=resource.getrusage(resource.RUSAGE_CHILDREN)
            start=time.monotonic_ns()
            subprocess.run(['./compile-'+variant,source,'--target=amdgpu:gfx1151','--root='+entry,'--config-file=config-'+str(count)+'.json','--output=pinned-cost-output.hsaco'],check=True)
            elapsed=time.monotonic_ns()-start
            after=resource.getrusage(resource.RUSAGE_CHILDREN)
            assert hashlib.sha256(Path('pinned-cost-output.hsaco').read_bytes()).digest()==hashlib.sha256(Path(f'{variant}-{label}-{entry}.hsaco').read_bytes()).digest()
            if repeat>=0:
                rows.append({'label':label,'variant':variant,'repeat':repeat,'wall_ns':elapsed,'cpu_ns':round(((after.ru_utime+after.ru_stime)-(before.ru_utime+before.ru_stime))*1e9),'minor_faults':after.ru_minflt-before.ru_minflt,'voluntary_switches':after.ru_nvcsw-before.ru_nvcsw,'involuntary_switches':after.ru_nivcsw-before.ru_nivcsw})
    print('completed',label,flush=True)
Path('pinned-compile-cost.json').write_text(json.dumps({'lease':os.environ['BENCHMARK_LOCK_LEASE_ID'],'cpu':cpu,'governor':Path(f'/sys/devices/system/cpu/cpu{cpu}/cpufreq/scaling_governor').read_text().strip(),'rows':rows},indent=2)+'\n')
