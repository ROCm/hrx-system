#ifndef SCAN_ORDERED_ALGEBRA_H_
#define SCAN_ORDERED_ALGEBRA_H_
#include <loomcxx/kernel.h>

struct Affine {
  // Multiplicative coefficient of the map modulo 2^32.
  unsigned scale;
  // Additive coefficient of the map modulo 2^32.
  unsigned offset;
};

LOOM_DEVICE LOOM_TEMPLATE_DECL("scan.affine.compose")
Affine compose(Affine left, Affine right);
#endif
