from pathlib import Path
import hashlib,json,re,subprocess
sdk=Path('/home/ben/tools/rocm-sdk-10.0.0-gfx1151'); llvm=sdk/'lib/python3.14/site-packages/_rocm_sdk_devel/llvm/bin'
base=json.loads(Path('address-config.json').read_text());rows=[]
cases=[(65537,t,i,'candidate') for t,i in [(64,16),(128,8),(256,4),(32,16),(64,8),(128,4)]]
for count,threads,items,version in cases:
 config=json.loads(json.dumps(base));config['scan'].update(capacity=count,threads=threads,items=items,packed_state=True,chain_length=32,refresh_rounds=16)
 stem=f'redundant-{threads}x{items}';cp=Path(stem+'-config.json');cp.write_text(json.dumps(config,indent=2)+'\n')
 entries=['scan_redundant']
 for entry in entries:
  name=stem+'-'+entry;artifact=Path(name+'.hsaco');report=Path(name+'-report.json')
  module='scan.loombc' if version=='candidate' else 'control.loombc'
  subprocess.run(['./compile',module,'--target=amdgpu:gfx1151','--root='+entry,'--config-file='+str(cp),'--output='+str(artifact),'--compile-report=details','--compile-report-output='+str(report)],check=True)
  asm=subprocess.check_output([llvm/'llvm-objdump','-d',artifact],text=True);metadata=subprocess.check_output([llvm/'llvm-readelf','-n','-S',artifact],text=True)
  Path(name+'.s').write_text(asm);Path(name+'.metadata.txt').write_text(metadata)
  row={'version':version,'count':count,'threads_config':threads,'threads':threads or (((count+items-1)//items+31)//32*32),'items':items,'entry':entry,'artifact':str(artifact),'profile':stem+'.ireeprof','sha256':hashlib.sha256(artifact.read_bytes()).hexdigest(),'instructions':len(re.findall(r'//\s*[0-9a-fA-F]+:',asm)),'text_bytes':int(re.search(r'\]\s+\.text\s+PROGBITS\s+\S+\s+\S+\s+([0-9a-fA-F]+)',metadata)[1],16)}
  for f in ['group_segment_fixed_size','private_segment_fixed_size','sgpr_count','vgpr_count','wavefront_size']:row[f]=int(re.search(r'\.'+f+r':\s+(\d+)',metadata)[1])
  rows.append(row);print(json.dumps(row),flush=True)
Path('redundant-native.json').write_text(json.dumps(rows,indent=2)+'\n')
