"""Final primary matrix using the exact already-qualified native images."""
from pathlib import Path
import collections
import csv
import hashlib
import json
import os
import re
import subprocess
import sys
import time

llvm = Path('/opt/rocm/llvm/bin')
cases = [
    (32, 32, 1, 'dpp-32', 'scan.loombc'),
    (512, 32, 16, 'dpp-512', 'scan.loombc'),
    (65537, 256, 4, 'retune-256x4', 'storage-disjoint.loombc'),
    (2097152, 128, 8, 'dpp-2097152', 'scan.loombc'),
    (16777216, 64, 8, 'dpp-16777216', 'scan.loombc'),
]

def native_arguments(case, phase):
    count, threads, items, prefix, source = case
    return ['./geometry', str(count), str(16 if count == 16777216 else 128),
            str(threads), str(items), str(threads), str(items),
            prefix, prefix, phase]

def serve(case):
    count, threads, items, prefix, source = case
    config = json.loads(Path(prefix + '-config.json').read_text())['scan']
    arguments = ['./loom-dpp', '--scan_source=' + str(Path(source).resolve()),
                 '--amdgpu_command_buffer_mode=aql', '--scan_count=' + str(count),
                 '--scan_iterations=' + str(16 if count == 16777216 else 128),
                 '--gtest_also_run_disabled_tests',
                 '--gtest_filter=ScanTest.DISABLED_BenchmarkScan']
    for key in ['threads', 'items', 'packed_state', 'chain_length',
                'refresh_rounds', 'ballot', 'local_barriers', 'prefix_form',
                'lookback', 'indirect', 'fused_prefix']:
        value = config[key]
        arguments.append('--scan_' + key + '=' +
                         (str(value).lower() if isinstance(value, bool) else str(value)))
    subprocess.run(arguments, check=True)

def check_oracle(binary):
    subprocess.run([llvm / 'llvm-objdump', '--offloading', binary], check=True)
    images = list(Path('.').glob(binary + '.*hipv4*gfx1151'))
    assert len(images) == 1
    symbols = {}
    for line in subprocess.check_output(
            [llvm / 'llvm-nm', '--defined-only', images[0]], text=True).splitlines():
        parts = line.split()
        if len(parts) == 3 and parts[1] in ['T', 't']:
            name = subprocess.check_output(['c++filt', parts[2]], text=True).strip()
            symbols[name] = parts[2]
    oracle_rows = json.loads(Path('oracle-identity.json').read_text())['sizes']
    def words(text):
        return re.findall(r'//\s*[0-9a-fA-F]+:\s*([0-9A-Fa-f ]+)', text)
    for case in cases:
        count = case[0]
        oracle = next(row for row in oracle_rows if row['count'] == count)
        for index, kernel in enumerate(oracle['kernels']):
            assembly = subprocess.check_output(
                [llvm / 'llvm-objdump', '-d',
                 '--disassemble-symbols=' + symbols[kernel['name']], images[0]], text=True)
            assert words(assembly) == words(Path(f'oracle-{count}-{index}.s').read_text())
    return oracle_rows

phase = sys.argv[1]
assert phase in ['native', 'serve']
print('lease=' + os.environ['BENCHMARK_LOCK_LEASE_ID'], flush=True)
idle_start = time.monotonic()
previous = None
while True:
    busy = Path('/sys/class/drm/card0/device/gpu_busy_percent').read_text().strip()
    if busy != previous:
        print('preflight_gpu_busy=' + busy, flush=True)
        previous = busy
    if busy == '0':
        break
    time.sleep(0.05)
print('preflight_idle_wait_seconds=' + str(time.monotonic() - idle_start), flush=True)
print('cpu_governor=' + Path('/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor').read_text().strip(), flush=True)
print('gpu_power_level=' + Path('/sys/class/drm/card0/device/power_dpm_force_performance_level').read_text().strip(), flush=True)

native_rows = json.loads(Path('dpp-native.json').read_text()) + json.loads(Path('retune-native.json').read_text())
identities = []
for count, threads, items, prefix, source in cases:
    entries = ['scan_single'] if count <= threads * items else ['reset_states', 'scan_lookback']
    for entry in entries:
        path = Path(prefix + '-' + entry + '.hsaco')
        row = next(row for row in native_rows if row['artifact'] == str(path))
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
        identities.append(row)
Path('primary-native-identities.json').write_text(json.dumps(identities, indent=2) + '\n')

oracle_rows = check_oracle('geometry' if phase == 'native' else 'rocprim')
if phase == 'native':
    traces_proof = []
    for case in cases:
        count, threads, items, prefix, source = case
        directory = 'primary-trace-' + str(count)
        subprocess.run(['/opt/rocm/bin/rocprofv3', '--kernel-trace', '--output-format', 'csv',
                        '--output-directory', directory, '--output-file', 'geometry', '--',
                        *native_arguments(case, 'trace')], check=True)
        traces = list(Path(directory).rglob('*kernel_trace.csv'))
        assert len(traces) == 1
        Path(directory + '.csv').write_bytes(traces[0].read_bytes())
        events = list(csv.DictReader(traces[0].open()))
        frequencies = collections.Counter(event['Kernel_Name'] for event in events)
        oracle = next(row for row in oracle_rows if row['count'] == count)
        for kernel in oracle['kernels']:
            name = kernel['name']
            assert frequencies[name] == 32
            dimensions = sorted(set((event['Grid_Size_X'], event['Workgroup_Size_X'])
                                    for event in events if event['Kernel_Name'] == name))
            assert [list(value) for value in dimensions] == kernel['grid_block_x']
        groups = (count + threads * items - 1) // (threads * items)
        entries = ['scan_single'] if groups == 1 else ['reset_states', 'scan_lookback']
        for name in entries:
            actual = collections.Counter((int(event['Grid_Size_X']), int(event['Workgroup_Size_X']))
                                         for event in events if event['Kernel_Name'] == name)
            grid = 1 if name == 'scan_single' else ((groups + threads - 1) // threads
                                                   if name == 'reset_states' else groups)
            assert actual == collections.Counter({(grid * threads, threads): 64})
        known = set(entries) | {'__amd_rocclr_copyBuffer'} | {kernel['name'] for kernel in oracle['kernels']}
        assert not (set(frequencies) - known)
        traces_proof.append({'count': count, 'passed': True})
    Path('primary-oracle-identity.json').write_text(json.dumps(
        {'binary_sha256': hashlib.sha256(Path('geometry').read_bytes()).hexdigest(),
         'traces': traces_proof}, indent=2) + '\n')
    subprocess.run(['vmstat', '1', '3'], check=True)
    for case in cases:
        for allocation in range(3 if case[0] == 2097152 else 1):
            print(f'case={case[0]}-set{allocation}', flush=True)
            subprocess.run(native_arguments(case, 'measure'), check=True)
else:
    subprocess.run(['vmstat', '1', '3'], check=True)
    for window, implementation in enumerate(['rocprim', 'loom', 'rocprim', 'loom', 'rocprim']):
        print('window_index=' + str(window), flush=True)
        for case in cases:
            count = case[0]
            print('case=' + str(count), flush=True)
            if implementation == 'rocprim':
                subprocess.run(['./rocprim', 'u32', str(count),
                                str(16 if count == 16777216 else 128), '32'], check=True)
            else:
                serve(case)
subprocess.run(['vmstat', '1', '3'], check=True)
