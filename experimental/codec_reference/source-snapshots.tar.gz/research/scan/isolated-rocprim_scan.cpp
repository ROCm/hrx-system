// Standalone development comparator, never linked into Loom.
#include <hip/hip_runtime.h>
#include <rocprim/device/device_scan.hpp>
#include <rocprim/rocprim_version.hpp>
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
#include <type_traits>

static void check(hipError_t error, const char* expression) {
  if (error != hipSuccess) {
    std::fprintf(stderr, "%s: %s\n", expression, hipGetErrorString(error));
    std::exit(1);
  }
}
#define HIP(expression) check((expression), #expression)

template <class T>
int benchmark(size_t count, unsigned iterations) {
  hipDeviceProp_t device;
  HIP(hipGetDeviceProperties(&device, 0));
  hipStream_t stream;
  HIP(hipStreamCreate(&stream));
  T* input;
  T* output;
  HIP(hipMalloc(&input, std::max<size_t>(count, 1) * sizeof(T)));
  HIP(hipMalloc(&output, std::max<size_t>(count, 1) * sizeof(T)));
  std::vector<T> host_input(count);
  std::vector<T> host_output(count);
  for (size_t i = 0; i < count; ++i) host_input[i] = T((i * 104729 + 12345) % 7 == 0);
  if (count) HIP(hipMemcpyAsync(input, host_input.data(), count * sizeof(T), hipMemcpyHostToDevice, stream));
  size_t scratch_bytes = 0;
  HIP(rocprim::exclusive_scan(nullptr, scratch_bytes, input, output, T(0), count, rocprim::plus<T>(), stream));
  void* scratch;
  HIP(hipMalloc(&scratch, std::max<size_t>(scratch_bytes, 1)));
  HIP(rocprim::exclusive_scan(scratch, scratch_bytes, input, output, T(0), count, rocprim::plus<T>(), stream));
  if (count) HIP(hipMemcpyAsync(host_output.data(), output, count * sizeof(T), hipMemcpyDeviceToHost, stream));
  HIP(hipStreamSynchronize(stream));
  T prefix = 0;
  for (size_t i = 0; i < count; ++i) {
    if (host_output[i] != prefix) {
      std::fprintf(stderr, "incorrect prefix at %zu\n", i);
      return 1;
    }
    prefix += host_input[i];
  }
  hipGraph_t graph;
  hipGraphExec_t executable;
  HIP(hipStreamBeginCapture(stream, hipStreamCaptureModeThreadLocal));
  HIP(rocprim::exclusive_scan(scratch, scratch_bytes, input, output, T(0), count, rocprim::plus<T>(), stream));
  HIP(hipStreamEndCapture(stream, &graph));
  HIP(hipGraphInstantiate(&executable, graph, nullptr, nullptr, 0));
  for (unsigned i = 0; i < 10; ++i) HIP(hipGraphLaunch(executable, stream));
  HIP(hipStreamSynchronize(stream));
  std::vector<double> queued, latency;
  for (unsigned repetition = 0; repetition < 9; ++repetition) {
    const auto start = std::chrono::steady_clock::now();
    for (unsigned i = 0; i < iterations; ++i) HIP(hipGraphLaunch(executable, stream));
    HIP(hipStreamSynchronize(stream));
    queued.push_back(std::chrono::duration<double, std::nano>(std::chrono::steady_clock::now() - start).count() / iterations);
    const auto one_start = std::chrono::steady_clock::now();
    for (unsigned i = 0; i < 31; ++i) {
      HIP(hipGraphLaunch(executable, stream));
      HIP(hipStreamSynchronize(stream));
    }
    latency.push_back(std::chrono::duration<double, std::nano>(std::chrono::steady_clock::now() - one_start).count() / 31);
  }
  for (unsigned sample = 0; sample < queued.size(); ++sample) {
    std::printf("{\"implementation\":\"rocprim\",\"type\":\"%s\",\"count\":%zu,\"sample\":%u,\"queued_e2e_ns\":%.3f,\"single_e2e_ns\":%.3f}\n", std::is_floating_point_v<T> ? "f32" : sizeof(T) == 4 ? "u32" : "u64", count, sample, queued[sample], latency[sample]);
  }
  std::sort(queued.begin(), queued.end());
  std::sort(latency.begin(), latency.end());
  std::printf("{\"implementation\":\"rocprim\",\"version\":%u,\"arch\":\"%s\",\"element_bytes\":%zu,\"count\":%zu,\"scratch_bytes\":%zu,\"iterations\":%u,\"queued_e2e_ns\":%.3f,\"single_e2e_ns\":%.3f}\n", ROCPRIM_VERSION, device.gcnArchName, sizeof(T), count, scratch_bytes, iterations, queued[4], latency[4]);
  HIP(hipGraphExecDestroy(executable));
  HIP(hipGraphDestroy(graph));
  HIP(hipFree(scratch));
  HIP(hipFree(output));
  HIP(hipFree(input));
  HIP(hipStreamDestroy(stream));
  return 0;
}
int main(int argc, char** argv) {
  if (argc != 4) {
    std::fprintf(stderr, "usage: rocprim_scan {u32|u64|f32} count iterations\n");
    return 1;
  }
  size_t count = std::strtoull(argv[2], nullptr, 10);
  unsigned iterations = std::strtoul(argv[3], nullptr, 10);
  if (!iterations || count > (1ull << 28)) return 1;
  if (std::string(argv[1]) == "u32") return benchmark<uint32_t>(count, iterations);
  if (std::string(argv[1]) == "u64") return benchmark<uint64_t>(count, iterations);
  if (std::string(argv[1]) == "f32") return benchmark<float>(count, iterations);
  return 1;
}
