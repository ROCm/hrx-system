"""Locked CLI compilation cost, including process startup, import, and emission."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

for label in ('baseline', 'candidate'):
    command=[f'./compile-{label}', 'natural_scan.loombc', '--target=amdgpu:gfx1151', '--root=scan_lookback', '--config-file=dpp-config.json', f'--output=dpp-{label}.hsaco']
    subprocess.run(command,check=True,stdout=subprocess.DEVNULL)
for sample, label in enumerate(('baseline','candidate','candidate','baseline') * 5):
    command=[f'./compile-{label}', 'natural_scan.loombc', '--target=amdgpu:gfx1151', '--root=scan_lookback', '--config-file=dpp-config.json', f'--output=dpp-{label}.hsaco']
    start=time.monotonic_ns()
    subprocess.run(command,check=True,stdout=subprocess.DEVNULL)
    elapsed=time.monotonic_ns()-start
    print(json.dumps({'implementation':'loom-compile','variant':label,'sample':sample,'process_e2e_ns':elapsed}),flush=True)
for label in ('baseline','candidate'):
    artifact=Path(f'dpp-{label}.hsaco')
    print(json.dumps({'artifact':str(artifact),'sha256':hashlib.sha256(artifact.read_bytes()).hexdigest(),'bytes':artifact.stat().st_size}),flush=True)
