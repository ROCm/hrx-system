"""Rebased DPP qualification on the owned Gorgon staging directory."""
from pathlib import Path
import collections
import csv
import hashlib
import json
import os
import re
import subprocess
import sys
import time

os.chdir(Path(__file__).resolve().parent)
llvm = Path('/opt/rocm/llvm/bin')
cases = [(32, 32, 1, 'scan.loombc'), (512, 32, 16, 'scan.loombc'),
         (65537, 256, 4, 'storage-disjoint.loombc'),
         (2097152, 128, 8, 'scan.loombc'), (16777216, 64, 8, 'scan.loombc')]

def run(arguments):
    subprocess.run(arguments, check=True)

def capture(arguments):
    return subprocess.check_output(arguments, text=True)

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write_json(name, value):
    Path(name).write_text(json.dumps(value, indent=2) + '\n')

def arguments(case, phase):
    count, threads, items, source = case
    return ['./geometry', str(count), str(16 if count == 16777216 else 128),
            str(threads), str(items), str(threads), str(items),
            'baseline-' + str(count), 'candidate-' + str(count), phase]

def words(assembly):
    return re.findall(r'//\s*[0-9a-fA-F]+:\s*([0-9a-fA-F ]+)', assembly)

phase = sys.argv[1]
if phase == 'build':
    run(['hipcc', '-std=c++20', '-O3', '--offload-arch=gfx1151',
         'geometry-native.cpp', '-o', 'geometry'])
    Path('hip-version.txt').write_text(capture(['hipcc', '--version']))
    run([llvm / 'llvm-objdump', '--offloading', 'geometry'])
    images = list(Path('.').glob('geometry.*hipv4*gfx1151'))
    assert len(images) == 1, images
    symbols = {}
    for line in capture([llvm / 'llvm-nm', '--defined-only', images[0]]).splitlines():
        parts = line.split()
        if len(parts) == 3 and parts[1] in ['T', 't']:
            symbols[capture(['c++filt', parts[2]]).strip()] = parts[2]
    oracle = json.loads(Path('oracle-identity.json').read_text())
    identity = []
    for case in oracle['sizes']:
        for index, kernel in enumerate(case['kernels']):
            assembly = capture([llvm / 'llvm-objdump', '-d',
                                '--disassemble-symbols=' + symbols[kernel['name']], images[0]])
            old = Path(f"prior-oracle-{case['count']}-{index}.s").read_text()
            assert words(assembly) == words(old), (case['count'], index)
            name = f"oracle-{case['count']}-{index}.s"
            Path(name).write_text(assembly)
            identity.append({'count': case['count'], 'index': index,
                             'instructions': len(words(assembly)),
                             'unchanged_instruction_words': True,
                             'assembly_sha256': digest(name)})
    write_json('oracle-code-identity.json', {'binary_sha256': digest('geometry'), 'rows': identity})
elif phase == 'inspect':
    rows = []
    for count, threads, items, source in cases:
        for variant in ['baseline', 'candidate']:
            for entry in (['scan_single'] if count <= threads * items else ['reset_states', 'scan_lookback']):
                name = f'{variant}-{count}-{entry}'
                artifact = name + '.hsaco'
                run(['./compile-' + variant, source, '--target=amdgpu:gfx1151',
                     '--root=' + entry, '--config-file=config-' + str(count) + '.json',
                     '--output=' + artifact, '--compile-report=summary',
                     '--compile-report-output=' + name + '-report.json'])
                assembly = capture([llvm / 'llvm-objdump', '-d', artifact])
                metadata = capture([llvm / 'llvm-readelf', '-n', '-S', artifact])
                Path(name + '.s').write_text(assembly)
                Path(name + '.metadata.txt').write_text(metadata)
                row = {'variant': variant, 'count': count, 'threads': threads,
                       'items': items, 'entry': entry, 'artifact': artifact,
                       'sha256': digest(artifact), 'instructions': len(words(assembly)),
                       'dpp_rows': len(re.findall(r'row_sh[lr]:', assembly)),
                       'bpermutes': assembly.count('ds_bpermute_b32'),
                       'text_bytes': int(re.search(r'\]\s+\.text\s+PROGBITS\s+\S+\s+\S+\s+([0-9a-fA-F]+)', metadata)[1], 16)}
                for field in ['group_segment_fixed_size', 'private_segment_fixed_size',
                              'sgpr_count', 'vgpr_count', 'wavefront_size']:
                    row[field] = int(re.search(r'\.' + field + r':\s+(\d+)', metadata)[1])
                assert row['private_segment_fixed_size'] == 0
                if variant == 'candidate' and entry == 'reset_states':
                    assert digest(artifact) == digest(artifact.replace('candidate', 'baseline'))
                rows.append(row)
                print(json.dumps(row), flush=True)
    write_json('native-images.json', rows)
    for variant in ['baseline', 'candidate']:
        Path('size-' + variant + '.txt').write_text(capture(['size', '-A', 'compile-' + variant]))
elif phase == 'identity':
    identities = []
    for row in json.loads(Path('native-images.json').read_text()):
        if row['variant'] != 'candidate':
            continue
        source = 'storage-disjoint.loombc' if row['count'] == 65537 else 'scan.loombc'
        run(['./compile-candidate', source, '--target=amdgpu:gfx1151',
             '--root=' + row['entry'], '--config-file=config-' + str(row['count']) + '.json',
             '--output=identity-output.hsaco'])
        assert digest('identity-output.hsaco') == row['sha256'], row
        identities.append({'artifact': row['artifact'], 'sha256': row['sha256'], 'identical': True})
    write_json('final-kernel-identity.json', identities)
elif phase in ['trace', 'qualify', 'measure', 'cost']:
    print('lease=' + os.environ['BENCHMARK_LOCK_LEASE_ID'], flush=True)
    print('phase=' + phase, flush=True)
    print('cpu_governor=' + Path('/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor').read_text().strip(), flush=True)
    print('gpu_power_level=' + Path('/sys/class/drm/card0/device/power_dpm_force_performance_level').read_text().strip(), flush=True)
    for row in json.loads(Path('native-images.json').read_text()):
        assert digest(row['artifact']) == row['sha256']
    if phase == 'trace':
        oracle = json.loads(Path('oracle-identity.json').read_text())['sizes']
        proof = []
        for case in cases:
            count, threads, items, source = case
            directory = 'trace-' + str(count)
            run(['/opt/rocm/bin/rocprofv3', '--kernel-trace', '--output-format', 'csv',
                 '--output-directory', directory, '--output-file', 'geometry', '--',
                 *arguments(case, 'trace')])
            traces = list(Path(directory).rglob('*kernel_trace.csv'))
            assert len(traces) == 1
            Path(directory + '.csv').write_bytes(traces[0].read_bytes())
            events = list(csv.DictReader(traces[0].open()))
            frequencies = collections.Counter(event['Kernel_Name'] for event in events)
            row = next(row for row in oracle if row['count'] == count)
            for kernel in row['kernels']:
                name = kernel['name']
                assert frequencies[name] == 32, (count, name, frequencies[name])
                dimensions = sorted(set((event['Grid_Size_X'], event['Workgroup_Size_X'])
                                        for event in events if event['Kernel_Name'] == name))
                assert [list(value) for value in dimensions] == kernel['grid_block_x']
            groups = (count + threads * items - 1) // (threads * items)
            entries = ['scan_single'] if groups == 1 else ['reset_states', 'scan_lookback']
            for name in entries:
                actual = collections.Counter((int(event['Grid_Size_X']), int(event['Workgroup_Size_X']))
                                             for event in events if event['Kernel_Name'] == name)
                grid = 1 if name == 'scan_single' else ((groups + threads - 1) // threads if name == 'reset_states' else groups)
                assert actual == collections.Counter({(grid * threads, threads): 64}), (count, name, actual)
            known = set(entries) | {'__amd_rocclr_copyBuffer'} | {kernel['name'] for kernel in row['kernels']}
            assert not (set(frequencies) - known)
            proof.append({'count': count, 'verified_dispatches_and_grids': True})
        write_json('dispatch-proof.json', proof)
    elif phase == 'qualify':
        for case in cases:
            count, threads, items, source = case
            config = json.loads(Path('config-' + str(count) + '.json').read_text())['scan']
            common = ['./loom', '--scan_source=' + str(Path(source).resolve()),
                      '--scan_count=' + str(count), '--amdgpu_command_buffer_mode=aql']
            for key in ['threads', 'items', 'packed_state', 'chain_length', 'refresh_rounds',
                        'ballot', 'local_barriers', 'prefix_form', 'lookback', 'indirect', 'fused_prefix']:
                value = config[key]
                common.append('--scan_' + key + '=' + (str(value).lower() if isinstance(value, bool) else str(value)))
            print('case=' + str(count), flush=True)
            run([*common, '--gtest_filter=ScanTest.DeviceWidePrefixes:ScanTest.CapacityBoundaries'])
            run([*common, '--scan_chain_length=8', '--scan_indirect=true',
                 '--gtest_filter=ScanTest.StableCompactIndirectConsumer'])
            if count == 65537:
                run([*common, '--scan_chain_length=8', '--scan_force_fallback=true',
                     '--scan_reverse_schedule=true', '--gtest_filter=ScanTest.CapacityBoundaries'])
    elif phase == 'measure':
        assert Path('/sys/class/drm/card0/device/gpu_busy_percent').read_text().strip() == '0'
        run(['vmstat', '1', '3'])
        for case in cases:
            for allocation in range(3 if case[0] == 2097152 else 1):
                print(f'case={case[0]}-allocation{allocation}', flush=True)
                run(arguments(case, 'measure'))
        run(['vmstat', '1', '3'])
    else:
        costs = []
        for count, threads, items, source in cases:
            entry = 'scan_single' if count <= threads * items else 'scan_lookback'
            for repeat in range(10):
                for variant in (['baseline', 'candidate'] if repeat % 2 == 0 else ['candidate', 'baseline']):
                    start = time.monotonic_ns()
                    run(['./compile-' + variant, source, '--target=amdgpu:gfx1151',
                         '--root=' + entry, '--config-file=config-' + str(count) + '.json',
                         '--output=cost-output.hsaco'])
                    elapsed = time.monotonic_ns() - start
                    assert digest('cost-output.hsaco') == digest(f'{variant}-{count}-{entry}.hsaco')
                    costs.append({'count': count, 'variant': variant, 'repeat': repeat,
                                  'process_start_import_compile_emit_ns': elapsed})
        write_json('compile-cost.json', costs)
else:
    raise ValueError(phase)
