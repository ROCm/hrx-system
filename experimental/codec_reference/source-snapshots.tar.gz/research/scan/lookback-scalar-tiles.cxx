#include <loomcxx/kernel.h>
#include <loomcxx/atomic.h>
#include <loomcxx/target.h>

[[loom::config("scan.inclusive")]] extern const bool inclusive;
[[loom::config("scan.reverse")]] extern const bool reverse;
[[loom::config("scan.compact")]] extern const bool compact;
[[loom::config("scan.portable")]] extern const bool portable;
[[loom::config("scan.threads")]] extern const unsigned configured_threads;
[[loom::config("scan.items")]] extern const unsigned items;
[[loom::config("scan.lookback")]] extern const bool lookback;
[[loom::config("scan.force_fallback")]] extern const bool force_fallback;
[[loom::config("scan.reverse_schedule")]] extern const bool reverse_schedule;
using Values = unsigned __attribute__((ext_vector_type(16)));

static loom::kernel::configuration configure_tiles(unsigned capacity) {
  unsigned threads = (configured_threads ? configured_threads : loom::target::subgroup::size() * 4);
  return {{(capacity + threads * items - 1) / (threads * items), 1, 1},
          {threads, 1, 1}};
}

static loom::kernel::configuration configure_one() {
  return {{1, 1, 1}, {(configured_threads ? configured_threads : loom::target::subgroup::size() * 4), 1, 1}};
}

// Portable workgroup-only baseline; no inter-workgroup waiting. The final
// barrier protects the returned register values before a loop reuses scratch.
struct Prefix {
  unsigned exclusive;
  unsigned total;
};
static LOOM_FORCE_INLINE Prefix local_prefix(unsigned value) {
  if (!portable) {
    return {loom::kernel::workgroup::scan::addi<
              loom::kernel::scan_mode::exclusive>(value),
            loom::kernel::workgroup::reduce::addi(value)};
  }
  unsigned item = loom::kernel::workitem::id.x;
  unsigned threads = loom::kernel::workgroup::size.x;
  auto* storage = loom::buffer::alloca<unsigned, loom::memory_space::workgroup>(threads);
  storage[item] = value;
  loom::kernel::workgroup::barrier();
  for (unsigned distance = 1; distance < threads; distance *= 2) {
    unsigned previous = storage[(item + threads - distance) % threads];
    if (item < distance) previous = 0;
    loom::kernel::workgroup::barrier();
    value += previous;
    storage[item] = value;
    loom::kernel::workgroup::barrier();
  }
  unsigned previous = storage[(item + threads - 1) % threads];
  Prefix result = {item ? previous : 0, storage[threads - 1]};
  loom::kernel::workgroup::barrier();
  return result;
}

// A device-read length changes the dispatch grid without changing the compiled
// program. Its caller guarantees length <= the planned input capacity.
[[loom::kernel(configure_one)]]
void prepare(const unsigned* length, unsigned* schedule) {
  if (loom::kernel::workitem::id.x == 0) {
    unsigned tile = loom::kernel::workgroup::size.x * items;
    schedule[0] = (length[0] + tile - 1) / tile;
    schedule[1] = 1;
    schedule[2] = 1;
  }
}

[[loom::kernel(configure_tiles)]]
void reduce_tiles(const unsigned* length, const unsigned* input,
                  unsigned* totals) {
  unsigned item = loom::kernel::workitem::id.x;
  unsigned group = loom::kernel::workgroup::id.x;
  unsigned threads = loom::kernel::workgroup::size.x;
  unsigned count = length[0];
  unsigned begin = (group * threads + item) * items;
  unsigned sum = 0;
  [[loom::unroll]]
  for (unsigned index = 0; index < items; ++index) {
    unsigned position = begin + index;
    if (position < count) {
      unsigned source = reverse ? count - 1 - position : position;
      sum += compact ? (input[source] & 1) : input[source];
    }
  }
  unsigned total = local_prefix(sum).total;
  if (item == 0) totals[group] = total;
}

// Hierarchical control: at most one tile is scanned serially by each workgroup.
static LOOM_FORCE_INLINE void scan_summary_tile(unsigned count,
    const unsigned* input, unsigned* output, unsigned carry) {
  unsigned item = loom::kernel::workitem::id.x;
  unsigned threads = loom::kernel::workgroup::size.x;
  unsigned begin = (loom::kernel::workgroup::id.x * threads + item) * items;
  Values values = {begin + 0 < count ? input[begin + 0] : 0,
                  begin + 1 < count ? input[begin + 1] : 0,
                  begin + 2 < count ? input[begin + 2] : 0,
                  begin + 3 < count ? input[begin + 3] : 0,
                  begin + 4 < count ? input[begin + 4] : 0,
                  begin + 5 < count ? input[begin + 5] : 0,
                  begin + 6 < count ? input[begin + 6] : 0,
                  begin + 7 < count ? input[begin + 7] : 0,
                  begin + 8 < count ? input[begin + 8] : 0,
                  begin + 9 < count ? input[begin + 9] : 0,
                  begin + 10 < count ? input[begin + 10] : 0,
                  begin + 11 < count ? input[begin + 11] : 0,
                  begin + 12 < count ? input[begin + 12] : 0,
                  begin + 13 < count ? input[begin + 13] : 0,
                  begin + 14 < count ? input[begin + 14] : 0,
                  begin + 15 < count ? input[begin + 15] : 0};
  unsigned sum = 0;
  [[loom::unroll]]
  for (unsigned i = 0; i < items; ++i) { sum += values[i]; }
  carry += local_prefix(sum).exclusive;
  [[loom::unroll]]
  for (unsigned i = 0; i < items; ++i) {
    if (begin + i < count) output[begin + i] = carry;
    carry += values[i];
  }
}

[[loom::kernel(configure_one)]]
void prefix_summaries(const unsigned* schedule, const unsigned* totals,
                      unsigned* prefixes) {
  scan_summary_tile(schedule[0], totals, prefixes, 0);
}

[[loom::kernel(configure_tiles)]]
void reduce_summaries(const unsigned* schedule, const unsigned* totals,
                     unsigned* upper_totals) {
  unsigned item = loom::kernel::workitem::id.x;
  unsigned group = loom::kernel::workgroup::id.x;
  unsigned begin = (group * loom::kernel::workgroup::size.x + item) * items;
  unsigned sum = 0;
  [[loom::unroll]]
  for (unsigned i = 0; i < items; ++i) {
    if (begin + i < schedule[0]) sum += totals[begin + i];
  }
  unsigned total = local_prefix(sum).total;
  if (item == 0) upper_totals[group] = total;
}

[[loom::kernel(configure_one)]]
void prefix_upper_summaries(const unsigned* schedule, const unsigned* totals,
                            unsigned* prefixes) {
  unsigned tile = loom::kernel::workgroup::size.x * items;
  scan_summary_tile((schedule[0] + tile - 1) / tile, totals, prefixes, 0);
}

[[loom::kernel(configure_tiles)]]
void scan_summaries(const unsigned* schedule, const unsigned* totals,
                    const unsigned* upper_prefixes, unsigned* prefixes) {
  scan_summary_tile(schedule[0], totals, prefixes,
                    upper_prefixes[loom::kernel::workgroup::id.x]);
}

static LOOM_FORCE_INLINE unsigned read_input(const unsigned* input,
                                             unsigned position, unsigned count) {
  if (position >= count) return 0;
  return input[reverse ? count - 1 - position : position];
}

static LOOM_FORCE_INLINE unsigned read_value(const unsigned* input,
                                             unsigned position, unsigned count) {
  unsigned value = read_input(input, position, count);
  return compact ? (value & 1) : value;
}

static LOOM_FORCE_INLINE Values read_data_values(const unsigned* input,
    unsigned begin, unsigned count) {
  return {read_input(input, begin + 0, count),
                   read_input(input, begin + 1, count),
                   read_input(input, begin + 2, count),
                   read_input(input, begin + 3, count),
                   read_input(input, begin + 4, count),
                   read_input(input, begin + 5, count),
                   read_input(input, begin + 6, count),
                   read_input(input, begin + 7, count),
                   read_input(input, begin + 8, count),
                   read_input(input, begin + 9, count),
                   read_input(input, begin + 10, count),
                   read_input(input, begin + 11, count),
                   read_input(input, begin + 12, count),
                   read_input(input, begin + 13, count),
                   read_input(input, begin + 14, count),
                   read_input(input, begin + 15, count)};
}

static LOOM_FORCE_INLINE unsigned sum_values(Values values) {
  unsigned sum = 0;
  [[loom::unroll]]
  for (unsigned index = 0; index < items; ++index) {
    sum += compact ? (values[index] & 1) : values[index];
  }
  return sum;
}

static LOOM_FORCE_INLINE unsigned write_data_values(unsigned count,
    unsigned* output, unsigned begin, Values values,
    unsigned carry) {
  [[loom::unroll]]
  for (unsigned index = 0; index < items; ++index) {
    unsigned position = begin + index;
    unsigned value = compact ? (values[index] & 1) : values[index];
    unsigned prefix = inclusive ? carry + value : carry;
    carry += value;
    if (position < count) {
      unsigned destination = reverse ? count - 1 - position : position;
      if (compact) {
        if (value) output[carry - 1] = values[index];
      } else {
        output[destination] = prefix;
      }
    }
  }
  return carry;
}

static LOOM_FORCE_INLINE unsigned scan_tile_values(unsigned count,
    const unsigned* input, unsigned* output, unsigned initial) {
  unsigned begin = (loom::kernel::workgroup::id.x *
      loom::kernel::workgroup::size.x + loom::kernel::workitem::id.x) * items;
  Values values = read_data_values(input, begin, count);
  unsigned carry = initial + local_prefix(sum_values(values)).exclusive;
  return write_data_values(count, output, begin, values, carry);
}

[[loom::kernel(configure_tiles)]]
void scan_tiles(const unsigned* length, const unsigned* input,
                const unsigned* prefixes, unsigned* output) {
  scan_tile_values(length[0], input, output,
                    prefixes[loom::kernel::workgroup::id.x]);
}

[[loom::kernel(configure_one)]]
void scan_single(const unsigned* length, const unsigned* input, unsigned* output) {
  scan_tile_values(length[0], input, output, 0);
}

[[loom::kernel(configure_one)]]
void compact_single(const unsigned* length, const unsigned* input,
                     unsigned* output, unsigned* selected) {
  unsigned carry = scan_tile_values(length[0], input, output, 0);
  unsigned threads = loom::kernel::workgroup::size.x;
  if (loom::kernel::workitem::id.x == threads - 1) {
    selected[0] = (carry + threads - 1) / threads;
    selected[1] = 1;
    selected[2] = 1;
    selected[3] = carry;
  }
}

[[loom::kernel(configure_one)]]
void publish_count(const unsigned* schedule, const unsigned* totals,
                   const unsigned* prefixes, unsigned* selected) {
  if (loom::kernel::workitem::id.x == 0) {
    unsigned tiles = schedule[0];
    unsigned count = tiles ? prefixes[tiles - 1] + (lookback ? 0 : totals[tiles - 1]) : 0;
    selected[0] = (count + loom::kernel::workgroup::size.x - 1) /
                  loom::kernel::workgroup::size.x;
    selected[1] = 1;
    selected[2] = 1;
    selected[3] = count;
  }
}

[[loom::kernel(configure_tiles)]]
void consume(const unsigned* selected, const unsigned* input, unsigned* output) {
  unsigned item = loom::kernel::workgroup::id.x * loom::kernel::workgroup::size.x +
                  loom::kernel::workitem::id.x;
  if (item < selected[3]) output[item] = input[item] * 3 + 7;
}

// One immutable aggregate and prefix per tile, with a separately published flag.
// Ordered reset permits reuse without generation tags or stale-state ambiguity.
[[loom::kernel(configure_tiles)]]
void reset_states(const unsigned* length, unsigned* states, unsigned* schedule) {
  unsigned item = loom::kernel::workgroup::id.x * loom::kernel::workgroup::size.x +
                  loom::kernel::workitem::id.x;
  unsigned tile = loom::kernel::workgroup::size.x * items;
  unsigned groups = (length[0] + tile - 1) / tile;
  [[loom::unroll]]
  for (unsigned index = 0; index < items; ++index) {
    unsigned position = item * items + index;
    if (position < groups) states[position] = 0;
  }
  if (item == 0) {
    schedule[0] = groups;
    schedule[1] = 1;
    schedule[2] = 1;
  }
}

[[loom::kernel(configure_tiles)]]
void scan_lookback(const unsigned* length, const unsigned* input, unsigned* output,
                   unsigned* states, unsigned* aggregates, unsigned* prefixes) {
  unsigned item = loom::kernel::workitem::id.x;
  unsigned threads = loom::kernel::workgroup::size.x;
  unsigned tile = threads * items;
  unsigned count = length[0];
  unsigned groups = (count + tile - 1) / tile;
  unsigned group = loom::kernel::workgroup::id.x;
  if (group >= groups) return;
  if (reverse_schedule) group = groups - 1 - group;
  unsigned begin = group * tile + item * items;
  Values values = read_data_values(input, begin, count);
  Prefix local = local_prefix(sum_values(values));
  auto* carry_storage = loom::buffer::alloca<unsigned, loom::memory_space::workgroup>(1);
  if (item == 0) {
    aggregates[group] = local.total;
    loom::view::atomic::store<loom::atomic::ordering::release,
        loom::atomic::scope::device>(1u, states + group);
  }
  unsigned width = loom::kernel::subgroup::size();
  if (item < width) {
    unsigned carry = 0;
    unsigned previous = group;
    bool complete = false;
    while (previous > 0 && !complete) {
      --previous;
      unsigned state = 0;
      unsigned value = 0;
      if (item == 0 && !force_fallback) {
        state = loom::view::atomic::load<loom::atomic::ordering::acquire,
            loom::atomic::scope::device>(states + previous);
        if (state == 1) value = aggregates[previous];
        if (state == 2) value = prefixes[previous];
      }
      state = loom::kernel::subgroup::broadcast(state, 0);
      value = loom::kernel::subgroup::broadcast(value, 0);
      if (state == 0) {
        unsigned partial = 0;
        for (unsigned position = item; position < tile; position += width) {
          partial += read_value(input, previous * tile + position, count);
        }
        value = loom::kernel::subgroup::reduce::addi(partial);
      }
      carry = value + carry;
      complete = state == 2;
    }
    if (item == 0) {
      carry_storage[0] = carry;
      prefixes[group] = carry + local.total;
      loom::view::atomic::store<loom::atomic::ordering::release,
          loom::atomic::scope::device>(2u, states + group);
    }
  }
  loom::kernel::workgroup::barrier();
  write_data_values(count, output, begin, values,
                    carry_storage[0] + local.exclusive);
}
