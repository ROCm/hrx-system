import hashlib
import json
import os
from pathlib import Path
import subprocess

roots = json.loads(os.environ['BUREAU_TAG_ROOTS'])
report = {
    'baseline_commit': 'a06c751e660e062143b9ef2dfc4475eedfee6ed8',
    'target': '//loom/src/loom/tools/loom-serve',
    'build_flags': ['--config=opt'],
    'artifacts': {},
}
for name, root in roots.items():
    path = Path(root) / 'loom/src/loom/tools/loom-serve/loom-serve'
    sections = {}
    output = subprocess.check_output(['size', '-A', str(path)], text=True)
    for line in output.splitlines():
        fields = line.split()
        if len(fields) == 3 and fields[0].startswith('.'):
            sections[fields[0]] = int(fields[1])
    symbols = subprocess.check_output(['nm', '-S', str(path)], text=True)
    command_symbols = [line for line in symbols.splitlines() if 'loom_cmd_' in line]
    report['artifacts'][name] = {
        'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
        'file_bytes': path.stat().st_size,
        'sections': sections,
        'command_symbol_count': len(command_symbols),
        'count_placement_symbols': [line for line in command_symbols if 'dispatch_count' in line],
    }
    assert command_symbols, 'Measured tool does not contain command compiler'
baseline = report['artifacts']['indirect-baseline']
candidate = report['artifacts']['indirect-candidate']
report['delta'] = {
    'file_bytes': candidate['file_bytes'] - baseline['file_bytes'],
    'sections': {name: candidate['sections'].get(name, 0) - baseline['sections'].get(name, 0)
                 for name in sorted(set(candidate['sections']) | set(baseline['sections']))},
}
Path('experimental/codec_reference/research/scan/mutable-indirect-cost.json').write_text(json.dumps(report, indent=2) + '\n')
for name, artifact in report['artifacts'].items():
    print(name, 'file', artifact['file_bytes'], 'text', artifact['sections']['.text'],
          'immutable', artifact['sections'].get('.rodata', 0) + artifact['sections'].get('.data.rel.ro', 0),
          'cmd_symbols', artifact['command_symbol_count'])
print('delta', report['delta'])
