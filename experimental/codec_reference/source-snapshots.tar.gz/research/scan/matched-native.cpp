// Development-only comparison: every graph uses the same input/output storage.
#include <hip/hip_runtime.h>
#include <rocprim/device/device_scan.hpp>
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>

static void check(hipError_t error, const char* expression) {
  if (error != hipSuccess) {
    std::fprintf(stderr, "%s: %s\n", expression, hipGetErrorString(error));
    std::exit(1);
  }
}
#define HIP(expression) check((expression), #expression)

struct NativeScan {
  // Owned scan code object.
  hipModule_t scan_module = nullptr;
  // Owned reset code object, absent for a single-workgroup scan.
  hipModule_t reset_module = nullptr;
  // Borrowed scan entry from scan_module.
  hipFunction_t scan = nullptr;
  // Borrowed reset entry from reset_module.
  hipFunction_t reset = nullptr;
};

static NativeScan load_scan(const std::string& prefix, bool single) {
  NativeScan result;
  const char* entry = single ? "scan_single" : "scan_lookback";
  HIP(hipModuleLoad(&result.scan_module, (prefix + "-" + entry + ".hsaco").c_str()));
  HIP(hipModuleGetFunction(&result.scan, result.scan_module, entry));
  if (!single) {
    HIP(hipModuleLoad(&result.reset_module, (prefix + "-reset_states.hsaco").c_str()));
    HIP(hipModuleGetFunction(&result.reset, result.reset_module, "reset_states"));
  }
  return result;
}

int main(int argc, char** argv) {
  if (argc != 8) {
    std::fprintf(stderr, "usage: matched count iterations threads items control_prefix candidate_prefix {trace|measure}\n");
    return 1;
  }
  const size_t count = std::strtoull(argv[1], nullptr, 10);
  const unsigned iterations = std::strtoul(argv[2], nullptr, 10);
  const unsigned threads = std::strtoul(argv[3], nullptr, 10);
  const unsigned items = std::strtoul(argv[4], nullptr, 10);
  const bool trace = std::string(argv[7]) == "trace";
  if (!count || count > (1u << 24) || !iterations || !threads || threads > 1024 ||
      !items || items > 16 || (!trace && std::string(argv[7]) != "measure")) return 1;
  constexpr unsigned chain = 32;
  constexpr uint32_t canary = 0x735ab192;
  const unsigned groups = (count + threads * items - 1) / (threads * items);
  const bool single = groups == 1;
  const size_t bytes = (count + 16) * sizeof(uint32_t);
  const size_t states_bytes = (size_t(groups) * 8 + 15) & ~size_t(15);
  hipStream_t stream;
  HIP(hipStreamCreate(&stream));
  uint32_t *input, *output, *length;
  uint8_t* scratch = nullptr;
  HIP(hipMalloc(&input, bytes));
  HIP(hipMalloc(&output, bytes));
  HIP(hipMalloc(&length, sizeof(uint32_t)));
  if (!single) HIP(hipMalloc(&scratch, states_bytes + 12));
  uint32_t* states = reinterpret_cast<uint32_t*>(scratch);
  uint32_t* schedule = single ? nullptr : reinterpret_cast<uint32_t*>(scratch + states_bytes);
  const uint32_t runtime_count = count;
  std::vector<uint32_t> host_input(count + 16);
  std::vector<uint32_t> host_output(count + 16, canary);
  for (size_t i = 0; i < host_input.size(); ++i) host_input[i] = (i * 104729 + 12345) % 7 == 0;
  HIP(hipMemcpyAsync(input, host_input.data(), bytes, hipMemcpyHostToDevice, stream));
  HIP(hipMemcpyAsync(length, &runtime_count, sizeof(runtime_count), hipMemcpyHostToDevice, stream));
  size_t oracle_bytes = 0;
  HIP(rocprim::exclusive_scan(nullptr, oracle_bytes, input, output, uint32_t(0),
                              count, rocprim::plus<uint32_t>(), stream));
  void* oracle_scratch;
  HIP(hipMalloc(&oracle_scratch, oracle_bytes));
  HIP(hipStreamSynchronize(stream));

  NativeScan natives[] = {load_scan(argv[5], single), load_scan(argv[6], single)};
  hipGraph_t graphs[3];
  hipGraphExec_t executables[3];
  void* single_arguments[] = {&length, &input, &output};
  void* reset_arguments[] = {&length, &states, &schedule};
  void* scan_arguments[] = {&length, &input, &output, &states, &states, &states};
  const char* names[] = {"rocprim", "control", "candidate"};
  for (unsigned variant = 0; variant < 3; ++variant) {
    HIP(hipStreamBeginCapture(stream, hipStreamCaptureModeThreadLocal));
    for (unsigned operation = 0; operation < chain; ++operation) {
      if (variant == 0) {
        HIP(rocprim::exclusive_scan(oracle_scratch, oracle_bytes, input, output,
                                    uint32_t(0), count, rocprim::plus<uint32_t>(), stream));
      } else if (single) {
        HIP(hipModuleLaunchKernel(natives[variant - 1].scan, 1, 1, 1, threads, 1, 1,
                                  0, stream, single_arguments, nullptr));
      } else {
        HIP(hipModuleLaunchKernel(natives[variant - 1].reset,
                                  (groups + threads - 1) / threads, 1, 1,
                                  threads, 1, 1, 0, stream, reset_arguments, nullptr));
        HIP(hipModuleLaunchKernel(natives[variant - 1].scan, groups, 1, 1,
                                  threads, 1, 1, 0, stream, scan_arguments, nullptr));
      }
    }
    HIP(hipStreamEndCapture(stream, &graphs[variant]));
    size_t nodes = 0;
    HIP(hipGraphGetNodes(graphs[variant], nullptr, &nodes));
    if (nodes != chain * (single ? 1 : 2)) {
      std::fprintf(stderr, "unexpected graph node count: %zu\n", nodes);
      return 1;
    }
    HIP(hipGraphInstantiate(&executables[variant], graphs[variant], nullptr, nullptr, 0));
  }
  auto reset_output = [&] {
    std::fill(host_output.begin(), host_output.end(), canary);
    HIP(hipMemcpyAsync(output, host_output.data(), bytes, hipMemcpyHostToDevice, stream));
  };
  auto verify = [&] {
    HIP(hipMemcpyAsync(host_output.data(), output, bytes, hipMemcpyDeviceToHost, stream));
    HIP(hipStreamSynchronize(stream));
    uint32_t prefix = 0;
    for (size_t i = 0; i < host_output.size(); ++i) {
      const uint32_t expected = i < count ? prefix : canary;
      if (host_output[i] != expected) {
        std::fprintf(stderr, "prefix/canary mismatch at %zu: %u != %u\n", i, host_output[i], expected);
        std::exit(1);
      }
      if (i < count) prefix += host_input[i];
    }
  };
  for (unsigned variant = 0; variant < 3; ++variant) {
    reset_output();
    HIP(hipGraphLaunch(executables[variant], stream));
    verify();
  }
  std::printf("shared_buffers count=%zu input=%p output=%p length=%p loom_scratch=%p oracle_scratch=%p\n",
               count, input, output, length, scratch, oracle_scratch);
  if (!trace) {
    const unsigned order[] = {0, 1, 2, 0, 2, 1, 0};
    for (unsigned window = 0; window < 7; ++window) {
      const unsigned variant = order[window];
      std::printf("window=%s\n", names[variant]);
      reset_output();
      for (unsigned warmup = 0; warmup < 10; ++warmup) HIP(hipGraphLaunch(executables[variant], stream));
      HIP(hipStreamSynchronize(stream));
      std::vector<double> samples;
      for (unsigned sample = 0; sample < 9; ++sample) {
        const auto start = std::chrono::steady_clock::now();
        for (unsigned iteration = 0; iteration < iterations; ++iteration) HIP(hipGraphLaunch(executables[variant], stream));
        HIP(hipStreamSynchronize(stream));
        const double elapsed = std::chrono::duration<double, std::nano>(std::chrono::steady_clock::now() - start).count();
        samples.push_back(elapsed / (iterations * double(chain)));
        std::printf("{\"implementation\":\"%s\",\"count\":%zu,\"batch_scans\":32,\"submissions\":%u,\"window_index\":%u,\"sample\":%u,\"elapsed_ns\":%.3f,\"per_scan_ns\":%.3f}\n",
                     names[variant], count, iterations, window, sample, elapsed, samples.back());
      }
      verify();
      std::sort(samples.begin(), samples.end());
      std::printf("{\"implementation\":\"%s\",\"count\":%zu,\"batch_scans\":32,\"submissions\":%u,\"window_index\":%u,\"median_per_scan_ns\":%.3f}\n",
                   names[variant], count, iterations, window, samples[4]);
    }
  }
  for (unsigned variant = 0; variant < 3; ++variant) {
    HIP(hipGraphExecDestroy(executables[variant]));
    HIP(hipGraphDestroy(graphs[variant]));
  }
  for (auto& native : natives) {
    HIP(hipModuleUnload(native.scan_module));
    if (native.reset_module) HIP(hipModuleUnload(native.reset_module));
  }
  HIP(hipFree(oracle_scratch));
  if (scratch) HIP(hipFree(scratch));
  HIP(hipFree(length));
  HIP(hipFree(output));
  HIP(hipFree(input));
  HIP(hipStreamDestroy(stream));
  return 0;
}
