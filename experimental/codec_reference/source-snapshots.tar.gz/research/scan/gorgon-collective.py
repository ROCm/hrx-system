"""Inspect, qualify, and measure the bounded source collective choices."""
from pathlib import Path
import json,hashlib,re,subprocess,sys,os
sdk=Path('/opt/rocm');llvm=sdk/'llvm/bin'
base=json.loads(Path('address-config.json').read_text())
variants={'control':{},'local':{'local_barriers':True},'fused':{'local_barriers':True,'fused_prefix':True},'ballot':{'ballot':True},'both':{'local_barriers':True,'fused_prefix':True,'ballot':True}}
def config(label,count):
 c=dict(base['scan']);c.update(capacity=count,threads=128 if count<16777216 else 64,items=8,packed_state=True,chain_length=32,refresh_rounds=16,ballot=False,local_barriers=False,prefix_form=0)
 if label.startswith('prefix'):
  c.update(threads=0,items=1 if count==32 else 16,prefix_form=int(label[-1]))
 else:c.update(variants[label])
 return {'scan':c}
def run(label,count,extra):
 c=config(label,count)['scan'];args=['./loom','--scan_source='+str(Path('scan.loombc').resolve()),'--amdgpu_command_buffer_mode=aql']
 for key in ['threads','items','packed_state','chain_length','refresh_rounds','ballot','local_barriers','prefix_form','lookback','indirect','fused_prefix']:
  v=c[key]; args.append('--scan_'+key+'='+ (str(v).lower() if isinstance(v,bool) else str(v)))
 args += ['--scan_count='+str(count),*extra];subprocess.run(args,check=True)
cases=[(f'prefix{form}',count) for count in [32,512] for form in [0,1,2]]+[(label,count) for label in variants for count in [65537,16777216]]
phase=sys.argv[1]
if phase=='inspect':
 rows=[]
 for label,count in cases:
  cfg=config(label,count);c=cfg['scan'];stem=f'collective-{label}-{count}';cp=Path(stem+'-config.json');cp.write_text(json.dumps(cfg,indent=2)+'\n')
  for entry in (['scan_single'] if count<1024 else ['reset_states','scan_lookback']):
   name=stem+'-'+entry;artifact=Path(name+'.hsaco')
   subprocess.run(['./compile','scan.loombc','--target=amdgpu:gfx1151','--root='+entry,'--config-file='+str(cp),'--output='+str(artifact),'--compile-report=details','--compile-report-output='+name+'-report.json'],check=True)
   asm=subprocess.check_output([llvm/'llvm-objdump','-d',artifact],text=True);meta=subprocess.check_output([llvm/'llvm-readelf','-n','-S',artifact],text=True)
   Path(name+'.s').write_text(asm);Path(name+'.metadata.txt').write_text(meta)
   row={'version':label,'count':count,'threads_config':c['threads'],'threads':c['threads'] or 32,'items':c['items'],'entry':entry,'artifact':str(artifact),'profile':stem+'.ireeprof','sha256':hashlib.sha256(artifact.read_bytes()).hexdigest(),'instructions':len(re.findall(r'//\s*[0-9a-fA-F]+:',asm)),'text_bytes':int(re.search(r'\]\s+\.text\s+PROGBITS\s+\S+\s+\S+\s+([0-9a-fA-F]+)',meta)[1],16)}
   for f in ['group_segment_fixed_size','private_segment_fixed_size','sgpr_count','vgpr_count','wavefront_size']:row[f]=int(re.search(r'\.'+f+r':\s+(\d+)',meta)[1])
   rows.append(row);print(json.dumps(row),flush=True)
 Path('collective-native.json').write_text(json.dumps(rows,indent=2)+'\n')
elif phase=='qualify':
 print('lease='+os.environ['BENCHMARK_LOCK_LEASE_ID'],flush=True)
 for label,count in cases:
  run(label,count,['--gtest_filter=ScanTest.DeviceWidePrefixes:ScanTest.CapacityBoundaries'])
  if count<16777216:
   run(label,count,['--scan_chain_length=8','--scan_indirect=true','--gtest_filter=ScanTest.StableCompactIndirectConsumer'])
  if count==65537:
   run(label,count,['--scan_chain_length=8','--scan_force_fallback=true','--scan_reverse_schedule=true','--gtest_filter=ScanTest.CapacityBoundaries'])
  run(label,count,['--gtest_also_run_disabled_tests','--gtest_filter=ScanTest.DISABLED_ProfileScan','--device_profiling_mode=queue-events,device-queue-events,dispatch-events','--device_profiling_output='+str(Path(f'collective-{label}-{count}.ireeprof').resolve())])
 for label in variants:run(label,2097152,['--gtest_filter=ScanTest.DeviceWidePrefixes:ScanTest.CapacityBoundaries'])
elif phase=='measure':
 print('lease='+os.environ['BENCHMARK_LOCK_LEASE_ID'],flush=True);subprocess.run(['vmstat','1','3'],check=True)
 print('cpu_governor='+Path('/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor').read_text().strip(),flush=True)
 print('gpu_power_level='+Path('/sys/class/drm/card0/device/power_dpm_force_performance_level').read_text().strip(),flush=True)
 busy=Path('/sys/class/drm/card0/device/gpu_busy_percent').read_text().strip();print('preflight_gpu_busy='+busy,flush=True);assert busy=='0'
 for label in ['rocprim','prefix0','prefix1','prefix2','control','local','fused','ballot','both','rocprim','both','ballot','fused','local','control','prefix2','prefix1','prefix0','rocprim']:
  print('window='+label,flush=True)
  counts=[32,512] if label.startswith('prefix') else [65537,2097152,16777216]
  if label=='rocprim':counts=[32,512,65537,2097152,16777216]
  for count in counts:
   iterations=16 if count==16777216 else 128
   if label=='rocprim':subprocess.run(['./rocprim','u32',str(count),str(iterations),'32'],check=True)
   else:run(label,count,['--scan_iterations='+str(iterations),'--gtest_also_run_disabled_tests','--gtest_filter=ScanTest.DISABLED_BenchmarkScan'])
 subprocess.run(['vmstat','1','3'],check=True)
else:raise ValueError(phase)
