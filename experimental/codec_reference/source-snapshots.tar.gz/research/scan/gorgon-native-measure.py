from pathlib import Path
import subprocess,os,json,hashlib,re
# The new executable must contain the same selected oracle instruction words.
def words(path):return re.findall(r'//\s*[0-9a-fA-F]+:\s*([0-9A-Fa-f ]+)',path.read_text())
old=json.loads(Path('oracle-identity.json').read_text());new=json.loads(Path('native-oracle-identity.json').read_text())
assert new['comparator_sha256']==hashlib.sha256(Path('native').read_bytes()).hexdigest()
assert old['comparator_sha256']==hashlib.sha256(Path('rocprim').read_bytes()).hexdigest()
assert [r['count'] for r in old['sizes']]==[r['count'] for r in new['sizes']]
for a,b in zip(old['sizes'],new['sizes']):
 assert len(a['kernels'])==len(b['kernels'])
 for index,(x,y) in enumerate(zip(a['kernels'],b['kernels'])):
  assert x['name']==y['name'] and x['grid_block_x']==y['grid_block_x']
  assert words(Path(f"oracle-{a['count']}-{index}.s"))==words(Path(f"native-oracle-{b['count']}-{index}.s"))
print('native_oracle_words_identical=true',flush=True)
subprocess.run(['vmstat','1','3'],check=True)
print('cpu_governor='+Path('/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor').read_text().strip(),flush=True)
print('gpu_power_level='+Path('/sys/class/drm/card0/device/power_dpm_force_performance_level').read_text().strip(),flush=True)
print('post_profile_gpu_busy='+Path('/sys/class/drm/card0/device/gpu_busy_percent').read_text().strip(),flush=True)
for window in ['rocprim','control','candidate','rocprim','candidate','control','rocprim']:
 print('window='+window,flush=True)
 for count in [32,512,65537,2097152,16777216]:
  iterations=16 if count==16777216 else 128
  if window=='rocprim':args=['./native','u32',str(count),str(iterations),'32']
  else:
   label=('prefix2' if window=='candidate' else 'prefix0') if count<1024 else ('both' if window=='candidate' and count<16777216 else 'control')
   threads=32 if count<1024 else 64 if count==16777216 else 128
   items=1 if count==32 else 16 if count==512 else 8
   args=['./native','loom',f'collective-{label}-{count}',str(count),str(iterations),'32',str(threads),str(items)]
  subprocess.run(args,check=True)
subprocess.run(['vmstat','1','3'],check=True)
