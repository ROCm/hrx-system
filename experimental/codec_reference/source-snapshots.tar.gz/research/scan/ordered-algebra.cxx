#include "ordered-algebra.h"

LOOM_TEMPLATE_DEF(compose)
[[loom::priority(1)]]
Affine compose_affine(Affine left, Affine right) {
  return {right.scale * left.scale,
          right.scale * left.offset + right.offset};
}
