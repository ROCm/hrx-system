"""Short scan ownership experiment, using the pinned compiler and comparator."""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

llvm = Path('/opt/rocm/llvm/bin')
phase = sys.argv[1]
modes = ['length', 'input', 'both']
counts = [32, 512]

def prefix(mode, count):
    return f'short-{mode}-{count}'

def config(count):
    return json.loads(Path(f'dpp-{count}-config.json').read_text())

def invoke(mode, count, extra):
    values = config(count)['scan']
    arguments = ['./loom-dpp', '--scan_source=' + str(Path(f'short-{mode}.loombc').resolve()),
                 '--scan_count=' + str(count), '--amdgpu_command_buffer_mode=aql']
    for key in ['threads', 'items', 'packed_state', 'chain_length', 'refresh_rounds',
                'ballot', 'local_barriers', 'prefix_form', 'lookback', 'indirect', 'fused_prefix']:
        value = values[key]
        arguments.append('--scan_' + key + '=' + (str(value).lower() if isinstance(value, bool) else str(value)))
    subprocess.run([*arguments, *extra], check=True)

def native_arguments(mode, count, action):
    items = config(count)['scan']['items']
    return ['./geometry', str(count), '128', '32', str(items), '32', str(items),
            f'dpp-{count}', prefix(mode, count), action]

if phase == 'inspect':
    rows = []
    baseline = json.loads(Path('dpp-native.json').read_text())
    for mode in modes:
        for count in [32, 512, 65537, 2097152, 16777216]:
            stem = prefix(mode, count)
            values = config(count)
            Path(stem + '-config.json').write_text(json.dumps(values, indent=2) + '\n')
            entries = ['scan_single'] if count in counts else ['reset_states', 'scan_lookback']
            for entry in entries:
                name = stem + '-' + entry
                artifact = Path(name + '.hsaco')
                subprocess.run(['./compile-dpp', f'short-{mode}.loombc', '--target=amdgpu:gfx1151',
                                '--root=' + entry, '--config-file=' + stem + '-config.json',
                                '--output=' + str(artifact), '--compile-report=summary',
                                '--compile-report-output=' + name + '-report.json'], check=True)
                digest = hashlib.sha256(artifact.read_bytes()).hexdigest()
                control = next(row for row in baseline if row['count'] == count and row['entry'] == entry)
                if count not in counts:
                    # The old DPP65K experiment used flow-loop source; compare
                    # against this experiment's actual launch source instead.
                    control_path = Path(f'short-control-{count}-{entry}.hsaco')
                    subprocess.run(['./compile-dpp', 'scan.loombc', '--target=amdgpu:gfx1151',
                                    '--root=' + entry, '--config-file=' + stem + '-config.json',
                                    '--output=' + str(control_path)], check=True)
                    assert artifact.read_bytes() == control_path.read_bytes(), (mode, count, entry)
                    continue
                assembly = subprocess.check_output([llvm/'llvm-objdump', '-d', artifact], text=True)
                metadata = subprocess.check_output([llvm/'llvm-readelf', '-n', '-S', artifact], text=True)
                Path(name + '.s').write_text(assembly)
                Path(name + '.metadata.txt').write_text(metadata)
                row = {'version': mode, 'count': count, 'threads': 32, 'items': values['scan']['items'],
                       'entry': entry, 'artifact': str(artifact), 'profile': stem + '.ireeprof',
                       'sha256': digest, 'identical_control': digest == control['sha256'],
                       'instructions': len(re.findall(r'//\s*[0-9a-fA-F]+:', assembly))}
                for field in ['group_segment_fixed_size', 'private_segment_fixed_size', 'sgpr_count', 'vgpr_count', 'wavefront_size']:
                    row[field] = int(re.search(r'\.' + field + r':\s+(\d+)', metadata)[1])
                assert row['private_segment_fixed_size'] == 0 and row['group_segment_fixed_size'] == 0
                rows.append(row)
                print(json.dumps(row), flush=True)
    Path('short-native.json').write_text(json.dumps(rows, indent=2) + '\n')
else:
    print('lease=' + os.environ['BENCHMARK_LOCK_LEASE_ID'], flush=True)
    rows = json.loads(Path('short-native.json').read_text())
    cases = []
    seen = set()
    for row in rows:
        if row['identical_control'] or row['sha256'] in seen:
            continue
        seen.add(row['sha256'])
        cases.append((row['version'], row['count']))
    if phase == 'qualify':
        for mode, count in cases:
            print(f'case={mode}-{count}', flush=True)
            invoke(mode, count, ['--gtest_filter=ScanTest.DeviceWidePrefixes:ScanTest.CapacityBoundaries'])
            invoke(mode, count, ['--scan_chain_length=8', '--scan_indirect=true',
                                '--gtest_filter=ScanTest.StableCompactIndirectConsumer'])
            invoke(mode, count, ['--gtest_also_run_disabled_tests', '--gtest_filter=ScanTest.DISABLED_ProfileScan',
                                '--device_profiling_mode=queue-events,device-queue-events,dispatch-events',
                                '--device_profiling_output=' + str(Path(prefix(mode,count) + '.ireeprof').resolve())])
    elif phase in ['measure', 'serve']:
        while Path('/sys/class/drm/card0/device/gpu_busy_percent').read_text().strip() != '0':
            time.sleep(0.05)
        print('preflight_gpu_busy=0', flush=True)
        print('cpu_governor=' + Path('/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor').read_text().strip(), flush=True)
        print('gpu_power_level=' + Path('/sys/class/drm/card0/device/power_dpm_force_performance_level').read_text().strip(), flush=True)
        assert hashlib.sha256(Path('geometry').read_bytes()).hexdigest() == json.loads(Path('primary-oracle-identity.json').read_text())['binary_sha256']
        for row in rows:
            assert hashlib.sha256(Path(row['artifact']).read_bytes()).hexdigest() == row['sha256']
        subprocess.run(['vmstat','1','3'], check=True)
        if phase == 'measure':
            for mode, count in cases:
                print(f'case={mode}-{count}', flush=True)
                subprocess.run(native_arguments(mode, count, 'measure'), check=True)
        else:
            selected = json.loads(Path('short-selected.json').read_text())
            for window, mode in enumerate(['control', 'candidate', 'control', 'candidate', 'control']):
                print('window_index=' + str(window), flush=True)
                for count in counts:
                    print(f'case={count}-{mode}', flush=True)
                    choice = selected[str(count)] if mode == 'candidate' else 'control'
                    if choice == 'control':
                        source = Path('scan.loombc')
                    else:
                        source = Path(f'short-{choice}.loombc')
                    # Reuse the qualified argument construction with only the source replaced.
                    values = config(count)['scan']
                    arguments = ['./loom-dpp','--scan_source='+str(source.resolve()), '--scan_count='+str(count),
                                 '--scan_iterations=128','--amdgpu_command_buffer_mode=aql',
                                 '--gtest_also_run_disabled_tests','--gtest_filter=ScanTest.DISABLED_BenchmarkScan']
                    for key in ['threads','items','packed_state','chain_length','refresh_rounds','ballot','local_barriers','prefix_form','lookback','indirect','fused_prefix']:
                        value=values[key]
                        arguments.append('--scan_'+key+'='+(str(value).lower() if isinstance(value,bool) else str(value)))
                    subprocess.run(arguments, check=True)
        subprocess.run(['vmstat','1','3'], check=True)
    else:
        raise ValueError(phase)
