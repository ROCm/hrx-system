import difflib
import json
import os
from pathlib import Path
import subprocess
roots=json.loads(os.environ['BUREAU_TAG_ROOTS'])
assembly={}
for name,root in roots.items():
    path=Path(root)/'loom/src/loom/tools/loom-serve/loom-serve'
    output=subprocess.check_output(['objdump','-d','--disassemble=loom_cmd_dispatch_count_table_build',str(path)],text=True)
    lines=output.splitlines()
    begin=next(i for i,line in enumerate(lines) if '<loom_cmd_dispatch_count_table_build>:' in line)
    assembly[name]=lines[begin:]
diff='\n'.join(difflib.unified_diff(assembly['indirect-baseline'],assembly['indirect-candidate'],fromfile='baseline',tofile='candidate',lineterm=''))+'\n'
Path('experimental/codec_reference/research/scan/mutable-indirect-native-code.diff').write_text(diff)
print(diff)
