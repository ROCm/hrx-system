"""Establish which native load families disagree with carrier prediction."""

from pathlib import Path
import hashlib
import json
import resource
import subprocess
import tempfile

notes = Path(__file__).resolve().parent
compiler = Path('bazel-bin/loom/src/loom/tools/loom-compile/loom-compile').resolve()
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
base = (notes / 'uniform-three-word-load.loom').read_text().replace('load_three', 'load_words')
sources = []
for element, count in [('i8', 12), ('i16', 6), ('i32', 3), ('f8E4M3', 12),
                       ('f8E5M2', 12), ('f16', 6), ('bf16', 6), ('f32', 3)]:
    sources.append((element + '-three-words', base.replace('3xi32', f'{count}x{element}')))
for count in [1, 2, 3, 4]:
    source = base.replace('3xi32', f'{count}xi32')
    source = source.replace('  %constant_input = buffer.assume.memory_space<constant> %input : buffer',
                            '  %source, %destination = buffer.assume.noalias %input, %output : buffer, buffer')
    source = source.replace('%constant_input[%base]', '%source[%base]').replace('%output[%base]', '%destination[%base]')
    sources.append((f'global-{count}-words', source))
    policy = source.replace('vector.load %view[0] :', 'vector.load %view[0] {cache_scope = system, cache_temporal = bypass} :')
    sources.append((f'global-cache-{count}-words', policy))
    sources.append((f'global-fence-{count}-words', source.replace('  %value =', '  buffer.fence scope(system) ordering(acquire)\n  %value =')))
sources.append(('global-scalar-fence', '''kernel.def @load_words() {
  %unit = index.constant 1 : index
  kernel.launch.config workgroups(%unit, %unit, %unit) workgroup_size(%unit, %unit, %unit) : index
} launch(%input: buffer, %output: buffer) {
  %source, %destination = buffer.assume.noalias %input, %output : buffer, buffer
  %base = index.constant 0 : offset
  %view = buffer.view %source[%base] : buffer -> view<1024xi32>
  %result = buffer.view %destination[%base] : buffer -> view<1xi32>
  buffer.fence scope(system) ordering(acquire)
  %value = view.load %view[0] : view<1024xi32> -> i32
  view.store %value, %result[0] : i32, view<1xi32>
  kernel.return
}
'''))
rows = []
with tempfile.TemporaryDirectory(prefix='loom-load-family-') as scratch:
    for label, source in sources:
        source_path = notes / f'load-family-{label}.loom'
        source_path.write_text(source)
        for profile in ['gfx942', 'gfx1100', 'gfx1151']:
            output = Path(scratch) / 'probe.hsaco'
            result = subprocess.run([str(compiler), str(source_path), '--target=amdgpu:' + profile,
                                     '--root=load_words', '--output=' + str(output)],
                                    text=True, capture_output=True)
            (notes / f'load-family-{label}-{profile}.log').write_text(result.stdout + result.stderr)
            row = {'label': label, 'profile': profile, 'exit_code': result.returncode,
                   'source_sha256': hashlib.sha256(source.encode()).hexdigest()}
            if result.returncode == 0:
                row['native_sha256'] = hashlib.sha256(output.read_bytes()).hexdigest()
                assembly = subprocess.check_output(['llvm-objdump', '-d', str(output)], text=True)
                (notes / f'load-family-{label}-{profile}.s').write_text(assembly)
            else:
                row['diagnostic'] = result.stderr
            rows.append(row)
            print(label, profile, result.returncode, flush=True)
(notes / 'load-family-baseline.json').write_text(json.dumps({
    'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'diff_sha256': hashlib.sha256(subprocess.check_output(['git', 'diff', '--binary'])).hexdigest(),
    'compiler_sha256': hashlib.sha256(compiler.read_bytes()).hexdigest(),
    'build_flags': '--config=asan', 'rows': rows,
}, indent=2) + '\n')
