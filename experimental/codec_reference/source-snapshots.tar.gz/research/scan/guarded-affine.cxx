#include <loomcxx/kernel.h>
#include <loomcxx/vector.h>
using Pair = unsigned __attribute__((ext_vector_type(2)));
static loom::kernel::configuration configure() { return {{1,1,1},{32,1,1}}; }
static LOOM_FORCE_INLINE Pair load_pair(const unsigned* input) {
  auto view = loom::buffer::view<2>(input, {}, loom::encoding::layout::dense<1>());
  return loom::vector::load<Pair>(view, {0});
}
static LOOM_FORCE_INLINE void store_pair(Pair value, unsigned* output) {
  auto view = loom::buffer::view<2>(output, {}, loom::encoding::layout::dense<1>());
  loom::vector::store(value, view, {0});
}
[[loom::kernel(configure)]]
void guarded_record(const unsigned* input, unsigned* output) {
  unsigned lane = loom::kernel::workitem::id.x;
  Pair left = load_pair(input + lane * 4);
  Pair right = load_pair(input + lane * 4 + 2);
  if (lane >= 1) right = {right[0] * left[0], right[0] * left[1] + right[1]};
  store_pair(right, output + lane * 2);
}
[[loom::kernel(configure)]]
void guarded_components(const unsigned* input, unsigned* output) {
  unsigned lane = loom::kernel::workitem::id.x;
  Pair left = load_pair(input + lane * 4);
  Pair right = load_pair(input + lane * 4 + 2);
  unsigned left_scale = left[0], left_offset = left[1];
  unsigned right_scale = right[0], right_offset = right[1];
  if (lane >= 1) right = {right_scale * left_scale, right_scale * left_offset + right_offset};
  store_pair(right, output + lane * 2);
}
[[loom::kernel(configure)]]
void guarded_scalars(const unsigned* input, unsigned* output) {
  unsigned lane = loom::kernel::workitem::id.x;
  Pair left = load_pair(input + lane * 4);
  Pair right = load_pair(input + lane * 4 + 2);
  unsigned left_scale = left[0], left_offset = left[1];
  unsigned right_scale = right[0], right_offset = right[1];
  unsigned scale = right_scale, offset = right_offset;
  if (lane >= 1) {
    scale = right_scale * left_scale;
    offset = right_scale * left_offset + right_offset;
  }
  store_pair({scale, offset}, output + lane * 2);
}
