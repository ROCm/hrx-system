"""Owned remote staging for the launch-specialization experiment."""
from pathlib import Path
import hashlib, io, json, os, shlex, subprocess, sys, tarfile
notes=Path(__file__).resolve().parent
manifest_path=notes/'gorgon-artifacts.json'
def remote(args,**kwargs):
 try:return subprocess.run(['ssh','-o','BatchMode=yes','hrx-gorgon-3',shlex.join(args)],check=True,**kwargs)
 except subprocess.CalledProcessError as error:
  if error.stderr:print(error.stderr.decode() if isinstance(error.stderr,bytes) else error.stderr,file=sys.stderr)
  raise
def stage(files,m):
 payload=io.BytesIO()
 with tarfile.open(fileobj=payload,mode='w',dereference=True) as a:
  for n,p in files.items(): a.add(p,arcname=n,recursive=False)
 remote(['tar','-xf','-','-C',m['remote_directory']],input=payload.getvalue(),capture_output=True)
 for n,p in files.items():
  digest=hashlib.sha256(p.read_bytes()).hexdigest()
  actual=remote(['sha256sum',m['remote_directory']+'/'+n],capture_output=True,text=True).stdout.split()[0]
  assert digest==actual
  m['files'][n]={'sha256':digest,'bytes':p.stat().st_size}
 manifest_path.write_text(json.dumps(m,indent=2)+'\n')
mode=sys.argv[1]
if mode=='prepare':
 assert not manifest_path.exists()
 m={'remote_directory':remote(['mktemp','-d','/tmp/loom-scan-gorgon.XXXXXXXX'],capture_output=True,text=True).stdout.strip(),'files':{}}
 stage({'pipeline-rocprim.cpp':notes/'pipeline-rocprim.cpp','gorgon-collective.py':notes/'gorgon-collective.py','gorgon-build.sh':notes/'gorgon-build.sh'},m)
 print(m['remote_directory'])
elif mode=='stage':
 m=json.loads(manifest_path.read_text()); root=Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['scan-launch'])
 m['tag_root']=str(root)
 stage({'loom':root/'loom/src/loom/tooling/target/amdgpu/serve/scan_launch_specialization_test','compile':root/'loom/src/loom/tools/loom-compile/loom-compile','scan.loombc':root/'experimental/codec_reference/research/scan/launch_scan.loombc','control.loombc':root/'experimental/codec_reference/research/scan/thread_refresh_scan.loombc', 'flow-length.loombc':root/'experimental/codec_reference/research/scan/flow_length_scan.loombc', 'flow-loop.loombc':root/'experimental/codec_reference/research/scan/flow_loop_scan.loombc', 'flow-combined.loombc':root/'experimental/codec_reference/research/scan/flow_combined_scan.loombc'},m)
elif mode=='stage-dpp':
 m=json.loads(manifest_path.read_text()); root=Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['scan-dpp'])
 for label,name in [('launch_scan','scan.loombc'),('flow_loop_scan','flow-loop.loombc')]:
  data=(root/('experimental/codec_reference/research/scan/'+label+'.loombc')).read_bytes()
  assert hashlib.sha256(data).hexdigest()==m['files'][name]['sha256'],name
 stage({'loom-dpp':root/'loom/src/loom/tooling/target/amdgpu/serve/scan_launch_specialization_test','compile-dpp':root/'loom/src/loom/tools/loom-compile/loom-compile'},m)
elif mode=='stage-shared':
 m=json.loads(manifest_path.read_text()); root=Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['scan-dpp'])
 assert hashlib.sha256((root/'loom/src/loom/tools/loom-compile/loom-compile').read_bytes()).hexdigest()==m['files']['compile-dpp']['sha256']
 stage({name:root/('experimental/codec_reference/research/scan/shared_'+kind+'_scan.loombc') for kind,name in [('unroll','shared-unroll.loombc'),('inclusive','shared-inclusive.loombc')]},m)
elif mode=='stage-storage':
 m=json.loads(manifest_path.read_text()); root=Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['scan-dpp'])
 assert hashlib.sha256((root/'loom/src/loom/tools/loom-compile/loom-compile').read_bytes()).hexdigest()==m['files']['compile-dpp']['sha256']
 stage({name:root/('experimental/codec_reference/research/scan/storage_'+kind+'_scan.loombc') for kind,name in [('barrier','storage-barrier.loombc'),('disjoint','storage-disjoint.loombc')]},m)
elif mode=='stage-short':
 m=json.loads(manifest_path.read_text()); root=Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['scan-dpp'])
 for label,name in [('loom/src/loom/tools/loom-compile/loom-compile','compile-dpp'),('loom/src/loom/tooling/target/amdgpu/serve/scan_launch_specialization_test','loom-dpp')]:
  assert hashlib.sha256((root/label).read_bytes()).hexdigest()==m['files'][name]['sha256']
 files={'short-'+kind+'.loombc':root/('experimental/codec_reference/research/scan/short_'+kind+'_scan.loombc') for kind in ['length','input','both']}
 files['uniform-count-compare.loombc']=root/'experimental/codec_reference/research/scan/uniform_count_compare.loombc'
 stage(files,m)
elif mode=='stage-extra':
 m=json.loads(manifest_path.read_text()); stage({n:notes/n for n in sys.argv[2:]},m)
elif mode=='run':
 m=json.loads(manifest_path.read_text()); phase=sys.argv[2]
 command=['/bin/bash',m['remote_directory']+'/gorgon-'+phase+'.sh',*sys.argv[3:]]
 if phase not in ['build','build-native','build-matched','build-geometry','inspect','redundant-inspect','collective-inspect','flow-inspect','dpp-inspect','shared-inspect','storage-inspect','retune-inspect','short-inspect','short-compare-inspect']: command=['/home/benvanik/.dotfiles/bin/benchmark-lock','--label','scan-gorgon-'+phase,'--',*command]
 with (notes/('gorgon-'+phase+'.log')).open('w') as out:
  try: remote(command,stdout=out,stderr=subprocess.STDOUT); result=0
  except subprocess.CalledProcessError as e: result=e.returncode
 (notes/('gorgon-'+phase+'-run.json')).write_text(json.dumps({'command':command,'exit_code':result},indent=2)+'\n')
 print(phase,result); sys.exit(result)
elif mode=='collect':
 m=json.loads(manifest_path.read_text())
 inv=json.loads(remote(['python3','-c','from pathlib import Path; import hashlib,json,sys; p=Path(sys.argv[1]); print(json.dumps({str(f.relative_to(p)):{"sha256":hashlib.sha256(f.read_bytes()).hexdigest(),"bytes":f.stat().st_size} for f in p.rglob("*") if f.is_file()}))',m['remote_directory']],capture_output=True,text=True).stdout)
 names=[n for n in inv if '/' not in n and n.endswith(('.json','.s','.txt','.ireeprof','.csv','.hpp'))]
 names=[n for n in names if not (notes/('gorgon-'+n)).exists() or hashlib.sha256((notes/('gorgon-'+n)).read_bytes()).hexdigest()!=inv[n]['sha256']]
 if names:
  payload=remote(['tar','-cf','-','-C',m['remote_directory'],*names],capture_output=True).stdout
  with tarfile.open(fileobj=io.BytesIO(payload),mode='r:') as a:
   for member in a:
    assert member.name in names and member.isfile()
    data=a.extractfile(member).read(); assert hashlib.sha256(data).hexdigest()==inv[member.name]['sha256']
    (notes/('gorgon-'+member.name)).write_bytes(data)
 m['inventory']=inv; manifest_path.write_text(json.dumps(m,indent=2)+'\n'); print('retained',len(names))
elif mode=='retire':
 m=json.loads(manifest_path.read_text()); assert not m.get('retired') and m['remote_directory'].startswith('/tmp/loom-scan-gorgon.')
 program='''from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1]); expected=json.load(sys.stdin)
files={str(p.relative_to(root)):p for p in root.rglob('*') if p.is_file()}
assert set(files)==set(expected)
for n,p in files.items():
 assert '__pycache__' not in p.parts
 assert p.stat().st_size==expected[n]['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==expected[n]['sha256'],n
for p in files.values(): p.unlink()
print(json.dumps({'retired_files':len(files),'retired_bytes':sum(x['bytes'] for x in expected.values())}))
'''
 result=json.loads(remote(['python3','-c',program,m['remote_directory']],input=json.dumps(m['inventory']),capture_output=True,text=True).stdout)
 m.update(result,retired=True); manifest_path.write_text(json.dumps(m,indent=2)+'\n'); print(result)
else: raise ValueError(mode)
