from pathlib import Path
import collections,csv,hashlib,json,os,re,subprocess,sys,time
llvm=Path('/opt/rocm/llvm/bin')
cases=[(32,32,1,'collective-prefix2-32','scan.loombc'),
       (512,32,16,'collective-prefix2-512','scan.loombc'),
       (65537,128,8,'flow-loop','flow-loop.loombc'),
       (2097152,128,8,'collective-control-2097152','scan.loombc'),
       (16777216,64,8,'collective-control-16777216','scan.loombc')]
def config(case):return json.loads(Path(case[3]+'-config.json').read_text())
def run(case,extra):
 count,threads,items,control,source=case;c=config(case)['scan']
 args=['./loom-dpp','--scan_source='+str(Path(source).resolve()),'--amdgpu_command_buffer_mode=aql','--scan_count='+str(count)]
 for key in ['threads','items','packed_state','chain_length','refresh_rounds','ballot','local_barriers','prefix_form','lookback','indirect','fused_prefix']:
  v=c[key];args.append('--scan_'+key+'='+(str(v).lower() if isinstance(v,bool) else str(v)))
 subprocess.run([*args,*extra],check=True)
def native_arguments(case,phase):
 count,threads,items,control,source=case
 return ['./geometry',str(count),str(16 if count==16777216 else 128),str(threads),str(items),str(threads),str(items),control,'dpp-'+str(count),phase]
phase=sys.argv[1]
if phase=='inspect':
 rows=[]
 for case in cases:
  count,threads,items,control,source=case;stem='dpp-'+str(count)
  Path(stem+'-config.json').write_text(json.dumps(config(case),indent=2)+'\n')
  for entry in (['scan_single'] if count<=threads*items else ['reset_states','scan_lookback']):
   name=stem+'-'+entry;artifact=Path(name+'.hsaco')
   subprocess.run(['./compile-dpp',source,'--target=amdgpu:gfx1151','--root='+entry,'--config-file='+stem+'-config.json','--output='+str(artifact),'--compile-report=summary','--compile-report-output='+name+'-report.json'],check=True)
   assembly=subprocess.check_output([llvm/'llvm-objdump','-d',artifact],text=True);metadata=subprocess.check_output([llvm/'llvm-readelf','-n','-S',artifact],text=True)
   Path(name+'.s').write_text(assembly);Path(name+'.metadata.txt').write_text(metadata)
   row={'version':'dpp','count':count,'threads':threads,'items':items,'entry':entry,'artifact':str(artifact),'profile':stem+'.ireeprof','sha256':hashlib.sha256(artifact.read_bytes()).hexdigest(),'instructions':len(re.findall(r'//\s*[0-9a-fA-F]+:',assembly)),'text_bytes':int(re.search(r'\]\s+\.text\s+PROGBITS\s+\S+\s+\S+\s+([0-9a-fA-F]+)',metadata)[1],16)}
   for field in ['group_segment_fixed_size','private_segment_fixed_size','sgpr_count','vgpr_count','wavefront_size']:row[field]=int(re.search(r'\.'+field+r':\s+(\d+)',metadata)[1])
   assert row['private_segment_fixed_size']==0
   if entry=='reset_states':assert artifact.read_bytes()==Path(control+'-'+entry+'.hsaco').read_bytes()
   rows.append(row);print(json.dumps(row),flush=True)
 Path('dpp-native.json').write_text(json.dumps(rows,indent=2)+'\n')
 for tool in ['compile','compile-dpp']:Path('dpp-size-'+tool+'.txt').write_text(subprocess.check_output(['size','-A',tool],text=True))
elif phase=='qualify':
 print('lease='+os.environ['BENCHMARK_LOCK_LEASE_ID'],flush=True)
 for case in cases:
  count=case[0];print('case='+str(count),flush=True)
  run(case,['--gtest_filter=ScanTest.DeviceWidePrefixes:ScanTest.CapacityBoundaries'])
  run(case,['--scan_chain_length=8','--scan_indirect=true','--gtest_filter=ScanTest.StableCompactIndirectConsumer'])
  if count==65537:run(case,['--scan_chain_length=8','--scan_force_fallback=true','--scan_reverse_schedule=true','--gtest_filter=ScanTest.CapacityBoundaries'])
  run(case,['--gtest_also_run_disabled_tests','--gtest_filter=ScanTest.DISABLED_ProfileScan','--device_profiling_mode=queue-events,device-queue-events,dispatch-events','--device_profiling_output='+str(Path('dpp-'+str(count)+'.ireeprof').resolve())])
elif phase=='measure':
 print('lease='+os.environ['BENCHMARK_LOCK_LEASE_ID'],flush=True)
 idle_start=time.monotonic();previous=None
 while True:
  busy=Path('/sys/class/drm/card0/device/gpu_busy_percent').read_text().strip()
  if busy!=previous:print('preflight_gpu_busy='+busy,flush=True);previous=busy
  if busy=='0':break
  time.sleep(0.05)
 print('preflight_idle_wait_seconds='+str(time.monotonic()-idle_start),flush=True)
 print('cpu_governor='+Path('/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor').read_text().strip(),flush=True)
 print('gpu_power_level='+Path('/sys/class/drm/card0/device/power_dpm_force_performance_level').read_text().strip(),flush=True)
 subprocess.run([llvm/'llvm-objdump','--offloading','geometry'],check=True)
 images=list(Path('.').glob('geometry.*hipv4*gfx1151'));assert len(images)==1
 symbols={}
 for line in subprocess.check_output([llvm/'llvm-nm','--defined-only',images[0]],text=True).splitlines():
  parts=line.split()
  if len(parts)==3 and parts[1] in ['T','t']:symbols[subprocess.check_output(['c++filt',parts[2]],text=True).strip()]=parts[2]
 oracle_rows=json.loads(Path('oracle-identity.json').read_text())['sizes']
 def words(s):return re.findall(r'//\s*[0-9a-fA-F]+:\s*([0-9A-Fa-f ]+)',s)
 traces_proof=[]
 for case in cases:
  count,threads,items,control,source=case;oracle=next(row for row in oracle_rows if row['count']==count)
  for index,kernel in enumerate(oracle['kernels']):
   assembly=subprocess.check_output([llvm/'llvm-objdump','-d','--disassemble-symbols='+symbols[kernel['name']],images[0]],text=True)
   assert words(assembly)==words(Path(f'oracle-{count}-{index}.s').read_text())
   Path(f'dpp-oracle-{count}-{index}.s').write_text(assembly)
  directory='dpp-trace-'+str(count)
  subprocess.run(['/opt/rocm/bin/rocprofv3','--kernel-trace','--output-format','csv','--output-directory',directory,'--output-file','geometry','--',*native_arguments(case,'trace')],check=True)
  traces=list(Path(directory).rglob('*kernel_trace.csv'));assert len(traces)==1
  Path(directory+'.csv').write_bytes(traces[0].read_bytes())
  events=list(csv.DictReader(traces[0].open()));frequencies=collections.Counter(x['Kernel_Name'] for x in events)
  for kernel in oracle['kernels']:
   name=kernel['name'];assert frequencies[name]==32
   dims=sorted(set((x['Grid_Size_X'],x['Workgroup_Size_X']) for x in events if x['Kernel_Name']==name))
   assert [list(x) for x in dims]==kernel['grid_block_x']
  groups=(count+threads*items-1)//(threads*items)
  entries=['scan_single'] if groups==1 else ['reset_states','scan_lookback']
  for name in entries:
   actual=collections.Counter((int(x['Grid_Size_X']),int(x['Workgroup_Size_X'])) for x in events if x['Kernel_Name']==name)
   grid=1 if name=='scan_single' else ((groups+threads-1)//threads if name=='reset_states' else groups)
   assert actual==collections.Counter({(grid*threads,threads):64}),(count,name,actual)
  known=set(entries)|{'__amd_rocclr_copyBuffer'}|{x['name'] for x in oracle['kernels']}
  assert not(set(frequencies)-known)
  traces_proof.append({'count':count,'passed':True})
 Path('dpp-oracle-identity.json').write_text(json.dumps({'binary_sha256':hashlib.sha256(Path('geometry').read_bytes()).hexdigest(),'traces':traces_proof},indent=2)+'\n')
 subprocess.run(['vmstat','1','3'],check=True)
 for case in cases:
  print('case='+str(case[0]),flush=True);subprocess.run(native_arguments(case,'measure'),check=True)
 subprocess.run(['vmstat','1','3'],check=True)
 # Fixed source/config; process startup, parsing, specialization and emission included.
 costs=[]
 for repeat in range(10):
  for tool in (['compile','compile-dpp'] if repeat%2==0 else ['compile-dpp','compile']):
   start=time.monotonic_ns()
   result=subprocess.run(['./'+tool,'flow-loop.loombc','--target=amdgpu:gfx1151','--root=scan_lookback','--config-file=dpp-65537-config.json','--output=dpp-jit-output.hsaco'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True)
   elapsed=time.monotonic_ns()-start
   if result.stdout:print(result.stdout.decode(),flush=True)
   expected='flow-loop-scan_lookback.hsaco' if tool=='compile' else 'dpp-65537-scan_lookback.hsaco'
   assert Path('dpp-jit-output.hsaco').read_bytes()==Path(expected).read_bytes()
   costs.append({'tool':tool,'repeat':repeat,'compile_and_emit_ns':elapsed})
 Path('dpp-jit-cost.json').write_text(json.dumps(costs,indent=2)+'\n')
else:raise ValueError(phase)
