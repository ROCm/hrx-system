#include "ordered-device-algebra.h"
#include <loomcxx/predicate.h>
#include <loomcxx/target.h>

[[loom::config("scan.capacity"), loom::where(loom::predicate::range(1u, 16777216u))]]
extern const unsigned capacity;
[[loom::config("scan.subgroups"), loom::where(loom::predicate::range(1u, 16u))]]
extern const unsigned subgroup_count;
[[loom::config("scan.items"), loom::where(loom::predicate::range(1u, 16u))]]
extern const unsigned items;
[[loom::config("scan.padding_period"), loom::where(loom::predicate::range(1u, 64u))]]
extern const unsigned padding_period;
[[loom::config("scan.refresh_rounds")]] extern const unsigned refresh_rounds;
[[loom::config("scan.force_recompute")]] extern const bool force_recompute;
[[loom::config("scan.reverse_schedule")]] extern const bool reverse_schedule;
[[loom::config("scan.diagnostics")]] extern const bool diagnostics;

static loom::kernel::configuration configure_tiles() {
  unsigned threads = loom::target::subgroup::size() * subgroup_count;
  unsigned tile = threads * items;
  return {{(capacity + tile - 1) / tile, 1, 1}, {threads, 1, 1}};
}

static loom::kernel::configuration configure_reset() {
  unsigned threads = loom::target::subgroup::size() * subgroup_count;
  unsigned tile = threads * items;
  unsigned groups = (capacity + tile - 1) / tile;
  return {{(groups + threads - 1) / threads, 1, 1}, {threads, 1, 1}};
}

[[loom::kernel(configure_reset)]]
void reset_states(const unsigned* length, unsigned* states, unsigned* schedule) {
  unsigned threads = loom::kernel::workgroup::size.x;
  unsigned item = loom::kernel::workgroup::id.x * threads + loom::kernel::workitem::id.x;
  unsigned tile = threads * items;
  unsigned groups = (length[0] + tile - 1) / tile;
  if (item < groups) states[item] = 0;
  if (item == 0) {
    schedule[0] = groups;
    schedule[1] = 1;
    schedule[2] = 1;
  }
}

[[loom::kernel(configure_tiles)]]
void scan_coalesced(const unsigned* length, const Affine* input,
                 const Affine* initial, Affine* output, unsigned* states,
                 Affine* aggregates, Affine* prefixes, unsigned* counters) {
  // Finite predecessor recomputation requires disjoint immutable input.
  input = loom::buffer::assume::memory_space<loom::memory_space::constant>(input);
  length = loom::buffer::assume::memory_space<loom::memory_space::constant>(length);
  unsigned count = length[0];
  unsigned width = loom::kernel::subgroup::size();
  unsigned lane = loom::kernel::subgroup::lane_id();
  unsigned subgroup = loom::kernel::subgroup::id();
  unsigned logical_thread = subgroup * width + lane;
  unsigned threads = loom::kernel::workgroup::size.x;
  unsigned tile = threads * items;
  unsigned groups = (count + tile - 1) / tile;
  unsigned group = loom::kernel::workgroup::id.x;
  if (group >= groups) return;
  if (reverse_schedule) group = groups - 1 - group;
  unsigned begin = group * tile + logical_thread * items;
  Values scales = {};
  Values offsets = {};
  if (items == 16 && begin + items <= count) {
    auto source = loom::buffer::view<32>(
        reinterpret_cast<const unsigned*>(input + begin), {},
        loom::encoding::layout::dense<1>());
    Block values = loom::vector::load<Block>(source, {0});
    [[loom::unroll]]
    for (unsigned index = 0; index < items; ++index) {
      scales[index] = values[index * 2];
      offsets[index] = values[index * 2 + 1];
    }
  } else {
    [[loom::unroll]]
    for (unsigned index = 0; index < items; ++index) {
      Pair value = {1, 0};
      if (begin + index < count) value = read_pair(input + begin + index);
      scales[index] = value[0];
      offsets[index] = value[1];
    }
  }
  Pair total = {1, 0};
  [[loom::unroll]]
  for (unsigned index = 0; index < items; ++index) {
    total = combine(total, {scales[index], offsets[index]});
  }
  Prefix local = group_prefix(total);
  auto* carry_storage = loom::buffer::alloca<Affine, loom::memory_space::workgroup>(1);
  if (logical_thread == 0) publish(1u, local.total, group, states, aggregates);
  if (subgroup == 0) {
    Pair carry = {1, 0};
    unsigned previous = group;
    bool complete = false;
    unsigned windows = 0;
    unsigned recomputations = 0;
    unsigned terms = 0;
    while (previous > 0 && !complete) {
      if (diagnostics) ++windows;
      unsigned state = 0;
      Pair value = {1, 0};
      if (lane < previous && !force_recompute) {
        Publication publication = observe(states, aggregates, prefixes, previous - 1 - lane);
        state = publication.state;
        value = publication.value;
      }
      unsigned prefix_lane = first_matching_lane(state == 2);
      unsigned extent = previous < width ? previous : width;
      if (prefix_lane < extent) extent = prefix_lane + 1;
      unsigned missing = first_matching_lane(lane < extent && state == 0);
      for (unsigned attempt = 0; attempt < refresh_rounds && missing < width; ++attempt) {
        if (lane < extent && state == 0 && !force_recompute) {
          Publication publication = observe(states, aggregates, prefixes, previous - 1 - lane);
          state = publication.state;
          value = publication.value;
        }
        prefix_lane = first_matching_lane(state == 2);
        if (prefix_lane < extent) extent = prefix_lane + 1;
        missing = first_matching_lane(lane < extent && state == 0);
      }
      while (missing < width) {
        unsigned predecessor = previous - 1 - missing;
        unsigned observed_state = 0;
        Pair aggregate = {1, 0};
        if (lane == 0 && !force_recompute) {
          Publication publication = observe(states, aggregates, prefixes, predecessor);
          observed_state = publication.state;
          aggregate = publication.value;
        }
        observed_state = loom::kernel::subgroup::broadcast(observed_state, 0u);
        aggregate = loom::kernel::subgroup::broadcast(aggregate, 0u);
        if (observed_state == 0) {
          if (diagnostics) ++recomputations;
          aggregate = recompute(input, count, predecessor, tile);
        }
        if (lane == missing) {
          value = aggregate;
          state = observed_state ? observed_state : 1;
        }
        if (observed_state == 2) {
          extent = missing + 1;
          prefix_lane = missing;
        }
        missing = first_matching_lane(lane < extent && state == 0);
      }
      if (lane >= extent) value = {1, 0};
      carry = combine(reverse_window(value), carry);
      if (diagnostics) terms += extent;
      complete = prefix_lane < width;
      previous = previous > width ? previous - width : 0;
    }
    if (!complete) carry = combine(read_pair(initial), carry);
    if (lane == 0) {
      write_pair(carry, carry_storage);
      publish(2u, combine(carry, local.total), group, states, prefixes);
      if (diagnostics) {
        counters[group * 3] = windows;
        counters[group * 3 + 1] = recomputations;
        counters[group * 3 + 2] = terms;
      }
    }
  }
  local_barrier();
  Pair prefix = combine(read_pair(carry_storage), local.exclusive);
  auto* exchange = loom::buffer::alloca<Affine, loom::memory_space::workgroup>(
      tile + tile / padding_period);
  [[loom::unroll]]
  for (unsigned index = 0; index < items; ++index) {
    unsigned rank = logical_thread * items + index;
    write_pair(prefix, exchange + rank + rank / padding_period);
    prefix = combine(prefix, {scales[index], offsets[index]});
  }
  local_barrier();
  [[loom::unroll]]
  for (unsigned index = 0; index < items; ++index) {
    unsigned rank = index * threads + logical_thread;
    unsigned position = group * tile + rank;
    if (position < count) {
      write_pair(read_pair(exchange + rank + rank / padding_period),
                 output + position);
    }
  }
}
