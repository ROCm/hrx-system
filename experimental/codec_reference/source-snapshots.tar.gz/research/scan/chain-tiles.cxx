#include <loomcxx/kernel.h>
#include <loomcxx/atomic.h>
#include <loomcxx/target.h>
#include <loomcxx/vector.h>

[[loom::config("scan.inclusive")]] extern const bool inclusive;
[[loom::config("scan.reverse")]] extern const bool reverse;
[[loom::config("scan.compact")]] extern const bool compact;
[[loom::config("scan.portable")]] extern const bool portable;
[[loom::config("scan.threads")]] extern const unsigned configured_threads;
[[loom::config("scan.items")]] extern const unsigned items;
[[loom::config("scan.lookback")]] extern const bool lookback;
[[loom::config("scan.force_fallback")]] extern const bool force_fallback;
[[loom::config("scan.reverse_schedule")]] extern const bool reverse_schedule;
using Values = unsigned __attribute__((ext_vector_type(16)));
using Packet = unsigned __attribute__((ext_vector_type(4)));

static loom::kernel::configuration configure_tiles(unsigned capacity) {
  unsigned threads = (configured_threads ? configured_threads : loom::target::subgroup::size() * 4);
  return {{(capacity + threads * items - 1) / (threads * items), 1, 1},
          {threads, 1, 1}};
}

static loom::kernel::configuration configure_consumer(unsigned capacity) {
  unsigned threads = (configured_threads ? configured_threads : loom::target::subgroup::size() * 4);
  return {{(capacity + threads - 1) / threads, 1, 1}, {threads, 1, 1}};
}

static loom::kernel::configuration configure_one() {
  return {{1, 1, 1}, {(configured_threads ? configured_threads : loom::target::subgroup::size() * 4), 1, 1}};
}

// Portable workgroup-only baseline; no inter-workgroup waiting. The final
// barrier protects the returned register values before a loop reuses scratch.
struct Prefix {
  unsigned exclusive;
  unsigned total;
};
static LOOM_FORCE_INLINE Prefix local_prefix(unsigned value) {
  if (!portable) {
    return {loom::kernel::workgroup::scan::addi<
              loom::kernel::scan_mode::exclusive>(value),
            loom::kernel::workgroup::reduce::addi(value)};
  }
  unsigned item = loom::kernel::workitem::id.x;
  unsigned threads = loom::kernel::workgroup::size.x;
  auto* storage = loom::buffer::alloca<unsigned, loom::memory_space::workgroup>(threads);
  storage[item] = value;
  loom::kernel::workgroup::barrier();
  for (unsigned distance = 1; distance < threads; distance *= 2) {
    unsigned previous = storage[(item + threads - distance) % threads];
    if (item < distance) previous = 0;
    loom::kernel::workgroup::barrier();
    value += previous;
    storage[item] = value;
    loom::kernel::workgroup::barrier();
  }
  unsigned previous = storage[(item + threads - 1) % threads];
  Prefix result = {item ? previous : 0, storage[threads - 1]};
  loom::kernel::workgroup::barrier();
  return result;
}

static LOOM_FORCE_INLINE unsigned read_input(const unsigned* input,
                                             unsigned position, unsigned count) {
  if (position >= count) return 0;
  return input[reverse ? count - 1 - position : position];
}

static LOOM_FORCE_INLINE unsigned read_value(const unsigned* input,
                                             unsigned position, unsigned count) {
  unsigned value = read_input(input, position, count);
  return compact ? (value & 1) : value;
}

template <bool Full>
static LOOM_FORCE_INLINE Packet read_packet(const unsigned* input,
    unsigned begin, unsigned count) {
  if (Full || begin + 4 <= count) {
    auto source = loom::buffer::view<4>(
        input + (reverse ? count - begin - 4 : begin), {},
        loom::encoding::layout::dense<1>());
    Packet result = loom::vector::load<Packet>(source, {0});
    return reverse ? Packet{result[3], result[2], result[1], result[0]} : result;
  }
  return {read_input(input, begin, count),
          read_input(input, begin + 1, count),
          read_input(input, begin + 2, count),
          read_input(input, begin + 3, count)};
}

template <bool Full>
static LOOM_FORCE_INLINE Values read_data_packets(const unsigned* input,
    unsigned begin, unsigned count) {
  Packet a = read_packet<Full>(input, begin, count);
  Packet b = {};
  Packet c = {};
  Packet d = {};
  if (items > 4) b = read_packet<Full>(input, begin + 4, count);
  if (items > 8) {
    c = read_packet<Full>(input, begin + 8, count);
    d = read_packet<Full>(input, begin + 12, count);
  }
  return {a[0], a[1], a[2], a[3], b[0], b[1], b[2], b[3],
          c[0], c[1], c[2], c[3], d[0], d[1], d[2], d[3]};
}

static LOOM_FORCE_INLINE Values read_data_values(const unsigned* input,
    unsigned begin, unsigned count) {
  if (items > 4 && begin + items <= count) return read_data_packets<true>(input, begin, count);
  return read_data_packets<false>(input, begin, count);
}

template <bool Full>
static LOOM_FORCE_INLINE void write_packet(Packet value, unsigned* output,
    unsigned begin, unsigned count) {
  if (Full || begin + 4 <= count) {
    auto destination = loom::buffer::view<4>(
        output + (reverse ? count - begin - 4 : begin), {},
        loom::encoding::layout::dense<1>());
    loom::vector::store(reverse ? Packet{value[3], value[2], value[1], value[0]} : value, destination, {0});
  } else {
    [[loom::unroll]]
    for (unsigned index = 0; index < 4; ++index) {
      unsigned position = begin + index;
      if (position < count) {
        output[reverse ? count - 1 - position : position] = value[index];
      }
    }
  }
}

static LOOM_FORCE_INLINE unsigned sum_values(Values values) {
  unsigned sum = 0;
  [[loom::unroll]]
  for (unsigned index = 0; index < items; ++index) {
    sum += compact ? (values[index] & 1) : values[index];
  }
  return sum;
}

// A device-read length changes the dispatch grid without changing the compiled
// program. Its caller guarantees length <= the planned input capacity.
[[loom::kernel(configure_one)]]
void prepare(const unsigned* length, unsigned* schedule) {
  if (loom::kernel::workitem::id.x == 0) {
    unsigned tile = loom::kernel::workgroup::size.x * items;
    schedule[0] = (length[0] + tile - 1) / tile;
    schedule[1] = 1;
    schedule[2] = 1;
  }
}

[[loom::kernel(configure_tiles)]]
void reduce_tiles(const unsigned* length, const unsigned* input,
                  unsigned* totals) {
  unsigned item = loom::kernel::workitem::id.x;
  unsigned group = loom::kernel::workgroup::id.x;
  unsigned threads = loom::kernel::workgroup::size.x;
  unsigned count = length[0];
  unsigned begin = (group * threads + item) * items;
  unsigned sum = sum_values(read_data_values(input, begin, count));
  unsigned total = local_prefix(sum).total;
  if (item == 0) totals[group] = total;
}

// Hierarchical control: at most one tile is scanned serially by each workgroup.
static LOOM_FORCE_INLINE void scan_summary_tile(unsigned count,
    const unsigned* input, unsigned* output, unsigned carry) {
  unsigned item = loom::kernel::workitem::id.x;
  unsigned threads = loom::kernel::workgroup::size.x;
  unsigned begin = (loom::kernel::workgroup::id.x * threads + item) * items;
  Values values = {begin + 0 < count ? input[begin + 0] : 0,
                  begin + 1 < count ? input[begin + 1] : 0,
                  begin + 2 < count ? input[begin + 2] : 0,
                  begin + 3 < count ? input[begin + 3] : 0,
                  begin + 4 < count ? input[begin + 4] : 0,
                  begin + 5 < count ? input[begin + 5] : 0,
                  begin + 6 < count ? input[begin + 6] : 0,
                  begin + 7 < count ? input[begin + 7] : 0,
                  begin + 8 < count ? input[begin + 8] : 0,
                  begin + 9 < count ? input[begin + 9] : 0,
                  begin + 10 < count ? input[begin + 10] : 0,
                  begin + 11 < count ? input[begin + 11] : 0,
                  begin + 12 < count ? input[begin + 12] : 0,
                  begin + 13 < count ? input[begin + 13] : 0,
                  begin + 14 < count ? input[begin + 14] : 0,
                  begin + 15 < count ? input[begin + 15] : 0};
  unsigned sum = 0;
  [[loom::unroll]]
  for (unsigned i = 0; i < items; ++i) { sum += values[i]; }
  carry += local_prefix(sum).exclusive;
  [[loom::unroll]]
  for (unsigned i = 0; i < items; ++i) {
    if (begin + i < count) output[begin + i] = carry;
    carry += values[i];
  }
}

[[loom::kernel(configure_one)]]
void prefix_summaries(const unsigned* schedule, const unsigned* totals,
                      unsigned* prefixes) {
  scan_summary_tile(schedule[0], totals, prefixes, 0);
}

[[loom::kernel(configure_tiles)]]
void reduce_summaries(const unsigned* schedule, const unsigned* totals,
                     unsigned* upper_totals) {
  unsigned item = loom::kernel::workitem::id.x;
  unsigned group = loom::kernel::workgroup::id.x;
  unsigned begin = (group * loom::kernel::workgroup::size.x + item) * items;
  unsigned sum = 0;
  [[loom::unroll]]
  for (unsigned i = 0; i < items; ++i) {
    if (begin + i < schedule[0]) sum += totals[begin + i];
  }
  unsigned total = local_prefix(sum).total;
  if (item == 0) upper_totals[group] = total;
}

[[loom::kernel(configure_one)]]
void prefix_upper_summaries(const unsigned* schedule, const unsigned* totals,
                            unsigned* prefixes) {
  unsigned tile = loom::kernel::workgroup::size.x * items;
  scan_summary_tile((schedule[0] + tile - 1) / tile, totals, prefixes, 0);
}

[[loom::kernel(configure_tiles)]]
void scan_summaries(const unsigned* schedule, const unsigned* totals,
                    const unsigned* upper_prefixes, unsigned* prefixes) {
  scan_summary_tile(schedule[0], totals, prefixes,
                    upper_prefixes[loom::kernel::workgroup::id.x]);
}

template <bool Full>
static LOOM_FORCE_INLINE unsigned write_scan_packet(Packet value,
    unsigned* output, unsigned begin, unsigned count, unsigned carry) {
  unsigned first = carry;
  unsigned second = first + value[0];
  unsigned third = second + value[1];
  unsigned fourth = third + value[2];
  Packet result = {first, second, third, fourth};
  if (inclusive) result += value;
  write_packet<Full>(result, output, begin, count);
  return fourth + value[3];
}

template <bool Full>
static LOOM_FORCE_INLINE unsigned write_scan_values(unsigned count,
    unsigned* output, unsigned begin, Values values, unsigned carry) {
    carry = write_scan_packet<Full>(loom::vector::slice<Packet>(values, 0),
                             output, begin, count, carry);
    if (items > 4) {
      carry = write_scan_packet<Full>(loom::vector::slice<Packet>(values, 4),
                               output, begin + 4, count, carry);
    }
    if (items > 8) {
      carry = write_scan_packet<Full>(loom::vector::slice<Packet>(values, 8),
                               output, begin + 8, count, carry);
      carry = write_scan_packet<Full>(loom::vector::slice<Packet>(values, 12),
                               output, begin + 12, count, carry);
    }
  return carry;
}

static LOOM_FORCE_INLINE unsigned write_data_values(unsigned count,
    unsigned* output, unsigned begin, Values values, unsigned carry) {
  if (!compact) {
    if (items > 4 && begin + items <= count) {
      return write_scan_values<true>(count, output, begin, values, carry);
    }
    return write_scan_values<false>(count, output, begin, values, carry);
  }
  [[loom::unroll]]
  for (unsigned index = 0; index < items; ++index) {
    unsigned position = begin + index;
    unsigned value = compact ? (values[index] & 1) : values[index];
    unsigned prefix = inclusive ? carry + value : carry;
    carry += value;
    if (position < count) {
      unsigned destination = reverse ? count - 1 - position : position;
      if (compact) {
        if (value) output[carry - 1] = values[index];
      } else {
        output[destination] = prefix;
      }
    }
  }
  return carry;
}

static LOOM_FORCE_INLINE unsigned scan_tile_values(unsigned count,
    const unsigned* input, unsigned* output, unsigned initial) {
  unsigned begin = (loom::kernel::workgroup::id.x *
      loom::kernel::workgroup::size.x + loom::kernel::workitem::id.x) * items;
  Values values = read_data_values(input, begin, count);
  unsigned carry = initial + local_prefix(sum_values(values)).exclusive;
  return write_data_values(count, output, begin, values, carry);
}

[[loom::kernel(configure_tiles)]]
void scan_tiles(const unsigned* length, const unsigned* input,
                const unsigned* prefixes, unsigned* output) {
  scan_tile_values(length[0], input, output,
                    prefixes[loom::kernel::workgroup::id.x]);
}

[[loom::kernel(configure_one)]]
void scan_single(const unsigned* length, const unsigned* input, unsigned* output) {
  scan_tile_values(length[0], input, output, 0);
}

[[loom::kernel(configure_one)]]
void compact_single(const unsigned* length, const unsigned* input,
                     unsigned* output, unsigned* selected) {
  unsigned carry = scan_tile_values(length[0], input, output, 0);
  unsigned threads = loom::kernel::workgroup::size.x;
  if (loom::kernel::workitem::id.x == threads - 1) {
    selected[0] = (carry + threads - 1) / threads;
    selected[1] = 1;
    selected[2] = 1;
    selected[3] = carry;
  }
}

[[loom::kernel(configure_one)]]
void publish_count(const unsigned* schedule, const unsigned* totals,
                   const unsigned* prefixes, unsigned* selected) {
  if (loom::kernel::workitem::id.x == 0) {
    unsigned tiles = schedule[0];
    unsigned count = tiles ? prefixes[tiles - 1] + (lookback ? 0 : totals[tiles - 1]) : 0;
    selected[0] = (count + loom::kernel::workgroup::size.x - 1) /
                  loom::kernel::workgroup::size.x;
    selected[1] = 1;
    selected[2] = 1;
    selected[3] = count;
  }
}

[[loom::kernel(configure_consumer)]]
void consume(const unsigned* selected, const unsigned* input, unsigned* output) {
  unsigned item = loom::kernel::workgroup::id.x * loom::kernel::workgroup::size.x +
                  loom::kernel::workitem::id.x;
  if (item < selected[3]) output[item] = input[item] * 3 + 7;
}

// One immutable aggregate and prefix per tile, with a separately published flag.
// Ordered reset permits reuse without generation tags or stale-state ambiguity.
[[loom::kernel(configure_tiles)]]
void reset_states(const unsigned* length, unsigned* states, unsigned* schedule) {
  unsigned item = loom::kernel::workgroup::id.x * loom::kernel::workgroup::size.x +
                  loom::kernel::workitem::id.x;
  unsigned tile = loom::kernel::workgroup::size.x * items;
  unsigned groups = (length[0] + tile - 1) / tile;
  [[loom::unroll]]
  for (unsigned index = 0; index < items; ++index) {
    unsigned position = item * items + index;
    if (position < groups) states[position] = 0;
  }
  if (item == 0) {
    schedule[0] = groups;
    schedule[1] = 1;
    schedule[2] = 1;
  }
}

[[loom::kernel(configure_tiles)]]
void scan_lookback(const unsigned* length, const unsigned* input, unsigned* output,
                   unsigned* states, unsigned* aggregates, unsigned* prefixes) {
  // The caller keeps input immutable and disjoint from all writable storage.
  input = loom::buffer::assume_memory_space<loom::memory_space::constant>(input);
  unsigned item = loom::kernel::workitem::id.x;
  unsigned threads = loom::kernel::workgroup::size.x;
  unsigned tile = threads * items;
  unsigned count = length[0];
  unsigned groups = (count + tile - 1) / tile;
  unsigned group = loom::kernel::workgroup::id.x;
  if (group >= groups) return;
  if (reverse_schedule) group = groups - 1 - group;
  unsigned begin = group * tile + item * items;
  Values values = read_data_values(input, begin, count);
  Prefix local = local_prefix(sum_values(values));
  auto* carry_storage = loom::buffer::alloca<unsigned, loom::memory_space::workgroup>(1);
  if (item == 0) {
    aggregates[group] = local.total;
    loom::view::atomic::store<loom::atomic::ordering::release,
        loom::atomic::scope::device>(1u, states + group);
  }
  unsigned width = loom::kernel::subgroup::size();
  if (item < width) {
    unsigned carry = 0;
    unsigned previous = group;
    bool complete = false;
    while (previous > 0 && !complete) {
      unsigned state = 0;
      unsigned value = 0;
      if (item < previous && !force_fallback) {
        unsigned predecessor = previous - 1 - item;
        state = loom::view::atomic::load<loom::atomic::ordering::acquire,
            loom::atomic::scope::device>(states + predecessor);
        if (state == 1) value = aggregates[predecessor];
        if (state == 2) value = prefixes[predecessor];
      }
      unsigned prefix_lane = loom::kernel::subgroup::reduce::minui(
          state == 2 ? item : width);
      unsigned extent = previous < width ? previous : width;
      if (prefix_lane < extent) extent = prefix_lane + 1;
      unsigned missing = loom::kernel::subgroup::reduce::minui(
          item < extent && state == 0 ? item : width);
      while (missing < width) {
        unsigned predecessor = previous - 1 - missing;
        unsigned observed_state = 0;
        unsigned aggregate = 0;
        if (item == 0 && !force_fallback) {
          observed_state = loom::view::atomic::load<loom::atomic::ordering::acquire,
              loom::atomic::scope::device>(states + predecessor);
          if (observed_state == 1) aggregate = aggregates[predecessor];
          if (observed_state == 2) aggregate = prefixes[predecessor];
        }
        observed_state = loom::kernel::subgroup::broadcast(observed_state, 0);
        aggregate = loom::kernel::subgroup::broadcast(aggregate, 0);
        if (observed_state == 0) {
          unsigned partial = 0;
          for (unsigned position = item; position < tile; position += width) {
            partial += read_value(input, predecessor * tile + position, count);
          }
          aggregate = loom::kernel::subgroup::reduce::addi(partial);
        }
        if (item == missing) {
          value = aggregate;
          state = observed_state ? observed_state : 1;
        }
        if (observed_state == 2) {
          extent = missing + 1;
          prefix_lane = missing;
        }
        missing = loom::kernel::subgroup::reduce::minui(
            item < extent && state == 0 ? item : width);
      }
      unsigned subtotal = loom::kernel::subgroup::reduce::addi(
          item < extent ? value : 0);
      carry = subtotal + carry;
      complete = prefix_lane < width;
      previous = previous > width ? previous - width : 0;
    }
    if (item == 0) {
      carry_storage[0] = carry;
      prefixes[group] = carry + local.total;
      loom::view::atomic::store<loom::atomic::ordering::release,
          loom::atomic::scope::device>(2u, states + group);
    }
  }
  loom::kernel::workgroup::barrier();
  write_data_values(count, output, begin, values,
                    carry_storage[0] + local.exclusive);
}
