"""Probe the full native comparison operand family using installed LLVM MC."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

llvm = Path('/opt/rocm/llvm/bin/llvm-mc')
cpus = ['gfx900', 'gfx908', 'gfx90a', 'gfx942', 'gfx950', 'gfx1010', 'gfx1030', 'gfx1100', 'gfx1151', 'gfx1170', 'gfx1200', 'gfx1250']
rows = []
for cpu in cpus:
    for wave in ([64] if cpu.startswith('gfx9') else [32, 64]):
        mask = 's[0:1]' if wave == 64 else 's0'
        cases = []
        families = {'i32': ['eq','ne','lt','le','gt','ge'], 'u32': ['lt','le','gt','ge']}
        for width in [16, 32, 64]:
            families[f'f{width}'] = ['eq','gt','ge','lt','le','lg','o','nlg','nle','nlt','nge','ngt','neq','u']
        for kind, predicates in families.items():
            scalar = 's[4:5]' if kind == 'f64' else 's4'
            other_scalar = 's[6:7]' if kind == 'f64' else 's6'
            vector = 'v[2:3]' if kind == 'f64' else 'v2'
            other_vector = 'v[4:5]' if kind == 'f64' else 'v4'
            immediate = '1.0' if kind.startswith('f') else '1'
            for predicate in predicates:
                for form, lhs, rhs in [('sv',scalar,vector),('vs',vector,scalar),('vv',vector,other_vector),('ss',scalar,other_scalar),('same',scalar,scalar),('si',scalar,immediate),('is',immediate,scalar)]:
                    cases.append({'kind':kind,'predicate':predicate,'form':form,'assembly':f'v_cmp_{predicate}_{kind}_e64 {mask}, {lhs}, {rhs}'})
        source = '.text\n' + '\n'.join(c['assembly'] for c in cases) + '\n'
        arguments = [str(llvm),'--triple=amdgcn-amd-amdhsa','--mcpu='+cpu,'--mattr=+wavefrontsize'+str(wave),'--show-encoding']
        result = subprocess.run(arguments,input=source,text=True,capture_output=True)
        errors = {}
        for match in re.finditer(r'<stdin>:(\d+):\d+: error: ([^\n]+)',result.stderr):
            errors[int(match[1])-2] = match[2]
        assert (result.returncode == 0) == (not errors), (cpu,wave,result.stderr)
        encodings = iter(line.strip() for line in result.stdout.splitlines() if 'encoding:' in line)
        for index, case in enumerate(cases):
            case['error'] = errors.get(index)
            if index not in errors:
                case['encoding'] = next(encodings)
        assert next(encodings,None) is None
        rows.append({'cpu':cpu,'wave':wave,'command':arguments,'cases':cases,'stderr':result.stderr})
print(json.dumps({'llvm_path':str(llvm.resolve()),'llvm_sha256':hashlib.sha256(llvm.read_bytes()).hexdigest(),'version':subprocess.check_output([str(llvm),'--version'],text=True),'rows':rows},indent=2))
