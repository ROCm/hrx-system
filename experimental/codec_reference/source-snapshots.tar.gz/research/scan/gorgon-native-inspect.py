from pathlib import Path
import json,hashlib,subprocess
rows=[]
for label in ['control','both']:
 config=json.loads(Path(f'collective-{label}-65537-config.json').read_text())
 config['scan']['capacity']=2097152
 stem=f'collective-{label}-2097152'
 Path(stem+'-config.json').write_text(json.dumps(config,indent=2)+'\n')
 for entry in ['reset_states','scan_lookback']:
  artifact=stem+'-'+entry+'.hsaco'
  subprocess.run(['./compile','scan.loombc','--target=amdgpu:gfx1151','--root='+entry,'--config-file='+stem+'-config.json','--output='+artifact,'--compile-report=details','--compile-report-output='+stem+'-'+entry+'-report.json'],check=True)
  same=Path(f'collective-{label}-65537-{entry}.hsaco').read_bytes()==Path(artifact).read_bytes()
  assert same,artifact
  rows.append({'artifact':artifact,'sha256':hashlib.sha256(Path(artifact).read_bytes()).hexdigest(),'equal_to_65537':same})
Path('native-comparison-additional.json').write_text(json.dumps(rows,indent=2)+'\n')
