from pathlib import Path
import collections,csv,hashlib,json,os,re,subprocess,sys,time

llvm=Path('/opt/rocm/llvm/bin')
count=65537
base=json.loads(Path('collective-both-65537-config.json').read_text())
cases=[(f'{threads}x{items}-{kind}',threads,items,kind=='both')
       for threads,items in [(64,16),(128,8),(256,4),(512,2),(1024,1)]
       for kind in ['both','ballot'] if (threads,kind)!=(128,'both')]
def config(case):
 label,threads,items,fused=case
 result={'scan':dict(base['scan'])}
 result['scan'].update(threads=threads,items=items,fused_prefix=fused,local_barriers=fused)
 return result
def run(case,extra):
 c=config(case)['scan']
 args=['./loom','--scan_source='+str(Path('scan.loombc').resolve()),'--amdgpu_command_buffer_mode=aql','--scan_count=65537']
 for key in ['threads','items','packed_state','chain_length','refresh_rounds','ballot','local_barriers','prefix_form','lookback','indirect','fused_prefix']:
  v=c[key];args.append('--scan_'+key+'='+(str(v).lower() if isinstance(v,bool) else str(v)))
 subprocess.run([*args,*extra],check=True)
def native_arguments(case,phase):
 label,threads,items,fused=case
 return ['./geometry','65537','128','128','8',str(threads),str(items),'collective-both-65537','geometry-'+label,phase]
phase=sys.argv[1]
if phase=='inspect':
 rows=[]
 for case in cases:
  label,threads,items,fused=case;stem='geometry-'+label
  Path(stem+'-config.json').write_text(json.dumps(config(case),indent=2)+'\n')
  for entry in ['reset_states','scan_lookback']:
   name=stem+'-'+entry;artifact=Path(name+'.hsaco')
   subprocess.run(['./compile','scan.loombc','--target=amdgpu:gfx1151','--root='+entry,'--config-file='+stem+'-config.json','--output='+str(artifact),'--compile-report=summary','--compile-report-output='+name+'-report.json'],check=True)
   assembly=subprocess.check_output([llvm/'llvm-objdump','-d',artifact],text=True);metadata=subprocess.check_output([llvm/'llvm-readelf','-n','-S',artifact],text=True)
   Path(name+'.s').write_text(assembly);Path(name+'.metadata.txt').write_text(metadata)
   row={'version':label,'count':count,'threads':threads,'items':items,'entry':entry,'artifact':str(artifact),'profile':stem+'.ireeprof','sha256':hashlib.sha256(artifact.read_bytes()).hexdigest(),'instructions':len(re.findall(r'//\s*[0-9a-fA-F]+:',assembly)),'text_bytes':int(re.search(r'\]\s+\.text\s+PROGBITS\s+\S+\s+\S+\s+([0-9a-fA-F]+)',metadata)[1],16)}
   for field in ['group_segment_fixed_size','private_segment_fixed_size','sgpr_count','vgpr_count','wavefront_size']:row[field]=int(re.search(r'\.'+field+r':\s+(\d+)',metadata)[1])
   rows.append(row);print(json.dumps(row),flush=True)
 Path('geometry-native.json').write_text(json.dumps(rows,indent=2)+'\n')
elif phase=='qualify':
 print('lease='+os.environ['BENCHMARK_LOCK_LEASE_ID'],flush=True)
 for case in cases:
  print('case='+case[0],flush=True)
  run(case,['--gtest_filter=ScanTest.DeviceWidePrefixes:ScanTest.CapacityBoundaries'])
  run(case,['--scan_chain_length=8','--scan_indirect=true','--gtest_filter=ScanTest.StableCompactIndirectConsumer'])
  run(case,['--scan_chain_length=8','--scan_force_fallback=true','--scan_reverse_schedule=true','--gtest_filter=ScanTest.CapacityBoundaries'])
  run(case,['--gtest_also_run_disabled_tests','--gtest_filter=ScanTest.DISABLED_ProfileScan','--device_profiling_mode=queue-events,device-queue-events,dispatch-events','--device_profiling_output='+str(Path('geometry-'+case[0]+'.ireeprof').resolve())])
elif phase=='measure':
 print('lease='+os.environ['BENCHMARK_LOCK_LEASE_ID'],flush=True)
 # Hold exclusion until the GPU reports idle; earlier lease work may still
 # be reflected in the hardware activity sample. No GPU job starts here.
 idle_start=time.monotonic();previous=None
 while True:
  busy=Path('/sys/class/drm/card0/device/gpu_busy_percent').read_text().strip()
  if busy!=previous:print('preflight_gpu_busy='+busy,flush=True);previous=busy
  if busy=='0':break
  time.sleep(0.05)
 print('preflight_idle_wait_seconds='+str(time.monotonic()-idle_start),flush=True)
 print('cpu_governor='+Path('/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor').read_text().strip(),flush=True)
 print('gpu_power_level='+Path('/sys/class/drm/card0/device/power_dpm_force_performance_level').read_text().strip(),flush=True)
 subprocess.run([llvm/'llvm-objdump','--offloading','geometry'],check=True)
 images=list(Path('.').glob('geometry.*hipv4*gfx1151'));assert len(images)==1
 symbols={}
 for line in subprocess.check_output([llvm/'llvm-nm','--defined-only',images[0]],text=True).splitlines():
  parts=line.split()
  if len(parts)==3 and parts[1] in ['T','t']:symbols[subprocess.check_output(['c++filt',parts[2]],text=True).strip()]=parts[2]
 oracle=next(row for row in json.loads(Path('oracle-identity.json').read_text())['sizes'] if row['count']==count)
 def words(s):return re.findall(r'//\s*[0-9a-fA-F]+:\s*([0-9A-Fa-f ]+)',s)
 for index,kernel in enumerate(oracle['kernels']):
  assembly=subprocess.check_output([llvm/'llvm-objdump','-d','--disassemble-symbols='+symbols[kernel['name']],images[0]],text=True)
  assert words(assembly)==words(Path(f'oracle-65537-{index}.s').read_text())
  Path(f'geometry-oracle-{index}.s').write_text(assembly)
 traces_proof=[]
 for case in cases:
  label,threads,items,fused=case;directory='geometry-trace-'+label
  subprocess.run(['/opt/rocm/bin/rocprofv3','--kernel-trace','--output-format','csv','--output-directory',directory,'--output-file','geometry','--',*native_arguments(case,'trace')],check=True)
  traces=list(Path(directory).rglob('*kernel_trace.csv'));assert len(traces)==1
  Path('geometry-trace-'+label+'.csv').write_bytes(traces[0].read_bytes())
  events=list(csv.DictReader(traces[0].open()));frequencies=collections.Counter(x['Kernel_Name'] for x in events)
  for kernel in oracle['kernels']:
   name=kernel['name'];assert frequencies[name]==32
   dims=sorted(set((x['Grid_Size_X'],x['Workgroup_Size_X']) for x in events if x['Kernel_Name']==name))
   assert [list(x) for x in dims]==kernel['grid_block_x']
  for name in ['reset_states','scan_lookback']:
   actual=collections.Counter((int(x['Grid_Size_X']),int(x['Workgroup_Size_X'])) for x in events if x['Kernel_Name']==name)
   expected=collections.Counter()
   for t in [128,threads]:expected[((65+t-1)//t*t if name=='reset_states' else 65*t,t)]+=32
   assert actual==expected,(label,name,actual,expected)
  known={'reset_states','scan_lookback','__amd_rocclr_copyBuffer'}|{x['name'] for x in oracle['kernels']}
  assert not (set(frequencies)-known)
  traces_proof.append({'case':label,'passed':True})
 Path('geometry-oracle-identity.json').write_text(json.dumps({'binary_sha256':hashlib.sha256(Path('geometry').read_bytes()).hexdigest(),'traces':traces_proof},indent=2)+'\n')
 subprocess.run(['vmstat','1','3'],check=True)
 for case in cases:
  print('case='+case[0],flush=True)
  subprocess.run(native_arguments(case,'measure'),check=True)
 subprocess.run(['vmstat','1','3'],check=True)
else:raise ValueError(phase)
