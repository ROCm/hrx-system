"""Probe aligned packed payloads, strided packets, and address carriers."""

from pathlib import Path
import hashlib
import json
import resource
import subprocess
import sys
import tempfile

notes = Path(__file__).resolve().parent
compiler = Path('bazel-bin/loom/src/loom/tools/loom-compile/loom-compile').resolve()
variant = sys.argv[1]
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
base = (notes / 'uniform-three-word-load.loom').read_text().replace('load_three', 'load_words')
base = base.replace('  %constant_input =', '  %aligned = buffer.assume.alignment %input {minimum_alignment = 16} : buffer\n  %constant_input =')
base = base.replace('space<constant> %input', 'space<constant> %aligned')
sources = []
for element, bytes_per_element in [('i8', 1), ('i16', 2), ('i32', 4), ('i64', 8),
                                  ('f8E4M3', 1), ('f8E5M2', 1), ('f16', 2), ('bf16', 2), ('f32', 4), ('f64', 8)]:
    for words in [1, 2, 3, 4]:
        if (words * 4) % bytes_per_element:
            continue
        count = words * 4 // bytes_per_element
        source = base.replace('3xi32', f'{count}x{element}')
        sources.append((f'aligned-{element}-{words}', source))
        if words in [1, 3] or bytes_per_element == 8:
            stride = max(2, 4 // bytes_per_element)
            strided = source.replace('  %view =', f'  %layout = encoding.layout.strided [{stride}] : encoding<layout>\n  %view =')
            strided = strided.replace(f'%constant_input[%base] : buffer -> view<{count}x{element}>',
                                      f'%constant_input[%base] : buffer -> view<{count}x{element}, %layout>')
            strided = strided.replace(f'vector.load %view[0] : view<{count}x{element}>',
                                      f'vector.load %view[0] : view<{count}x{element}, %layout>')
            sources.append((f'strided-{element}-{words}', strided))
for words in [1, 2, 3, 4]:
    source = base.replace('3xi32', f'{words}xi32')
    for offset in [4, 2097148, 4294967296]:
        shifted = source.replace('  %view =', f'  %input_offset = index.constant {offset} : offset\n  %view =')
        shifted = shifted.replace('%constant_input[%base]', '%constant_input[%input_offset]')
        sources.append((f'offset-{offset}-{words}', shifted))
    dynamic = source.replace('%output: buffer)', '%output: buffer, %position: offset)')
    dynamic = dynamic.replace('  %view =', '  %input_offset = index.assume %position [multiple_of(%position, 4)] : offset\n  %view =')
    dynamic = dynamic.replace('%constant_input[%base]', '%constant_input[%input_offset]')
    sources.append((f'dynamic-offset-{words}', dynamic))

for element, elements_per_word in [('i8', 4), ('i16', 2), ('i32', 1)]:
    for words in [1, 2, 3, 4]:
        count = words * elements_per_word
        source = base.replace('3xi32', f'{count}x{element}')
        source = source.replace('%output: buffer)', '%output: buffer, %row_input: index, %pitch_input: index)')
        source = source.replace('  %view =', '''  %row = index.assume %row_input [range(%row_input, 0, 7)] : index
  %pitch = index.assume %pitch_input [range(%pitch_input, 16, 1073741808), multiple_of(%pitch_input, 16)] : index
  %layout = encoding.layout.strided [%pitch, 1] : encoding<layout>
  %view =''')
        source = source.replace(f'%constant_input[%base] : buffer -> view<{count}x{element}>',
                                f'%constant_input[%base] : buffer -> view<8x{count}x{element}, %layout>')
        source = source.replace(f'vector.load %view[0] : view<{count}x{element}>',
                                f'vector.load %view[%row, 0] : view<8x{count}x{element}, %layout>')
        sources.append((f'dynamic-pitch-{element}-{words}', source))

rows = []
with tempfile.TemporaryDirectory(prefix='loom-load-extended-') as scratch:
    for label, source in sources:
        source_path = notes / f'load-extended-{label}.loom'
        source_path.write_text(source)
        for profile in ['gfx942', 'gfx1151', 'gfx1201']:
            output = Path(scratch) / 'probe.hsaco'
            result = subprocess.run([str(compiler), str(source_path), '--target=amdgpu:' + profile,
                                     '--root=load_words', '--output=' + str(output)],
                                    text=True, capture_output=True)
            (notes / f'load-extended-{variant}-{label}-{profile}.log').write_text(result.stdout + result.stderr)
            row = {'label': label, 'profile': profile, 'exit_code': result.returncode,
                   'source_sha256': hashlib.sha256(source.encode()).hexdigest()}
            if result.returncode == 0:
                row['native_sha256'] = hashlib.sha256(output.read_bytes()).hexdigest()
                assembly = subprocess.check_output(['llvm-objdump', '-d', str(output)], text=True)
                (notes / f'load-extended-{variant}-{label}-{profile}.s').write_text(assembly)
            else:
                row['diagnostic'] = result.stderr
            rows.append(row)
            print(label, profile, result.returncode, flush=True)
(notes / f'load-extended-{variant}.json').write_text(json.dumps({
    'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'diff_sha256': hashlib.sha256(subprocess.check_output(['git', 'diff', '--binary'])).hexdigest(),
    'compiler_sha256': hashlib.sha256(compiler.read_bytes()).hexdigest(),
    'build_flags': '--config=asan', 'rows': rows,
}, indent=2) + '\n')
