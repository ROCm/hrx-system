"""Owned temporary staging, execution, and retention for this DPP comparison."""
from pathlib import Path
import hashlib
import io
import json
import os
import shlex
import subprocess
import sys
import tarfile

notes = Path(__file__).resolve().parent
manifest = notes / 'dpp-landing-artifacts.json'

def remote(arguments, **kwargs):
    return subprocess.run(['ssh', '-o', 'BatchMode=yes', 'hrx-gorgon-3', shlex.join(arguments)], check=True, **kwargs)

mode = sys.argv[1]
if mode == 'stage':
    assert not manifest.exists()
    roots = {name: Path(root) for name, root in json.loads(os.environ['BUREAU_TAG_ROOTS']).items()}
    candidate = roots['scan-dpp-candidate']
    files = {'compile-baseline': roots['scan-dpp-baseline'] / 'loom/src/loom/tools/loom-compile/loom-compile',
             'compile-candidate': candidate / 'loom/src/loom/tools/loom-compile/loom-compile',
             'loom': candidate / 'loom/src/loom/tooling/target/amdgpu/serve/scan_launch_specialization_test',
             'scan.loombc': candidate / 'experimental/codec_reference/research/scan/launch_scan.loombc',
             'storage-disjoint.loombc': candidate / 'experimental/codec_reference/research/scan/storage_disjoint_scan.loombc',
             'geometry-native.cpp': notes / 'geometry-native.cpp',
             'dpp-landing-run.py': notes / 'dpp-landing-run.py',
             'oracle-identity.json': notes / 'gorgon-oracle-identity.json'}
    for count in [32, 512, 65537, 2097152, 16777216]:
        files[f'config-{count}.json'] = notes / ('gorgon-retune-256x4-config.json' if count == 65537 else f'gorgon-dpp-{count}-config.json')
        for index in range(1 if count <= 512 else 2):
            files[f'prior-oracle-{count}-{index}.s'] = notes / f'gorgon-oracle-{count}-{index}.s'
    for path in files.values():
        assert path.is_file(), path
    directory = remote(['mktemp', '-d', '/tmp/loom-dpp-landing.XXXXXXXX'], capture_output=True, text=True).stdout.strip()
    payload = io.BytesIO()
    with tarfile.open(fileobj=payload, mode='w', dereference=True) as archive:
        for name, path in files.items():
            archive.add(path, arcname=name, recursive=False)
    remote(['tar', '-xf', '-', '-C', directory], input=payload.getvalue(), capture_output=True)
    identities = {name: {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'bytes': path.stat().st_size}
                  for name, path in files.items()}
    output = remote(['sha256sum', *[directory + '/' + name for name in files]], capture_output=True, text=True).stdout
    for line in output.splitlines():
        digest, name = line.split(maxsplit=1)
        assert identities[Path(name).name]['sha256'] == digest
    value = {'baseline_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
             'remote_directory': directory, 'files': identities,
             'build_flags': '--config=opt', 'tags': {name: str(root) for name, root in roots.items()}}
    manifest.write_text(json.dumps(value, indent=2) + '\n')
    print(directory)
elif mode == 'final-compiler':
    value = json.loads(manifest.read_text())
    root = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['scan-dpp-candidate'])
    source = root / 'loom/src/loom/tools/loom-compile/loom-compile'
    payload = io.BytesIO()
    with tarfile.open(fileobj=payload, mode='w', dereference=True) as archive:
        archive.add(source, arcname='compile-candidate', recursive=False)
        archive.add(notes / 'dpp-landing-run.py', arcname='dpp-landing-run.py', recursive=False)
    remote(['tar', '-xf', '-', '-C', value['remote_directory']], input=payload.getvalue(), capture_output=True)
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    actual = remote(['sha256sum', value['remote_directory'] + '/compile-candidate'], capture_output=True, text=True).stdout.split()[0]
    assert actual == digest
    value['measured_compiler'] = value['files']['compile-candidate']
    value['files']['compile-candidate'] = {'sha256': digest, 'bytes': source.stat().st_size}
    script = notes / 'dpp-landing-run.py'
    value['files']['dpp-landing-run.py'] = {'sha256': hashlib.sha256(script.read_bytes()).hexdigest(), 'bytes': script.stat().st_size}
    value['final_commit'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
    value['final_compiler_tag'] = json.loads(subprocess.check_output(['bureau-bazel', 'tag', 'inspect', 'scan-dpp-candidate', '--json'], text=True))
    manifest.write_text(json.dumps(value, indent=2) + '\n')
elif mode == 'run':
    value = json.loads(manifest.read_text())
    phase = sys.argv[2]
    command = ['python3', '-B', value['remote_directory'] + '/dpp-landing-run.py', phase]
    if phase not in ['build', 'inspect', 'identity']:
        command = ['/home/benvanik/.dotfiles/bin/benchmark-lock', '--label', 'scan-dpp-landing-' + phase, '--', *command]
    with (notes / ('dpp-landing-' + phase + '.log')).open('w') as output:
        result = subprocess.run(['ssh', '-o', 'BatchMode=yes', 'hrx-gorgon-3', shlex.join(command)], stdout=output, stderr=subprocess.STDOUT)
    (notes / ('dpp-landing-' + phase + '-run.json')).write_text(json.dumps({'command': command, 'exit_code': result.returncode}, indent=2) + '\n')
    print(phase, result.returncode)
    sys.exit(result.returncode)
elif mode == 'collect':
    value = json.loads(manifest.read_text())
    inventory = json.loads(remote(['python3', '-B', '-c',
        'from pathlib import Path; import hashlib,json,sys; root=Path(sys.argv[1]); print(json.dumps({str(p.relative_to(root)):{"sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"bytes":p.stat().st_size} for p in root.rglob("*") if p.is_file()}))',
        value['remote_directory']], capture_output=True, text=True).stdout)
    names = [name for name in inventory if name.endswith(('.json', '.s', '.txt', '.csv')) and not name.startswith('prior-')]
    payload = remote(['tar', '-cf', '-', '-C', value['remote_directory'], *names], capture_output=True).stdout
    with tarfile.open(fileobj=io.BytesIO(payload), mode='r:') as archive:
        for member in archive:
            assert member.name in names and member.isfile()
            data = archive.extractfile(member).read()
            assert hashlib.sha256(data).hexdigest() == inventory[member.name]['sha256']
            (notes / ('dpp-landing-' + member.name.replace('/', '-'))).write_bytes(data)
    value['inventory'] = inventory
    manifest.write_text(json.dumps(value, indent=2) + '\n')
    print('retained', len(names), 'files', sum(inventory[name]['bytes'] for name in names), 'bytes')
elif mode == 'retire':
    value = json.loads(manifest.read_text())
    script = '''from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1])
expected=json.load(sys.stdin)
assert root.parent == Path('/tmp') and root.name.startswith('loom-dpp-landing.')
assert root.is_dir() and not root.is_symlink()
paths=list(root.rglob('*'))
assert all(not p.is_symlink() for p in paths)
actual={str(p.relative_to(root)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in paths if p.is_file()}
assert actual == expected
for p in paths:
    if p.is_file(): p.unlink()
for p in sorted((p for p in paths if p.is_dir()),key=lambda p:len(p.parts),reverse=True): p.rmdir()
root.rmdir()
print('retired',root)
'''
    remote(['python3', '-B', '-c', script, value['remote_directory']], input=json.dumps(value['inventory']), text=True)
    value['remote_retired'] = True
    manifest.write_text(json.dumps(value, indent=2) + '\n')
else:
    raise ValueError(mode)
