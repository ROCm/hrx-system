// Standalone development comparator, never linked into Loom.
#include <hip/hip_runtime.h>
#include <rocprim/device/device_scan.hpp>
#include <rocprim/rocprim_version.hpp>
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
#include <type_traits>

static void check(hipError_t error, const char* expression) {
  if (error != hipSuccess) {
    std::fprintf(stderr, "%s: %s\n", expression, hipGetErrorString(error));
    std::exit(1);
  }
}
#define HIP(expression) check((expression), #expression)

template <class T>
int benchmark(size_t count, unsigned iterations, unsigned chain_length) {
  hipDeviceProp_t device;
  HIP(hipGetDeviceProperties(&device, 0));
  hipStream_t stream;
  HIP(hipStreamCreate(&stream));
  T* input;
  T* output;
  HIP(hipMalloc(&input, std::max<size_t>(count, 1) * sizeof(T)));
  HIP(hipMalloc(&output, std::max<size_t>(count, 1) * sizeof(T)));
  std::vector<T> host_input(count);
  std::vector<T> host_output(count);
  for (size_t i = 0; i < count; ++i) host_input[i] = T((i * 104729 + 12345) % 7 == 0);
  if (count) HIP(hipMemcpyAsync(input, host_input.data(), count * sizeof(T), hipMemcpyHostToDevice, stream));
  size_t scratch_bytes = 0;
  HIP(rocprim::exclusive_scan(nullptr, scratch_bytes, input, output, T(0), count, rocprim::plus<T>(), stream));
  void* scratch;
  HIP(hipMalloc(&scratch, std::max<size_t>(scratch_bytes, 1)));
  HIP(rocprim::exclusive_scan(scratch, scratch_bytes, input, output, T(0), count, rocprim::plus<T>(), stream));
  if (count) HIP(hipMemcpyAsync(host_output.data(), output, count * sizeof(T), hipMemcpyDeviceToHost, stream));
  HIP(hipStreamSynchronize(stream));
  T prefix = 0;
  for (size_t i = 0; i < count; ++i) {
    if (host_output[i] != prefix) {
      std::fprintf(stderr, "incorrect prefix at %zu\n", i);
      return 1;
    }
    prefix += host_input[i];
  }
  hipGraph_t graph;
  hipGraphExec_t executable;
  HIP(hipStreamBeginCapture(stream, hipStreamCaptureModeThreadLocal));
  for (unsigned operation = 0; operation < chain_length; ++operation) {
    HIP(rocprim::exclusive_scan(scratch, scratch_bytes, input, output, T(0), count, rocprim::plus<T>(), stream));
  }
  HIP(hipStreamEndCapture(stream, &graph));
  HIP(hipGraphInstantiate(&executable, graph, nullptr, nullptr, 0));
  for (unsigned i = 0; i < 10; ++i) HIP(hipGraphLaunch(executable, stream));
  HIP(hipStreamSynchronize(stream));
  if (count) HIP(hipMemcpyAsync(host_output.data(), output, count * sizeof(T), hipMemcpyDeviceToHost, stream));
  HIP(hipStreamSynchronize(stream));
  prefix = 0;
  for (size_t i = 0; i < count; ++i) {
    if (host_output[i] != prefix) {
      std::fprintf(stderr, "incorrect composed prefix at %zu\n", i);
      return 1;
    }
    prefix += host_input[i];
  }
  std::vector<double> samples;
  const double operations = double(iterations) * chain_length;
  for (unsigned repetition = 0; repetition < 9; ++repetition) {
    const auto start = std::chrono::steady_clock::now();
    for (unsigned i = 0; i < iterations; ++i) HIP(hipGraphLaunch(executable, stream));
    HIP(hipStreamSynchronize(stream));
    const double elapsed = std::chrono::duration<double, std::nano>(
        std::chrono::steady_clock::now() - start).count();
    samples.push_back(elapsed / operations);
    std::printf("{\"implementation\":\"rocprim\",\"count\":%zu,\"batch_scans\":%u,\"submissions\":%u,\"sample\":%u,\"elapsed_ns\":%.3f,\"per_scan_ns\":%.3f}\n",
        count, chain_length, iterations, repetition, elapsed, samples.back());
  }
  std::sort(samples.begin(), samples.end());
  std::printf("{\"implementation\":\"rocprim\",\"version\":%u,\"arch\":\"%s\",\"element_bytes\":%zu,\"count\":%zu,\"batch_scans\":%u,\"submissions\":%u,\"scratch_bytes\":%zu,\"median_per_scan_ns\":%.3f}\n",
      ROCPRIM_VERSION, device.gcnArchName, sizeof(T), count, chain_length,
      iterations, scratch_bytes, samples[4]);
  if (count) HIP(hipMemcpyAsync(host_output.data(), output, count * sizeof(T), hipMemcpyDeviceToHost, stream));
  HIP(hipStreamSynchronize(stream));
  prefix = 0;
  for (size_t i = 0; i < count; ++i) {
    if (host_output[i] != prefix) {
      std::fprintf(stderr, "incorrect final prefix at %zu\n", i);
      return 1;
    }
    prefix += host_input[i];
  }
  HIP(hipGraphExecDestroy(executable));
  HIP(hipGraphDestroy(graph));
  HIP(hipFree(scratch));
  HIP(hipFree(output));
  HIP(hipFree(input));
  HIP(hipStreamDestroy(stream));
  return 0;
}
static int rocprim_main(int argc, char** argv) {
  if (argc != 4 && argc != 5) {
    std::fprintf(stderr, "usage: rocprim_scan {u32|u64|f32} count iterations [chain_length]\n");
    return 1;
  }
  size_t count = std::strtoull(argv[2], nullptr, 10);
  unsigned iterations = std::strtoul(argv[3], nullptr, 10);
  unsigned chain_length = argc == 5 ? std::strtoul(argv[4], nullptr, 10) : 1;
  if (!iterations || count > (1ull << 28) || chain_length < 2 || chain_length > 32) return 1;
  if (std::string(argv[1]) == "u32") return benchmark<uint32_t>(count, iterations, chain_length);
  if (std::string(argv[1]) == "u64") return benchmark<uint64_t>(count, iterations, chain_length);
  if (std::string(argv[1]) == "f32") return benchmark<float>(count, iterations, chain_length);
  return 1;
}


static void measure_graph(hipGraphExec_t executable, hipStream_t stream,
                           size_t count, unsigned iterations,
                           unsigned chain_length, unsigned threads, unsigned items) {
  std::vector<double> samples;
  for (unsigned repetition = 0; repetition < 9; ++repetition) {
    const auto start = std::chrono::steady_clock::now();
    for (unsigned i = 0; i < iterations; ++i) HIP(hipGraphLaunch(executable, stream));
    HIP(hipStreamSynchronize(stream));
    const double elapsed = std::chrono::duration<double, std::nano>(std::chrono::steady_clock::now()-start).count();
    samples.push_back(elapsed / (double(iterations) * chain_length));
    std::printf("{\"implementation\":\"loom-native\",\"count\":%zu,\"threads\":%u,\"items\":%u,\"batch_scans\":%u,\"submissions\":%u,\"sample\":%u,\"per_scan_ns\":%.3f}\n", count, threads, items, chain_length, iterations, repetition, samples.back());
  }
  std::sort(samples.begin(),samples.end());
  std::printf("{\"implementation\":\"loom-native\",\"count\":%zu,\"threads\":%u,\"items\":%u,\"batch_scans\":%u,\"submissions\":%u,\"median_per_scan_ns\":%.3f}\n",count,threads,items,chain_length,iterations,samples[4]);
}
// Loads the same three-buffer and six-buffer HSACO ABIs used by serving.
static int benchmark_loom(const std::string& directory, size_t count,
                          unsigned iterations, unsigned chain_length, unsigned threads, unsigned items) {
  const unsigned tile = threads * items;
  constexpr uint32_t canary = 0x735ab192;
  const unsigned groups = static_cast<unsigned>((count + tile - 1) / tile);
  const bool single = count <= tile;
  const unsigned reset_tile = threads;
  const size_t summary_bytes = size_t(groups) * sizeof(uint64_t);
  const size_t aligned_summary_bytes = (summary_bytes + 15) & ~size_t(15);
  const size_t scratch_bytes = single ? 0 : aligned_summary_bytes + 12;
  hipDeviceProp_t device;
  HIP(hipGetDeviceProperties(&device, 0));
  hipStream_t stream;
  HIP(hipStreamCreate(&stream));
  uint32_t *input, *output, *length;
  uint8_t* scratch = nullptr;
  const size_t allocation_count = count + 16;
  HIP(hipMalloc(&input, allocation_count * sizeof(uint32_t)));
  HIP(hipMalloc(&output, allocation_count * sizeof(uint32_t)));
  HIP(hipMalloc(&length, sizeof(uint32_t)));
  if (!single) HIP(hipMalloc(&scratch, scratch_bytes));
  uint32_t* totals = reinterpret_cast<uint32_t*>(scratch);
  uint32_t* prefixes = reinterpret_cast<uint32_t*>(scratch);
  uint32_t* schedule = single ? nullptr : reinterpret_cast<uint32_t*>(scratch + aligned_summary_bytes);
  uint32_t* states = single ? nullptr : reinterpret_cast<uint32_t*>(scratch);
  std::vector<uint32_t> host_input(allocation_count);
  std::vector<uint32_t> host_output(allocation_count, canary);
  for (size_t position = 0; position < allocation_count; ++position) {
    host_input[position] = (position * 104729 + 12345) % 7 == 0;
  }
  uint32_t runtime_count = static_cast<uint32_t>(count);
  HIP(hipMemcpyAsync(length, &runtime_count, sizeof(runtime_count), hipMemcpyHostToDevice, stream));
  HIP(hipMemcpyAsync(input, host_input.data(), allocation_count * sizeof(uint32_t), hipMemcpyHostToDevice, stream));
  HIP(hipMemcpyAsync(output, host_output.data(), allocation_count * sizeof(uint32_t), hipMemcpyHostToDevice, stream));
  if (!single) HIP(hipMemsetAsync(scratch, 0xfd, scratch_bytes, stream));
  HIP(hipStreamSynchronize(stream));

  hipModule_t scan_module = nullptr;
  hipModule_t reset_module = nullptr;
  hipFunction_t scan_function = nullptr;
  hipFunction_t reset_function = nullptr;
  const std::string scan_name = single ? "scan_single" : "scan_lookback";
  HIP(hipModuleLoad(&scan_module, (directory + "-" + scan_name + ".hsaco").c_str()));
  HIP(hipModuleGetFunction(&scan_function, scan_module, scan_name.c_str()));
  if (!single) {
    HIP(hipModuleLoad(&reset_module, (directory + "-reset_states.hsaco").c_str()));
    HIP(hipModuleGetFunction(&reset_function, reset_module, "reset_states"));
  }
  void* single_arguments[] = {&length, &input, &output};
  void* reset_arguments[] = {&length, &states, &schedule};
  void* scan_arguments[] = {&length, &input, &output, &states, &totals, &prefixes};
  auto launch = [&] {
    if (single) {
      HIP(hipModuleLaunchKernel(scan_function, 1, 1, 1, threads, 1, 1, 0,
                               stream, single_arguments, nullptr));
    } else {
      HIP(hipModuleLaunchKernel(reset_function, (groups + reset_tile - 1) / reset_tile,
                               1, 1, threads, 1, 1, 0, stream,
                               reset_arguments, nullptr));
      HIP(hipModuleLaunchKernel(scan_function, groups, 1, 1, threads, 1, 1,
                               0, stream, scan_arguments, nullptr));
    }
  };
  hipGraph_t graph;
  hipGraphExec_t executable;
  HIP(hipStreamBeginCapture(stream, hipStreamCaptureModeThreadLocal));
  for (unsigned operation = 0; operation < chain_length; ++operation) launch();
  HIP(hipStreamEndCapture(stream, &graph));
  HIP(hipGraphInstantiate(&executable, graph, nullptr, nullptr, 0));
  for (unsigned replay = 0; replay < 3; ++replay) HIP(hipGraphLaunch(executable, stream));
  HIP(hipMemcpyAsync(host_output.data(), output, allocation_count * sizeof(uint32_t), hipMemcpyDeviceToHost, stream));
  HIP(hipStreamSynchronize(stream));
  uint32_t prefix = 0;
  for (size_t position = 0; position < allocation_count; ++position) {
    const uint32_t expected = position < count ? prefix : canary;
    if (host_output[position] != expected) {
      std::fprintf(stderr, "Loom HIP output mismatch at %zu: %u != %u\n",
                   position, host_output[position], expected);
      return 1;
    }
    if (position < count) prefix += host_input[position];
  }
  std::printf("loom-hip verified count=%zu scratch=%zu threads=%u scan_grid=%u reset_grid=%u chain=%u\n",
              count, scratch_bytes, threads, single ? 1 : groups,
              single ? 0 : (groups + reset_tile - 1) / reset_tile, chain_length);
  if (iterations) {
    for (unsigned warmup = 0; warmup < 10; ++warmup) HIP(hipGraphLaunch(executable, stream));
    HIP(hipStreamSynchronize(stream));
    measure_graph(executable, stream, count, iterations, chain_length, threads, items);
  }
  HIP(hipMemcpyAsync(host_output.data(), output, allocation_count * sizeof(uint32_t), hipMemcpyDeviceToHost, stream));
  HIP(hipStreamSynchronize(stream));
  prefix = 0;
  for (size_t position = 0; position < allocation_count; ++position) {
    const uint32_t expected = position < count ? prefix : canary;
    if (host_output[position] != expected) {
      std::fprintf(stderr, "Post-measurement mismatch at %zu: %u != %u\n", position, host_output[position], expected);
      return 1;
    }
    if (position < count) prefix += host_input[position];
  }
  HIP(hipGraphExecDestroy(executable));
  HIP(hipGraphDestroy(graph));
  HIP(hipModuleUnload(scan_module));
  if (!single) HIP(hipModuleUnload(reset_module));
  if (!single) HIP(hipFree(scratch));
  HIP(hipFree(length));
  HIP(hipFree(output));
  HIP(hipFree(input));
  HIP(hipStreamDestroy(stream));
  return 0;
}

int main(int argc,char**argv) {
 if (argc>1 && std::string(argv[1])=="loom") {
  if (argc!=8) return 1;
  const size_t count=std::strtoull(argv[3],nullptr,10);
  const unsigned iterations=std::strtoul(argv[4],nullptr,10);
  const unsigned chain=std::strtoul(argv[5],nullptr,10);
  const unsigned threads=std::strtoul(argv[6],nullptr,10);
  const unsigned items=std::strtoul(argv[7],nullptr,10);
  if (!count || count>(1u<<24) || !iterations || chain!=32 || !threads || threads>1024 || !items || items>16) return 1;
  return benchmark_loom(argv[2],count,iterations,chain,threads,items);
 }
 return rocprim_main(argc,argv);
}
