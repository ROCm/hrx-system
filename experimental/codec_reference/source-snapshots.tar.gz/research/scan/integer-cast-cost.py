import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess

notes = Path('experimental/codec_reference/research/scan/integer-cast')
notes.mkdir(exist_ok=True)
roots = json.loads(os.environ['BUREAU_TAG_ROOTS'])
temporary = Path('/tmp/codec-predicate-transport')
temporary.mkdir(exist_ok=True)

def text_bytes(path):
    data = path.read_bytes()
    offset = struct.unpack_from('<Q', data, 40)[0]
    size, count, strings_index = struct.unpack_from('<HHH', data, 58)
    headers = [struct.unpack_from('<IIQQQQIIQQ', data, offset + i * size) for i in range(count)]
    strings_header = headers[strings_index]
    strings = data[strings_header[4]:strings_header[4] + strings_header[5]]
    return next(data[h[4]:h[4] + h[5]] for h in headers if strings[h[0]:].split(b'\0')[0] == b'.text')

controls = Path('loom/src/loom/target/arch/amdgpu/test/source_low/source_low_subgroup_shuffle_dynamic.loom-test').read_text().split('// ====')[:4]
cases = Path('loom/src/loom/target/arch/amdgpu/test/source_low/source_low_subgroup_predicate_transport.loom-test').read_text().split('// ====')
results = []
for tag, root in roots.items():
    result = {'tag': tag, 'tools': {}, 'controls': [], 'predicates': []}
    for tool in ['loom-compile', 'loom-import-cxx']:
        path = Path(root) / 'loom/src/loom/tools' / tool / tool
        output = subprocess.check_output(['size', '-A', str(path)], text=True)
        sections = {p[0]: int(p[1]) for line in output.splitlines() if len(p := line.split()) == 3 and p[0].startswith('.')}
        result['tools'][tool] = {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'sections': sections}
    compiler = Path(root) / 'loom/src/loom/tools/loom-compile/loom-compile'
    for mode, case in zip(['index', 'xor', 'up', 'down'], controls):
        source = temporary / f'{mode}.loom'
        source.write_text(case.split('// ----')[0])
        artifact = temporary / f'{tag}-{mode}.hsaco'
        subprocess.run([str(compiler), str(source), '--target=amdgpu:gfx1151', '--output=' + str(artifact)], check=True, capture_output=True)
        code = text_bytes(artifact)
        result['controls'].append({'mode': mode, 'text_bytes': len(code), 'sha256': hashlib.sha256(code).hexdigest()})
        artifact.unlink()
    if True:
        for case in cases:
            program = case.split('// ----')[0]
            target = re.search(r'amdgpu.target<([^>]+)>', program)[1]
            name = re.search(r'kernel.def target\(@target\) @(\w+)', program)[1]
            manual = program.replace(': i1, i32', ': i32, i32').replace(': vector<3xi1>', ': vector<3xi32>').replace(': vector<7xi1>', ': vector<7xi32>')
            manual = re.sub(r'(%predicate = )scalar.trunci (%word) : i32 to i1', r'%bit_mask = scalar.constant 1 : i32\n  \1scalar.andi \2, %bit_mask : i32', manual)
            manual = re.sub(r'(%predicate = )vector.trunci (%words) : vector<(\d+)xi32> to vector<\3xi1>', r'%bit_mask = vector.constant 1 : vector<\3xi32>\n  \1vector.andi \2, %bit_mask : vector<\3xi32>', manual)
            # Result projections observe only bit zero, including undefined-source values.
            manual = re.sub(r'(= )scalar.extui (%(?:indexed|xored|up|down)) : i1 to i32', r'\1scalar.andi \2, %bit_mask : i32', manual)
            manual = re.sub(r'(= )vector.extui (%\w+) : vector<(\d+)xi32> to vector<\3xi32>', r'\1vector.andi \2, %bit_mask : vector<\3xi32>', manual)
            for variant, source_text in [('predicate', program), ('integer', manual)]:
                source = notes / f'{name}-{variant}.loom'
                source.write_text(source_text)
                artifact = temporary / f'{name}-{variant}.hsaco'
                report = notes / f'{tag}-{name}-{variant}-report.json'
                run = subprocess.run([str(compiler), str(source), '--target=amdgpu:' + target, '--output=' + str(artifact), '--compile-report=details', '--compile-report-output=' + str(report)], text=True, capture_output=True)
                if run.returncode:
                    raise RuntimeError(run.stderr)
                assembly = subprocess.check_output(['llvm-objdump', '--disassemble', '--mcpu=' + target, str(artifact)], text=True)
                (notes / f'{tag}-{name}-{variant}.isa').write_text(assembly)
                instructions = [line for line in assembly.splitlines() if re.match(r'^\s+\w.*// [0-9A-F]+:', line)]
                code = text_bytes(artifact)
                entry = json.loads(report.read_text())['entries']['rows'][0]
                result['predicates'].append({'registers': {k: entry['target_resources'][k]['final']['register_count'] for k in ['scalar', 'vector']}, 'spills': entry['allocation_spill_count'], 'name': name, 'variant': variant, 'target': target, 'text_bytes': len(code), 'instructions': len(instructions), 'sha256': hashlib.sha256(code).hexdigest()})
                artifact.unlink()
    results.append(result)
assert results[0]['controls'] == results[1]['controls']
(notes / 'cost.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps([{**r, 'tools': {k: {s: v['sections'].get(s, 0) for s in ['.text', '.rodata', '.data.rel.ro', '.bss']} for k, v in r['tools'].items()}} for r in results], indent=2))
