#include <loomcxx/kernel.h>

static loom::kernel::configuration configure(unsigned capacity) {
  return {{(capacity + 1023) / 1024, 1, 1}, {128, 1, 1}};
}

[[loom::kernel(configure)]]
void scan_lookback(const unsigned* length, const unsigned* input,
                   unsigned* output) {
  input = loom::buffer::assume_memory_space<loom::memory_space::constant>(input);
  unsigned item = loom::kernel::workitem::id.x;
  unsigned group = loom::kernel::workgroup::id.x;
  unsigned count = length[0];
  unsigned groups = (count + 1023) / 1024;
  if (group >= groups) return;
  unsigned tile_begin = group * 1024;
  if (tile_begin + 1024 > count) return;
  const unsigned* tile_input = input + tile_begin;
  unsigned sum = 0;
  [[loom::unroll]]
  for (unsigned stripe = 0; stripe < 8; ++stripe) {
    sum += tile_input[item + stripe * 128];
  }
  output[group * 128 + item] = sum;
}
