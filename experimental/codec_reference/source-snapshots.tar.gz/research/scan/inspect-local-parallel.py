from pathlib import Path
import hashlib,json,re,subprocess
sdk=Path('/home/ben/tools/rocm-sdk-10.0.0-gfx1151/lib/python3.14/site-packages/_rocm_sdk_devel/llvm/bin')
c=json.loads(Path('address-config.json').read_text());c['scan']['packed_state']=True;c['scan']['fused_prefix']=True
Path('local-config.json').write_text(json.dumps(c)+'\n');rows=[]
for name,module in [('fused','parallel.loombc'),('local','local.loombc')]:
 p=Path(name+'.hsaco')
 subprocess.run(['./compile',module,'--target=amdgpu:gfx1151','--root=scan_lookback','--config-file=local-config.json','--output='+str(p)],check=True)
 assembly=subprocess.check_output([sdk/'llvm-objdump','-d',p],text=True);metadata=subprocess.check_output([sdk/'llvm-readelf','-n','-S',p],text=True)
 Path(name+'.s').write_text(assembly);Path(name+'.metadata.txt').write_text(metadata)
 row={'variant':name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'barriers':assembly.count('s_barrier'),'instructions':len(re.findall(r'//\s*[0-9a-fA-F]+:',assembly))}
 for field in ['group_segment_fixed_size','private_segment_fixed_size','sgpr_count','vgpr_count','wavefront_size']:row[field]=int(re.search(r'\.'+field+r':\s+(\d+)',metadata)[1])
 rows.append(row)
Path('local-parallel-native.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
