"""Bounded Low substitutions for eight full-tile input addresses.

This is experiment construction, not a compiler optimization. Each substitution
stays inside the same full-tile block and changes only a proved identical value.
Unmodified Low must reproduce the source-compiled artifact byte for byte.
"""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tempfile

notes = Path(__file__).resolve().parent
output = notes / 'address-reuse'
compiler = Path('bazel-bin/loom/src/loom/tools/loom-compile/loom-compile').resolve()
baseline = json.loads((output / 'baseline.json').read_text())
rows = []
value = r'%[A-Za-z0-9_$]+'
for source in ['mixed-address', 'striped-base']:
    for target in ['gfx1151', 'gfx942']:
        prefix = f'{source}-{target}'
        trace = (output / f'{prefix}.trace.loom').read_text()
        control = trace[trace.index('low.kernel.def '):]
        block = control.split('^_bb2:\n', 1)[1].split('\n^', 1)[0]
        loads = re.findall(rf'  ({value}) = global_load_(?:b32|dword)_saddr ({value}), ({value})([^\n]*)', block)
        assert len(loads) == 8, (prefix, loads)
        suffix = ' : reg<amdgpu.vgpr>' if target == 'gfx942' else ''
        assert [tail for _, _, _, tail in loads] == [suffix] + [f' {{offset = {i * 512}}}' + suffix for i in range(1, 8)]
        # The authored shared shift and the eight packet-local shifts must all
        # consume the same wide value and the same constant shift amount.
        shifts = re.findall(rf'^  ({value}) = s_lshl_b64 ({value}), ({value})$', block, re.M)
        assert len(shifts) == 9 and len({operand for _, operand, _ in shifts}) == 1, (prefix, shifts)
        definitions = {}
        for line in block.splitlines():
            match = re.match(rf'  ({value}) = (.*)', line)
            if match:
                definitions[match[1]] = match[2]
        for _, _, amount in shifts[1:]:
            assert definitions[amount] == 's_mov_b32 2'
        # Independently verify each packet-local base is binding + the matching
        # shifted tile offset, with a complete explicit carry chain.
        bases = []
        roots = []
        for (_, _, address, _), (shift, _, _) in zip(loads, shifts[1:]):
            match = re.fullmatch(rf'concat\(({value}), ({value})\).*', definitions[address])
            assert match, (prefix, address)
            lo, hi = match.groups()
            low = re.search(rf'^  {re.escape(lo)}, ({value}) = s_add_co_u32 ({value}), ({value})$', block, re.M)
            high = re.search(rf'^  {re.escape(hi)}, ({value}) = s_addc_u32 ({value}), ({value}), ({value})$', block, re.M)
            assert low and high and low[1] == high[4]
            root = re.fullmatch(rf'slice ({value})\[0\].*', definitions[low[2]])
            assert root and definitions[high[2]].startswith(f'slice {root[1]}[1] :')
            assert definitions[low[3]].startswith(f'slice {shift}[0] :')
            assert definitions[high[3]].startswith(f'slice {shift}[1] :')
            roots.append(root[1])
            bases.append(address)
        assert len(set(roots)) == 1
        shift_variant = block
        # Replace uses, never definitions; dead expressions are left to the
        # unchanged normal Low cleanup pipeline.
        for redundant, _, _ in shifts[1:]:
            shift_variant = re.sub(rf'(?<![A-Za-z0-9_$]){re.escape(redundant)}(?![A-Za-z0-9_$]| =)', lambda _: shifts[0][0], shift_variant)
        base_variant = block
        for _, _, address, _ in loads[1:]:
            base_variant = re.sub(rf'(global_load_(?:b32|dword)_saddr {value}, ){re.escape(address)}(?=\s|$)', lambda m: m[1] + bases[0], base_variant)
        variants = {'control': control,
                    'shift': control.replace(block, shift_variant, 1),
                    'base': control.replace(block, base_variant, 1)}
        for kind, text in variants.items():
            input_path = output / f'{prefix}-{kind}.loom'
            input_path.write_text(text)
            with tempfile.TemporaryDirectory(prefix='loom-address-reuse-') as temporary:
                artifact = Path(temporary) / 'kernel.hsaco'
                report = output / f'{prefix}-{kind}.json'
                command = [str(compiler), str(input_path), f'--target=amdgpu:{target}', '--root=scan_lookback', f'--output={artifact}', '--compile-report=details', f'--compile-report-output={report}']
                subprocess.run(command, check=True)
                digest = hashlib.sha256(artifact.read_bytes()).hexdigest()
                if kind == 'control':
                    original = next(row for row in baseline['cases'] if Path(row['source']).name.startswith(source+'-') and row['target'] == target)
                    assert digest == original['artifact_sha256'], (prefix, 'control did not reproduce source artifact')
                assembly = subprocess.check_output(['llvm-objdump', '--disassemble', f'--mcpu={target}', str(artifact)], text=True)
                (output / f'{prefix}-{kind}.s').write_text(assembly)
                details = json.loads(report.read_text())
                row = {'source': source, 'target': target, 'variant': kind,
                       'input_sha256': hashlib.sha256(text.encode()).hexdigest(),
                       'artifact_sha256': digest,
                       'scalar_wide_shift_count': len(re.findall(r'\bs_lshl_b64\b', assembly)),
                       **{key: details[key] for key in ('emission', 'target_resources', 'allocation', 'residency_constraints') if key in details}}
                report.write_text(json.dumps(row, indent=2)+'\n')
                rows.append(row)
                (output / 'counterfactual.json').write_text(json.dumps(rows, indent=2)+'\n')
                print(prefix, kind, row['emission'], 'shifts',row['scalar_wide_shift_count'],flush=True)
