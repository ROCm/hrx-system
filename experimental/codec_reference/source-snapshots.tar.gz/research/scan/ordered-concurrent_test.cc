#include <array>
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <filesystem>
#include <string>
#include <vector>
#include "iree/async/frontier_tracker.h"
#include "iree/async/util/proactor_pool.h"
#include "iree/base/tooling/flags.h"
#include "iree/hal/drivers/init.h"
#include "iree/testing/gtest.h"
#include "iree/testing/status_matchers.h"
#include "loom/serve/runtime/execution/execution.h"
#include "loom/serve/runtime/host/host.h"
#include "loom/serve/runtime/program/jit.h"
#include "loom/serve/testing/compiler.h"
#include "loomc/sanitizer.h"
IREE_FLAG(string, scan_device, "amdgpu", "Device under qualification.");
IREE_FLAG(bool, scan_device_asan, false, "Enable device access assertions.");
IREE_FLAG(bool, scan_in_place, false, "Use the same input and output buffer range.");
IREE_FLAG(bool, scan_distinct_queues, false, "Use a second exact dispatch queue.");
IREE_FLAG(int32_t, scan_threads, 64, "Late shared command/kernel workgroup geometry.");
IREE_FLAG(int32_t, scan_count, 65537, "Maximum runtime record count.");
IREE_FLAG(string, scan_source, "", "Offline-produced ordered scan bytecode.");
namespace {
struct Affine {
  // Multiplicative coefficient modulo 2^32.
  uint32_t scale;
  // Additive coefficient modulo 2^32, or final evaluation after consumption.
  uint32_t offset;
};
static_assert(sizeof(Affine) == 8);
iree_hal_queue_t* SelectQueue(iree_hal_device_t* device,
                              iree_hal_queue_family_role_flags_t role) {
  const auto* queues =
      iree_hal_device_spec_queues(iree_hal_device_spec(device));
  for (iree_host_size_t i = 0; i < queues->family_count; ++i) {
    const auto& family = queues->families[i];
    if (family.provisioned_queue_count &&
        iree_all_bits_set(family.role_flags, role)) {
      return iree_hal_device_queue(device, i, 0);
    }
  }
  return nullptr;
}


class OrderedScanTest : public ::testing::Test {
 protected:
  void SetUp() override {
    ASSERT_GT(FLAG_scan_count, 0);
    ASSERT_LE(FLAG_scan_count, 65537);
    ASSERT_GE(FLAG_scan_threads, 32);
    ASSERT_LE(FLAG_scan_threads, 256);
    IREE_ASSERT_OK(CreateDevice());
    auto* dispatch =
        SelectQueue(device_, IREE_HAL_QUEUE_FAMILY_ROLE_FLAG_DISPATCH);
    auto* transfer =
        SelectQueue(device_, IREE_HAL_QUEUE_FAMILY_ROLE_FLAG_TRANSFER);
    ASSERT_NE(dispatch, nullptr);
    ASSERT_NE(transfer, nullptr);
    const auto* family = iree_hal_queue_family(dispatch);
    const auto* transfer_family = iree_hal_queue_family(transfer);
    const iree_hal_pool_family_access_t families[] = {
        {.family = family,
         .usage = IREE_HAL_BUFFER_USAGE_STORAGE |
                  IREE_HAL_BUFFER_USAGE_TRANSFER |
                  IREE_HAL_BUFFER_USAGE_DISPATCH_INDIRECT_PARAMETERS},
        {.family = transfer_family, .usage = IREE_HAL_BUFFER_USAGE_TRANSFER},
    };
    const iree_hal_pool_scope_t scope = {
        .family_count = family == transfer_family ? 1u : 2u,
        .families = families,
    };
    const iree_hal_slab_pool_options_t pool_options = {};
    IREE_ASSERT_OK(iree_hal_slab_pool_create(group_, scope, &pool_options,
                                             host_allocator_, &storage_pool_));
    iree_hal_asan_pool_options_t asan_options = {};
    const auto* sanitizer =
        iree_hal_device_spec_sanitizer(iree_hal_device_spec(device_));
    if (FLAG_scan_device_asan) {
      ASSERT_TRUE(iree_any_bit_set(sanitizer->flags, IREE_HAL_DEVICE_SANITIZER_FLAG_ASAN));
    }
    if (iree_any_bit_set(sanitizer->flags,
                         IREE_HAL_DEVICE_SANITIZER_FLAG_ASAN)) {
      asan_options = sanitizer->asan.pool_options;
    }
    IREE_ASSERT_OK(loom_serve_workspace_create(
        group_, storage_pool_, &asan_options, host_allocator_, &workspace_));
    std::printf("dispatch_family=%u provisioned_queues=%u distinct_queues=%u\n",
        iree_hal_queue_family_ordinal(family),
        iree_hal_queue_family_spec(family)->provisioned_queue_count,
        unsigned(FLAG_scan_distinct_queues));
    for (size_t i = 0; i < rows_.size(); ++i) {
      auto* row_dispatch = dispatch;
      iree_hal_queue_t* acquired_queue = nullptr;
      if (i && FLAG_scan_distinct_queues) {
        const auto* family_spec = iree_hal_queue_family_spec(family);
        if (family_spec->provisioned_queue_count > 1) {
          row_dispatch = iree_hal_device_queue(
              device_, iree_hal_queue_family_ordinal(family), 1);
        } else {
          ASSERT_TRUE(iree_any_bit_set(family_spec->flags,
              IREE_HAL_QUEUE_FAMILY_SPEC_FLAG_DYNAMIC_ACQUISITION))
              << "second exact dispatch queue unavailable";
          iree_hal_queue_params_t params;
          iree_hal_queue_params_initialize(&params);
          IREE_ASSERT_OK(iree_hal_queue_acquire(family, &params, &acquired_queue));
          row_dispatch = acquired_queue;
        }
        ASSERT_NE(row_dispatch, dispatch);
        std::printf("second_dispatch_queue=%s\n", acquired_queue ? "acquired" : "provisioned");
      }
      auto status = loom_serve_execution_create(row_dispatch, transfer, workspace_,
          host_allocator_, &rows_[i].execution);
      iree_hal_queue_release(acquired_queue);
      IREE_ASSERT_OK(status);
    }
    IREE_ASSERT_OK(iree_hal_semaphore_create(device_,
        IREE_HAL_QUEUE_FAMILY_AFFINITY_ANY, 0,
        IREE_HAL_SEMAPHORE_FLAG_DEFAULT, &gate_));
    directory_ = std::filesystem::path(FLAG_scan_source).parent_path().string();
    filename_ = std::filesystem::path(FLAG_scan_source).filename().string();
    const iree_string_view_t providers[] = {iree_make_cstring_view(filename_.c_str())};
    const loom_serve_sources_t sources = {
      .base_directory = iree_make_cstring_view(directory_.c_str()),
      .count = 1, .values = providers};
    const loomc_sanitizer_options_t kernel_sanitizer = {
      .type = LOOMC_STRUCTURE_TYPE_SANITIZER_OPTIONS,
      .structure_size = sizeof(loomc_sanitizer_options_t),
      .checks = LOOMC_SANITIZER_CHECK_ACCESS,
      .reporting_mode = LOOMC_SANITIZER_REPORTING_MODE_DEFAULT};
    IREE_ASSERT_OK(loom_serve_jit_allocate(device_, dispatch, host_, &sources,
      FLAG_scan_device_asan ? &kernel_sanitizer : nullptr,
      &compilation_, host_allocator_, &jit_));
  }
  void TearDown() override {
    // A failed submission/assertion still releases accepted work to retirement.
    if (gate_pending_) IREE_EXPECT_OK(iree_hal_semaphore_signal(gate_, gate_value_, nullptr));
    for (auto& row : rows_) {
      if (row.execution) IREE_EXPECT_OK(loom_serve_execution_drain(row.execution));
    }
    for (auto& row : rows_) {
      for (auto* buffer : row.buffers) iree_hal_buffer_release(buffer);
      loom_serve_execution_release(row.execution);
    }
    iree_hal_semaphore_release(gate_);
    for (auto* command : commands_) iree_hal_command_buffer_release(command);
    loom_serve_jit_free(jit_);
    loom_serve_workspace_release(workspace_);
    iree_hal_pool_release(storage_pool_);
    iree_hal_device_group_release(group_);
    iree_hal_device_release(device_);
    iree_async_frontier_tracker_release(frontier_tracker_);
    loom_serve_host_release(host_);
  }
  void BeginBatch() {
    ++gate_value_;
    gate_pending_ = true;
    for (auto& row : rows_) {
      IREE_ASSERT_OK(loom_serve_execution_barrier(
          row.execution, {1, &gate_, &gate_value_}));
    }
  }
  void ReleaseBatch() {
    for (auto& row : rows_) {
      auto frontier = loom_serve_execution_frontier(row.execution);
      for (unsigned branch = 0; branch < 2; ++branch) {
        uint64_t completed = 0;
        IREE_ASSERT_OK(iree_hal_semaphore_query(frontier.semaphores[branch], &completed));
        ASSERT_LT(completed, frontier.values[branch]);
      }
    }
    IREE_ASSERT_OK(iree_hal_semaphore_signal(gate_, gate_value_, nullptr));
    gate_pending_ = false;
  }
  iree_status_t CreateDevice() {
    iree_hal_driver_registry_t* registry = nullptr;
    IREE_RETURN_IF_ERROR(
        iree_hal_driver_registry_allocate(host_allocator_, &registry));
    iree_status_t status = iree_hal_register_all_available_drivers(registry);
    if (iree_status_is_ok(status)) {
      status = loom_serve_test_host_create(2, host_allocator_, &host_);
    }
    if (iree_status_is_ok(status)) {
      auto params = iree_hal_device_create_params_default();
      params.proactor_pool = loom_serve_host_proactor_pool(host_);
      status = iree_hal_create_device(registry, iree_make_cstring_view(FLAG_scan_device), &params,
                                      host_allocator_, &device_);
    }
    iree_hal_driver_registry_free(registry);
    if (iree_status_is_ok(status)) {
      status = iree_async_frontier_tracker_create(
          iree_async_frontier_tracker_options_default(), host_allocator_,
          &frontier_tracker_);
    }
    if (iree_status_is_ok(status)) {
      status = iree_hal_device_group_create_from_device(
          device_, frontier_tracker_, host_allocator_, &group_);
    }
    return status;
  }


  void Prepare() {
    for (unsigned mode = 0; mode < 4; ++mode) {
      const std::string json = "{\"scan.capacity\":" + std::to_string(kCapacity) +
          ",\"scan.threads\":" + std::to_string(FLAG_scan_threads) +
          ",\"scan.inclusive\":" + ((mode & 1) ? "true" : "false") +
          ",\"scan.reverse\":" + ((mode & 2) ? "true" : "false") + "}";
      const loomc_config_options_t config = {
          .json_object = loomc_make_cstring_view(json.c_str())};
      loom_serve_jit_stage_t* stage = nullptr;
      IREE_ASSERT_OK(loom_serve_jit_compile(jit_, IREE_SV("scan"), &config, &stage));
      const auto* program = loom_serve_jit_stage_program(stage);
      const size_t scratch_bytes = program->requirements.transient.required_byte_length;
      ASSERT_LE(scratch_bytes, kCapacity * sizeof(Affine) * 2 + 32);
      EXPECT_EQ(program->requirements.rebindable_binding_count, 5u);
      EXPECT_EQ(program->requirements.transient.binding_index, 4u);
      if (mode == 0) lengths_[4] = scratch_bytes;
      EXPECT_EQ(lengths_[4], scratch_bytes);
      std::printf("mode=%u scratch=%zu commands=%u entries=%u\n", mode,
          scratch_bytes, program->commands.count, program->requirements.entry_count);
      auto status = loom_serve_jit_stage_record(stage,
          iree_hal_queue_family(SelectQueue(device_, IREE_HAL_QUEUE_FAMILY_ROLE_FLAG_DISPATCH)),
          IREE_HAL_COMMAND_BUFFER_MODE_DEFAULT, nullptr, nullptr, &commands_[mode]);
      loom_serve_jit_stage_free(stage);
      IREE_ASSERT_OK(status);
    }
    // Recorded products retain executables independently of compiler lifetime.
    loom_serve_jit_free(jit_);
    jit_ = nullptr;
    for (auto& row : rows_) {
      for (size_t i = 0; i < row.buffers.size(); ++i) {
        if (FLAG_scan_in_place && i == 2) {
          row.buffers[i] = row.buffers[1];
          iree_hal_buffer_retain(row.buffers[i]);
          continue;
        }
        IREE_ASSERT_OK(iree_hal_pool_allocate_buffer(storage_pool_,
            iree_hal_make_pool_reservation_request(lengths_[i], 16),
            iree_infinite_timeout(), &row.buffers[i]));
      }
      row.input.resize(kCapacity + 16);
      row.output.resize(kCapacity + 16);
      row.initial.assign(kCapacity + 16, kCanary);
    }
  }
  void SetInput(unsigned distribution) {
    for (auto& row : rows_) {
      for (size_t i = 0; i < row.input.size(); ++i) {
        uint32_t scale = distribution == 0 ? 1u : (uint32_t(i * 13 + 5) | 1u);
        if (distribution == 2 && (i % 67 == 0 || i % 129 == 0)) scale = 0;
        row.input[i] = {scale, uint32_t(i * 104729 + 0xfedcba98u)};
      }
    }
  }
  void Enqueue(size_t index, unsigned mode) {
    auto& row = rows_[index];
    row.seed = {uint32_t(5 + 2 * index), row.length * 17u + 0xf7654321u};
    const void* sources[] = {&row.length, row.input.data(), row.initial.data(), &row.seed};
    std::array<iree_hal_transfer_operation_t, 4> uploads = {};
    size_t upload_count = 0;
    for (size_t i = 0; i < uploads.size(); ++i) {
      if (FLAG_scan_in_place && i == 2) continue;
      auto& upload = uploads[upload_count++];
      upload.type = IREE_HAL_TRANSFER_OPERATION_TYPE_UPLOAD;
      upload.upload.source = sources[i];
      upload.upload.target_buffer = row.buffers[i];
      upload.upload.length = lengths_[i];
    }
    uint64_t completion = 0;
    IREE_ASSERT_OK(loom_serve_execution_transfer(row.execution, upload_count, uploads.data(), &completion));
    std::array<iree_hal_buffer_binding_t, 5> bindings = {};
    for (size_t i = 0; i < bindings.size(); ++i) {
      bindings[i] = {row.buffers[i], 0, lengths_[i]};
    }
    for (unsigned repeat = 0; repeat < 3; ++repeat) {
      IREE_ASSERT_OK(loom_serve_execution_execute(row.execution, commands_[mode],
          {bindings.size(), bindings.data()}, &completion));
    }
    iree_hal_transfer_operation_t download = {};
    download.type = IREE_HAL_TRANSFER_OPERATION_TYPE_DOWNLOAD;
    download.download.source_buffer = row.buffers[2];
    download.download.target = row.output.data();
    download.download.length = lengths_[2];
    IREE_ASSERT_OK(loom_serve_execution_feedback(row.execution, 1, &download, &row.completion));
  }
  void Verify(size_t index, unsigned mode) {
    auto& row = rows_[index];
    IREE_ASSERT_OK(loom_serve_execution_feedback_wait(row.execution, row.completion));
    // Sequential map application has no hierarchy, parallel combine, or provider.
    std::vector<Affine> expected = row.input;
    const unsigned passes = FLAG_scan_in_place ? 3 : 1;
    for (unsigned pass = 0; pass < passes; ++pass) {
      uint32_t scale = row.seed.scale;
      uint32_t offset = row.seed.offset;
      for (size_t i = 0; i < row.length; ++i) {
        size_t position = (mode & 2) ? row.length - 1 - i : i;
        Affine value = expected[position];
        uint32_t before_scale = scale;
        uint32_t before_evaluation = 7u * scale + offset;
        scale *= value.scale;
        offset = offset * value.scale + value.offset;
        expected[position] = {(mode & 1) ? scale : before_scale,
                             (mode & 1) ? 7u * scale + offset : before_evaluation};
      }
    }
    if (!FLAG_scan_in_place) {
      std::fill(expected.begin() + row.length, expected.end(), kCanary);
    }
    for (size_t position = 0; position < row.output.size(); ++position) {
      ASSERT_EQ(row.output[position].scale, expected[position].scale)
          << "mode=" << mode << " length=" << row.length << " position=" << position;
      ASSERT_EQ(row.output[position].offset, expected[position].offset)
          << "mode=" << mode << " length=" << row.length << " position=" << position;
    }
  }
  const size_t kCapacity = FLAG_scan_count;
  static constexpr Affine kCanary = {0x735ab192u, 0x16d9438fu};
  std::array<size_t, 5> lengths_ = {4, (kCapacity + 16) * 8, (kCapacity + 16) * 8, 8, 0};
  struct Row {
    // Owned independent work and feedback timelines over the shared workspace.
    loom_serve_execution_t* execution = nullptr;
    // Owned runtime count, input, output, initial value, and transient storage.
    std::array<iree_hal_buffer_t*, 5> buffers = {};
    // Number of logical records in this invocation.
    uint32_t length = 0;
    // Runtime initial affine map, updated before every submission batch.
    Affine seed = {1, 0};
    // Host input records, retained through queued uploads.
    std::vector<Affine> input;
    // Downloaded final consumer output, including sixteen canaries.
    std::vector<Affine> output;
    // Output initialization, retained through queued uploads.
    std::vector<Affine> initial;
    // Queue feedback completion associated with this row's output.
    uint64_t completion = 0;
  };
  std::array<Row, 2> rows_;
  iree_allocator_t host_allocator_ = iree_allocator_system();
  loom_serve_compilation_report_t compilation_ = {};
  loom_serve_host_t* host_ = nullptr;
  iree_async_frontier_tracker_t* frontier_tracker_ = nullptr;
  iree_hal_device_t* device_ = nullptr;
  iree_hal_device_group_t* group_ = nullptr;
  iree_hal_pool_t* storage_pool_ = nullptr;
  loom_serve_workspace_t* workspace_ = nullptr;
  // Owned admission gate shared by one pair of independent execution instances.
  iree_hal_semaphore_t* gate_ = nullptr;
  // Next strictly increasing pair-admission payload.
  uint64_t gate_value_ = 0;
  // Accepted work is blocked on gate_value_ until released, including failure cleanup.
  bool gate_pending_ = false;
  std::string directory_, filename_;
  loom_serve_jit_t* jit_ = nullptr;
  std::array<iree_hal_command_buffer_t*, 4> commands_ = {};
};
TEST_F(OrderedScanTest, ConsumedOrderedPrefixes) {
  ASSERT_NO_FATAL_FAILURE(Prepare());
  std::vector<uint32_t> lengths = {0, 1, 31, 32, 33, 63, 64, 65, 127, 128, 129,
                                  511, 512, 513, 4095, 4096, 4097, 65535, 65536, 65537};
  const uint32_t threads = FLAG_scan_threads;
  lengths.insert(lengths.end(), {threads - 1, threads, threads + 1,
      threads * threads - 1, threads * threads, threads * threads + 1});
  std::sort(lengths.begin(), lengths.end());
  lengths.erase(std::unique(lengths.begin(), lengths.end()), lengths.end());
  std::erase_if(lengths, [&](uint32_t length) { return length > kCapacity; });
  lengths.push_back(kCapacity);
  if (lengths.size() % 2) lengths.push_back(kCapacity);
  for (unsigned distribution = 0; distribution < 3; ++distribution) {
    SetInput(distribution);
    for (unsigned mode = 0; mode < 4; ++mode) {
      for (size_t i = 0; i < lengths.size(); i += 2) {
        rows_[0].length = lengths[i];
        rows_[1].length = lengths[i + 1];
        ASSERT_NO_FATAL_FAILURE(BeginBatch());
        ASSERT_NO_FATAL_FAILURE(Enqueue(0, mode));
        ASSERT_NO_FATAL_FAILURE(Enqueue(1, mode));
        ASSERT_NO_FATAL_FAILURE(ReleaseBatch());
        ASSERT_NO_FATAL_FAILURE(Verify(0, mode));
        ASSERT_NO_FATAL_FAILURE(Verify(1, mode));
      }
    }
  }
}
}  // namespace
