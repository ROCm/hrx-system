"""Locked fixed-core compiler cost with complete native-image identity checks."""
from pathlib import Path
import hashlib
import json
import os
import platform
import resource
import statistics
import subprocess
import time

os.chdir(Path(__file__).resolve().parent)
lease = os.environ['BENCHMARK_LOCK_LEASE_ID']
cpu = min(os.sched_getaffinity(0))
os.sched_setaffinity(0, {cpu})
prior = json.loads(Path('expected-native.json').read_text())['rows']
module_names = {'smem-512': 'short-length', 'uniform': 'uniform', '65537': 'storage-disjoint'}
output = Path('cost-output.hsaco')

def arguments(variant, label, entry):
    source = module_names.get(label, 'scan') + '.loombc'
    result = ['./compile-' + variant, source, '--target=amdgpu:gfx1151',
              '--root=' + entry, '--output=' + str(output)]
    if label != 'uniform':
        count = '512' if label == 'smem-512' else label
        result.append('--config-file=config-' + count + '.json')
    return result

sizes = {}
identities = []
for variant in ['baseline', 'candidate']:
    sections = subprocess.check_output(['size', '-A', 'compile-' + variant], text=True)
    sizes[variant] = {p[0]: int(p[1]) for line in sections.splitlines()
                      if len(p := line.split()) == 3 and p[0].startswith('.')}
    for row in prior:
        subprocess.run(arguments(variant, row['label'], row['entry']), check=True)
        digest = hashlib.sha256(output.read_bytes()).hexdigest()
        identities.append({'variant': variant, 'label': row['label'], 'entry': row['entry'],
                           'sha256': digest, 'identical': digest == row['sha256']})
assert all(row['identical'] for row in identities), identities
print('All 20 baseline/candidate native images match the measured programs.', flush=True)

rows = []
for label in ['32', '512', '65537', '2097152', '16777216', 'smem-512']:
    entry = 'scan_single' if label in ['32', '512', 'smem-512'] else 'scan_lookback'
    expected = next(row['sha256'] for row in prior if row['label'] == label and row['entry'] == entry)
    for repeat in range(-4, 40):
        order = ['baseline', 'candidate'] if repeat % 2 == 0 else ['candidate', 'baseline']
        for variant in order:
            before = resource.getrusage(resource.RUSAGE_CHILDREN)
            start = time.monotonic_ns()
            subprocess.run(arguments(variant, label, entry), check=True)
            elapsed = time.monotonic_ns() - start
            after = resource.getrusage(resource.RUSAGE_CHILDREN)
            assert hashlib.sha256(output.read_bytes()).hexdigest() == expected
            if repeat >= 0:
                rows.append({'label': label, 'variant': variant, 'repeat': repeat,
                             'wall_ns': elapsed,
                             'cpu_ns': round(((after.ru_utime + after.ru_stime) - (before.ru_utime + before.ru_stime)) * 1e9),
                             'minor_faults': after.ru_minflt - before.ru_minflt,
                             'voluntary_switches': after.ru_nvcsw - before.ru_nvcsw,
                             'involuntary_switches': after.ru_nivcsw - before.ru_nivcsw})
    print('completed', label, flush=True)
record = {'lease': lease, 'cpu': cpu, 'host': platform.node(),
          'governor': Path(f'/sys/devices/system/cpu/cpu{cpu}/cpufreq/scaling_governor').read_text().strip(),
          'compiler_sections': sizes, 'native_images': identities, 'rows': rows}
Path('compile-cost.json').write_text(json.dumps(record, indent=2) + '\n')
