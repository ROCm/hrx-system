"""Capture the real serving command through public HAL profiling tooling."""

import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import tarfile

notes = Path(__file__).resolve().parent
root = Path(json.loads(os.environ["BUREAU_TAG_ROOTS"])["scan-profile-candidate"])
binary = root / "loom/src/loom/tooling/target/amdgpu/serve/scan_profile_experiment_test"
files = {
    "candidate": binary,
    "natural_scan.loombc": Path(str(binary) + ".runfiles/_main/experimental/codec_reference/research/scan/natural_scan.loombc"),
    "capture-dispatch.sh": notes / "capture-dispatch.sh",
}
manifest = {
    "revision": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
    "build": "--config=opt --copt=-march=x86-64-v3 --cxxopt=-march=x86-64-v3 --host_copt=-march=x86-64-v3 --host_cxxopt=-march=x86-64-v3",
    "tag_generation_root": str(root),
    "files": {},
}
for name, path in {**files, **{name: notes / name for name in (
        "dispatch-profile-scan_test.cc", "experiment-profile-build.txt",
        "natural-slice-tiles.cxx", "command.loom")}}.items():
    content = path.read_bytes()
    manifest["files"][name] = {"sha256": hashlib.sha256(content).hexdigest(), "bytes": len(content)}
(notes / "dispatch-profile-artifacts.json").write_text(json.dumps(manifest, indent=2) + "\n")

def remote(command):
    return ["ssh", "-o", "BatchMode=yes", "noxa-pc", shlex.join([
        "ssh", "-o", "BatchMode=yes", "ben@dogwood.tail63922.ts.net", command])]

directory = "/tmp/loom-scan-comparison-OPsFupY5"
process = subprocess.Popen(remote(shlex.join(["tar", "-xf", "-", "-C", directory])), stdin=subprocess.PIPE)
with tarfile.open(fileobj=process.stdin, mode="w|", dereference=True) as archive:
    for name, path in files.items():
        archive.add(path, arcname=name, recursive=False)
process.stdin.close()
if process.wait() != 0:
    raise SystemExit("Diagnostic transfer failed")

with (notes / "dispatch-capture.log").open("w") as output:
    subprocess.run(remote(shlex.join([
        "/home/ben/.dotfiles/bin/benchmark-lock", "--label", "loom-scan-dispatch-attribution",
        "--", "bash", directory + "/capture-dispatch.sh"])), stdout=output, stderr=subprocess.STDOUT, check=True)

decoder = root / "runtime/src/iree/tools/iree-profile/iree-profile"
for count in (32, 65537, 2097152, 16777216):
    capture = notes / f"dispatch-{count}.ireeprof"
    with capture.open("wb") as output:
        subprocess.run(remote(shlex.join(["cat", directory + "/" + capture.name])), stdout=output, check=True)
    for report in ("summary", "dispatch", "queue", "command"):
        command = [str(decoder), report, "--format=jsonl"]
        if report == "dispatch":
            command.append("--dispatch_events")
        command.append(str(capture))
        with (notes / f"dispatch-{count}-{report}.jsonl").open("w") as output:
            subprocess.run(command, stdout=output, check=True)
    print(f"Captured and decoded {count}: {capture.stat().st_size} bytes", flush=True)
