#include <loomcxx/kernel.h>
#include <loomcxx/target.h>

[[loom::config("scan.inclusive")]] extern const bool inclusive;
[[loom::config("scan.reverse")]] extern const bool reverse;
[[loom::config("scan.compact")]] extern const bool compact;
[[loom::config("scan.portable")]] extern const bool portable;
[[loom::config("scan.threads")]] extern const unsigned configured_threads;

static loom::kernel::configuration configure_tiles(unsigned capacity) {
  unsigned threads = (configured_threads ? configured_threads : loom::target::subgroup::size() * 4);
  return {{(capacity + threads * 4 - 1) / (threads * 4), 1, 1},
          {threads, 1, 1}};
}

static loom::kernel::configuration configure_one() {
  return {{1, 1, 1}, {(configured_threads ? configured_threads : loom::target::subgroup::size() * 4), 1, 1}};
}

// Portable workgroup-only baseline; no inter-workgroup waiting. The final
// barrier protects the returned register values before a loop reuses scratch.
struct Prefix {
  unsigned exclusive;
  unsigned total;
};
static LOOM_FORCE_INLINE Prefix local_prefix(unsigned value) {
  if (!portable) {
    return {loom::kernel::workgroup::scan::addi<
              loom::kernel::scan_mode::exclusive>(value),
            loom::kernel::workgroup::reduce::addi(value)};
  }
  unsigned item = loom::kernel::workitem::id.x;
  unsigned threads = loom::kernel::workgroup::size.x;
  auto* storage = loom::buffer::alloca<unsigned, loom::memory_space::workgroup>(threads);
  storage[item] = value;
  loom::kernel::workgroup::barrier();
  for (unsigned distance = 1; distance < threads; distance *= 2) {
    unsigned previous = storage[(item + threads - distance) % threads];
    if (item < distance) previous = 0;
    loom::kernel::workgroup::barrier();
    value += previous;
    storage[item] = value;
    loom::kernel::workgroup::barrier();
  }
  unsigned previous = storage[(item + threads - 1) % threads];
  Prefix result = {item ? previous : 0, storage[threads - 1]};
  loom::kernel::workgroup::barrier();
  return result;
}

// A device-read length changes the dispatch grid without changing the compiled
// program. Its caller guarantees length <= the planned input capacity.
[[loom::kernel(configure_one)]]
void prepare(const unsigned* length, unsigned* schedule) {
  if (loom::kernel::workitem::id.x == 0) {
    unsigned tile = loom::kernel::workgroup::size.x * 4;
    schedule[0] = (length[0] + tile - 1) / tile;
    schedule[1] = 1;
    schedule[2] = 1;
  }
}

[[loom::kernel(configure_tiles)]]
void reduce_tiles(const unsigned* length, const unsigned* input,
                  unsigned* totals) {
  unsigned item = loom::kernel::workitem::id.x;
  unsigned group = loom::kernel::workgroup::id.x;
  unsigned threads = loom::kernel::workgroup::size.x;
  unsigned count = length[0];
  unsigned begin = (group * threads + item) * 4;
  unsigned sum = 0;
  [[loom::unroll]]
  for (unsigned index = 0; index < 4; ++index) {
    unsigned position = begin + index;
    if (position < count) {
      unsigned source = reverse ? count - 1 - position : position;
      sum += compact ? (input[source] & 1) : input[source];
    }
  }
  unsigned total = local_prefix(sum).total;
  if (item == 0) totals[group] = total;
}

// Small summary arrays are scanned in workgroup-sized stripes. Only this
// bounded experiment uses a serial stripe recurrence; a selected scalable
// implementation must compare recursive hierarchy and look-back alternatives.
[[loom::kernel(configure_one)]]
void prefix_summaries(const unsigned* schedule, const unsigned* totals,
                      unsigned* prefixes) {
  unsigned item = loom::kernel::workitem::id.x;
  unsigned threads = loom::kernel::workgroup::size.x;
  unsigned count = schedule[0];
  unsigned carry = 0;
  for (unsigned begin = 0; begin < count; begin += threads) {
    unsigned position = begin + item;
    unsigned value = position < count ? totals[position] : 0;
    Prefix local = local_prefix(value);
    unsigned prefix = local.exclusive;
    unsigned total = local.total;
    if (position < count) prefixes[position] = carry + prefix;
    carry += total;
  }
}

static LOOM_FORCE_INLINE unsigned read_value(const unsigned* input,
                                             unsigned position, unsigned count) {
  if (position >= count) return 0;
  unsigned source = reverse ? count - 1 - position : position;
  return compact ? (input[source] & 1) : input[source];
}

[[loom::kernel(configure_tiles)]]
void scan_tiles(const unsigned* length, const unsigned* input,
                const unsigned* prefixes, unsigned* output) {
  unsigned item = loom::kernel::workitem::id.x;
  unsigned group = loom::kernel::workgroup::id.x;
  unsigned threads = loom::kernel::workgroup::size.x;
  unsigned count = length[0];
  unsigned begin = (group * threads + item) * 4;
  using Values = unsigned __attribute__((ext_vector_type(4)));
  Values values = {read_value(input, begin, count),
                   read_value(input, begin + 1, count),
                   read_value(input, begin + 2, count),
                   read_value(input, begin + 3, count)};
  unsigned sum = values[0] + values[1] + values[2] + values[3];
  unsigned carry = prefixes[group] + local_prefix(sum).exclusive;
  [[loom::unroll]]
  for (unsigned index = 0; index < 4; ++index) {
    unsigned position = begin + index;
    unsigned prefix = inclusive ? carry + values[index] : carry;
    carry += values[index];
    if (position < count) {
      unsigned destination = reverse ? count - 1 - position : position;
      if (compact) {
        if (values[index]) output[carry - 1] = input[destination];
      } else {
        output[destination] = prefix;
      }
    }
  }
}

[[loom::kernel(configure_one)]]
void publish_count(const unsigned* schedule, const unsigned* totals,
                   const unsigned* prefixes, unsigned* selected) {
  if (loom::kernel::workitem::id.x == 0) {
    unsigned tiles = schedule[0];
    unsigned count = tiles ? prefixes[tiles - 1] + totals[tiles - 1] : 0;
    selected[0] = (count + loom::kernel::workgroup::size.x - 1) /
                  loom::kernel::workgroup::size.x;
    selected[1] = 1;
    selected[2] = 1;
    selected[3] = count;
  }
}

[[loom::kernel(configure_tiles)]]
void consume(const unsigned* selected, const unsigned* input, unsigned* output) {
  unsigned item = loom::kernel::workgroup::id.x * loom::kernel::workgroup::size.x +
                  loom::kernel::workitem::id.x;
  if (item < selected[3]) output[item] = input[item] * 3 + 7;
}
