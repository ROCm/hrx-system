from pathlib import Path
import collections,csv,hashlib,json,re,subprocess

sdk=Path('/opt/rocm'); llvm=sdk/'llvm/bin'
counts=[32,512,65537,2097152,16777216]
def arguments(count,mode):
 threads=32 if count<1024 else 64 if count==16777216 else 128
 items=1 if count==32 else 16 if count==512 else 8
 control='prefix0' if count<1024 else 'control'
 candidate='prefix2' if count<1024 else 'both' if count<16777216 else 'control'
 return ['./matched',str(count),str(16 if count==16777216 else 128),str(threads),str(items),f'collective-{control}-{count}',f'collective-{candidate}-{count}',mode]
def words(text):return re.findall(r'//\s*[0-9a-fA-F]+:\s*([0-9A-Fa-f ]+)',text)

oracle=json.loads(Path('oracle-identity.json').read_text())
assert oracle['comparator_sha256']==hashlib.sha256(Path('rocprim').read_bytes()).hexdigest()
subprocess.run([llvm/'llvm-objdump','--offloading','matched'],check=True)
images=list(Path('.').glob('matched.*hipv4*gfx1151'));assert len(images)==1
symbols={}
for line in subprocess.check_output([llvm/'llvm-nm','--defined-only',images[0]],text=True).splitlines():
 parts=line.split()
 if len(parts)==3 and parts[1] in ['T','t']:
  symbols[subprocess.check_output(['c++filt',parts[2]],text=True).strip()]=parts[2]
proof={'binary_sha256':hashlib.sha256(Path('matched').read_bytes()).hexdigest(),'sizes':[]}
for row in oracle['sizes']:
 count=row['count'];directory=f'matched-trace-{count}'
 subprocess.run([sdk/'bin/rocprofv3','--kernel-trace','--output-format','csv','--output-directory',directory,'--output-file','matched','--',*arguments(count,'trace')],check=True)
 traces=list(Path(directory).rglob('*kernel_trace.csv'));assert len(traces)==1
 Path(f'matched-{count}.csv').write_bytes(traces[0].read_bytes())
 events=list(csv.DictReader(traces[0].open()));frequencies=collections.Counter(x['Kernel_Name'] for x in events)
 selected=[]
 for index,kernel in enumerate(row['kernels']):
  name=kernel['name'];assert frequencies[name]==32,(count,name,frequencies)
  dims=sorted(set((x['Grid_Size_X'],x['Workgroup_Size_X']) for x in events if x['Kernel_Name']==name))
  assert [list(x) for x in dims]==kernel['grid_block_x'],(count,name,dims)
  assembly=subprocess.check_output([llvm/'llvm-objdump','-d','--disassemble-symbols='+symbols[name],images[0]],text=True)
  assert words(assembly)==words(Path(f'oracle-{count}-{index}.s').read_text()),(count,name)
  Path(f'matched-{count}-{index}.s').write_text(assembly)
  selected.append({'name':name,'dispatches':32,'grid_block_x':dims,'instruction_words_equal':True})
 args=arguments(count,'trace');threads=int(args[3]);items=int(args[4]);groups=(count+threads*items-1)//(threads*items)
 expected={'scan_single':(64,1)} if groups==1 else {'reset_states':(64,(groups+threads-1)//threads),'scan_lookback':(64,groups)}
 for name,(frequency,grid) in expected.items():
  assert frequencies[name]==frequency,(count,name,frequencies)
  dims=set((int(x['Grid_Size_X']),int(x['Workgroup_Size_X'])) for x in events if x['Kernel_Name']==name)
  assert dims=={(grid*threads,threads)},(count,name,dims)
 known=set(expected)|{x['name'] for x in row['kernels']}|{'__amd_rocclr_copyBuffer'}
 assert not (set(frequencies)-known),(count,frequencies)
 proof['sizes'].append({'count':count,'oracle':selected,'native_dispatches':expected,'copies':frequencies['__amd_rocclr_copyBuffer']})
Path('matched-identity.json').write_text(json.dumps(proof,indent=2)+'\n')
print('matched_identity_passed=true',flush=True)
subprocess.run(['vmstat','1','3'],check=True)
for allocation in range(3):
 for count in (counts if allocation==0 else [2097152]):
  print(f'allocation={allocation}',flush=True)
  subprocess.run(arguments(count,'measure'),check=True)
subprocess.run(['vmstat','1','3'],check=True)
