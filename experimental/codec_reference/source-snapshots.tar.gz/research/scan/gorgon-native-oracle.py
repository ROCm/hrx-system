"""Bind short-size rocPRIM dispatches to actual selected code and resources."""
from pathlib import Path
import collections,csv,hashlib,json,re,subprocess
sdk=Path('/opt/rocm')
llvm=sdk/'llvm/bin'
subprocess.run([llvm/'llvm-objdump','--offloading','native'],check=True)
images=list(Path('.').glob('native.*hipv4*gfx1151')); assert len(images)==1
symbols=subprocess.check_output([llvm/'llvm-nm','--defined-only',images[0]],text=True)
names={}
for line in symbols.splitlines():
 parts=line.split()
 if len(parts)==3 and parts[1] in ['T','t']:
  symbol=parts[2]; name=subprocess.check_output(['c++filt',symbol],text=True).strip(); names[name]=symbol
metadata=subprocess.check_output([llvm/'llvm-readelf','-n',images[0]],text=True)
Path('native-oracle.metadata.txt').write_text(metadata)
result={'comparator_sha256':hashlib.sha256(Path('native').read_bytes()).hexdigest(),'sizes':[]}
for count in [32,512,65537,2097152,16777216]:
 directory=f'native-oracle-trace-{count}'
 if not Path(directory).exists(): subprocess.run([sdk/'bin/rocprofv3','--kernel-trace','--output-format','csv','--output-directory',directory,'--output-file','native-oracle','--','./native','u32',str(count),'1','32'],check=True)
 traces=list(Path(directory).rglob('*kernel_trace.csv')); assert len(traces)==1
 Path(f'native-oracle-{count}.csv').write_bytes(traces[0].read_bytes())
 rows=list(csv.DictReader(traces[0].open())); counts=collections.Counter(row['Kernel_Name'] for row in rows)
 selected=[]
 ignored={}
 for name,n in counts.items():
  if name=='__amd_rocclr_copyBuffer':
   ignored[name]=n; continue
  assert n==609,(count,name,n)
  symbol=names[name]
  assembly=subprocess.check_output([llvm/'llvm-objdump','-d','--disassemble-symbols='+symbol,images[0]],text=True)
  index=len(selected); Path(f'native-oracle-{count}-{index}.s').write_text(assembly)
  dimensions=sorted(set((row['Grid_Size_X'],row['Workgroup_Size_X']) for row in rows if row['Kernel_Name']==name))
  selected.append({'name':name,'symbol':symbol,'dispatch_count':n,'grid_block_x':dimensions,'instructions':len(re.findall(r'//\s*[0-9a-fA-F]+:',assembly)),'assembly_sha256':hashlib.sha256(assembly.encode()).hexdigest()})
 result['sizes'].append({'count':count,'kernels':selected,'outside_scan_copies':ignored})
Path('native-oracle-identity.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
