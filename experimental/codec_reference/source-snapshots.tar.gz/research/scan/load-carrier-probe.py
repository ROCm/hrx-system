"""Bounded source-to-native probe of memory result/consumer carrier agreement."""

from pathlib import Path
import hashlib
import json
import resource
import subprocess
import sys
import tempfile

notes = Path(__file__).resolve().parent
compiler = Path('bazel-bin/loom/src/loom/tools/loom-compile/loom-compile').resolve()
variant = sys.argv[1]
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
base = (notes / 'uniform-three-word-load.loom').read_text()
rows = []
with tempfile.TemporaryDirectory(prefix='loom-load-carrier-') as scratch:
    for count in [1, 2, 3, 4]:
        for consumer in ['copy', 'vector_add', 'extract_add']:
            source = base.replace('load_three', 'load_words').replace('3xi32', f'{count}xi32')
            store = f'  vector.store %value, %result[0] : vector<{count}xi32>, view<{count}xi32>'
            if consumer == 'vector_add':
                source = source.replace(store, f'  %sum = vector.addi %value, %value : vector<{count}xi32>\n' + store.replace('%value,', '%sum,'))
            elif consumer == 'extract_add':
                source = source.replace(f'%result = buffer.view %output[%base] : buffer -> view<{count}xi32>',
                                        f'%result = buffer.view %output[%base] : buffer -> view<{count + 1}xi32>')
                retained_store = store.replace(f', view<{count}xi32>', f', view<{count + 1}xi32>')
                source = source.replace(store, retained_store + f'\n  %element = vector.extract %value[0] : vector<{count}xi32> -> i32\n  %sum = scalar.addi %element, %element : i32\n  view.store %sum, %result[{count}] : i32, view<{count + 1}xi32>')
            source_path = notes / f'load-carrier-{count}-{consumer}.loom'
            source_path.write_text(source)
            for profile in ['gfx942', 'gfx1100', 'gfx1151']:
                label = f'{variant}-{profile}-{count}-{consumer}'
                output = Path(scratch) / 'probe.hsaco'
                result = subprocess.run([str(compiler), str(source_path), '--target=amdgpu:' + profile,
                                         '--root=load_words', '--output=' + str(output)],
                                        text=True, capture_output=True)
                (notes / f'load-carrier-{label}.log').write_text(result.stdout + result.stderr)
                row = {'profile': profile, 'count': count, 'consumer': consumer,
                       'exit_code': result.returncode,
                       'source_sha256': hashlib.sha256(source.encode()).hexdigest()}
                if result.returncode == 0:
                    row['native_sha256'] = hashlib.sha256(output.read_bytes()).hexdigest()
                    assembly = subprocess.check_output(['llvm-objdump', '-d', str(output)], text=True)
                    (notes / f'load-carrier-{label}.s').write_text(assembly)
                else:
                    row['diagnostic'] = result.stderr
                rows.append(row)
                print(label, result.returncode, flush=True)
(notes / f'load-carrier-{variant}.json').write_text(json.dumps({
    'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'diff_sha256': hashlib.sha256(subprocess.check_output(['git', 'diff', '--binary'])).hexdigest(),
    'compiler_sha256': hashlib.sha256(compiler.read_bytes()).hexdigest(),
    'build_flags': '--config=asan', 'rows': rows,
}, indent=2) + '\n')
