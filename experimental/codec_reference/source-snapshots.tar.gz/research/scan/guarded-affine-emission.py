from pathlib import Path
import hashlib,json,os,re,subprocess,tempfile
n=Path(__file__).resolve().parent
root=Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['ordered-scan-current'])
tools={x:root/f'loom/src/loom/tools/{x}/{x}' for x in ['loom-import-cxx','loom-compile']}
source=n/'guarded-affine.cxx'; module=n/'guarded-affine.loom'
subprocess.run([str(tools['loom-import-cxx']),str(source),'--output='+str(module)],check=True)
rows=[]
with tempfile.TemporaryDirectory(prefix='codec-guarded-affine-') as d:
 for entry in ['guarded_record','guarded_components','guarded_scalars']:
  p=Path(d)/(entry+'.hsaco'); trace=Path(d)/(entry+'-trace')
  subprocess.run([str(tools['loom-compile']),str(module),'--root='+entry,'--target=amdgpu:gfx1151','--output='+str(p),'--dump-ir-before=scf-to-cfg','--dump-ir-output='+str(trace)+'/'],check=True)
  for name,args in [('s',['llvm-objdump','-d','--mcpu=gfx1151',str(p)]),('metadata.txt',['llvm-readelf','-n','-S',str(p)])]:
   (n/f'guarded-affine-{entry}.{name}').write_text(subprocess.check_output(args,text=True))
  files=list(trace.glob('ir/*.loom'))
  assert len(files)==1,files
  (n/f'guarded-affine-{entry}-before-cfg.loom').write_bytes(files[0].read_bytes())
  rows.append({'entry':entry,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
(n/'guarded-affine-emission.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows))
