"""Inspect the scan's actual bytecode through the public compiler CLI."""

import argparse
import collections
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("label")
parser.add_argument("--module", default="bazel-bin/experimental/codec_reference/research/scan/scan.loombc")
parser.add_argument("--compiler", default="bazel-bin/loom/src/loom/tools/loom-compile/loom-compile")
parser.add_argument("--source-input", default="tiles.cxx")
parser.add_argument("--items", type=int, default=16)
parser.add_argument("--threads", type=int, default=64)
parser.add_argument("--case", action="append", default=[])
options = parser.parse_args()
notes = Path(__file__).resolve().parent
label = options.label
scratch = Path(tempfile.mkdtemp(prefix=f"loom-scan-{label}-"))
compiler = Path(options.compiler)
source = Path(options.module)
base = json.loads((notes / "scalarization-config.json").read_text())
base["scan"]["items"] = options.items
base["scan"]["threads"] = options.threads
cases = [
    ("rdna-forward", "amdgpu:gfx1151", "scan_lookback", {}),
    ("rdna-reverse-inclusive", "amdgpu:gfx1151", "scan_lookback", {"reverse": True, "inclusive": True}),
    ("rdna-compact", "amdgpu:gfx1151", "scan_lookback", {"compact": True}),
    ("rdna-packed-state", "amdgpu:gfx1151", "scan_lookback", {"packed_state": True}),
    ("cdna-forward", "amdgpu:gfx942", "scan_lookback", {}),
    ("spirv-forward", "spirv:vulkan1.3+bda", "scan_tiles", {"portable": True, "lookback": False}),
    ("spirv-reverse", "spirv:vulkan1.3+bda", "scan_tiles", {"portable": True, "lookback": False, "reverse": True}),
]
results = {
    "commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
    "index_tree": subprocess.check_output(["git", "write-tree"], text=True).strip(),
    "compiler_sha256": hashlib.sha256(compiler.read_bytes()).hexdigest(),
    "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
    "source_inputs": {
        name: hashlib.sha256((notes / name).read_bytes()).hexdigest()
        for name in (options.source_input, "command.loom")
    },
    "scratch": str(scratch),
    "cases": [],
}
for name, target, root, overrides in cases:
    if options.case and name not in options.case:
        continue
    config = {"scan": {**base["scan"], **overrides}}
    config_path = scratch / f"{name}.json"
    config_path.write_text(json.dumps(config))
    artifact = scratch / (name + (".spv" if target.startswith("spirv") else ".hsaco"))
    report = scratch / f"{name}.report.json"
    trace = scratch / f"{name}.ir.loom"
    command = [
        str(compiler), str(source), f"--target={target}", f"--root={root}",
        f"--config-file={config_path}", f"--output={artifact}",
        "--compile-report=details", f"--compile-report-output={report}",
        "--dump-ir-before=source-to-low", "--dump-ir-after=source-to-low",
        f"--dump-ir-output={trace}",
    ]
    process = subprocess.run(command, capture_output=True, text=True)
    case = {
        "name": name, "target": target, "root": root, "config": config,
        "command": command, "exit_code": process.returncode,
        "diagnostics": process.stdout + process.stderr,
    }
    if process.returncode == 0:
        details = json.loads(report.read_text())
        for key in ("emission", "target_resources", "allocation", "move_causes", "static_instruction_mix", "workload"):
            if key in details:
                case[key] = details[key]
        if "target_legalization" in details:
            case["legalization"] = details["target_legalization"]
        case["memory"] = details["source_low"]["memory_rows"]
        expansion = collections.defaultdict(lambda: [0, 0, 0])
        for row in details["source_low"]["rows"]:
            values = expansion[row["source_op"]]
            values[0] += 1
            values[1] += row["emitted_low_op_count"]
            values[2] = max(values[2], row["emitted_low_op_count"])
        case["expansion_count_total_max"] = dict(sorted(expansion.items()))
        case["artifact_sha256"] = hashlib.sha256(artifact.read_bytes()).hexdigest()
        disassembler = (["spirv-dis", str(artifact)] if target.startswith("spirv") else
                        ["llvm-objdump", "--disassemble", "--mcpu=" + target.split(":")[1], str(artifact)])
        assembly = subprocess.check_output(disassembler, text=True)
        (notes / f"audit-{label}-{name}.s").write_text(assembly)
        # Keep only the compact before/after boundary, not a whole pass trace.
        (notes / f"audit-{label}-{name}.loom").write_text(trace.read_text())
        print(name, "OK", case.get("emission", "no native ISA emission report"), flush=True)
    else:
        print(name, "REJECTED", case["diagnostics"].splitlines()[:2], flush=True)
    results["cases"].append(case)
    (notes / f"audit-{label}.json").write_text(json.dumps(results, indent=2) + "\n")
