"""Check the bounded LDS-lifetime experiment's emitted mechanism."""
from pathlib import Path
import collections
import json
import re

notes = Path(__file__).resolve().parent
rows = json.loads((notes / 'gorgon-storage-native.json').read_text())
evidence = []
for label in ['barrier', 'disjoint']:
    row = next(row for row in rows
               if row['version'] == label and row['entry'] == 'scan_lookback')
    stem = 'gorgon-storage-' + label + '-scan_lookback'
    assembly = (notes / (stem + '.s')).read_text()
    report = json.loads((notes / (stem + '-report.json')).read_text())
    instructions = [line.strip() for line in assembly.splitlines()
                    if re.search(r'//\s*[0-9A-Fa-f]+:', line)]
    counts = collections.Counter(line.split()[0] for line in instructions)
    assert row['group_segment_fixed_size'] == 20, row
    assert row['private_segment_fixed_size'] == 0, row
    assert report['allocation']['spill_count'] == 0
    assert counts['s_barrier'] == (3 if label == 'barrier' else 2), counts
    record = dict(row, barriers=counts['s_barrier'],
                  lds_accesses=[line for line in instructions
                                if line.startswith(('ds_store_', 'ds_load_'))])
    evidence.append(record)
    print(json.dumps(record, indent=2))
(notes / 'gorgon-storage-mechanism.json').write_text(
    json.dumps(evidence, indent=2) + '\n')
