"""Remote native inspection of the existing packed-state configuration."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

sdk = Path("/home/ben/tools/rocm-sdk-10.0.0-gfx1151/lib/python3.14/site-packages/_rocm_sdk_devel/llvm/bin")
config = json.loads(Path("address-config.json").read_text())
config["scan"]["packed_state"] = True
Path("packed-config.json").write_text(json.dumps(config) + "\n")
rows = []
for variant, module, root in [("packed-control", "scan.loombc", "scan_lookback"),
                              ("packed-parallel", "parallel.loombc", "scan_lookback"),
                              ("packed-reset", "parallel.loombc", "reset_states")]:
    artifact = Path(variant + ".hsaco")
    subprocess.run(["./compile", module, "--target=amdgpu:gfx1151", "--root=" + root,
                    "--config-file=packed-config.json", "--output=" + str(artifact)], check=True)
    assembly = subprocess.check_output([sdk / "llvm-objdump", "-d", artifact], text=True)
    metadata = subprocess.check_output([sdk / "llvm-readelf", "-n", "-S", artifact], text=True)
    Path(variant + ".s").write_text(assembly)
    Path(variant + ".metadata.txt").write_text(metadata)
    row = {"variant": variant, "sha256": hashlib.sha256(artifact.read_bytes()).hexdigest(),
           "text_bytes": int(re.search(r"\]\s+\.text\s+PROGBITS\s+\S+\s+\S+\s+([0-9a-fA-F]+)", metadata)[1], 16),
           "instructions": len(re.findall(r"//\s*[0-9a-fA-F]+:", assembly))}
    for field in ["group_segment_fixed_size", "private_segment_fixed_size", "sgpr_count", "vgpr_count", "wavefront_size"]:
        row[field] = int(re.search(r"\." + field + r":\s+(\d+)", metadata)[1])
    rows.append(row)
Path("packed-native.json").write_text(json.dumps(rows, indent=2) + "\n")
print(json.dumps(rows, indent=2))
