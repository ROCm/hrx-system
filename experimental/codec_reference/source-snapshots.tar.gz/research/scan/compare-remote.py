"""Owned artifact staging for the binary comparison operand experiment."""
from pathlib import Path
import hashlib
import io
import json
import os
import shlex
import subprocess
import sys
import tarfile

notes = Path(__file__).resolve().parent
manifest = notes/'compare-artifacts.json'
def remote(arguments,**kwargs):
    return subprocess.run(['ssh','-o','BatchMode=yes','hrx-gorgon-3',shlex.join([str(a) for a in arguments])],check=True,**kwargs)

mode = sys.argv[1]
if mode == 'stage':
    assert not manifest.exists()
    roots = {name:Path(root) for name,root in json.loads(os.environ['BUREAU_TAG_ROOTS']).items()}
    files = {'compile-'+name:roots['scan-compare-'+name]/'loom/src/loom/tools/loom-compile/loom-compile' for name in ['baseline','candidate']}
    for name,target,tag in [('scan','launch_scan','baseline'),('storage-disjoint','storage_disjoint_scan','baseline'),('short-length','short_length_scan','candidate'),('uniform','uniform_count_compare','candidate')]:
        files[name+'.loombc'] = roots['scan-compare-'+tag]/('experimental/codec_reference/research/scan/'+target+'.loombc')
    files['compare-run.py'] = notes/'compare-run.py'
    files['geometry-native.cpp'] = notes/'geometry-native.cpp'
    for count in [32,512,65537,2097152,16777216]:
        files[f'config-{count}.json'] = notes/('gorgon-retune-256x4-config.json' if count == 65537 else f'gorgon-dpp-{count}-config.json')
    for path in files.values():
        assert path.is_file(),path
    directory = remote(['mktemp','-d','/tmp/loom-compare-operands.XXXXXXXX'],capture_output=True,text=True).stdout.strip()
    payload = io.BytesIO()
    with tarfile.open(fileobj=payload,mode='w',dereference=True) as archive:
        for name,path in files.items():
            archive.add(path,arcname=name,recursive=False)
    remote(['tar','-xf','-','-C',directory],input=payload.getvalue(),capture_output=True)
    identities = {name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for name,p in files.items()}
    for line in remote(['sha256sum',*[directory+'/'+name for name in files]],capture_output=True,text=True).stdout.splitlines():
        digest,name = line.split(maxsplit=1)
        assert identities[Path(name).name]['sha256'] == digest
    patch = subprocess.check_output(['git','diff','--binary'])
    (notes/'compare-candidate.patch').write_bytes(patch)
    value = {'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'candidate_patch_sha256':hashlib.sha256(patch).hexdigest(),'remote_directory':directory,'files':identities,'build_flags':'--config=opt','tags':{name:str(root) for name,root in roots.items()}}
    manifest.write_text(json.dumps(value,indent=2)+'\n')
    print(directory)
elif mode == 'update':
    value = json.loads(manifest.read_text())
    roots = {name:Path(root) for name,root in json.loads(os.environ['BUREAU_TAG_ROOTS']).items()}
    files = {'compile-'+name:roots['scan-compare-'+name]/'loom/src/loom/tools/loom-compile/loom-compile' for name in ['baseline','candidate']}
    for name,target in [('scan','scan_kernels'),('storage-disjoint','storage_disjoint_kernels'),('short-length','short_length_kernels'),('uniform','uniform_count_compare')]:
        files[name+'.loombc'] = roots['scan-compare-baseline']/('experimental/codec_reference/research/scan/'+target+'.loombc')
    for name in ['compare-run.py','dpp-landing-run.py','compare-scalar-corpus-inspect.loom','compare-integer-corpus-inspect.loom']:
        files[name] = notes/name
    files['oracle-identity.json'] = notes/'gorgon-oracle-identity.json'
    for count in [32,512,65537,2097152,16777216]:
        for index in range(1 if count <= 512 else 2):
            files[f'prior-oracle-{count}-{index}.s'] = notes/f'gorgon-oracle-{count}-{index}.s'
    payload = io.BytesIO()
    with tarfile.open(fileobj=payload,mode='w',dereference=True) as archive:
        for name,path in files.items():
            archive.add(path,arcname=name,recursive=False)
    remote(['tar','-xf','-','-C',value['remote_directory']],input=payload.getvalue(),capture_output=True)
    identities = {name:{'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size} for name,path in files.items()}
    for line in remote(['sha256sum',*[value['remote_directory']+'/'+name for name in files]],capture_output=True,text=True).stdout.splitlines():
        digest,name=line.split(maxsplit=1)
        assert identities[Path(name).name]['sha256'] == digest
    value.setdefault('prior_compilers',[]).append({name:value['files'][name] for name in ['compile-baseline','compile-candidate']})
    value['files'].update(identities)
    value['baseline_commit']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
    patch=subprocess.check_output(['git','diff','--binary'])
    (notes/'compare-current-candidate.patch').write_bytes(patch)
    value['candidate_patch_sha256']=hashlib.sha256(patch).hexdigest()
    value['untracked_source_hashes']={name:hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()}
    value['tags']={name:str(root) for name,root in roots.items()}
    manifest.write_text(json.dumps(value,indent=2)+'\n')
    print('updated',len(files),'files')
elif mode == 'run':
    value = json.loads(manifest.read_text())
    phase = sys.argv[2]
    command = ['python3','-B',value['remote_directory']+'/compare-run.py',phase]
    if phase in ['trace','measure','cost']:
        command = ['/home/benvanik/.dotfiles/bin/benchmark-lock','--label','scan-compare-'+phase,'--',*command]
    with (notes/('compare-'+sys.argv[2]+'.log')).open('w') as output:
        result = subprocess.run(['ssh','-o','BatchMode=yes','hrx-gorgon-3',shlex.join(command)],stdout=output,stderr=subprocess.STDOUT)
    (notes/('compare-'+phase+'-run.json')).write_text(json.dumps({'command':command,'exit_code':result.returncode},indent=2)+'\n')
    print(phase,result.returncode)
    sys.exit(result.returncode)
elif mode == 'collect':
    value = json.loads(manifest.read_text())
    inventory = json.loads(remote(['python3','-B','-c','from pathlib import Path; import hashlib,json,sys; root=Path(sys.argv[1]); print(json.dumps({str(p.relative_to(root)):{"sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"bytes":p.stat().st_size} for p in root.rglob("*") if p.is_file()}))',value['remote_directory']],capture_output=True,text=True).stdout)
    names = [name for name in inventory if name.endswith(('.json','.s','.txt','.csv'))]
    payload = remote(['tar','-cf','-','-C',value['remote_directory'],*names],capture_output=True).stdout
    with tarfile.open(fileobj=io.BytesIO(payload),mode='r:') as archive:
        for member in archive:
            assert member.name in names and member.isfile()
            data = archive.extractfile(member).read()
            assert hashlib.sha256(data).hexdigest() == inventory[member.name]['sha256']
            (notes/('compare-'+member.name.replace('/','-'))).write_bytes(data)
    value['inventory'] = inventory
    manifest.write_text(json.dumps(value,indent=2)+'\n')
    print('retained',len(names),'files',sum(inventory[n]['bytes'] for n in names),'bytes')
elif mode == 'retire':
    value = json.loads(manifest.read_text())
    script = '''from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1])
expected=json.load(sys.stdin)
assert root.parent == Path('/tmp') and root.name.startswith('loom-compare-operands.')
assert root.is_dir() and not root.is_symlink()
paths=list(root.rglob('*'))
assert all(not p.is_symlink() and p.name != '__pycache__' for p in paths)
actual={str(p.relative_to(root)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in paths if p.is_file()}
assert actual == expected
for p in paths:
    if p.is_file(): p.unlink()
for p in sorted((p for p in paths if p.is_dir()),key=lambda p:len(p.parts),reverse=True): p.rmdir()
root.rmdir()
print('retired',root)
'''
    remote(['python3', '-B', '-c', script, value['remote_directory']], input=json.dumps(value['inventory']), text=True)
    value['remote_retired'] = True
    manifest.write_text(json.dumps(value, indent=2) + '\n')
else:
    raise ValueError(mode)
