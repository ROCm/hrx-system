#pragma once
#include "ordered-algebra.h"
#include <loomcxx/atomic.h>
#include <loomcxx/scalar.h>
#include <loomcxx/vector.h>

using Pair = unsigned __attribute__((ext_vector_type(2)));
using Values = unsigned __attribute__((ext_vector_type(16)));
using Block = unsigned __attribute__((ext_vector_type(32)));

static LOOM_FORCE_INLINE Pair combine(Pair left, Pair right) {
  Affine result = compose({left[0], left[1]}, {right[0], right[1]});
  return {result.scale, result.offset};
}

static LOOM_FORCE_INLINE Pair read_pair(const Affine* source) {
  auto view = loom::buffer::view<2>(reinterpret_cast<const unsigned*>(source),
                                   {}, loom::encoding::layout::dense<1>());
  return loom::vector::load<Pair>(view, {0});
}

static LOOM_FORCE_INLINE void write_pair(Pair value, Affine* destination) {
  auto view = loom::buffer::view<2>(reinterpret_cast<unsigned*>(destination),
                                   {}, loom::encoding::layout::dense<1>());
  loom::vector::store(value, view, {0});
}

static LOOM_FORCE_INLINE void local_barrier() {
  loom::kernel::barrier<loom::memory_space::workgroup,
      loom::atomic::scope::workgroup, loom::atomic::ordering::acq_rel>();
}

static LOOM_FORCE_INLINE Pair wave_inclusive(Pair value) {
  unsigned width = loom::kernel::subgroup::size();
  [[loom::unroll]]
  for (unsigned level = 0; level < 6; ++level) {
    unsigned distance = 1u << level;
    if (distance < width) {
      auto previous = loom::kernel::subgroup::shuffle_up(value, distance, width);
      if (previous.valid) value = combine(previous.value, value);
    }
  }
  return value;
}

static LOOM_FORCE_INLINE Pair reverse_window(Pair value) {
  unsigned width = loom::kernel::subgroup::size();
  [[loom::unroll]]
  for (unsigned level = 0; level < 6; ++level) {
    unsigned distance = 1u << level;
    if (distance < width) {
      auto previous = loom::kernel::subgroup::shuffle_down(value, distance, width);
      if (previous.valid) value = combine(previous.value, value);
    }
  }
  return loom::kernel::subgroup::broadcast(value, 0u);
}

struct Prefix {
  // Product of all earlier thread sequences in the workgroup.
  Pair exclusive;
  // Product of every thread sequence in the workgroup.
  Pair total;
};

// Each thread publishes one total. The first complete subgroup owns the
// ordered scan of those totals and returns prefixes through the same storage.
static LOOM_FORCE_INLINE Prefix group_prefix(Pair value, Affine* exchange,
                                              unsigned padding_period) {
  unsigned width = loom::kernel::subgroup::size();
  unsigned lane = loom::kernel::subgroup::lane_id();
  unsigned subgroup = loom::kernel::subgroup::id();
  unsigned logical_thread = subgroup * width + lane;
  unsigned threads = loom::kernel::workgroup::size.x;
  unsigned terms = threads / width;
  write_pair(value, exchange + logical_thread + logical_thread / padding_period);
  local_barrier();
  if (subgroup == 0) {
    Values scales = {};
    Values offsets = {};
    Pair total = {1, 0};
    [[loom::unroll]]
    for (unsigned index = 0; index < terms; ++index) {
      unsigned rank = lane * terms + index;
      Pair term = read_pair(exchange + rank + rank / padding_period);
      scales[index] = term[0];
      offsets[index] = term[1];
      total = combine(total, term);
    }
    Pair inclusive = wave_inclusive(total);
    auto predecessor = loom::kernel::subgroup::shuffle_up(inclusive, 1u, width);
    Pair prefix = {1, 0};
    if (predecessor.valid) prefix = predecessor.value;
    [[loom::unroll]]
    for (unsigned index = 0; index < terms; ++index) {
      unsigned rank = lane * terms + index;
      prefix = combine(prefix, {scales[index], offsets[index]});
      write_pair(prefix, exchange + rank + rank / padding_period);
    }
  }
  local_barrier();
  Pair exclusive = {1, 0};
  if (logical_thread != 0) {
    unsigned rank = logical_thread - 1;
    exclusive = read_pair(exchange + rank + rank / padding_period);
  }
  unsigned last = threads - 1;
  Pair total = read_pair(exchange + last + last / padding_period);
  return {exclusive, total};
}

struct Publication {
  // Zero is unavailable, one is an aggregate, and two is a completed prefix.
  unsigned state;
  // Immutable payload selected by the acquired state, or the identity for zero.
  Pair value;
};

static LOOM_FORCE_INLINE Publication observe(const unsigned* states,
    const Affine* aggregates, const Affine* prefixes, unsigned position) {
  unsigned state = loom::view::atomic::load<loom::atomic::ordering::acquire,
      loom::atomic::scope::device>(states + position);
  Pair value = {1, 0};
  if (state == 1) value = read_pair(aggregates + position);
  if (state == 2) value = read_pair(prefixes + position);
  return {state, value};
}

static LOOM_FORCE_INLINE void publish(unsigned state, Pair value,
    unsigned position, unsigned* states, Affine* payload) {
  write_pair(value, payload + position);
  loom::view::atomic::store<loom::atomic::ordering::release,
      loom::atomic::scope::device>(state, states + position);
}

static LOOM_FORCE_INLINE unsigned first_matching_lane(bool predicate) {
  unsigned width = loom::kernel::subgroup::size();
  unsigned long long mask = loom::kernel::subgroup::vote::ballot(predicate);
  unsigned lane = static_cast<unsigned>(loom::scalar::cttzi(mask));
  return lane < width ? lane : width;
}

static LOOM_FORCE_INLINE Pair recompute(const Affine* input, unsigned count,
                                        unsigned predecessor, unsigned tile) {
  unsigned width = loom::kernel::subgroup::size();
  unsigned lane = loom::kernel::subgroup::lane_id();
  unsigned terms = tile / width;
  unsigned begin = predecessor * tile + lane * terms;
  Pair partial = {1, 0};
  for (unsigned index = 0; index < terms; ++index) {
    Pair value = {1, 0};
    if (begin + index < count) value = read_pair(input + begin + index);
    partial = combine(partial, value);
  }
  partial = wave_inclusive(partial);
  return loom::kernel::subgroup::broadcast(partial, width - 1);
}
