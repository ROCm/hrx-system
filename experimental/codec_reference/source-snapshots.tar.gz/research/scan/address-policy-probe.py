"""Compare the same retained source IR across address-policy experiments."""

import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("label")
parser.add_argument("--compiler", default="bazel-bin/loom/src/loom/tools/loom-compile/loom-compile")
options = parser.parse_args()
notes = Path(__file__).resolve().parent
output = notes / "address-policy"
output.mkdir(exist_ok=True)
compiler = Path(options.compiler).resolve()
result = {
    "commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
    "patch_sha256": hashlib.sha256(subprocess.check_output(["git", "diff", "HEAD"])).hexdigest(),
    "compiler_sha256": hashlib.sha256(compiler.read_bytes()).hexdigest(),
    "cases": [],
}
for source in ("mixed-address", "natural-final", "striped-base", "striped-qualified"):
    for case, target in (("rdna-forward", "amdgpu:gfx1151"), ("cdna-forward", "amdgpu:gfx942")):
        name = f"{source}-{case}"
        trace = (notes / f"audit-{name}.loom").read_text()
        before = trace.split("// Loom IR dump after pass source-to-low", 1)[0]
        start = before.index("kernel.def")
        before = before[start:].rsplit("//===", 1)[0]
        frozen = output / f"{name}.before.loom"
        if frozen.exists():
            assert frozen.read_text() == before
        else:
            frozen.write_text(before)
        with tempfile.TemporaryDirectory(prefix="loom-address-policy-") as temporary:
            temporary = Path(temporary)
            artifact = temporary / "kernel.hsaco"
            report = temporary / "report.json"
            command = [str(compiler), str(frozen), f"--target={target}",
                       "--root=scan_lookback", f"--output={artifact}",
                       "--compile-report=details", f"--compile-report-output={report}"]
            process = subprocess.run(command, capture_output=True, text=True)
            row = {"source": source, "target": target, "source_sha256": hashlib.sha256(before.encode()).hexdigest(),
                   "command": command, "exit_code": process.returncode,
                   "diagnostics": process.stdout + process.stderr}
            if process.returncode == 0:
                details = json.loads(report.read_text())
                row.update({key: details[key] for key in ("emission", "target_resources", "allocation", "static_instruction_mix") if key in details})
                assembly = subprocess.check_output(["llvm-objdump", "--disassemble", "--mcpu=" + target.split(":")[1], str(artifact)], text=True)
                (output / f"{options.label}-{name}.s").write_text(assembly)
                row["vector_wide_shift_count"] = len(re.findall(r"\bv_lshlrev_b64\b", assembly))
            result["cases"].append(row)
            (output / f"{options.label}.json").write_text(json.dumps(result, indent=2) + "\n")
            print(name, process.returncode, row.get("emission", row["diagnostics"][:200]), flush=True)
            if process.returncode:
                raise SystemExit(process.returncode)
