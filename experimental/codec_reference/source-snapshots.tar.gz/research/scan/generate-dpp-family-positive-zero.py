"""Bounded native family witness with independent serial scalar prefixes."""
from pathlib import Path
import sys

workitems, components = map(int, sys.argv[1:3])
assert 1 <= workitems <= 1024 and 1 <= components <= 32

rows = [
    ('addi', 'i32', '0', '-1073741823', '104729', '17'),
    ('muli', 'i32', '1', '3', '2', '13'),
    ('minsi', 'i32', '2147483647', '-27', '3', '23'),
    ('maxsi', 'i32', '-2147483648', '-27', '3', '23'),
    ('minui', 'i32', '-1', '-17', '3', '23'),
    ('maxui', 'i32', '0', '-17', '3', '23'),
    ('andi', 'i32', '-1', '-19', '7', '17'),
    ('ori', 'i32', '0', '-19', '7', '17'),
    ('xori', 'i32', '0', '-19', '7', '17'),
    ('addf', 'f32', '0.0', '-1.0', '0.25', '17'),
    ('mulf', 'f32', '1.0', '-1.0', '2.0', '2'),
    ('minnumf', 'f32', 'inf', '-1.0', '0.25', '17'),
    ('maxnumf', 'f32', '-inf', '-1.0', '0.25', '17'),
]
text = ['''config.decl @scan_family.workitems : %value: index where [range(%value, 1, 1024)]
config.decl @scan_family.components : %value: index where [range(%value, 1, 32)]
''']
for kind, scalar, identity, offset, step, period in rows:
    input_type = f'view<[%count]x[%components]x{scalar}>'
    output_type = f'view<[%count]x4x[%components]x{scalar}>'
    vector_type = f'vector<[%components]x{scalar}>'
    text.append(f'''
kernel.def @scan_family_{kind}() {{
  %unit = index.constant 1 : index
  %count = config.get @scan_family.workitems : index
  kernel.launch.config workgroups(%unit, %unit, %unit) workgroup_size(%count, %unit, %unit) : index
}} launch(%input: buffer, %output: buffer) {{
  %count = config.get @scan_family.workitems : index
  %components = config.get @scan_family.components : index
  %base = index.constant 0 : offset
  %item = kernel.workitem.id<x> : index
  %input_view = buffer.view %input[%base] : buffer -> {input_type}
  %output_view = buffer.view %output[%base] : buffer -> {output_type}
  %value = vector.load %input_view[%item, 0] : {input_type} -> {vector_type}
''')
    for mode_index, (direction, mode) in enumerate((('forward','inclusive'),('forward','exclusive'),('reverse','inclusive'),('reverse','exclusive'))):
        text.append(f'''  %result{mode_index} = kernel.workgroup.scan<{kind}> %value {{direction = {direction}, mode = {mode}}} : {vector_type}
  vector.store %result{mode_index}, %output_view[%item, {mode_index}, 0] : {vector_type}, {output_type}
''')
    text.append(f'''  kernel.return
}}

func.def @scan_family_{kind}_oracle(%input: buffer, %output: buffer) {{
  %count = config.get @scan_family.workitems : index
  %components = config.get @scan_family.components : index
  %base = index.constant 0 : offset
  %zero = index.constant 0 : index
  %one = index.constant 1 : index
  %last = index.sub %count, %one : index
  %identity = scalar.constant {identity} : {scalar}
  %input_view = buffer.view %input[%base] : buffer -> {input_type}
  %output_view = buffer.view %output[%base] : buffer -> {output_type}
  scf.for %component = [%zero to %components step %one] {{
    %forward_total = scf.for %position = [%zero to %count step %one](%prefix = %identity : {scalar}) -> ({scalar}) {{
      %value = view.load %input_view[%position, %component] : {input_type} -> {scalar}
      %next = scalar.{kind} %prefix, %value : {scalar}
      view.store %next, %output_view[%position, 0, %component] : {scalar}, {output_type}
      view.store %prefix, %output_view[%position, 1, %component] : {scalar}, {output_type}
      scf.yield %next : {scalar}
    }}
    %reverse_total = scf.for %iteration = [%zero to %count step %one](%suffix = %identity : {scalar}) -> ({scalar}) {{
      %position = index.sub %last, %iteration : index
      %value = view.load %input_view[%position, %component] : {input_type} -> {scalar}
      %next = scalar.{kind} %suffix, %value : {scalar}
      view.store %next, %output_view[%position, 2, %component] : {scalar}, {output_type}
      view.store %suffix, %output_view[%position, 3, %component] : {scalar}, {output_type}
      scf.yield %next : {scalar}
    }}
  }}
  func.return
}}

check.scenario @scan_family_{kind}_values {{
  check.trial[1](%trial: index, %entropy: check.entropy) {{
    %count = config.get @scan_family.workitems : index
    %components = config.get @scan_family.components : index
    %input = check.generate.iota offset({offset}) step({step}) period({period}) : tensor<[%count]x[%components]x{scalar}>
    %output = check.generate.fill value({"37.0" if scalar == "f32" else "37"}) : tensor<[%count]x4x[%components]x{scalar}>
    check.compare<@scan_family_{kind}, @scan_family_{kind}_oracle>(%input, %output) : (tensor<[%count]x[%components]x{scalar}>, tensor<[%count]x4x[%components]x{scalar}>) -> () {{
      check.expect.bitwise actual(%input) expected(%input) : tensor<[%count]x[%components]x{scalar}>
      check.expect.bitwise actual(%output) expected(%output) : tensor<[%count]x4x[%components]x{scalar}>
    }}
  }}
  check.return
}}
''')
source = ''.join(text)
source = '\n'.join(line for line in source.splitlines() if not line.startswith('config.decl ')) + '\n'
# Trial declarations own statically shaped inputs; configuration belongs in
# compiled callers, not the scenario planner's input declaration region.
source = source.replace('    %count = config.get @scan_family.workitems : index\n', '')
source = source.replace('    %components = config.get @scan_family.components : index\n', '')
source = source.replace('config.get @scan_family.workitems : index', f'index.constant {workitems} : index')
source = source.replace('config.get @scan_family.components : index', f'index.constant {components} : index')
source = source.replace('[%count]', str(workitems)).replace('[%components]', str(components))
if len(sys.argv) > 3:
    assert sys.argv[3] == '--wave64'
    source = 'amdgpu.target<gfx11-generic> @scan_family_wave64 {subgroup_size = 64}\n' + source.replace('kernel.def @', 'kernel.def target(@scan_family_wave64) @')
Path(__file__).with_name('dpp-family.loom').write_text(source)

