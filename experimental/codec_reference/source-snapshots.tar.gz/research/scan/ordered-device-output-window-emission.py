"""Compile the bounded ordered lookback profiles and retain textual evidence."""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import tempfile

notes = Path(__file__).resolve().parent
root = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['ordered-scan-current'])
tools = {name: root / f'loom/src/loom/tools/{name}/{name}'
         for name in ['loom-import-cxx', 'loom-link', 'loom-compile']}
for name in ['ordered-device-output-window', 'ordered-algebra']:
    subprocess.run([str(tools['loom-import-cxx']), str(notes / (name + '.cxx')),
                    '--output=' + str(notes / (name + '-imported.loom'))], check=True)
rows = []
with tempfile.TemporaryDirectory(prefix='codec-ordered-device-output-window-') as directory:
    directory = Path(directory)
    module = directory / 'ordered.loombc'
    subprocess.run([str(tools['loom-link']), '--mode=merge', '--to=bc',
                    str(notes / 'ordered-device-output-window-imported.loom'),
                    str(notes / 'ordered-algebra-imported.loom'),
                    '--output=' + str(module)], check=True)
    for profile in ['normal', 'diagnostic', 'force', 'reverse']:
        config = {'scan': {'capacity': 16777216, 'subgroups': 8, 'items': 16,
                           'refresh_rounds': 16, 'padding_period': 32, 'diagnostics': profile != 'normal',
                           'force_recompute': profile == 'force',
                           'reverse_schedule': profile == 'reverse'}}
        config_path = notes / f'ordered-device-output-window-{profile}-config.json'
        config_path.write_text(json.dumps(config, indent=2) + '\n')
        for entry in ['reset_states', 'scan_output_window']:
            name = f'ordered-device-output-window-{profile}-{entry}'
            artifact = directory / (name + '.hsaco')
            subprocess.run([str(tools['loom-compile']), str(module), '--root=' + entry,
                            '--target=amdgpu:gfx1151', '--config-file=' + str(config_path),
                            '--output=' + str(artifact), *[]], check=True)
            assembly = subprocess.check_output(['llvm-objdump', '-d', '--mcpu=gfx1151', str(artifact)], text=True)
            metadata = subprocess.check_output(['llvm-readelf', '-n', '-S', str(artifact)], text=True)
            (notes / (name + '.s')).write_text(assembly)
            (notes / (name + '-metadata.txt')).write_text(metadata)
            row = {'profile': profile, 'entry': entry, 'artifact_bytes': artifact.stat().st_size,
                   'sha256': hashlib.sha256(artifact.read_bytes()).hexdigest(),
                   'instructions': len(re.findall(r'//\s*[0-9a-fA-F]+:', assembly)),
                   'text_bytes': int(re.search(r'\.text\s+PROGBITS\s+\S+\s+\S+\s+(\S+)', metadata)[1], 16)}
            for field in ['group_segment_fixed_size', 'private_segment_fixed_size',
                          'sgpr_count', 'vgpr_count', 'wavefront_size']:
                row[field] = int(re.search(r'\.' + field + r':\s+(\d+)', metadata)[1])
            rows.append(row)
            print(json.dumps(row), flush=True)
    receipt = {'compiler': 'ca467cdd8403ab867d91e3040b02363861242e02',
               'module_bytes': module.stat().st_size,
               'module_sha256': hashlib.sha256(module.read_bytes()).hexdigest(), 'rows': rows}
    (notes / 'ordered-device-output-window-emission.json').write_text(json.dumps(receipt, indent=2) + '\n')
