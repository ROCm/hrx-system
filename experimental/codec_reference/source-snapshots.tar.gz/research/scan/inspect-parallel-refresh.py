from pathlib import Path
import hashlib,json,re,subprocess
sdk=Path('/home/ben/tools/rocm-sdk-10.0.0-gfx1151/lib/python3.14/site-packages/_rocm_sdk_devel/llvm/bin')
result=[]
for variant,module in [('control','scan.loombc'),('parallel','parallel.loombc')]:
 artifact=Path(variant+'.hsaco')
 subprocess.run(['./compile',module,'--target=amdgpu:gfx1151','--root=scan_lookback','--config-file=address-config.json','--output='+str(artifact)],check=True)
 assembly=subprocess.check_output([sdk/'llvm-objdump','-d',artifact],text=True)
 metadata=subprocess.check_output([sdk/'llvm-readelf','-n','-S',artifact],text=True)
 Path(variant+'.s').write_text(assembly);Path(variant+'.metadata.txt').write_text(metadata)
 row={'variant':variant,'sha256':hashlib.sha256(artifact.read_bytes()).hexdigest(),'text_bytes':int(re.search(r'\]\s+\.text\s+PROGBITS\s+\S+\s+\S+\s+([0-9a-fA-F]+)',metadata)[1],16)}
 for field in ['group_segment_fixed_size','private_segment_fixed_size','sgpr_count','vgpr_count','wavefront_size']:row[field]=int(re.search(r'\.'+field+r':\s+(\d+)',metadata)[1])
 row['instructions']=len(re.findall(r'//\s*[0-9a-fA-F]+:',assembly));result.append(row);print(json.dumps(row),flush=True)
Path('parallel-native.json').write_text(json.dumps(result,indent=2)+'\n')
