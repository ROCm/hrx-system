from pathlib import Path
import hashlib,json,re,subprocess
sdk=Path('/home/ben/tools/rocm-sdk-10.0.0-gfx1151/lib/python3.14/site-packages/_rocm_sdk_devel/llvm/bin')
config=json.loads(Path('address-config.json').read_text()); config['scan']['packed_state']=True; config['scan']['capacity']=65537
rows=[]
for name,diagnostics in [('uninstrumented',False),('phase',True)]:
    config['scan']['diagnostics']=diagnostics
    Path('phase-config.json').write_text(json.dumps(config)+'\n')
    artifact=Path(name+'.hsaco')
    subprocess.run(['./compile','phase.loombc','--target=amdgpu:gfx1151','--root=scan_lookback','--config-file=phase-config.json','--output='+str(artifact)],check=True)
    assembly=subprocess.check_output([sdk/'llvm-objdump','-d',artifact],text=True)
    metadata=subprocess.check_output([sdk/'llvm-readelf','-n','-S',artifact],text=True)
    Path(name+'.s').write_text(assembly);Path(name+'.metadata.txt').write_text(metadata)
    row={'variant':name,'sha256':hashlib.sha256(artifact.read_bytes()).hexdigest(),'text_bytes':int(re.search(r'\]\s+\.text\s+PROGBITS\s+\S+\s+\S+\s+([0-9a-fA-F]+)',metadata)[1],16),'instructions':len(re.findall(r'//\s*[0-9a-fA-F]+:',assembly))}
    for field in ['group_segment_fixed_size','private_segment_fixed_size','sgpr_count','vgpr_count','wavefront_size']:row[field]=int(re.search(r'\.'+field+r':\s+(\d+)',metadata)[1])
    rows.append(row)
Path('phase-native.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
