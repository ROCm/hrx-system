"""Inspect the same imported scan modules with two qualified compiler builds."""
from pathlib import Path
import collections
import hashlib
import json
import os
import re
import subprocess
import sys
import time

os.chdir(Path(__file__).resolve().parent)
llvm = Path('/opt/rocm/llvm/bin')
scan_cases = [(str(n), n, threads, items, source) for n,threads,items,source in [
    (32,32,1,'scan.loombc'), (512,32,16,'scan.loombc'),
    (65537,256,4,'storage-disjoint.loombc'),
    (2097152,128,8,'scan.loombc'), (16777216,64,8,'scan.loombc')]]
scan_cases.append(('smem-512',512,32,16,'short-length.loombc'))

def capture(arguments):
    return subprocess.check_output([str(a) for a in arguments],text=True)

def run(arguments):
    subprocess.run([str(a) for a in arguments],check=True)

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

phase = sys.argv[1]
if phase in ['build','trace']:
    run([sys.executable,'-B','dpp-landing-run.py',phase])
elif phase == 'inspect':
    rows = []
    cases = [(str(n),n,'storage-disjoint.loombc' if n == 65537 else 'scan.loombc') for n in [32,512,65537,2097152,16777216]]
    cases += [('smem-512',512,'short-length.loombc'),('uniform',0,'uniform.loombc')]
    for label,count,source in cases:
        for variant in ['baseline','candidate']:
            entries = ['compare_uniform_count'] if count == 0 else (['scan_single'] if count <= 512 else ['reset_states','scan_lookback'])
            for entry in entries:
                name = f'{variant}-{label}-{entry}'
                arguments = ['./compile-'+variant,source,'--target=amdgpu:gfx1151','--root='+entry,'--output='+name+'.hsaco','--compile-report=summary','--compile-report-output='+name+'-report.json']
                if count:
                    arguments += ['--config-file=config-'+str(count)+'.json']
                run(arguments)
                assembly = capture([llvm/'llvm-objdump','-d',name+'.hsaco'])
                metadata = capture([llvm/'llvm-readelf','-n','-S',name+'.hsaco'])
                Path(name+'.s').write_text(assembly)
                Path(name+'.metadata.txt').write_text(metadata)
                instructions = collections.Counter(re.findall(r'^\s+(\w+)\s+.*//\s*[0-9A-Fa-f]+:',assembly,re.M))
                row = {'variant':variant,'label':label,'count':count,'entry':entry,'artifact':name+'.hsaco','sha256':digest(name+'.hsaco'),'instructions':sum(instructions.values()),'instruction_mix':dict(instructions),'scalar_broadcasts':len(re.findall(r'^\s+v_mov_b32(?:_e32)?\s+v\d+,\s+s\d+\b',assembly,re.M)),'text_bytes':int(re.search(r'\]\s+\.text\s+PROGBITS\s+\S+\s+\S+\s+([0-9a-fA-F]+)',metadata)[1],16)}
                for field in ['group_segment_fixed_size','private_segment_fixed_size','sgpr_count','vgpr_count','wavefront_size']:
                    row[field] = int(re.search(r'\.'+field+r':\s+(\d+)',metadata)[1])
                rows.append(row)
                print(json.dumps(row),flush=True)
    Path('native-images.json').write_text(json.dumps(rows,indent=2)+'\n')
    for variant in ['baseline','candidate']:
        Path('size-'+variant+'.txt').write_text(capture(['size','-A','compile-'+variant]))
elif phase == 'corpus':
    rows=[]
    for profile in ['gfx942','gfx1100','gfx1151']:
        for label,kind,source in [('half','f16','compare-scalar-corpus-inspect.loom'),
                                  ('float','f32','compare-scalar-corpus-inspect.loom'),
                                  ('double','f64','compare-scalar-corpus-inspect.loom'),
                                  ('integer','[iu]32','compare-integer-corpus-inspect.loom')]:
            name=f'corpus-{label}-{profile}'
            run(['./compile-candidate',source,'--target=amdgpu:'+profile,
                 '--root=inspect_'+label,'--output='+name+'.hsaco'])
            assembly=capture([llvm/'llvm-objdump','-d',name+'.hsaco'])
            Path(name+'.s').write_text(assembly)
            forms=collections.Counter()
            predicates=collections.Counter()
            for match in re.finditer(r'\bv_cmp_(\w+)_(?:'+kind+r')(?:_e64|_e32)?\s+[^,]+,\s*([sv](?:\[\d+:\d+\]|\d+))(?:\.[lh])?,\s*([sv](?:\[\d+:\d+\]|\d+))(?:\.[lh])?',assembly):
                predicate,lhs,rhs=match.groups()
                forms[lhs[0]+rhs[0]]+=1
                predicates[predicate]+=1
            row={'profile':profile,'kind':label,'operand_forms':dict(forms),'predicates':dict(predicates),
                 'scalar_compare_count':len(re.findall(r'\bs_cmp_\w+_(?:'+kind+r')\s',assembly)),
                 'sha256':digest(name+'.hsaco'),'source_sha256':digest(source)}
            rows.append(row)
            print(json.dumps(row),flush=True)
    Path('corpus-operand-classes.json').write_text(json.dumps(rows,indent=2)+'\n')
elif phase in ['measure','cost']:
    print('lease='+os.environ['BENCHMARK_LOCK_LEASE_ID'],flush=True)
    print('phase='+phase,flush=True)
    print('cpu_governor='+Path('/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor').read_text().strip(),flush=True)
    print('gpu_power_level='+Path('/sys/class/drm/card0/device/power_dpm_force_performance_level').read_text().strip(),flush=True)
    for row in json.loads(Path('native-images.json').read_text()):
        assert digest(row['artifact']) == row['sha256']
    if phase == 'measure':
        assert Path('/sys/class/drm/card0/device/gpu_busy_percent').read_text().strip() == '0'
        run(['vmstat','1','3'])
        for label,count,threads,items,source in scan_cases:
            for allocation in range(3 if count == 2097152 else 1):
                print(f'case={label}-allocation{allocation}',flush=True)
                run(['./geometry',str(count),str(16 if count == 16777216 else 128),
                     str(threads),str(items),str(threads),str(items),
                     'baseline-'+label,'candidate-'+label,'measure'])
        run(['vmstat','1','3'])
    else:
        costs=[]
        for label,count,threads,items,source in scan_cases:
            entry='scan_single' if count <= threads*items else 'scan_lookback'
            for repeat in range(10):
                for variant in (['baseline','candidate'] if repeat%2 == 0 else ['candidate','baseline']):
                    start=time.monotonic_ns()
                    run(['./compile-'+variant,source,'--target=amdgpu:gfx1151',
                         '--root='+entry,'--config-file=config-'+str(count)+'.json',
                         '--output=cost-output.hsaco'])
                    elapsed=time.monotonic_ns()-start
                    assert digest('cost-output.hsaco') == digest(f'{variant}-{label}-{entry}.hsaco')
                    costs.append({'label':label,'count':count,'variant':variant,'repeat':repeat,
                                  'process_start_import_compile_emit_ns':elapsed})
        Path('compile-cost.json').write_text(json.dumps(costs,indent=2)+'\n')
else:
    raise ValueError(phase)
