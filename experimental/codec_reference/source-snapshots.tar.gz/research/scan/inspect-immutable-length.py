"""Static source-admission/code-generation gate for immutable device lengths."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tempfile

notes = Path(__file__).resolve().parent
compiler = Path('bazel-bin/loom/src/loom/tools/loom-compile/loom-compile').resolve()
output = notes / 'immutable-length-isa'
output.mkdir(exist_ok=True)
result = {
    'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'compiler_sha256': hashlib.sha256(compiler.read_bytes()).hexdigest(),
    'config': json.loads((notes / 'address-config.json').read_text()),
    'cases': [],
}
for variant, module in [('baseline', 'natural_scan'), ('immutable', 'immutable_length_scan')]:
    source = Path('bazel-bin/experimental/codec_reference/research/scan') / (module + '.loombc')
    for target in ('gfx1151', 'gfx942'):
        with tempfile.TemporaryDirectory(prefix='loom-immutable-length-') as directory:
            directory = Path(directory)
            artifact = directory / 'kernel.hsaco'
            report = directory / 'report.json'
            command = [str(compiler), str(source), '--target=amdgpu:' + target,
                       '--root=scan_lookback', '--config-file=' + str(notes / 'address-config.json'),
                       '--output=' + str(artifact), '--compile-report=details',
                       '--compile-report-output=' + str(report)]
            subprocess.run(command, check=True)
            details = json.loads(report.read_text())
            assembly = subprocess.check_output(['llvm-objdump', '-d', '--mcpu=' + target,
                                                 artifact], text=True)
            name = variant + '-' + target
            (output / (name + '.s')).write_text(assembly)
            row = {'variant': variant, 'target': target,
                   'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
                   'artifact_sha256': hashlib.sha256(artifact.read_bytes()).hexdigest(),
                   'scalar_load_count': len(re.findall(r'^\s+s_load_', assembly, re.MULTILINE)),
                   'barriers': len(re.findall(r'^\s+s_barrier\s', assembly, re.MULTILINE))}
            row.update({key: details[key] for key in
                        ('emission', 'target_resources', 'allocation', 'static_instruction_mix')
                        if key in details})
            result['cases'].append(row)
            print(name, row.get('emission'), row.get('target_resources'), flush=True)
(notes / 'immutable-length-static.json').write_text(json.dumps(result, indent=2) + '\n')
