"""Owned remote staging for the launch-specialization experiment."""
from pathlib import Path
import hashlib, io, json, os, shlex, subprocess, sys, tarfile
notes=Path(__file__).resolve().parent
manifest_path=notes/'launch-artifacts.json'
def remote(args,**kwargs):
 return subprocess.run(['ssh','-o','BatchMode=yes','noxa-pc',shlex.join(['ssh','-o','BatchMode=yes','ben@dogwood.tail63922.ts.net',shlex.join(args)])],check=True,**kwargs)
def stage(files,m):
 payload=io.BytesIO()
 with tarfile.open(fileobj=payload,mode='w',dereference=True) as a:
  for n,p in files.items(): a.add(p,arcname=n,recursive=False)
 remote(['tar','-xf','-','-C',m['remote_directory']],input=payload.getvalue(),capture_output=True)
 for n,p in files.items():
  digest=hashlib.sha256(p.read_bytes()).hexdigest()
  actual=remote(['sha256sum',m['remote_directory']+'/'+n],capture_output=True,text=True).stdout.split()[0]
  assert digest==actual
  m['files'][n]={'sha256':digest,'bytes':p.stat().st_size}
 manifest_path.write_text(json.dumps(m,indent=2)+'\n')
mode=sys.argv[1]
if mode=='prepare':
 assert not manifest_path.exists()
 m={'remote_directory':remote(['mktemp','-d','/tmp/loom-scan-launch.XXXXXXXX'],capture_output=True,text=True).stdout.strip(),'files':{}}
 stage({'pipeline-rocprim.cpp':notes/'pipeline-rocprim.cpp','launch-oracle.py':notes/'launch-oracle.py','launch-oracle.sh':notes/'launch-oracle.sh'},m)
 print(m['remote_directory'])
elif mode=='stage':
 m=json.loads(manifest_path.read_text()); root=Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['scan-launch'])
 m['tag_root']=str(root)
 stage({'loom':root/'loom/src/loom/tooling/target/amdgpu/serve/scan_launch_specialization_test','compile':root/'loom/src/loom/tools/loom-compile/loom-compile','scan.loombc':root/'experimental/codec_reference/research/scan/launch_scan.loombc','control.loombc':root/'experimental/codec_reference/research/scan/thread_refresh_scan.loombc'},m)
elif mode=='stage-extra':
 m=json.loads(manifest_path.read_text()); stage({n:notes/n for n in sys.argv[2:]},m)
elif mode=='run':
 m=json.loads(manifest_path.read_text()); phase=sys.argv[2]
 command=['/bin/bash',m['remote_directory']+'/launch-'+phase+'.sh',*sys.argv[3:]]
 if phase not in ['build','build-native','inspect','redundant-inspect','collective-inspect']: command=['/home/ben/.dotfiles/bin/benchmark-lock','--label','scan-launch-'+phase,'--',*command]
 with (notes/('launch-'+phase+'.log')).open('w') as out:
  try: remote(command,stdout=out,stderr=subprocess.STDOUT); result=0
  except subprocess.CalledProcessError as e: result=e.returncode
 (notes/('launch-'+phase+'-run.json')).write_text(json.dumps({'command':command,'exit_code':result},indent=2)+'\n')
 print(phase,result); sys.exit(result)
elif mode=='collect':
 m=json.loads(manifest_path.read_text())
 inv=json.loads(remote(['python3','-c','from pathlib import Path; import hashlib,json,sys; p=Path(sys.argv[1]); print(json.dumps({str(f.relative_to(p)):{"sha256":hashlib.sha256(f.read_bytes()).hexdigest(),"bytes":f.stat().st_size} for f in p.rglob("*") if f.is_file()}))',m['remote_directory']],capture_output=True,text=True).stdout)
 names=[n for n in inv if '/' not in n and n.endswith(('.json','.s','.txt','.ireeprof','.csv','.hpp'))]
 payload=remote(['tar','-cf','-','-C',m['remote_directory'],*names],capture_output=True).stdout
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:') as a:
  for member in a:
   assert member.name in names and member.isfile()
   data=a.extractfile(member).read(); assert hashlib.sha256(data).hexdigest()==inv[member.name]['sha256']
   (notes/('launch-'+member.name)).write_bytes(data)
 m['inventory']=inv; manifest_path.write_text(json.dumps(m,indent=2)+'\n'); print('retained',len(names))
elif mode=='retire':
 m=json.loads(manifest_path.read_text()); assert not m.get('retired') and m['remote_directory'].startswith('/tmp/loom-scan-launch.')
 program='''from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1]); expected=json.load(sys.stdin)
files={str(p.relative_to(root)):p for p in root.rglob('*') if p.is_file()}
assert set(files)==set(expected)
for n,p in files.items():
 assert '__pycache__' not in p.parts
 assert p.stat().st_size==expected[n]['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==expected[n]['sha256'],n
for p in files.values(): p.unlink()
print(json.dumps({'retired_files':len(files),'retired_bytes':sum(x['bytes'] for x in expected.values())}))
'''
 result=json.loads(remote(['python3','-c',program,m['remote_directory']],input=json.dumps(m['inventory']),capture_output=True,text=True).stdout)
 m.update(result,retired=True); manifest_path.write_text(json.dumps(m,indent=2)+'\n'); print(result)
else: raise ValueError(mode)
