#include <loomcxx/kernel.h>

struct Pair {
  // Low word of the probe payload.
  unsigned first;
  // High word distinguishes record stride from scalar stride.
  unsigned second;
};

[[loom::kernel, loom::workgroup_count(1, 1, 1), loom::workgroup_size(64, 1, 1)]]
void fixed_scalar(unsigned* output) {
  unsigned item = loom::kernel::workitem::id.x;
  auto* storage = loom::buffer::alloca<unsigned, loom::memory_space::workgroup>(64);
  storage[item] = item;
  loom::kernel::workgroup::barrier();
  unsigned value = 0;
  if (item >= 1) value = storage[item - 1];
  output[item] = value;
}

[[loom::kernel, loom::workgroup_count(1, 1, 1), loom::workgroup_size(64, 1, 1)]]
void fixed_record(Pair* output) {
  unsigned item = loom::kernel::workitem::id.x;
  auto* storage = loom::buffer::alloca<Pair, loom::memory_space::workgroup>(64);
  storage[item] = {item, item + 1};
  loom::kernel::workgroup::barrier();
  Pair value = {0, 0};
  if (item >= 1) value = storage[item - 1];
  output[item] = value;
}

[[loom::kernel, loom::workgroup_count(1, 1, 1), loom::workgroup_size(64, 1, 1)]]
void looped_scalar(unsigned* output) {
  unsigned item = loom::kernel::workitem::id.x;
  auto* storage = loom::buffer::alloca<unsigned, loom::memory_space::workgroup>(64);
  storage[item] = item;
  loom::kernel::workgroup::barrier();
  unsigned value = 0;
  for (unsigned distance = 1; distance < 64; distance *= 2) {
    if (item >= distance) value += storage[item - distance];
  }
  output[item] = value;
}

[[loom::kernel, loom::workgroup_count(1, 1, 1), loom::workgroup_size(64, 1, 1)]]
void looped_record(Pair* output) {
  unsigned item = loom::kernel::workitem::id.x;
  auto* storage = loom::buffer::alloca<Pair, loom::memory_space::workgroup>(64);
  storage[item] = {item, item + 1};
  loom::kernel::workgroup::barrier();
  Pair value = {0, 0};
  for (unsigned distance = 1; distance < 64; distance *= 2) {
    if (item >= distance) {
      Pair left = storage[item - distance];
      value.first += left.first;
      value.second += left.second;
    }
  }
  output[item] = value;
}
