"""Audit native operand classes from the authored numeric corpus."""
from pathlib import Path
import collections
import hashlib
import json
import os
import re
import subprocess
import tempfile

notes = Path(__file__).resolve().parent
compiler = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['scan-compare-candidate']) / 'loom/src/loom/tools/loom-compile/loom-compile'
rows = []
with tempfile.TemporaryDirectory(prefix='loom-compare-corpus-') as scratch:
    for profile in ['gfx942', 'gfx1100', 'gfx1151']:
        for label, kind, source in [
            ('half', 'f16', 'compare-scalar-corpus-inspect.loom'),
            ('float', 'f32', 'compare-scalar-corpus-inspect.loom'),
            ('double', 'f64', 'compare-scalar-corpus-inspect.loom'),
            ('integer', '[iu]32', 'compare-integer-corpus-inspect.loom'),
        ]:
            output = Path(scratch) / 'corpus.hsaco'
            subprocess.run([str(compiler), str(notes / source), '--target=amdgpu:' + profile,
                            '--root=inspect_' + label, '--output=' + str(output)], check=True)
            assembly = subprocess.check_output(['llvm-objdump', '-d', str(output)], text=True)
            (notes / f'compare-final-corpus-{label}-{profile}.s').write_text(assembly)
            pattern = r'\bv_cmp_(\w+)_(?:' + kind + r')(?:_e64|_e32)?\s+[^,]+,\s*([sv](?:\[\d+:\d+\]|\d+))(?:\.[lh])?,\s*([sv](?:\[\d+:\d+\]|\d+))(?:\.[lh])?'
            forms = collections.Counter()
            predicates = collections.Counter()
            for predicate, lhs, rhs in re.findall(pattern, assembly):
                forms[lhs[0] + rhs[0]] += 1
                predicates[predicate] += 1
            scalar_count = len(re.findall(r'\bs_cmp_\w+_(?:' + kind + r')\s', assembly))
            per_form = 40 if label == 'integer' else 14
            expected = {'sv': 2 * per_form, 'vs': per_form} if profile == 'gfx942' else {'sv': per_form, 'vs': per_form, 'ss': per_form}
            if profile == 'gfx1151' and label == 'float':
                del expected['ss']
                assert scalar_count == 14
            assert dict(forms) == expected, (profile, label, forms, expected)
            row = {'profile': profile, 'kind': label, 'operand_forms': dict(forms),
                   'predicates': dict(predicates), 'scalar_compare_count': scalar_count,
                   'native_sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
                   'source_sha256': hashlib.sha256((notes / source).read_bytes()).hexdigest()}
            rows.append(row)
            print(profile, label, dict(forms), 'scalar', scalar_count)
(notes / 'compare-final-corpus-operand-classes.json').write_text(json.dumps({
    'compiler_sha256': hashlib.sha256(compiler.read_bytes()).hexdigest(),
    'objdump_version': subprocess.check_output(['llvm-objdump', '--version'], text=True).splitlines()[0],
    'rows': rows,
}, indent=2) + '\n')
