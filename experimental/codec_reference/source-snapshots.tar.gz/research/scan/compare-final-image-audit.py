"""Prove rebased leaf modules emit the measured device programs."""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import tempfile
notes = Path(__file__).resolve().parent
roots = {k: Path(v) for k, v in json.loads(os.environ['BUREAU_TAG_ROOTS']).items()}
rows = json.loads((notes / 'compare-native-images.json').read_text())
modules = {'smem-512': 'short_length_kernels', 'uniform': 'uniform_count_compare', '65537': 'storage_disjoint_kernels'}
results = []
with tempfile.TemporaryDirectory(prefix='loom-compare-final-') as scratch:
    for row in rows:
        variant, label, entry = (row[k] for k in ['variant', 'label', 'entry'])
        compiler = roots['scan-compare-' + variant] / 'loom/src/loom/tools/loom-compile/loom-compile'
        source = roots['scan-compare-baseline'] / ('experimental/codec_reference/research/scan/' + modules.get(label, 'scan_kernels') + '.loombc')
        output = Path(scratch) / 'native.hsaco'
        arguments = [str(compiler), str(source), '--target=amdgpu:gfx1151', '--root=' + entry, '--output=' + str(output)]
        if row['count']:
            arguments.append('--config-file=' + str(notes / f"config-{row['count']}.json"))
            arguments[-1] = '--config-file=' + str(notes / ('gorgon-retune-256x4-config.json' if row['count'] == 65537 else f"gorgon-dpp-{row['count']}-config.json"))
        subprocess.run(arguments, check=True)
        assembly = subprocess.check_output(['llvm-objdump', '-d', str(output)], text=True)
        old = (notes / f'compare-{variant}-{label}-{entry}.s').read_text()
        words = lambda text: re.findall(r'//\s*[0-9a-fA-F]+:\s*([0-9a-fA-F ]+)', text)
        same = words(assembly) == words(old)
        new_hash = hashlib.sha256(output.read_bytes()).hexdigest()
        result = {'variant': variant, 'label': label, 'entry': entry,
                  'prior_sha256': row['sha256'], 'sha256': new_hash,
                  'identical_native_artifact': new_hash == row['sha256'],
                  'identical_instructions': same,
                  'module_sha256': hashlib.sha256(source.read_bytes()).hexdigest()}
        results.append(result)
        (notes / f'compare-rebased-{variant}-{label}-{entry}.s').write_text(assembly)
        print(variant, label, entry, 'artifact', result['identical_native_artifact'], 'ISA', same)
    sizes = {}
    for variant in ['baseline', 'candidate']:
        compiler = roots['scan-compare-' + variant] / 'loom/src/loom/tools/loom-compile/loom-compile'
        output = subprocess.check_output(['size', '-A', str(compiler)], text=True)
        sizes[variant] = {p[0]: int(p[1]) for line in output.splitlines() if len(p := line.split()) == 3 and p[0] in ['.text', '.rodata', '.data.rel.ro', '.data']}
        print(variant, sizes[variant])
(notes / 'compare-final-image-audit.json').write_text(json.dumps({'baseline_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(), 'rows': results, 'compiler_sections': sizes}, indent=2) + '\n')
assert all(row['identical_native_artifact'] for row in results)
