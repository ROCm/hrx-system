"""Compiler process end-to-end cost; includes startup, parsing, and emission."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

for source in ('natural_scan', 'striped_scan', 'striped_base_scan'):
    for variant in ('baseline', 'candidate'):
        subprocess.run([f'./compile-{variant}', source + '.loombc',
                        '--target=amdgpu:gfx1151', '--root=scan_lookback',
                        '--config-file=address-config.json',
                        f'--output={source}-{variant}.hsaco'],
                       check=True, stdout=subprocess.DEVNULL)
    for sample, variant in enumerate(('baseline', 'candidate', 'candidate', 'baseline') * 5):
        command = [f'./compile-{variant}', source + '.loombc',
                   '--target=amdgpu:gfx1151', '--root=scan_lookback',
                   '--config-file=address-config.json',
                   f'--output={source}-{variant}.hsaco']
        start = time.monotonic_ns()
        subprocess.run(command, check=True, stdout=subprocess.DEVNULL)
        print(json.dumps({'implementation': 'loom-compile', 'variant': variant,
                          'source': source, 'sample': sample,
                          'process_e2e_ns': time.monotonic_ns() - start}), flush=True)
    for variant in ('baseline', 'candidate'):
        path = Path(f'{source}-{variant}.hsaco')
        payload = path.read_bytes()
        print(json.dumps({'artifact': str(path), 'bytes': len(payload),
                          'sha256': hashlib.sha256(payload).hexdigest()}), flush=True)
