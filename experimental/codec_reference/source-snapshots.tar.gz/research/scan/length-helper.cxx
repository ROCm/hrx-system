#include <loomcxx/kernel.h>
#include <loomcxx/atomic.h>
static loom::kernel::configuration configure() {
  return {{1, 1, 1}, {128, 1, 1}};
}
static LOOM_FORCE_INLINE unsigned read_length(const unsigned* length) {
  return loom::buffer::assume_memory_space<loom::memory_space::constant>(length)[0];
}
[[loom::kernel(configure)]]
void guarded_barrier(const unsigned* length, unsigned* output) {
  unsigned count = read_length(length);
  if (count == 0) return;
  loom::kernel::barrier<loom::memory_space::workgroup,
      loom::atomic::scope::workgroup, loom::atomic::ordering::acq_rel>();
  output[loom::kernel::workitem::id.x] = count;
}
