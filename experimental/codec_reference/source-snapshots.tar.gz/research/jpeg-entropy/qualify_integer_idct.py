"""Compare every captured public integer component sample with the model."""
import hashlib
import json
from pathlib import Path

from device_fixture import input_bytes
from integer_idct import reconstruct
from sequential import decode, divide_up, parse

notes = Path(__file__).resolve().parent
reference = notes.parent / 'jpeg-gpu-oracle/raw-reference-small.log'
rows = [json.loads(line) for line in reference.read_text().splitlines()
        if line.startswith('{"name":')]
groups = {}
for row in rows:
    if row['method'] == 0:
        groups.setdefault(row['name'], []).append(row)
records = []
for name, expected_planes in groups.items():
    data = input_bytes(name)
    frame = parse(data)
    coefficients, counts = decode(frame)
    maximum_horizontal = max(component.horizontal for component in frame.components)
    maximum_vertical = max(component.vertical for component in frame.components)
    planes = []
    for component_index, (component, source) in enumerate(zip(frame.components, coefficients, strict=True)):
        width = divide_up(frame.width * component.horizontal, maximum_horizontal)
        height = divide_up(frame.height * component.vertical, maximum_vertical)
        pixels = bytearray(width * height)
        for block_row in range(component.block_height):
            for block_column in range(component.block_width):
                offset = (block_row * component.block_width + block_column) * 64
                block = reconstruct(source[offset:offset + 64], component.quantization)
                for row in range(8):
                    y = block_row * 8 + row
                    if y >= height:
                        break
                    x = block_column * 8
                    length = min(8, width - x)
                    pixels[y * width + x:y * width + x + length] = block[row * 8:row * 8 + length]
        expected = next(row for row in expected_planes if row['component'] == component_index)
        assert (width, height) == (expected['width'], expected['height'])
        oracle = bytes.fromhex(expected['hex'])
        assert pixels == oracle, (name, component_index,
            next((index, left, right) for index, (left, right) in enumerate(zip(pixels, oracle, strict=True)) if left != right))
        planes.append({'component': component_index, 'width': width, 'height': height,
                       'sha256': hashlib.sha256(pixels).hexdigest(), 'every_sample_equal': True})
    records.append({'name': name, 'input_sha256': hashlib.sha256(data).hexdigest(), 'planes': planes})
    print(json.dumps({'name': name, 'planes': len(planes), 'every_sample_equal': True}), flush=True)
result = {'state': 'All public integer component samples match; numerical model only, no native output timing.',
          'reference_sha256': hashlib.sha256(reference.read_bytes()).hexdigest(),
          'sources': {name: hashlib.sha256((notes / name).read_bytes()).hexdigest()
                      for name in ('integer_idct.py', 'qualify_integer_idct.py', 'sequential.py')},
          'cases': records}
(notes / 'integer-idct-qualified.json').write_text(json.dumps(result, indent=2) + '\n')
