"""Small device-count producer/consumer, no JPEG data or reconstruction."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
from device_fixture import write_words

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
directory = root / 'indirect-count-small'
directory.mkdir(exist_ok=True)
tags = json.loads(os.environ['BUREAU_TAG_ROOTS'])
base = Path(tags['codec-jpeg-rebased-tools']) / 'loom/src/loom/tools'
native = Path(tags['codec-jpeg-unsigned-opt']) / 'loom/src/loom/tools'
subprocess.run([str(base / 'loom-import-cxx/loom-import-cxx'), str(notes / 'indirect_count_probe.cxx'),
                '--output=' + str(directory / 'library.loom')], check=True)
(directory / 'summary.loom').write_text('''kernel.decl @write_grid() launch(%input: buffer, %schedule: buffer)
kernel.decl @read_grid(%schedule: buffer, %offset: offset) launch(%output: buffer)
command.program.def public @jpeg_decode() launch(%input: buffer, %schedule: buffer, %output: buffer) {
  %offset = index.constant 0 : offset
  command.serial {
    kernel.launch @write_grid(%input, %schedule) : (buffer, buffer)
    kernel.launch @read_grid[%schedule, %offset](%output) : [buffer, offset](buffer)
  }
  command.return
}
command.program.def public @jpeg_batch() launch(%input: buffer, %schedule: buffer, %output: buffer) {
  %zero = index.constant 0 : index
  %one = index.constant 1 : index
  %eight = index.constant 8 : index
  scf.for %repeat = [%zero to %eight step %one] unroll {
    command.program.launch @jpeg_decode(%input, %schedule, %output) : (buffer, buffer, buffer)
  }
  command.return
}
''')
(directory / 'config.json').write_text('{}\n')
write_words(directory / 'input.npy', [512, 16, 1])
write_words(directory / 'schedule.npy', [512, 16, 1])
write_words(directory / 'output.npy', [512, 16, 1, 32, 32] * (512 * 16) + [17] * 8)
(directory / 'bindings.txt').write_text('input 1 4 3 input.npy\nschedule 0 4 3 schedule.npy\noutput 0 4 40968 output.npy\n')
subprocess.run([str(base / 'loom-link/loom-link'), str(directory / 'summary.loom'), str(directory / 'library.loom'),
               '--to=bc', '--output=' + str(directory / 'summary.loombc')], check=True)
subprocess.run([str(native / 'loom-compile/loom-compile'), str(directory / 'summary.loombc'), '--root=read_grid',
               '--target=amdgpu:gfx1151', '--output=' + str(directory / 'read_grid.hsaco')], check=True)
with (notes / 'indirect-count-reader.native.s').open('w') as stream:
    subprocess.run(['/home/ben/tools/llvm/latest/bin/llvm-objdump', '-d', '--mcpu=gfx1151', str(directory / 'read_grid.hsaco')], stdout=stream, check=True)
files = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in directory.iterdir() if path.name != 'stage.json'}
(directory / 'stage.json').write_text(json.dumps({'files': files, 'scope': 'One GPU count producer followed by a GPU-configured launch, reading workgroup counts in every group. No JPEG.'}, indent=2) + '\n')
