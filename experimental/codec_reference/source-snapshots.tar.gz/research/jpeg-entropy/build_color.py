"""Build the bounded shared-chroma leaf; no GPU activity or large output."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
tags = json.loads(os.environ['BUREAU_TAG_ROOTS'])
base = Path(tags['codec-jpeg-rebased-tools']) / 'loom/src/loom/tools'
native = Path(tags['codec-jpeg-unsigned-opt']) / 'loom/src/loom/tools'
config = {'image': {'width': 4032, 'height': 3024, 'batch': 16, 'color_space': 3,
                    'horizontal0': 1, 'vertical0': 1, 'horizontal1': 2, 'vertical1': 2,
                    'horizontal2': 2, 'vertical2': 2}}
(root / 'color-config.json').write_text(json.dumps(config, indent=2) + '\n')
commands = [
    [str(base / 'loom-import-cxx/loom-import-cxx'), str(notes / 'device_color.cxx'), '--output=' + str(root / 'color.loom')],
    [str(base / 'loom-link/loom-link'), str(root / 'color.loom'), '--to=bc', '--output=' + str(root / 'color.loombc')],
    [str(native / 'loom-compile/loom-compile'), str(root / 'color.loombc'), '--root=jpeg_color',
     '--target=amdgpu:gfx1151', '--config-file=' + str(root / 'color-config.json'),
     '--output=' + str(root / 'jpeg_color.hsaco'), '--compile-report=details',
     '--compile-report-output=' + str(root / 'color-report.json')]]
for command in commands:
    subprocess.run(command, check=True)
with (root / 'jpeg_color-native.s').open('w') as stream:
    subprocess.run(['/home/ben/tools/llvm/latest/bin/llvm-objdump', '-d', '--mcpu=gfx1151',
                    str(root / 'jpeg_color.hsaco')], stdout=stream, check=True)
row = json.loads((root / 'color-report.json').read_text())['entries']['rows'][0]
metrics = {key: row[key] for key in ('instruction_count', 'code_byte_count', 'private_memory_bytes',
                                   'local_memory_bytes', 'target_resources')}
record = {'commands': commands, 'config': config, 'metrics': metrics,
          'files': {name: hashlib.sha256((root / name).read_bytes()).hexdigest()
                    for name in ('color.loombc', 'jpeg_color.hsaco', 'jpeg_color-native.s')},
          'sources': {name: hashlib.sha256((notes / name).read_bytes()).hexdigest()
                      for name in ('build_color.py', 'device_color.cxx')}}
(notes / 'color-native.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(metrics), flush=True)
