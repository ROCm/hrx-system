"""Build the bounded native caller in its existing owner package, then restore."""

import hashlib
import json
from pathlib import Path
import subprocess


notes = Path(__file__).resolve().parent
assert not subprocess.check_output(["git", "status", "--porcelain"], text=True)
build = Path("loom/src/loom/tooling/target/amdgpu/serve/BUILD.bazel")
original = build.read_bytes()
names = ["native_upload.c", "native_upload.h", "device_upload.h",
         "native_header.c", "native_header.h", "native_metadata.c", "native_metadata.h",
         "native_color.c", "native_color.h", "upload_probe.cc"]
files = {name: (notes / name).read_bytes() for name in names}
for name in names:
    assert not (build.parent / name).exists(), name
sources = ", ".join(json.dumps(name) for name in names)
target = '''
loom_cc_binary(
    name = "codec_upload_probe",
    testonly = True,
    srcs = [''' + sources + '''],
    deps = [
        ":test_compiler",
        ":test_device",
        "//loom/binding/c:loomc",
        "//loom/src/loom/serve/runtime/device",
        "//loom/src/loom/serve/runtime/execution",
        "//loom/src/loom/serve/runtime/host",
        "//loom/src/loom/serve/runtime/program:jit",
        "//loom/src/loom/serve/testing:compiler",
        "//loom/src/loom/serve/testing:device",
        "//runtime/src/iree/base",
        "//runtime/src/iree/base/tooling:flags",
        "//runtime/src/iree/hal",
        "//runtime/src/iree/testing:gtest",
        "//runtime/src/iree/testing:gtest_main",
    ],
)
'''
overlay = original + target.encode()
tag = "codec-jpeg-upload-checks"
command = ["bureau-bazel", "build", "--tag=" + tag, "--config=asan",
           "//loom/src/loom/tooling/target/amdgpu/serve:codec_upload_probe"]
receipt = notes / "upload-probe-build.json"
record = {"commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
          "tag": tag, "configuration": "asan", "command": command, "restored": False,
          "sources": {name: hashlib.sha256(data).hexdigest() for name, data in files.items()},
          "build_original_sha256": hashlib.sha256(original).hexdigest(),
          "build_overlay_sha256": hashlib.sha256(overlay).hexdigest()}
receipt.write_text(json.dumps(record, indent=2) + "\n")
build.write_bytes(overlay)
for name, data in files.items():
    (build.parent / name).write_bytes(data)
try:
    result = subprocess.run(command)
    record["build_returncode"] = result.returncode
finally:
    assert build.read_bytes() == overlay
    for name, data in files.items():
        assert (build.parent / name).read_bytes() == data
    build.write_bytes(original)
    for name in files:
        (build.parent / name).unlink()
    record["restored"] = True
    receipt.write_text(json.dumps(record, indent=2) + "\n")
assert result.returncode == 0
assert not subprocess.check_output(["git", "status", "--porcelain"], text=True)
record["capture"] = json.loads(subprocess.check_output(
    ["bureau-bazel", "tag", "inspect", tag, "--json"], text=True))
receipt.write_text(json.dumps(record, indent=2) + "\n")
