#include "device_entropy_cursor_state.h"
[[loom::config("jpeg.output_partitions"), loom::where(loom::predicate::range(2u, 8u))]]
extern const unsigned output_partitions;



static loom::kernel::configuration configure_chunks() {
  unsigned threads = loom::target::subgroup::size() * 4;
  return {{(chunks + threads - 1) / threads, 1, 1}, {threads, 1, 1}};
}

[[loom::kernel(configure_chunks)]]
void jpeg_speculate(const unsigned* entropy, const unsigned* jobs,
                    const unsigned* tables, const unsigned* blocks,
                    unsigned* summaries, unsigned* points) {
  unsigned lane = loom::kernel::workitem::id.x;
  unsigned threads = loom::kernel::workgroup::size.x;
  if (cache_tables) {
    auto* table_storage =
        loom::buffer::alloca<unsigned, loom::memory_space::workgroup, 16>(
            table_count * 832);
    auto* block_storage =
        loom::buffer::alloca<unsigned, loom::memory_space::workgroup, 16>(
            blocks_per_mcu);
    for (unsigned index = lane; index < table_count * 832; index += threads) {
      table_storage[index] = tables[index];
    }
    for (unsigned index = lane; index < blocks_per_mcu; index += threads) {
      block_storage[index] = blocks[index];
    }
    loom::kernel::workgroup::barrier();
    tables = table_storage;
    blocks = block_storage;
  }
  unsigned job = loom::kernel::workgroup::id.x * loom::kernel::workgroup::size.x +
                 loom::kernel::workitem::id.x;
  if (job >= chunks) return;
  unsigned offset = jobs[job * 3];
  unsigned limit = jobs[job * 3 + 1];
  unsigned interval = jobs[job * 3 + 2];
  unsigned chunk_bits = chunk_bytes * 8;
  unsigned first_boundary = interval * chunk_bits;
  unsigned last_boundary = first_boundary + chunk_bits;
  const unsigned* words = entropy + offset;
  Cursor cursor = {};
  cursor.position = interval ? first_boundary - chunk_bits : 0;
  cursor.budget = chunk_bits * 4 + 26;
  cursor.cached_word = 0xffffffffu;
  while (cursor.position < first_boundary && cursor.error == 0) {
    unsigned before = cursor.position;
    cursor = advance_state<false>(words, tables, blocks, limit, cursor);
    if (cursor.error == 1) {
      cursor.position = before + 1;
      cursor.blocks = 0;
      cursor.block_index = 0;
      cursor.coefficient = 0;
      cursor.predictors = {};
      cursor.error = 0;
    }
  }
  // Only phase survives lookbehind. Published totals start at this boundary.
  cursor.blocks = 0;
  cursor.predictors = {};
  unsigned first_bit = cursor.position;
  unsigned first_phase = cursor.block_index * 64 + cursor.coefficient;
  unsigned first_blocks = cursor.blocks;
  Predictors first_predictors = cursor.predictors;
  unsigned point_stride = (3 + component_count + 3) & ~3u;
  unsigned* job_points = points + job * (output_partitions - 1) * point_stride;
  for (unsigned partition = 1; partition < output_partitions; ++partition) {
    unsigned boundary = first_boundary + chunk_bits * partition / output_partitions;
    while (cursor.position < boundary && cursor.error == 0) {
      cursor = advance_state<true>(words, tables, blocks, limit, cursor);
    }
    unsigned* point = job_points + (partition - 1) * point_stride;
    [[loom::unroll]]
    for (unsigned field = 0; field < point_stride; ++field) point[field] = 0;
    point[0] = cursor.position;
    point[1] = cursor.blocks - first_blocks;
    point[2] = cursor.block_index * 64 + cursor.coefficient;
    [[loom::unroll]]
    for (unsigned component = 0; component < component_count; ++component) {
      point[3 + component] = cursor.predictors[component] - first_predictors[component];
    }
  }
  while (cursor.position < last_boundary && cursor.error == 0) {
    cursor = advance_state<true>(words, tables, blocks, limit, cursor);
  }
  unsigned stride = (5 + component_count + 3) & ~3u;
  unsigned* output = summaries + job * stride;
  [[loom::unroll]]
  for (unsigned index = 0; index < stride; ++index) output[index] = 0;
  output[0] = 0xffffffffu;
  if (cursor.error == 0) {
    output[0] = first_bit;
    output[1] = first_phase;
    output[2] = cursor.position;
    output[3] = cursor.block_index * 64 + cursor.coefficient;
    output[4] = cursor.blocks - first_blocks;
    [[loom::unroll]]
    for (unsigned component = 0; component < component_count; ++component) {
      output[5 + component] = cursor.predictors[component] - first_predictors[component];
    }
  } else {
    // Invalid speculative summaries never publish partial subdivision facts.
    for (unsigned partition = 0; partition + 1 < output_partitions; ++partition) {
      [[loom::unroll]]
      for (unsigned field = 0; field < point_stride; ++field) {
        job_points[partition * point_stride + field] = 0;
      }
    }
  }
}




static loom::kernel::configuration configure_bridges() {
  unsigned threads = loom::target::subgroup::size() * 4;
  return {{(chunks + threads - 1) / threads, 1, 1}, {threads, 1, 1}};
}

// A record is a later summary index, completed-block delta, and DC deltas.
// An all-ones target means no local connection; only the restart-rooted path
// may certify a record. No absolute predictor or entropy checkpoint is supplied
// by the host. Every candidate trajectory has its own fixed read cap.
[[loom::kernel(configure_bridges)]]
void jpeg_bridge(const unsigned* entropy, const unsigned* jobs,
                 const unsigned* tables, const unsigned* blocks,
                 const unsigned* summaries, unsigned* bridges) {
  unsigned job = loom::kernel::workgroup::id.x * loom::kernel::workgroup::size.x +
                 loom::kernel::workitem::id.x;
  if (job >= chunks) return;
  unsigned stride = (2 + component_count + 3) & ~3u;
  unsigned* output = bridges + job * stride;
  [[loom::unroll]]
  for (unsigned index = 0; index < stride; ++index) output[index] = 0;
  output[0] = 0xffffffffu;
  unsigned interval = jobs[job * 3 + 2];
  unsigned first_job = job - interval;
  unsigned summary_stride = (5 + component_count + 3) & ~3u;
  unsigned start_bit = 0;
  unsigned start_phase = 0;
  bool active = interval == 0;
  if (interval != 0) {
    const unsigned* previous = summaries + (job - 1) * summary_stride;
    start_bit = previous[2];
    start_phase = previous[3];
    const unsigned* current = summaries + job * summary_stride;
    active = previous[0] != 0xffffffffu &&
             (current[0] != start_bit || current[1] != start_phase);
  }
  if (!active) return;
  unsigned bit_limit = jobs[job * 3 + 1];
  unsigned chunk_bits = chunk_bytes * 8;
  unsigned intervals = bit_limit / chunk_bits + (bit_limit % chunk_bits != 0);
  const unsigned* words = entropy + jobs[job * 3];
  Cursor cursor = {};
  cursor.position = start_bit;
  cursor.block_index = start_phase >> 6;
  cursor.blocks = cursor.block_index;
  unsigned first_blocks = cursor.blocks;
  cursor.coefficient = start_phase & 63;
  cursor.budget = chunk_bits * 4 + 26;
  cursor.cached_word = 0xffffffffu;
  unsigned target = 0xffffffffu;
  while (cursor.error == 0 && target == 0xffffffffu) {
    // A saved entry can overshoot its fixed boundary by at most 26 bits.
    // Tiny chunks may have several entries at one symbol; choose the first.
    unsigned lower = cursor.position > 26 ? (cursor.position - 26) / chunk_bits : 0;
    if (cursor.position - lower * chunk_bits > 26) ++lower;
    if (lower < interval) lower = interval;
    unsigned upper = cursor.position / chunk_bits;
    for (unsigned index = lower; index <= upper && index < intervals &&
                                  target == 0xffffffffu; ++index) {
      const unsigned* candidate = summaries + (first_job + index) * summary_stride;
      if (candidate[0] == cursor.position &&
          candidate[1] == cursor.block_index * 64 + cursor.coefficient) {
        target = index;
      }
    }
    if (target != 0xffffffffu || cursor.position - start_bit >= chunk_bits * 4) break;
    cursor = advance_state<true>(words, tables, blocks, bit_limit, cursor);
  }
  if (target != 0xffffffffu) {
    output[0] = target;
    output[1] = cursor.blocks - first_blocks;
    [[loom::unroll]]
    for (unsigned component = 0; component < component_count; ++component) {
      output[2 + component] = cursor.predictors[component];
    }
  }
}




[[loom::config("jpeg.segments"), loom::where(loom::predicate::range(1u, 1048576u))]]
extern const unsigned certification_segments;

using Sums = unsigned __attribute__((ext_vector_type(4)));
using loom::kernel::scan_direction;
using loom::kernel::scan_mode;

static loom::kernel::configuration configure_segment_groups() {
  return {{certification_segments, 1, 1}, {loom::target::subgroup::size() * 4, 1, 1}};
}

static loom::kernel::configuration configure_segment_roots() {
  unsigned threads = loom::target::subgroup::size();
  return {{(certification_segments + threads - 1) / threads, 1, 1}, {threads, 1, 1}};
}

// Suffix records retain sequence limits and additive block/DC totals. The
// difference between two suffixes describes a contiguous summary range; it
// does not certify that range as part of the actual JPEG trajectory.
[[loom::kernel(configure_segment_groups)]]
void jpeg_index(const unsigned* segments, const unsigned* summaries,
                unsigned* suffixes, unsigned* ranges, unsigned* intervals) {
  unsigned segment = loom::kernel::workgroup::id.x;
  unsigned item = loom::kernel::workitem::id.x;
  unsigned threads = loom::kernel::workgroup::size.x;
  const unsigned* descriptor = segments + segment * 8;
  unsigned first_job = descriptor[2];
  unsigned count = descriptor[3];
  unsigned first_record = descriptor[5];
  unsigned summary_stride = (5 + component_count + 3) & ~3u;
  unsigned suffix_stride = (2 + component_count + 3) & ~3u;
  unsigned interval_stride = (4 + component_count + 3) & ~3u;
  unsigned* suffix = suffixes + first_record * suffix_stride;
  unsigned* range = ranges + first_record * suffix_stride;
  unsigned* output = intervals + ((output_partitions + 1) * first_job + segment) * interval_stride;
  if (item == 0) {
    [[loom::unroll]]
    for (unsigned field = 0; field < suffix_stride; ++field) {
      suffix[count * suffix_stride + field] = 0;
      range[count * suffix_stride + field] = 0;
    }
    suffix[count * suffix_stride] = count;
    range[count * suffix_stride] = 0xffffffffu;
    [[loom::unroll]]
    for (unsigned field = 0; field < interval_stride; ++field) {
      output[(output_partitions + 1) * count * interval_stride + field] = 0;
    }
  }
  unsigned end_carry = count;
  unsigned block_carry = 0;
  Sums dc_carry = {};
  for (unsigned tiles = (count + threads - 1) / threads; tiles != 0; --tiles) {
    unsigned index = (tiles - 1) * threads + item;
    unsigned end = count;
    unsigned blocks = 0;
    Sums dc = {};
    if (index < count) {
      const unsigned* summary = summaries + (first_job + index) * summary_stride;
      if (summary[0] != 0xffffffffu) {
        blocks = summary[4];
        [[loom::unroll]]
        for (unsigned component = 0; component < component_count; ++component) {
          dc[component] = summary[5 + component];
        }
      }
      bool connected = false;
      if (index + 1 < count) {
        const unsigned* next = summary + summary_stride;
        connected = summary[0] != 0xffffffffu && next[0] == summary[2] &&
                    next[1] == summary[3];
      }
      if (!connected) end = index + 1;
    }
    unsigned local_end = loom::kernel::workgroup::scan::minui<
        scan_mode::inclusive, scan_direction::reverse>(end);
    unsigned local_blocks = loom::kernel::workgroup::scan::addi<
        scan_mode::inclusive, scan_direction::reverse>(blocks);
    Sums local_dc = loom::kernel::workgroup::scan::addi<
        scan_mode::inclusive, scan_direction::reverse>(dc);
    if (index < count) {
      [[loom::unroll]]
      for (unsigned field = 0; field < suffix_stride; ++field) {
        suffix[index * suffix_stride + field] = 0;
        range[index * suffix_stride + field] = 0;
      }
      suffix[index * suffix_stride] = minimum(end_carry, local_end);
      suffix[index * suffix_stride + 1] = block_carry + local_blocks;
      range[index * suffix_stride] = 0xffffffffu;
      [[loom::unroll]]
      for (unsigned component = 0; component < component_count; ++component) {
        suffix[index * suffix_stride + 2 + component] = dc_carry[component] + local_dc[component];
      }
      [[loom::unroll]]
      for (unsigned field = 0; field < interval_stride; ++field) {
        for (unsigned partition = 0; partition <= output_partitions; ++partition) {
          output[(partition * count + index) * interval_stride + field] = 0;
        }
      }
    }
    end_carry = minimum(end_carry, loom::kernel::workgroup::reduce::minui(end));
    block_carry += loom::kernel::workgroup::reduce::addi(blocks);
    dc_carry += loom::kernel::workgroup::reduce::addi(dc);
  }
}

static LOOM_FORCE_INLINE void write_interval(unsigned* output, unsigned first,
    unsigned last, unsigned blocks, unsigned phase, Sums dc) {
  output[0] = first;
  output[1] = last;
  output[2] = blocks;
  output[3] = phase;
  [[loom::unroll]]
  for (unsigned component = 0; component < component_count; ++component) {
    output[4 + component] = dc[component];
  }
}

// Only this restart-rooted traversal certifies local transitions. It consumes
// indexed sequence ends and additive totals, never compressed entropy bytes.
[[loom::kernel(configure_segment_roots)]]
void jpeg_certify(const unsigned* segments, const unsigned* summaries,
                  const unsigned* bridges, const unsigned* suffixes,
                  unsigned* ranges, unsigned* intervals) {
  unsigned segment = loom::kernel::workgroup::id.x * loom::kernel::workgroup::size.x +
                     loom::kernel::workitem::id.x;
  if (segment >= certification_segments) return;
  const unsigned* descriptor = segments + segment * 8;
  unsigned first_job = descriptor[2];
  unsigned count = descriptor[3];
  unsigned total_blocks = descriptor[4];
  unsigned first_record = descriptor[5];
  unsigned summary_stride = (5 + component_count + 3) & ~3u;
  unsigned stride = (2 + component_count + 3) & ~3u;
  unsigned interval_stride = (4 + component_count + 3) & ~3u;
  const unsigned* suffix = suffixes + first_record * stride;
  unsigned* range = ranges + first_record * stride;
  unsigned* output = intervals + ((output_partitions + 1) * first_job + segment) * interval_stride;
  unsigned position = 0;
  unsigned blocks = 0;
  unsigned phase = 0;
  Sums dc = {};
  unsigned source = 0;
  while (source < count) {
    const unsigned* bridge = bridges + (first_job + source) * stride;
    unsigned target = bridge[0];
    bool joined = target != 0xffffffffu;
    bool fits = bridge[1] < total_blocks - blocks;
    if (joined & fits) {
      const unsigned* entry = summaries + (first_job + target) * summary_stride;
      write_interval(output + (output_partitions * count + source) * interval_stride,
                     position, entry[0], blocks, phase, dc);
      position = entry[0];
      blocks += bridge[1];
      phase = entry[1];
      [[loom::unroll]]
      for (unsigned component = 0; component < component_count; ++component) {
        dc[component] += bridge[2 + component];
      }
      unsigned sequence_end = suffix[target * stride];
      unsigned limit = sequence_end;
      unsigned base_blocks = suffix[target * stride + 1];
      if (base_blocks - suffix[limit * stride + 1] >= total_blocks - blocks) {
        unsigned lower = target;
        unsigned upper = sequence_end;
        while (lower < upper) {
          unsigned middle = lower + (upper - lower + 1) / 2;
          if (base_blocks - suffix[middle * stride + 1] < total_blocks - blocks) {
            lower = middle;
          } else {
            upper = middle - 1;
          }
        }
        limit = lower;
      }
      if (limit != target) {
        range[target * stride] = limit;
        range[target * stride + 1] = blocks;
        [[loom::unroll]]
        for (unsigned component = 0; component < component_count; ++component) {
          range[target * stride + 2 + component] = dc[component];
          dc[component] += suffix[target * stride + 2 + component] -
                           suffix[limit * stride + 2 + component];
        }
        const unsigned* last = summaries + (first_job + limit - 1) * summary_stride;
        position = last[2];
        phase = last[3];
        blocks += base_blocks - suffix[limit * stride + 1];
      }
      source = limit == sequence_end ? sequence_end : count;
    } else {
      source = count;
    }
  }
  // The output consumer owns the exact final MCU and padding validation.
  write_interval(output + (output_partitions + 1) * count * interval_stride,
                 position, descriptor[1], blocks, phase, dc);
}

[[loom::kernel(configure_segment_groups)]]
void jpeg_intervals(const unsigned* segments, const unsigned* summaries,
                    const unsigned* suffixes, const unsigned* ranges,
                    const unsigned* points, unsigned* intervals) {
  unsigned segment = loom::kernel::workgroup::id.x;
  unsigned item = loom::kernel::workitem::id.x;
  unsigned threads = loom::kernel::workgroup::size.x;
  const unsigned* descriptor = segments + segment * 8;
  unsigned first_job = descriptor[2];
  unsigned count = descriptor[3];
  unsigned first_record = descriptor[5];
  unsigned summary_stride = (5 + component_count + 3) & ~3u;
  unsigned stride = (2 + component_count + 3) & ~3u;
  unsigned interval_stride = (4 + component_count + 3) & ~3u;
  const unsigned* suffix = suffixes + first_record * stride;
  const unsigned* range = ranges + first_record * stride;
  unsigned* output = intervals + ((output_partitions + 1) * first_job + segment) * interval_stride;
  unsigned carry = 0;
  for (unsigned begin = 0; begin < count; begin += threads) {
    unsigned index = begin + item;
    unsigned start = 0;
    if (index < count && range[index * stride] != 0xffffffffu) start = index + 1;
    unsigned prefix = loom::kernel::workgroup::scan::maxui(start);
    if (prefix < carry) prefix = carry;
    if (index < count && prefix != 0) {
      unsigned target = prefix - 1;
      if (index < range[target * stride]) {
        const unsigned* summary = summaries + (first_job + index) * summary_stride;
        unsigned blocks = range[target * stride + 1] +
                          suffix[target * stride + 1] - suffix[index * stride + 1];
        Sums dc = {};
        [[loom::unroll]]
        for (unsigned component = 0; component < component_count; ++component) {
          dc[component] = range[target * stride + 2 + component] +
                          suffix[target * stride + 2 + component] -
                          suffix[index * stride + 2 + component];
        }
        unsigned point_stride = (3 + component_count + 3) & ~3u;
        const unsigned* job_points = points + (first_job + index) *
                                     (output_partitions - 1) * point_stride;
        unsigned position = summary[0];
        unsigned phase = summary[1];
        unsigned absolute_blocks = blocks;
        Sums absolute_dc = dc;
        for (unsigned partition = 0; partition + 1 < output_partitions; ++partition) {
          const unsigned* point = job_points + partition * point_stride;
          write_interval(output + (index * output_partitions + partition) * interval_stride,
                         position, point[0], absolute_blocks, phase, absolute_dc);
          position = point[0];
          absolute_blocks = blocks + point[1];
          phase = point[2];
          [[loom::unroll]]
          for (unsigned component = 0; component < component_count; ++component) {
            absolute_dc[component] = dc[component] + point[3 + component];
          }
        }
        write_interval(output + (index * output_partitions + output_partitions - 1) * interval_stride,
                       position, summary[2], absolute_blocks, phase, absolute_dc);
      }
    }
    unsigned total = loom::kernel::workgroup::reduce::maxui(start);
    if (total > carry) carry = total;
  }
}




[[loom::config("jpeg.mcu_width"), loom::where(loom::predicate::range(1u, 65536u))]]
extern const unsigned scan_mcu_width;

using WideValues = long long __attribute__((ext_vector_type(8)));

static loom::kernel::configuration configure_output() {
  unsigned threads = loom::target::subgroup::size();
  unsigned interval_capacity = chunks * (output_partitions + 1) + certification_segments;
  unsigned stripe = threads * certification_segments;
  return {{(interval_capacity + stripe - 1) / stripe, certification_segments, 1},
          {threads, 1, 1}};
}

static LOOM_FORCE_INLINE WideValues transform_block_axis(WideValues input) {
  long long sum = (input[0] + input[4]) * 8192;
  long long difference = (input[0] - input[4]) * 8192;
  long long rotation = (input[2] + input[6]) * 4433;
  long long two = rotation - input[6] * 15137;
  long long six = rotation + input[2] * 6270;
  long long even0 = sum + six;
  long long even1 = difference + two;
  long long even2 = difference - two;
  long long even3 = sum - six;
  long long odd_rotation = (input[1] + input[3] + input[5] + input[7]) * 9633;
  long long seven_three = odd_rotation - (input[7] + input[3]) * 16069;
  long long five_one = odd_rotation - (input[5] + input[1]) * 3196;
  long long seven_one = (input[7] + input[1]) * -7373;
  long long five_three = (input[5] + input[3]) * -20995;
  long long odd0 = input[1] * 12299 + seven_one + five_one;
  long long odd1 = input[3] * 25172 + five_three + seven_three;
  long long odd2 = input[5] * 16819 + five_three + five_one;
  long long odd3 = input[7] * 2446 + seven_one + seven_three;
  return {even0 + odd0, even1 + odd1, even2 + odd2, even3 + odd3,
          even3 - odd3, even2 - odd2, even1 - odd1, even0 - odd0};
}

static LOOM_FORCE_INLINE unsigned sample_byte(int value) {
  unsigned nonnegative = static_cast<unsigned>(value & ~(value >> 31));
  unsigned saturated = nonnegative | (0u - static_cast<unsigned>(nonnegative > 255u));
  return saturated & 255u;
}

static LOOM_FORCE_INLINE Symbol output_symbol(const unsigned* words,
    const unsigned* tables, const unsigned* blocks, unsigned limit,
    unsigned certified_end, Cursor cursor) {
  Symbol symbol = {};
  if (cursor.position < certified_end) {
    symbol = advance_symbol_certified(words, tables, blocks, cursor);
  } else {
    symbol = advance_symbol(words, tables, blocks, limit, cursor);
  }
  if (symbol.index == 0 && (symbol.value < -1024 || symbol.value > 1023)) {
    symbol.cursor.error = 5;
  }
  return symbol;
}

// The block owner has already consumed DC. Its retained table and the
// restart-rooted certificate establish the entire AC syntax transition.
static LOOM_FORCE_INLINE Symbol advance_ac_certified(const unsigned* words,
    const unsigned* table, Cursor cursor) {
  Read input = peek(words, cursor);
  cursor = input.cursor;
  unsigned packed = table[input.value >> 23];
  unsigned length = packed >> 8;
  unsigned symbol = packed & 255;
  if (length == 0) {
    unsigned prefix = input.value >> 16;
    for (unsigned candidate = 10; candidate <= 16 && length == 0; ++candidate) {
      unsigned value = prefix >> (16 - candidate);
      unsigned first = table[512 + candidate * 3];
      unsigned count = table[513 + candidate * 3];
      if (value >= first && value - first < count) {
        unsigned base = table[514 + candidate * 3];
        unsigned symbol_index = base + value - first;
        loom::assume(symbol_index < 256u);
        symbol = table[563 + symbol_index];
        length = candidate;
      }
    }
  }
  loom::assume(length != 0 && length <= 16u);
  unsigned category = symbol & 15u;
  loom::assume(category <= 11u);
  unsigned consumed = length + category;
  unsigned amplitude_mask = (1u << category) - 1;
  unsigned value = (input.value >> (32 - consumed)) & amplitude_mask;
  unsigned negative_mask = 0u - static_cast<unsigned>(value < ((1u << category) >> 1));
  int amplitude = static_cast<int>(value + ((0u - amplitude_mask) & negative_mask));
  unsigned output_index = 0xffffffffu;
  int output_value = 0;
    unsigned run = symbol >> 4;
    if (category == 0) {
      unsigned nonzero_run_mask = 0u - static_cast<unsigned>(run != 0);
      cursor.coefficient = ((cursor.coefficient + 16) & nonzero_run_mask) & 63;
    } else {
      unsigned index = cursor.coefficient + run;
      loom::assume(index < 64u);
      cursor.coefficient = (index + 1) & 63;
      output_index = index;
      output_value = amplitude;
    }
    if (cursor.coefficient == 0) {
      ++cursor.blocks;
      ++cursor.block_index;
      unsigned wrap_mask = 0u - static_cast<unsigned>(cursor.block_index != blocks_per_mcu);
      cursor.block_index &= wrap_mask;
    }
  cursor.position += consumed;
  cursor.reads += consumed;
  return {cursor, output_index, output_value};
}

using Values = int __attribute__((ext_vector_type(8)));

// Exchange the low three bits of the register index with the lane index.
// Every shuffle is confined to a fully participating eight-lane block.
static LOOM_FORCE_INLINE Values transpose_block(Values values, unsigned axis) {
  [[loom::unroll]]
  for (unsigned stage = 0; stage < 3; ++stage) {
    unsigned mask = 1u << stage;
    Values exchanged = loom::kernel::subgroup::shuffle_xor(values, mask, 8).value;
    Values next = {};
    [[loom::unroll]]
    for (unsigned index = 0; index < 8; ++index) {
      int exchange_mask = -static_cast<int>(((axis ^ index) & mask) != 0);
      next[index] = values[index] ^ ((values[index] ^ exchanged[index ^ mask]) & exchange_mask);
    }
    values = next;
  }
  return values;
}

// Row-local owner permutation preserves the payload while distributing
// each eight-lane consumer's column across independent LDS banks.
static LOOM_FORCE_INLINE unsigned coefficient_index(unsigned natural,
    unsigned owner, unsigned stride) {
  return natural * stride + (owner ^ ((natural & 7u) * 2u));
}

// All lanes enter; each group of eight consumes one producer's block.
static LOOM_FORCE_INLINE void reconstruct_cooperative(const short* coefficients,
    unsigned coefficient_stride, unsigned threads, unsigned lane,
    unsigned owner, bool valid, bool any_ac, unsigned offset,
    const unsigned* quantization, unsigned* pixels) {
  bool owner_valid = loom::kernel::subgroup::shuffle_index(
      static_cast<unsigned>(valid), owner, threads).value != 0;
  bool owner_ac = loom::kernel::subgroup::shuffle_index(
      static_cast<unsigned>(any_ac), owner, threads).value != 0;
  unsigned owner_offset = loom::kernel::subgroup::shuffle_index(offset, owner, threads).value;
  unsigned axis = lane & 7;
  if (owner_valid) {
    unsigned long long packed = 0;
    if (!owner_ac) {
      int dc = static_cast<int>(coefficients[owner]) * static_cast<int>(quantization[0]);
      unsigned value = sample_byte(((dc + 4) >> 3) + 128);
      packed = static_cast<unsigned long long>(value) * 0x0101010101010101ull;
    } else {
      WideValues input = {};
      int ac = 0;
      [[loom::unroll]]
      for (unsigned row = 0; row < 8; ++row) {
        unsigned natural = row * 8 + axis;
        unsigned step = quantization[natural];
        loom::assume(step <= 65535u);
        int value = static_cast<int>(coefficients[coefficient_index(natural, owner, coefficient_stride)]) *
                    static_cast<int>(step);
        input[row] = value;
        if (row != 0) ac |= value;
      }
      Values columns = {};
      if (ac == 0) {
        [[loom::unroll]]
        for (unsigned row = 0; row < 8; ++row) columns[row] = static_cast<int>(input[0] * 4);
      } else {
        WideValues result = transform_block_axis(input);
        [[loom::unroll]]
        for (unsigned row = 0; row < 8; ++row) {
          columns[row] = static_cast<int>((result[row] + 1024) >> 11);
        }
      }
      Values row = transpose_block(columns, axis);
      [[loom::unroll]]
      for (unsigned column = 0; column < 8; ++column) input[column] = row[column];
      WideValues result = transform_block_axis(input);
      [[loom::unroll]]
      for (unsigned column = 0; column < 8; ++column) {
        int value = static_cast<int>((result[column] + 131072) >> 18) + 128;
        packed |= static_cast<unsigned long long>(sample_byte(value)) << (column * 8);
      }
    }
    reinterpret_cast<unsigned long long*>(pixels + owner_offset)[axis] = packed;
  }
}

// A single subgroup owns the workgroup so its active vote controls every
// barrier uniformly. Producer lanes retain bounded interval cursors; consumers
// exchange matrix ownership only while a complete coefficient block is live.
[[loom::kernel(configure_output)]]
void jpeg_reconstruct(const unsigned* entropy, const unsigned* segments,
    const unsigned* tables, const unsigned* blocks, const unsigned* intervals,
    const unsigned* geometry, const unsigned* quantization, const unsigned* zigzag,
    unsigned* pixels, unsigned* status) {
  unsigned segment = loom::kernel::workgroup::id.y;
  unsigned lane = loom::kernel::workitem::id.x;
  unsigned threads = loom::kernel::workgroup::size.x;
  unsigned interval_capacity = chunks * (output_partitions + 1) + certification_segments;
  unsigned stripe = threads * certification_segments;
  unsigned group_count = (interval_capacity + stripe - 1) / stripe;
  const unsigned* descriptor = segments + segment * 8;
  unsigned count = descriptor[3];
  unsigned total_blocks = descriptor[4];
  unsigned first_interval = descriptor[2] * (output_partitions + 1) + segment;
  unsigned stride = (4 + component_count + 3) & ~3u;
  unsigned certified_end = intervals[
      (first_interval + (output_partitions + 1) * count) * stride];
  unsigned certified_blocks = intervals[
      (first_interval + (output_partitions + 1) * count) * stride + 2];
  const unsigned* words = entropy + descriptor[0];
  unsigned bit_limit = descriptor[1];
  // The row-local permutation avoids padding the coefficient payload.
  unsigned coefficient_stride = threads;
  auto* coefficients = loom::buffer::alloca<short, loom::memory_space::workgroup, 16>(coefficient_stride * 64);
  for (unsigned first = loom::kernel::workgroup::id.x * threads;
       first < count * (output_partitions + 1) + 1; first += group_count * threads) {
    unsigned interval = first + lane;
    bool present = interval < count * (output_partitions + 1) + 1;
    Cursor cursor = {};
    cursor.budget = bit_limit;
    cursor.cached_word = 0xffffffffu;
    unsigned end = 0;
    if (present) {
      const unsigned* entry = intervals + (first_interval + interval) * stride;
      cursor.position = entry[0];
      end = entry[1];
      cursor.blocks = entry[2];
      cursor.block_index = entry[3] >> 6;
      cursor.coefficient = entry[3] & 63;
      [[loom::unroll]]
      for (unsigned component = 0; component < component_count; ++component) {
        cursor.predictors[component] = static_cast<int>(entry[4 + component]);
      }
      if (cursor.position < end) {
        while ((cursor.block_index != 0 || cursor.coefficient != 0) && cursor.error == 0) {
          cursor = output_symbol(words, tables, blocks, bit_limit, certified_end, cursor).cursor;
        }
      }
    }
    bool active = present && cursor.blocks < total_blocks && cursor.position < end && cursor.error == 0;
    while (loom::kernel::subgroup::vote::any(active)) {
      unsigned mcu = descriptor[6] + cursor.blocks / blocks_per_mcu;
      unsigned mcu_row = mcu / scan_mcu_width;
      unsigned mcu_column = mcu % scan_mcu_width;
      for (unsigned block = 0; block < blocks_per_mcu; ++block) {
        bool any_ac = false;
        bool output_valid = false;
        unsigned offset = 0;
        unsigned table_index = blocks[block] >> 16;
        unsigned available_tables = table_count;
        loom::assume(table_index < available_tables);
        const unsigned* ac_table = tables + table_index * 832;
        if (active && cursor.error == 0) {
          [[loom::unroll]]
          for (unsigned index = 0; index < 64; ++index) coefficients[coefficient_index(index, lane, coefficient_stride)] = 0;
          if (cursor.blocks < certified_blocks) {
            // The root certificate covers this whole block. Syntax is proven;
            // the absolute DC predictor remains a consumer-owned constraint.
            unsigned first_coefficient = cursor.coefficient;
            loom::assume(first_coefficient == 0);
            cursor.coefficient = first_coefficient;
            Symbol dc = advance_symbol_certified(words, tables, blocks, cursor);
            cursor = dc.cursor;
            if (dc.value < -1024 || dc.value > 1023) cursor.error = 5;
            if (cursor.error == 0) {
              coefficients[lane] = static_cast<short>(dc.value);
              do {
                Symbol symbol = advance_ac_certified(words, ac_table, cursor);
                cursor = symbol.cursor;
                if (symbol.index != 0xffffffffu) {
                  unsigned natural = zigzag[symbol.index];
                  loom::assume(natural < 64u);
                  coefficients[coefficient_index(natural, lane, coefficient_stride)] = static_cast<short>(symbol.value);
                  any_ac = true;
                }
              } while (cursor.coefficient != 0);
            }
          } else {
            do {
              Symbol symbol = advance_symbol(words, tables, blocks, bit_limit, cursor);
              cursor = symbol.cursor;
              if (symbol.index == 0 && (symbol.value < -1024 || symbol.value > 1023)) {
                cursor.error = 5;
              }
              if (symbol.index != 0xffffffffu && cursor.error == 0) {
                unsigned natural = zigzag[symbol.index];
                loom::assume(natural < 64u);
                coefficients[coefficient_index(natural, lane, coefficient_stride)] = static_cast<short>(symbol.value);
                if (symbol.index != 0) any_ac = true;
              }
            } while (cursor.coefficient != 0 && cursor.error == 0);
          }
          const unsigned* shape = geometry + block * 8;
          unsigned column = mcu_column * shape[3] + shape[5];
          unsigned row = mcu_row * shape[4] + shape[6];
          output_valid = cursor.error == 0 && column < shape[1] && row < shape[2];
          offset = descriptor[7] + shape[0] + (row * shape[1] + column) * 16;
        }
        loom::kernel::barrier<loom::memory_space::workgroup,
            loom::atomic::scope::subgroup, loom::atomic::ordering::acq_rel>();
        unsigned component = blocks[block] & 255;
        unsigned components = component_count;
        loom::assume(component < components);
        for (unsigned round = 0; round < 8; ++round) {
          unsigned owner = round * (threads / 8) + lane / 8;
          reconstruct_cooperative(coefficients, coefficient_stride, threads, lane,
              owner, output_valid, any_ac, offset, quantization + component * 64, pixels);
        }
        loom::kernel::barrier<loom::memory_space::workgroup,
            loom::atomic::scope::subgroup, loom::atomic::ordering::acq_rel>();
      }
      active = present && cursor.blocks < total_blocks && cursor.position < end && cursor.error == 0;
    }
    if (present) {
      if (interval == count * (output_partitions + 1) && cursor.error == 0) {
        if (cursor.blocks != total_blocks || cursor.coefficient != 0) {
          cursor.error = 3;
        } else {
          unsigned padding = bit_limit - cursor.position;
          if (padding >= 8) {
            cursor.error = 4;
          } else if (padding != 0) {
            Read input = peek(words, cursor);
            if ((input.value >> (32 - padding)) != (1u << padding) - 1) cursor.error = 4;
          }
        }
      }
      status[first_interval + interval] = cursor.error;
    }
  }
}

