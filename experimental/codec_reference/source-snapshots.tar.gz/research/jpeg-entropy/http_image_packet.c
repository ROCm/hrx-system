// Explicit A/B selection for the bounded native compressed-input experiment.
#include "iree/base/tooling/flags.h"
#include "native_upload.h"

IREE_FLAG(bool, codec_jpeg, false, "Use the experimental compressed JPEG input contract.");

static iree_status_t jpeg_request_bound(
    const loom_serve_media_image_info_t* info, iree_host_size_t metadata_length,
    iree_host_size_t* out_length) {
  if (info->format != LOOM_SERVE_MEDIA_IMAGE_FORMAT_JPEG) {
    return iree_make_status(IREE_STATUS_UNIMPLEMENTED,
                            "compressed experiment requires JPEG input");
  }
  if (metadata_length != 8) {
    return iree_make_status(IREE_STATUS_INVALID_ARGUMENT,
                            "JPEG projector requires width and height metadata");
  }
  if (info->compressed_length > 4 * 1024 * 1024 ||
      info->width > UINT16_MAX || info->height > UINT16_MAX) {
    return iree_make_status(IREE_STATUS_RESOURCE_EXHAUSTED,
                            "JPEG exceeds the qualified device input domain");
  }
  // The independent upload has nine input spans. At most six selected Huffman
  // tables, ten MCU block records, and three quantizer planes are possible.
  // Reserve every input guard and alignment gap without inspecting the body.
  const uint64_t tiles = ((uint64_t)info->width + 63) / 64 *
                         (((uint64_t)info->height + 15) / 16);
  const uint64_t compressed = (info->compressed_length + 4095) / 4096 * 4096 + 16;
  const uint64_t metadata = sizeof(struct JpegUploadDirectory) +
      6 * 8192 + 16 + 10 * 32 + 3 * 256 + 256 + 72 + tiles * 12 + 4;
  const uint64_t length = 80 + compressed + metadata + 9 * (32 + 15) + 15;
  *out_length = (iree_host_size_t)((length + 15) & ~UINT64_C(15));
  return iree_ok_status();
}

static iree_status_t jpeg_request_create(
    const loom_serve_media_image_request_t* request,
    iree_allocator_t allocator, iree_vm_buffer_t** out_packet) {
  const loom_serve_media_image_info_t* info = &request->image->info;
  iree_host_size_t bound = 0;
  IREE_RETURN_IF_ERROR(jpeg_request_bound(info, request->metadata.data_length, &bound));
  jpeg_upload_image_t image;
  IREE_RETURN_IF_ERROR(jpeg_upload_image_initialize(request->image->encoded, &image));
  jpeg_upload_t upload;
  IREE_RETURN_IF_ERROR(jpeg_upload_create(1, &image, allocator, &upload));
  const iree_host_size_t length = 80 + upload.input.data_length;
  iree_vm_buffer_t* packet = NULL;
  iree_status_t status = iree_vm_buffer_create(length, 16, allocator, &packet);
  iree_byte_span_t bytes = iree_byte_span_empty();
  if (iree_status_is_ok(status)) {
    status = iree_vm_buffer_map_write(packet, 0, length, &bytes);
  }
  if (iree_status_is_ok(status)) {
    const uint32_t header[20] = {
        0x4745504a, 2, info->width, info->height,
        info->display_width, info->display_height, info->orientation,
        request->output_rows, 64, 8, 80, (uint32_t)upload.input.data_length,
        3, upload.output_length, (uint32_t)info->pixel_length, 0,
        iree_unaligned_load_le_u32(request->metadata.data),
        iree_unaligned_load_le_u32(request->metadata.data + 4), 0, 0};
    for (unsigned i = 0; i < 20; ++i) {
      iree_unaligned_store_le_u32(bytes.data + i * 4, header[i]);
    }
    memcpy(bytes.data + 80, upload.input.data, upload.input.data_length);
    *out_packet = packet;
  } else {
    iree_vm_buffer_release(packet);
  }
  jpeg_upload_deinitialize(&upload);
  return status;
}
