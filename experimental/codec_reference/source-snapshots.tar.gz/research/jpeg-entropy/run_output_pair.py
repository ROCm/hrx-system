"""Stage small variant artifacts, run one foreground lease, and retain evidence."""
import argparse
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import tarfile

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
parser = argparse.ArgumentParser()
parser.add_argument('control')
parser.add_argument('candidate')
parser.add_argument('prefix')
parser.add_argument('--fixtures', nargs=2)
parser.add_argument('--stage-fixture-data', action='store_true')
parser.add_argument('--check-candidate', action='store_true')
arguments = parser.parse_args()
files = {'device_output_compare.py': notes / 'device_output_compare.py'}
fixture_names = arguments.fixtures or [variant + '-batch16-1024' for variant in (arguments.control, arguments.candidate)]
for variant, fixture_name in zip((arguments.control, arguments.candidate), fixture_names):
    fixture = root / fixture_name
    for path in fixture.iterdir():
        if path.is_file() and (arguments.stage_fixture_data or path.suffix != '.npy'):
            files[str(path.relative_to(root))] = path
    stage = json.loads((fixture / 'stage.json').read_text())
    library = root / stage['library']['path']
    files[library.name] = library
assert sum(path.stat().st_size for path in files.values()) < (128 if arguments.stage_fixture_data else 16) * 1024 * 1024
process = subprocess.Popen(['ssh', 'hrx-gorgon-4', 'tar -xf - -C ' + shlex.quote(str(root))], stdin=subprocess.PIPE)
with tarfile.open(fileobj=process.stdin, mode='w|') as archive:
    for name, path in files.items():
        archive.add(path, arcname=name, recursive=False)
process.stdin.close()
if process.wait():
    raise SystemExit(process.returncode)
command = ['/home/benvanik/.dotfiles/bin/benchmark-lock', '--label=codec-jpeg-' + arguments.prefix,
           '--', 'env', 'LD_LIBRARY_PATH=/opt/rocm/lib', 'python3', '-B',
           str(root / 'device_output_compare.py'), '--pair', arguments.control,
           arguments.candidate, '--prefix', arguments.prefix, '--fixtures', *fixture_names]
if arguments.check_candidate:
    command.append('--check-candidate')
log = notes / (arguments.prefix + '-run.log')
with log.open('w') as stream:
    result = subprocess.run(['ssh', 'hrx-gorgon-4', shlex.join(command)], stdout=stream, stderr=subprocess.STDOUT)
status = subprocess.run(['ssh', 'hrx-gorgon-4', '/home/benvanik/.dotfiles/bin/benchmark-lock --status'], capture_output=True, text=True)
record = {'host': 'hrx-gorgon-4', 'command': command, 'returncode': result.returncode,
          'broker_status_returncode': status.returncode, 'broker_status_after': status.stdout + status.stderr,
          'staged_files': {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in files.items()}}
(notes / (arguments.prefix + '-lease.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: value for key, value in record.items() if key != 'staged_files'}), flush=True)
if result.returncode:
    print(log.read_text()[-4000:])
    raise SystemExit(result.returncode)
script = '''import json,pathlib,sys
root=pathlib.Path(sys.argv[1]);prefix=sys.argv[2];a=sys.argv[3];b=sys.argv[4];result={}
for index,variant in enumerate((a,b,a,b,a)):
 name=f'{prefix}-{index}-{variant}'
 rows=[json.loads(line) for line in (root/(name+'.jsonl')).read_text().splitlines()]
 result[name]={'rows':[row for row in rows if row['row'] != 'compile'],'receipt':json.loads((root/(name+'-receipt.json')).read_text())}
print(json.dumps(result))'''
result = subprocess.run(['ssh', 'hrx-gorgon-4', shlex.join(['python3', '-B', '-c', script,
                        str(root), arguments.prefix, arguments.control, arguments.candidate])], check=True, capture_output=True)
records = json.loads(result.stdout)
(notes / (arguments.prefix + '-measurements.json')).write_text(json.dumps(records, indent=2) + '\n')
for name, record in records.items():
    value = next(row['benchmark_result'] for row in record['rows'] if row['row'] == 'benchmark')
    kernel = next(row for row in value['profile_replay']['summary']['rows']
                  if row.get('type') == 'dispatch_function' and row['function_name'] == 'jpeg_reconstruct')
    print(json.dumps({'name': name, 'total_ms': value['measurement']['operation_timing_ns']['p50'] / 1e6,
                      'reconstruct_ms': kernel['timing']['mean_ns'] / 1e6,
                      'correctness': value['correctness']}), flush=True)
