"""Two co-resident subgroups transfer bounded coefficient slots through LDS."""
from pathlib import Path

notes = Path(__file__).resolve().parent
source = (notes / 'device_reconstruct_twolevel.cxx').read_text()
source = source.replace('#include "device_entropy_cursor.h"', '#include "device_entropy_cursor.h"\n#include <loomcxx/atomic.h>')
source = source.replace('{threads, 1, 1}};', '{threads * 2, 1, 1}};')
start = source.index('// A single subgroup owns the workgroup')
kernel = source[source.index('[[loom::kernel(configure_output)]]', start):]
source = source[:start]
helper = '''// Only a subgroup leader observes a token; the subgroup rendezvous then
// imports that acquire before any lane consumes the published payload.
static LOOM_FORCE_INLINE unsigned wait_slot(const unsigned* flag,
    unsigned lane, unsigned threads, bool empty) {
  unsigned state = 0;
  do {
    unsigned observed = 0;
    if (lane == 0) {
      observed = loom::view::atomic::load<loom::atomic::ordering::acquire,
          loom::atomic::scope::workgroup>(flag);
    }
    state = loom::kernel::subgroup::broadcast(observed, 0);
  } while (empty ? state != 0 : state == 0);
  loom::kernel::barrier<loom::memory_space::workgroup,
      loom::atomic::scope::subgroup, loom::atomic::ordering::acq_rel>();
  return state;
}

// The rendezvous gathers all lane writes/reads into the leader's release.
static LOOM_FORCE_INLINE void publish_slot(unsigned* flag, unsigned value,
                                           unsigned lane) {
  loom::kernel::barrier<loom::memory_space::workgroup,
      loom::atomic::scope::subgroup, loom::atomic::ordering::acq_rel>();
  if (lane == 0) {
    loom::view::atomic::store<loom::atomic::ordering::release,
        loom::atomic::scope::workgroup>(value, flag);
  }
}

'''
kernel = kernel.replace('  unsigned lane = loom::kernel::workitem::id.x;\n  unsigned threads = loom::kernel::workgroup::size.x;', '''  unsigned item = loom::kernel::workitem::id.x;
  unsigned threads = loom::kernel::workgroup::size.x / 2;
  unsigned lane = loom::kernel::subgroup::lane_id();''')
old = '''  // The row-local permutation avoids padding the coefficient payload.
  unsigned coefficient_stride = threads;
  auto* coefficients = loom::buffer::alloca<short, loom::memory_space::workgroup, 16>(coefficient_stride * 64);
'''
new = '''  unsigned coefficient_stride = threads;
  auto* storage = loom::buffer::alloca<short, loom::memory_space::workgroup, 16>(threads * 64 * 2);
  auto* metadata = loom::buffer::alloca<unsigned, loom::memory_space::workgroup, 16>(threads * 2 * 2);
  auto* control = loom::buffer::alloca<unsigned, loom::memory_space::workgroup, 16>(4);
  if (item == 0) {
    control[0] = 0;
    control[2] = 0;
  }
  loom::kernel::workgroup::barrier();
  unsigned sequence = 0;
  if (loom::kernel::subgroup::id() == 0) {
'''
assert kernel.count(old) == 1
kernel = kernel.replace(old, new)
marker = '      for (unsigned block = 0; block < blocks_per_mcu; ++block) {\n'
insert = '''        unsigned slot = sequence & 1u;
        wait_slot(control + slot * 2, lane, threads, true);
        short* coefficients = storage + slot * threads * 64;
'''
assert kernel.count(marker) == 1
kernel = kernel.replace(marker, marker + insert)
begin = kernel.index('        loom::kernel::barrier<loom::memory_space::workgroup,', kernel.index(marker))
end = kernel.index('      }\n      active =', begin)
old = kernel[begin:end]
assert 'reconstruct_cooperative' in old
new = '''        metadata[(slot * threads + lane) * 2] = offset;
        metadata[(slot * threads + lane) * 2 + 1] =
            static_cast<unsigned>(output_valid) | (static_cast<unsigned>(any_ac) << 1);
        if (lane == 0) control[slot * 2 + 1] = block_descriptor(block) & 3u;
        publish_slot(control + slot * 2, 1u, lane);
        ++sequence;
'''
kernel = kernel[:begin] + new + kernel[end:]
assert kernel.endswith('  }\n}\n')
kernel = kernel[:-2] + '''    unsigned final_slot = sequence & 1u;
    wait_slot(control + final_slot * 2, lane, threads, true);
    publish_slot(control + final_slot * 2, 2u, lane);
  } else {
    bool finished = false;
    while (!finished) {
      unsigned slot = sequence & 1u;
      unsigned token = wait_slot(control + slot * 2, lane, threads, false);
      finished = token == 2;
      if (!finished) {
        const short* coefficients = storage + slot * threads * 64;
        unsigned offset = metadata[(slot * threads + lane) * 2];
        unsigned flags = metadata[(slot * threads + lane) * 2 + 1];
        unsigned component = control[slot * 2 + 1];
        unsigned components = component_count;
        loom::assume(component < components);
        for (unsigned round = 0; round < 8; ++round) {
          unsigned owner = round * (threads / 8) + lane / 8;
          reconstruct_cooperative(coefficients, coefficient_stride, threads, lane,
              owner, (flags & 1u) != 0, (flags & 2u) != 0, offset,
              quantization + component * 64, pixels);
        }
        publish_slot(control + slot * 2, 0u, lane);
        ++sequence;
      }
    }
  }
}
'''
source += helper + kernel
(notes / 'device_reconstruct_overlap.cxx').write_text(source)
pipeline = (notes / 'device_twolevel_pipeline.cxx').read_text()
old = (notes / 'device_reconstruct_twolevel.cxx').read_text().replace('#include "device_entropy_cursor.h"', '')
assert pipeline.count(old) == 1
pipeline = pipeline.replace(old, source.replace('#include "device_entropy_cursor.h"', ''))
(notes / 'device_overlap_pipeline.cxx').write_text(pipeline)
