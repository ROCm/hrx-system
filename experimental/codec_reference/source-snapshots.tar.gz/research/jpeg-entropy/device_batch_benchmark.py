"""One foreground benchmark: sixteen images/operation, eight queued operations."""
import hashlib
import argparse
import json
import os
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--fixture', default='batch16')
parser.add_argument('--result-name', default='entropy-batch16')
parser.add_argument('--runner', default='iree-benchmark-loom-predicate')
parser.add_argument('--runner-sha256')
parser.add_argument('--program')
parser.add_argument('--program-sha256')
parser.add_argument('--cache-tables', type=int, choices=(0, 1))
arguments = parser.parse_args()
fixture = root / arguments.fixture
stage = json.loads((fixture / 'stage.json').read_text())
for name, expected in stage['files'].items():
    assert hashlib.sha256((fixture / name).read_bytes()).hexdigest() == expected, name
library = stage['library'] if 'library' in stage else {
    'path': 'entropy.loombc', 'sha256': stage['entropy_loombc_sha256']}
assert hashlib.sha256((root / library['path']).read_bytes()).hexdigest() == library['sha256']
runner = root / arguments.runner
if arguments.runner_sha256:
    runner_sha256 = arguments.runner_sha256
else:
    tools = json.loads((root / 'predicate-opt-tools.json').read_text())
    runner_sha256 = tools[runner.name]
assert hashlib.sha256(runner.read_bytes()).hexdigest() == runner_sha256
program = root / arguments.program if arguments.program else fixture / 'summary.loombc'
program_sha256 = hashlib.sha256(program.read_bytes()).hexdigest()
assert program_sha256 == (arguments.program_sha256 if arguments.program else stage['files']['summary.loombc'])
state = {'host': os.uname().nodename, 'lease': os.environ['BENCHMARK_LOCK_LEASE_ID'],
         'runner_sha256': runner_sha256, 'program_sha256': program_sha256,
         'cache_tables': arguments.cache_tables, 'load_average': os.getloadavg(),
         'kfd_processes': [p.name for p in Path('/sys/class/kfd/kfd/proc').iterdir()],
         'gpu_busy': Path('/sys/class/drm/card0/device/gpu_busy_percent').read_text().strip()}
assert not state['kfd_processes'], state
result = root / (arguments.result_name + '.jsonl')
command = [str(runner), str(program),
           '--benchmark=@summary_latency',
           '--config-file=' + str(fixture / 'config.json'),
           '--device=amdgpu', '--target=amdgpu:gfx1151', '--measure=dispatch_complete',
           '--batch-size=8', '--input-ring-count=1', '--iterations=9',
           '--min-time-ms=0', '--max-batches=9', '--stable-p90-to-p50-ppm=0',
           '--warmup-iterations=2', '--profile-final-batch=true',
           '--output-format=jsonl', '--output=' + str(result)]
if arguments.cache_tables is not None:
    assert stage['sizes']['tables'] % 832 == 0
    command.extend(['--config=jpeg.table_count=' + str(stage['sizes']['tables'] // 832),
                    '--config=jpeg.cache_tables=' + str(arguments.cache_tables)])
(root / (arguments.result_name + '-receipt.json')).write_text(json.dumps({
    'state': state, 'stage': stage, 'command': command,
    'hardware_work': f'Each logical operation processes {stage["jobs"]} entropy chunks across sixteen distinct 12 MP inputs; eight operations are recorded into one command buffer. Input allocation/staging, compilation, and correctness checking precede timing. Each timed submission waits once after all eight operations. Nine samples follow two warmups. The separate profiled replay records device timestamps. Launch records identify every physical dispatch.',
    'scope': stage.get('scope', 'C2 speculative summaries only; unstuffed input and CPU-created job records isolate entropy discovery. Device destuffing, anchored repair, MCU output, IDCT, and color conversion are absent.')}, indent=2) + '\n')
print(json.dumps({'state': state, 'command': command}), flush=True)
subprocess.run(command, check=True)
for line in result.read_text().splitlines():
    row = json.loads(line)
    if row['row'] == 'benchmark':
        data = row['benchmark_result']
        print(json.dumps({'row': 'benchmark', 'result': str(result), 'state': data['state'],
                          'correctness': data.get('correctness'), 'measurement': data.get('measurement'),
                          'device_dispatch': data.get('profile_replay', {}).get('dispatch_timing', {}).get('dispatch_distribution'),
                          'launches': data.get('launches'), 'data_cache': data.get('data_cache')}), flush=True)
    elif row['row'] == 'summary':
        print(json.dumps(row), flush=True)
