"""Fuse the admitted short-code syntax transition while retaining exact errors."""
from pathlib import Path

notes = Path(__file__).resolve().parent
source = (notes / 'device_entropy_cursor_fused.h').read_text()
source = source.replace('Symbol advance_symbol(', 'Symbol advance_symbol_slow(')
position = source.index('static LOOM_FORCE_INLINE Cursor advance(')
fast = '''// The fast admission proves the entire symbol is present. The original
// transition owns long codes and every partial-consumption/error outcome.
static LOOM_FORCE_INLINE Symbol advance_symbol(const unsigned* words,
    const unsigned* tables, const unsigned* blocks, unsigned limit, Cursor cursor) {
  unsigned block_index = cursor.block_index;
  unsigned block_count = blocks_per_mcu;
  loom::assume(block_index < block_count);
  unsigned descriptor = blocks[block_index];
  unsigned dc_mask = 0u - static_cast<unsigned>(cursor.coefficient == 0);
  unsigned dc_table = (descriptor >> 8) & 255;
  unsigned ac_table = descriptor >> 16;
  unsigned table_index = ac_table ^ ((ac_table ^ dc_table) & dc_mask);
  unsigned available_tables = table_count;
  loom::assume(table_index < available_tables);
  Read input = peek(words, cursor);
  cursor = input.cursor;
  unsigned packed = tables[table_index * 832 + (input.value >> 23)];
  unsigned length = packed >> 8;
  unsigned symbol = packed & 255;
  unsigned category = symbol & (15u | dc_mask);
  unsigned consumed = length + category;
  if (length == 0 || consumed > limit - cursor.position ||
      consumed > cursor.budget - cursor.reads) {
    return advance_symbol_slow(words, tables, blocks, limit, cursor);
  }
  loom::assume(length <= 9u);
  loom::assume(category <= 11u);
  unsigned amplitude_mask = (1u << category) - 1;
  unsigned value = (input.value >> (32 - consumed)) & amplitude_mask;
  unsigned negative_mask = 0u - static_cast<unsigned>(value < ((1u << category) >> 1));
  int amplitude = static_cast<int>(value + ((0u - amplitude_mask) & negative_mask));
  unsigned output_index = 0xffffffffu;
  int output_value = 0;
  if (cursor.coefficient == 0) {
    unsigned component = descriptor & 255;
    cursor.predictors[component] += amplitude;
    cursor.coefficient = 1;
    output_index = 0;
    output_value = cursor.predictors[component];
  } else {
    unsigned run = symbol >> 4;
    if (category == 0) {
      unsigned nonzero_run_mask = 0u - static_cast<unsigned>(run != 0);
      unsigned next = (cursor.coefficient + 16) & nonzero_run_mask;
      if (next > 64) cursor.error = 1;
      cursor.coefficient = next & 63;
    } else {
      unsigned index = cursor.coefficient + run;
      if (index >= 64) {
        // An invalid run consumes its codeword, but never its amplitude.
        consumed = length;
        cursor.error = 1;
      } else {
        cursor.coefficient = (index + 1) & 63;
        output_index = index;
        output_value = amplitude;
      }
    }
    if (cursor.coefficient == 0 && cursor.error == 0) {
      ++cursor.blocks;
      ++cursor.block_index;
      unsigned wrap_mask = 0u - static_cast<unsigned>(cursor.block_index != blocks_per_mcu);
      cursor.block_index &= wrap_mask;
    }
  }
  cursor.position += consumed;
  cursor.reads += consumed;
  return {cursor, output_index, output_value};
}

'''
source = source[:position] + fast + source[position:]
(notes / 'device_entropy_cursor_short.h').write_text(source)
pipeline = (notes / 'device_partitioned_pipeline.cxx').read_text()
assert pipeline.count('#include "device_entropy_cursor_fused.h"') == 1
pipeline = pipeline.replace('device_entropy_cursor_fused.h', 'device_entropy_cursor_short.h')
(notes / 'device_short_pipeline.cxx').write_text(pipeline)
