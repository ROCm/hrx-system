"""Put the qualified entropy-to-RGB control behind the identical command caller."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
original = root / 'twolevel-batch16-1024'
directory = root / 'command-control-batch16'
directory.mkdir(exist_ok=True)
source = (original / 'summary.loom').read_text()
paths = {key: ((original / relative).resolve(), count, dtype) for key, relative, count, dtype in
         re.findall(r'%([a-z_]+) = check.file.read.npy path\("([^"]+)"\) : tensor<(\d+)x(i32|i8)>', source)}
outputs = set(re.findall(r'%([a-z_]+)_output = check.generate.fill', source))
declaration = ', '.join('%' + key + ': buffer' for key in paths)
text = [source[:source.index('check.case')],
        'command.program.def public @jpeg_decode() launch(' + declaration + ') {',
        '  command.serial {']
for name, operands in re.findall(r'kernel.launch @(\w+)\(([^)]+)\)', source):
    arguments = operands.replace('_output', '')
    text.append('    kernel.launch @' + name + '(' + arguments + ') : (' + ', '.join('buffer' for _ in arguments.split(',')) + ')')
text.extend(['  }', '  command.return', '}', '',
             'command.program.def public @jpeg_batch() launch(' + declaration + ') {',
             '  %zero = index.constant 0 : index', '  %one = index.constant 1 : index',
             '  %eight = index.constant 8 : index',
             '  scf.for %repeat = [%zero to %eight step %one] unroll {',
             '    command.program.launch @jpeg_decode(' + ', '.join('%' + key for key in paths) + ') : (' + ', '.join('buffer' for key in paths) + ')',
             '  }', '  command.return', '}', ''])
(directory / 'summary.loom').write_text('\n'.join(text))
(directory / 'config.json').write_bytes((original / 'config.json').read_bytes())
(directory / 'bindings.txt').write_text('\n'.join(
    f'{key} {int(key not in outputs)} {1 if dtype == "i8" else 4} {count} {os.path.relpath(path, directory)}'
    for key, (path, count, dtype) in paths.items()) + '\n')
link = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['codec-jpeg-rebased-tools']) / 'loom/src/loom/tools/loom-link/loom-link'
library = root / 'entropy-twolevel.loombc'
subprocess.run([str(link), str(directory / 'summary.loom'), str(library), '--to=bc',
                '--output=' + str(directory / 'summary.loombc')], check=True)
stage = json.loads((original / 'stage.json').read_text())
stage['files'] = {os.path.relpath(path, directory): hashlib.sha256(path.read_bytes()).hexdigest()
                  for path, count, dtype in paths.values()}
stage['files'].update({path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in directory.iterdir() if path.name != 'stage.json'})
stage['scope'] = 'Qualified seven-stage entropy-to-RGB control behind the same serving command caller, eight serial operations per command buffer. CPU-unstuffed entropy and precomputed jobs/segments remain inputs; this is a partial-path control.'
(directory / 'stage.json').write_text(json.dumps(stage, indent=2) + '\n')
print('Control command ready', flush=True)
