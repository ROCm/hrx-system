"""Replace canonical long-code walks with one bounded secondary lookup."""
from pathlib import Path

notes = Path(__file__).resolve().parent


def rewrite(source):
    source = source.replace('832', '2048')
    marker = '  if (length == 0) {'
    while marker in source:
        start = source.index(marker)
        end = source.index('{', start)
        depth = 1
        end += 1
        while depth:
            if source[end] == '{': depth += 1
            elif source[end] == '}': depth -= 1
            end += 1
        assert 'for (unsigned candidate = 10;' in source[start:end]
        source = source[:start] + source[end:]
    source = source.replace('unsigned packed = table[bits >> 23];', 'unsigned packed = lookup_huffman(table, bits);')
    source = source.replace('unsigned packed = table[input.value >> 23];', 'unsigned packed = lookup_huffman(table, input.value);')
    source = source.replace('unsigned packed = tables[table_index * 2048 + (input.value >> 23)];',
                            'unsigned packed = lookup_huffman(tables + table_index * 2048, input.value);')
    source = source.replace('loom::assume(length <= 9u);', 'loom::assume(length <= 16u);')
    return source


source = rewrite((notes / 'device_entropy_cursor_layout.h').read_text())
marker = 'struct Codeword {'
helper = '''// Header-derived canonical tables retain a final root entry or a bounded
// offset/mask/shift into their secondary suffix table. Undefined prefixes stay
// zero; extent/read-cap and syntax errors remain the cursor transition's job.
static LOOM_FORCE_INLINE unsigned lookup_huffman(const unsigned* table, unsigned bits) {
  unsigned packed = table[bits >> 23];
  if ((packed & 0x80000000u) != 0) {
    unsigned offset = packed & 2047u;
    unsigned shift = (packed >> 24) & 31u;
    unsigned mask = (packed >> 16) & 127u;
    unsigned index = offset + ((bits >> shift) & mask);
    loom::assume(index < 2048u);
    packed = table[index];
  }
  return packed;
}

'''
assert source.count(marker) == 1
source = source.replace(marker, helper + marker)
(notes / 'device_entropy_cursor_twolevel.h').write_text(source)
speculate = (notes / 'device_entropy_layout.cxx').read_text().replace('832', '2048')
reconstruct = rewrite((notes / 'device_reconstruct_layout.cxx').read_text())
(notes / 'device_reconstruct_twolevel.cxx').write_text(reconstruct)
pipeline = '#include "device_entropy_cursor_twolevel.h"\n'
pipeline += '''[[loom::config("jpeg.output_partitions"), loom::where(loom::predicate::range(2u, 8u))]]
extern const unsigned output_partitions;
'''
for text in (speculate, (notes / 'device_bridge.cxx').read_text(),
             (notes / 'device_certify_partitioned.cxx').read_text(), reconstruct,
             (notes / 'device_color_store.cxx').read_text()):
    pipeline += '\n' + text.replace('#include "device_entropy_cursor.h"', '') + '\n'
(notes / 'device_twolevel_pipeline.cxx').write_text(pipeline)
