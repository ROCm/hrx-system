"""Numerical preflight for the captured public fancy-chroma/RGB boundary."""
import hashlib
import json
from pathlib import Path

from device_fixture import input_bytes
from sequential import parse

notes = Path(__file__).resolve().parent
raw_path = notes.parent / 'jpeg-gpu-oracle/raw-reference-small.log'
rgb_path = notes.parent / 'jpeg-reference/probe.log'
raw_rows = [json.loads(line) for line in raw_path.read_text().splitlines()
            if line.startswith('{"name":')]
rgb_rows = [json.loads(line) for line in rgb_path.read_text().splitlines()
            if line.startswith('{"kind":"result"')]
references = {row['name']: row for row in rgb_rows if row['mode'] == 1}
groups = {}
for row in raw_rows:
    if row['method'] == 0:
        groups.setdefault(row['name'], []).append(row)


def interpolate(plane, width, height, x, y, horizontal, vertical):
    column, row = x // horizontal, y // vertical

    def sample(column, row):
        return plane[min(max(row, 0), height - 1) * width + min(max(column, 0), width - 1)]

    center = sample(column, row)
    neighbor_column = column + (1 if x & 1 else -1)
    neighbor_row = row + (1 if y & 1 else -1)
    if horizontal == 2 and vertical == 2 and width > 2:
        weighted = (9 * center + 3 * sample(neighbor_column, row) +
                    3 * sample(column, neighbor_row) + sample(neighbor_column, neighbor_row))
        return (weighted + (7 if x & 1 else 8)) >> 4
    if horizontal == 2 and vertical == 1 and width > 2:
        return (3 * center + sample(neighbor_column, row) + (2 if x & 1 else 1)) >> 2
    if horizontal == 1 and vertical == 2:
        return (3 * center + sample(column, neighbor_row) + (2 if y & 1 else 1)) >> 2
    return center


def convert(frame, planes, color_space):
    horizontal = max(component.horizontal for component in frame.components)
    vertical = max(component.vertical for component in frame.components)
    output = bytearray()
    for y in range(frame.height):
        for x in range(frame.width):
            values = []
            for component, plane in zip(frame.components, planes, strict=True):
                assert horizontal % component.horizontal == 0 and vertical % component.vertical == 0
                values.append(interpolate(plane['pixels'], plane['width'], plane['height'], x, y,
                                          horizontal // component.horizontal, vertical // component.vertical))
            if color_space == 1:
                red = green = blue = values[0]
            elif color_space == 2:
                red, green, blue = values
            elif color_space == 3:
                luminance, cb, cr = values
                cb -= 128
                cr -= 128
                red = luminance + ((91881 * cr + 32768) >> 16)
                green = luminance + ((-22554 * cb - 46802 * cr + 32768) >> 16)
                blue = luminance + ((116130 * cb + 32768) >> 16)
            else:
                raise ValueError('No RGB interpretation selected for this component colorspace')
            output.extend(min(max(value, 0), 255) for value in (red, green, blue))
    return bytes(output)


rows = []
rejected = []
for name, planes in groups.items():
    reference = references[name]
    if not reference['complete']:
        rejected.append({'name': name, 'color_space': reference['color_space'],
                         'reason': 'Public RGB conversion rejects this component colorspace'})
        continue
    planes.sort(key=lambda plane: plane['component'])
    for plane in planes:
        plane['pixels'] = bytes.fromhex(plane['hex'])
    encoded = input_bytes(name)
    frame = parse(encoded)
    actual = convert(frame, planes, reference['color_space'])
    expected = bytes.fromhex(reference['rgb_hex'])
    if actual != expected:
        differences = [(index, left, right) for index, (left, right) in enumerate(zip(actual, expected, strict=True)) if left != right]
        raise AssertionError((name, len(differences), differences[:8]))
    row = {'name': name, 'color_space': reference['color_space'],
           'input_sha256': hashlib.sha256(encoded).hexdigest(),
           'rgb_sha256': hashlib.sha256(actual).hexdigest(), 'samples': len(actual), 'exact': True}
    rows.append(row)
    print(json.dumps(row), flush=True)
assert len(rows) == 13 and len(rejected) == 2
result = {'scope': 'Numerical preflight only. Captured public integer component planes and oracle-declared colorspace are inputs; no native color kernel, independent marker-color policy, full decoder, or serving integration is selected.',
          'rows': rows, 'rejected': rejected,
          'sources': {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in
                      (Path(__file__), raw_path, rgb_path,
                       notes.parent / 'jpeg-baseline/oracle-source/jdsample.c',
                       notes.parent / 'jpeg-baseline/oracle-source/jdcolor.c')}}
(notes / 'color-reference-qualified.json').write_text(json.dumps(result, indent=2) + '\n')
