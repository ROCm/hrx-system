"""Derive a bounded libjpeg/task-pool control with identical filter plan bytes."""
from pathlib import Path
import hashlib
import json

notes=Path(__file__).resolve().parent
base=notes.parent/'jpeg-baseline'
source=(base/'jpeg_pipeline_baseline.cc').read_text()
source=source.replace('#include <condition_variable>','#include <condition_variable>\n#include <cmath>\n#include <sys/resource.h>')
axis='''struct Axis {
  // First source sample for each output coordinate.
  std::vector<uint32_t> starts;
  // Prefix offsets into the normalized weights.
  std::vector<uint32_t> offsets;
  // Exact float32 weights prepared by the model filter contract.
  std::vector<float> weights;
};

using Channels = float __attribute__((ext_vector_type(4)));
static size_t batch_repeats = 8;

Axis ReadAxis(std::ifstream& file, uint32_t count) {
  Axis axis;
  axis.starts.resize(count);
  axis.offsets.resize(count + 1);
  file.read(reinterpret_cast<char*>(axis.starts.data()), count * 4);
  file.read(reinterpret_cast<char*>(axis.offsets.data()), (count + 1) * 4);
  if (!file || axis.offsets.front() != 0 || axis.offsets.back() > 65536) Fail("invalid axis extent");
  axis.weights.resize(axis.offsets.back());
  file.read(reinterpret_cast<char*>(axis.weights.data()), axis.weights.size() * 4);
  if (!file) Fail("short axis weights");
  return axis;
}

'''
source=source.replace('struct Image {',axis+'struct Image {')
source=source.replace('  // Sequential or progressive marker information', '''  // Model-selected destination width.
  uint32_t output_width = 0;
  // Model-selected destination height.
  uint32_t output_height = 0;
  // Maximum vertical support; bounds live horizontal storage.
  uint32_t ring_rows = 0;
  // Immutable model filter plans prepared outside decode timing.
  Axis horizontal;
  // Immutable vertical plan with the identical tap order as the GPU.
  Axis vertical;
  // Sequential or progressive marker information''')
needle='  jpeg_destroy_decompress(&codec);\n  return image;'
assert source.count(needle)==1
source=source.replace(needle,'''  jpeg_destroy_decompress(&codec);
  std::ifstream plan(std::string(path) + ".plan", std::ios::binary);
  if (!plan) Fail("missing exact filter plan");
  plan.read(reinterpret_cast<char*>(&image.output_width), 4);
  plan.read(reinterpret_cast<char*>(&image.output_height), 4);
  if (!plan || !image.output_width || !image.output_height || image.output_width > 8192 || image.output_height > 8192) Fail("invalid resize dimensions");
  image.horizontal = ReadAxis(plan, image.output_width);
  image.vertical = ReadAxis(plan, image.output_height);
  if (plan.peek() != std::char_traits<char>::eof()) Fail("unexpected plan suffix");
  for (uint32_t row = 0; row < image.output_height; ++row) {
    uint32_t count = image.vertical.offsets[row + 1] - image.vertical.offsets[row];
    if (!count || image.vertical.starts[row] + count > image.height) Fail("invalid vertical support");
    image.ring_rows = std::max(image.ring_rows, count);
  }
  for (uint32_t x = 0; x < image.output_width; ++x) {
    uint32_t count = image.horizontal.offsets[x + 1] - image.horizontal.offsets[x];
    if (!count || image.horizontal.starts[x] + count > image.width) Fail("invalid horizontal support");
  }
  image.pixel_bytes = size_t(image.output_width) * image.output_height * 3;
  return image;''')
begin=source.index('  while (codec.output_scanline < codec.output_height) {')
end=source.index('  if (!jpeg_finish_decompress',begin)
source=source[:begin]+'''  std::vector<uint8_t> row(image.width * 3);
  std::vector<Channels> horizontal(size_t(image.ring_rows) * image.output_width);
  uint32_t output_row = 0;
  while (codec.output_scanline < codec.output_height) {
    uint32_t y = codec.output_scanline;
    JSAMPROW pointer = row.data();
    if (jpeg_read_scanlines(&codec, &pointer, 1) != 1) Fail("short scanline");
    auto* filtered = horizontal.data() + size_t(y % image.ring_rows) * image.output_width;
    for (uint32_t x = 0; x < image.output_width; ++x) {
      uint32_t begin = image.horizontal.offsets[x];
      uint32_t end = image.horizontal.offsets[x + 1];
      const uint8_t* samples = row.data() + image.horizontal.starts[x] * 3;
      Channels value = {};
      for (uint32_t tap = begin; tap < end; ++tap, samples += 3) {
        Channels pixel = {float(samples[0]), float(samples[1]), float(samples[2]), 0.0f};
        value += pixel * image.horizontal.weights[tap];
      }
      filtered[x] = value;
    }
    while (output_row < image.output_height) {
      uint32_t start = image.vertical.starts[output_row];
      uint32_t begin = image.vertical.offsets[output_row];
      uint32_t end = image.vertical.offsets[output_row + 1];
      if (start + end - begin > y + 1) break;
      for (uint32_t x = 0; x < image.output_width; ++x) {
        Channels value = {};
        for (uint32_t tap = begin; tap < end; ++tap) {
          uint32_t source_row = (start + tap - begin) % image.ring_rows;
          value += horizontal[size_t(source_row) * image.output_width + x] * image.vertical.weights[tap];
        }
        for (uint32_t channel = 0; channel < 3; ++channel) {
          float sample = std::nearbyint(value[channel]);
          sample = std::min(std::max(sample, 0.0f), 255.0f);
          output[(size_t(output_row) * image.output_width + x) * 3 + channel] = uint8_t(sample);
        }
      }
      ++output_row;
    }
  }
  if (output_row != image.output_height) Fail("incomplete filtered output");
''' + source[end:]
source=source.replace('  Decode(*job->image, job->storage.data() + 32);','  for (size_t repeat = 0; repeat < batch_repeats; ++repeat) Decode(*job->image, job->storage.data() + 32);')
source=source.replace('for (auto& job : jobs) Decode(*job->image, job->storage.data() + 32);',
                      'for (auto& job : jobs) for (size_t repeat = 0; repeat < batch_repeats; ++repeat) Decode(*job->image, job->storage.data() + 32);')
needle='  std::string mode = argv[1];'
source=source.replace(needle,needle+'''
  if (mode == "capture") {
    if (argc != 4) Fail("capture input output");
    Image image = ReadImage(argv[2]);
    std::vector<uint8_t> output(image.pixel_bytes);
    Decode(image, output.data());
    std::ofstream file(argv[3], std::ios::binary);
    file.write(reinterpret_cast<const char*>(output.data()), output.size());
    if (!file) Fail("capture failed");
    return 0;
  }
''')
source=source.replace('  std::printf("],\\"full_rgb_and_guards\\":true}\\n");', '''  struct rusage usage = {};
  if (getrusage(RUSAGE_SELF, &usage)) Fail("getrusage failed");
  size_t maximum_workspace = 0;
  for (const auto& image : images) maximum_workspace = std::max(maximum_workspace,
      size_t(image.width) * 3 + size_t(image.ring_rows) * image.output_width * sizeof(Channels));
  std::printf("],\\"full_rgb_and_guards\\":true,\\"repeats_per_job\\":%zu,\\"maximum_row_workspace_bytes\\":%zu,\\"process_peak_rss_kib\\":%ld}\\n",
              batch_repeats, maximum_workspace, usage.ru_maxrss);''')
(base/'jpeg_resize_baseline.cc').write_text(source)
build=base/'BUILD.bazel';text=build.read_text()
if 'name = "jpeg_resize_islow"' not in text:
    for policy in ('islow','ifast'):
        text+=f'''
iree_cc_binary(
    name = "jpeg_resize_{policy}",
    srcs = ["jpeg_resize_baseline.cc"],
    defines = ["CODEC_REFERENCE_IDCT=JDCT_{policy.upper()}"],
    copts = ["-ffp-contract=off"],
    deps = ["//runtime/src/iree/base", "//runtime/src/iree/base/threading",
            "//runtime/src/iree/task:task", "@libjpeg_turbo//:jpeg"],
)
'''
    build.write_text(text)
(notes/'resize-cpu-source.json').write_text(json.dumps({'source_sha256':hashlib.sha256(source.encode()).hexdigest(),
 'numerics':'Exact supplied model weights, separate float32 multiply/add, round-to-even, unchanged libjpeg IDCT choice.',
 'memory':'One RGB row and vertical-support float4 rows per active decode; 16 disjoint final outputs retained.',
 'execution':'16 persistent task-pool jobs, eight decodes each, one final completion; no host/device interaction.'},indent=2)+'\n')
