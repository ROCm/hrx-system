"""Check queue ownership and poisoned gaps in captured native output."""
import argparse
import json
from pathlib import Path

import numpy as np

parser = argparse.ArgumentParser()
parser.add_argument('case')
arguments = parser.parse_args()
notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory']) / 'persistent'
directory = root / arguments.case
fixture = json.loads((directory / 'fixture.json').read_text())
actual = np.load(directory / 'actual/actual.npy').view(np.uint8)
initial = np.load(directory / 'output.npy').view(np.uint8)
inputs = np.load(directory / 'input.npy').view(np.uint8)


def value(name):
    row = fixture['ranges'][name]
    owner = inputs if row['root'] == 'input' else actual
    return owner[row['offset']:row['offset'] + row['bytes']].view(
        np.uint8 if row['type'] == 'i8' else np.uint32)


heads = value('heads')
links = value('links')
cursors = value('cursors').reshape(-1, 8)
intervals = value('intervals').reshape(-1, 8)
streams = value('streams').reshape(-1, 7)
images = value('images')[:288].reshape(16, 18)
blocks = value('blocks')[:64].reshape(16, 4)
segments = value('segments')[:128].reshape(16, 8)
seen = set()
rows = []
violations = []
for image in range(16):
    first = int(segments[image, 2]) * 5 + image
    count = int(segments[image, 3]) * 5 + 1
    tasks = {i for i in range(first, first + count)
             if intervals[i, 0] < intervals[i, 1] or i == first + count - 1}
    found = set()
    chains = []
    row_offset, row_count = map(int, streams[image, :2])
    for row in range(row_count):
        node = int(heads[row_offset + row])
        chain = []
        while node != 0xffffffff:
            if node not in tasks or node in seen:
                violations.append({'image': image, 'row': row, 'invalid_or_duplicate_task': node})
                break
            seen.add(node)
            found.add(node)
            chain.append(node)
            mcu = int(cursors[node, 2]) // int(blocks[image, 3]) + int(cursors[node, 3] != 0)
            expected_row = min(mcu // int(images[image, 11]), row_count - 1)
            if expected_row != row:
                violations.append({'task': node, 'queue_row': row, 'cursor_row': expected_row})
            node = int(links[node])
        if len(chain) != int(value('pending')[row_offset + row]):
            violations.append({'image': image, 'row': row, 'queued': len(chain),
                               'pending': int(value('pending')[row_offset + row])})
        chains.append(chain)
    if len(found) + int(streams[image, 5]) != len(tasks):
        violations.append({'image': image, 'queued': len(found), 'done': int(streams[image, 5]),
                           'expected': len(tasks)})
    selected = slice(row_offset, row_offset + row_count)
    rows.append({'image': image, 'name': fixture['images'][image]['name'],
                 'stream': streams[image].tolist(), 'queues': chains,
                 'decoded': value('decoded')[selected].tolist(),
                 'color_claimed': value('color_claimed')[selected].tolist(),
                 'color_done': value('color_done')[selected].tolist()})
mask = np.ones(len(actual), dtype=bool)
comparisons = {}
for name, row in fixture['ranges'].items():
    if row['root'] != 'output':
        continue
    mask[row['offset']:row['offset'] + row['bytes']] = False
    expected_file = directory / (name + '-expected.npy')
    if expected_file.exists():
        expected = np.load(expected_file).view(np.uint8 if row['type'] == 'i8' else np.uint32)
        mismatches = np.flatnonzero(value(name) != expected)
        comparisons[name] = {'mismatches': len(mismatches), 'first': mismatches[:8].tolist()}
guards = bool(np.array_equal(actual[mask], initial[mask]))
passed = guards and not violations and not any(row['mismatches'] for row in comparisons.values())
report = {'case': arguments.case, 'passed': passed, 'queued_tasks': len(seen),
          'guard_bytes': int(np.count_nonzero(mask)), 'guards_intact': guards,
          'ownership_violations': violations, 'comparisons': comparisons, 'images': rows}
(notes / ('persistent-' + arguments.case + '-audit.json')).write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2), flush=True)
raise SystemExit(0 if passed else 1)
