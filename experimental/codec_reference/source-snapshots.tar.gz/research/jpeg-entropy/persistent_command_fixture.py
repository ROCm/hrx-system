"""Expose the bounded consumer fixture to the existing serving command caller."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

parser = argparse.ArgumentParser()
parser.add_argument('case')
arguments = parser.parse_args()
notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory']) / 'persistent'
directory = root / arguments.case
fixture = json.loads((directory / 'fixture.json').read_text())
expected = np.load(directory / 'output.npy').view(np.uint8).copy()
regions = [('input', 0, fixture['root_bytes']['input'])]
end = 0
for name, row in fixture['ranges'].items():
    if row['root'] != 'output':
        continue
    if row['offset'] > end:
        regions.append(('output', end, row['offset'] - end))
    end = row['offset'] + row['bytes']
    path = directory / (name + '-expected.npy')
    if path.exists():
        value = np.load(path).view(np.uint8)
        assert len(value) == row['bytes']
        expected[row['offset']:end] = value
        regions.append(('output', row['offset'], row['bytes']))
regions.append(('output', end, len(expected) - end))
np.save(directory / 'output-expected.npy', expected.view(np.int8))
(directory / 'bindings.txt').write_text(
    f'input 1 1 {fixture["root_bytes"]["input"]} input.npy\n'
    f'output 0 1 {fixture["root_bytes"]["output"]} output-expected.npy\n')
(directory / 'regions.txt').write_text(''.join(
    f'{name} {offset} {length} exact\n' for name, offset, length in regions if length))
command = (root / 'connected/command.loom').read_text()
assert command.count('@jpeg_stream_decode') == 1
(directory / 'command.loom').write_text(command.replace('@jpeg_stream_decode', '@jpeg_decode'))
record = {'case': arguments.case, 'initial_values': ['input.npy', 'output.npy'],
          'expected_regions': regions,
          'unprescribed_values': ['links', 'cursors'],
          'ownership_audit': 'persistent_audit.py consumes complete raw output after the command',
          'source_sha256': hashlib.sha256((root / 'connected/persistent.cxx').read_bytes()).hexdigest()}
(directory / 'command-fixture.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'case': arguments.case, 'checked_bytes': sum(length for _, _, length in regions),
                  'regions': len(regions)}), flush=True)
