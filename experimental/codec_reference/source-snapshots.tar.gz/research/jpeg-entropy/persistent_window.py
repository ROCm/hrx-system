"""One bounded native ownership check; worker holds cover execution only."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import sharkbox_window as worker

ROOT = Path(__file__).resolve().parent
worker.ROOT = ROOT
worker.OWNER = 'codec-persistent-20261018'
worker.BROKER = str(Path.home() / '.dotfiles/bin/benchmark-lock')


def state():
    gpus = {}
    for card in Path('/sys/class/drm').iterdir():
        if not card.name.startswith('card') or not card.name[4:].isdecimal():
            continue
        root = card / 'device'
        names = ('vendor', 'device', 'unique_id', 'gpu_busy_percent', 'mem_info_vram_used')
        gpus[str(root.resolve())] = {name: (root / name).read_text().strip()
                                    for name in names if (root / name).is_file()}
    owners = []
    for path in Path('/sys/class/kfd/kfd/proc').iterdir():
        process = Path('/proc') / path.name
        if process.exists():
            owners.append({'pid': int(path.name), 'comm': (process / 'comm').read_text().strip()})
    native_workers = []
    for process in Path('/proc').iterdir():
        if not process.name.isdecimal():
            continue
        try:
            if (process / 'comm').read_text().strip() == 'bureau-build-ce':
                native_workers.append(int(process.name))
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
    return {'gpus': gpus, 'live_kfd': owners, 'native_workers': native_workers}


def run_group(command, timeout):
    process = subprocess.Popen(command, stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, text=True,
                               start_new_session=True)
    try:
        output, _ = process.communicate(timeout=timeout)
        return {'command': command, 'returncode': process.returncode, 'output': output}
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGTERM)
        try:
            output, _ = process.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            output, _ = process.communicate(timeout=5)
        return {'command': command, 'returncode': process.returncode,
                'harness_timeout': True, 'output': output}
    finally:
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=5)


def excluded(observed):
    """Qualify an explicit native-worker hold, or an absent worker population."""
    if observed['live_kfd']:
        return False
    if not observed['native_workers']:
        return True
    selected=json.loads(os.environ['CODEC_BENCHMARK_WORKERS'])
    assert {entry['pid'] for entry in selected}==set(observed['native_workers'])
    worker.OWNER=os.environ['CODEC_BENCHMARK_OWNER']
    observed['worker_exclusion']=[]
    for entry in selected:
        status=worker.control(entry,'verify',timeout=5)
        assert status['Owner']==worker.OWNER and status['Active']==0,status
        observed['worker_exclusion'].append({'pid':entry['pid'],'status':status})
    return True


def execute(case, gorgon, command_probe):
    assert os.environ['BENCHMARK_LOCK_LEASE_ID']
    record = {'scope': 'Native correctness/progress only; no performance measurement.',
              'lease': os.environ['BENCHMARK_LOCK_LEASE_ID'], 'before': state()}
    assert not record['before']['live_kfd'], record['before']
    if gorgon:
        assert not record['before']['native_workers'], record['before']
    fixture = ROOT / case
    if command_probe:
        (fixture / 'actual').mkdir(exist_ok=True)
        command = [str(ROOT / 'codec_command_probe'), '--jpeg_fixture=' + str(fixture),
                   '--jpeg_initial=.', '--jpeg_capture=' + str(fixture / 'actual'),
                   '--jpeg_regions=regions.txt', '--jpeg_access=true',
                   '--amdgpu_asan=true', '--amdgpu_asan_report_policy=fail-device',
                   '--gtest_filter=JpegCommandTest.CompressedToRgb']
    else:
        command = [str(ROOT / 'iree-test-loom'), str(fixture / 'check.loombc'),
                   '--config-file=' + str(fixture / 'config.json'),
                   '--file-output-root=' + str(fixture / 'actual'),
                   '--device=amdgpu', '--target=amdgpu:' + ('gfx1151' if gorgon else 'gfx1100'),
                   '--sanitizer=access']
    started = time.monotonic()
    result = run_group(command, 90)
    record.update(result=result, wall_seconds=time.monotonic() - started,
                  after=state())
    worker.save(fixture / 'result.json', record)
    print(json.dumps({'scope': record['scope'], 'lease': record['lease'],
                      'result': result, 'wall_seconds': record['wall_seconds'],
                      'remaining_kfd': record['after']['live_kfd']}), flush=True)
    if result['returncode'] or result.get('harness_timeout'):
        raise SystemExit(1)
    if command_probe:
        rows = [json.loads(line) for line in result['output'].splitlines() if line.startswith('{')]
        assert len([row for row in rows if row.get('phase') == 'command']) == 1, rows
        assert {row['binding'] for row in rows if row.get('phase') == 'regions'} == {'input', 'output'}, rows
    else:
        report = json.loads(result['output'])
        assert report['sample_count'] + report['trial_count'] > 0, report
        assert report['failed_sample_count'] + report['failed_trial_count'] == 0, report


def window(case, gorgon, command_probe):
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    for relative, expected in manifest['files'].items():
        path = ROOT / relative
        assert path.stat().st_size == expected['bytes'], relative
        assert worker.digest(path) == expected['sha256'], relative
    selected = [] if gorgon else worker.workers()
    record = {'owner': worker.OWNER, 'case': case, 'before': state(),
              'workers': selected, 'attempted_holds': [], 'controls': []}
    if gorgon:
        assert not record['before']['native_workers'], record['before']
    receipt = ROOT / case / 'window.json'
    worker.save(receipt, record)
    start = time.monotonic()
    try:
        for item in selected:
            status = worker.control(item, 'status')
            assert status['State'] == 'accepting' and not status['Owner'], status
        for item in selected:
            record['attempted_holds'].append(item['kind'])
            worker.save(receipt, record)
            status = worker.control(item, 'hold')
            record['controls'].append({'kind': item['kind'], 'hold': status})
            worker.save(receipt, record)
            assert status['Owner'] == worker.OWNER and status['Active'] == 0, status
        for item in selected:
            status = worker.control(item, 'verify')
            assert status['Owner'] == worker.OWNER and status['Active'] == 0, status
        command = [worker.BROKER, '--label=codec-persistent-' + case, '--', 'env',
                   'LD_LIBRARY_PATH=' + str(ROOT / 'lib')]
        if not gorgon:
            command.append('ROCR_VISIBLE_DEVICES=' + worker.GPU_UUID)
        command.extend(['python3', '-B', str(Path(__file__).resolve()), '--execute', case])
        if gorgon:
            command.append('--gorgon')
        if command_probe:
            command.append('--command')
        result = run_group(command, 150)
        record['execution'] = result
        worker.save(receipt, record)
        print(result['output'][-14000:], flush=True)
        if result['returncode'] or result.get('harness_timeout'):
            raise RuntimeError('Native ownership check did not pass')
    finally:
        failures = []
        for item in reversed(selected):
            if item['kind'] not in record['attempted_holds']:
                continue
            try:
                status = worker.control(item, 'status')
                if status['Owner'] == worker.OWNER:
                    record['controls'].append({'kind': item['kind'], 'resume': worker.control(item, 'resume')})
                elif status['Owner']:
                    raise RuntimeError(status)
                status = worker.control(item, 'status')
                assert status['State'] == 'accepting' and not status['Owner'], status
            except Exception as error:
                failures.append(repr(error))
        record['resume_failures'] = failures
        record['window_wall_seconds'] = time.monotonic() - start
        status = subprocess.run([worker.BROKER, '--status'], capture_output=True, text=True)
        record['broker_status_after'] = status.stdout + status.stderr
        worker.save(receipt, record)
        print(json.dumps({key: record[key] for key in ('resume_failures', 'window_wall_seconds', 'broker_status_after')}), flush=True)
        if failures:
            raise RuntimeError(failures)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--window')
    parser.add_argument('--execute')
    parser.add_argument('--gorgon', action='store_true')
    parser.add_argument('--command', action='store_true')
    args = parser.parse_args()
    assert bool(args.window) != bool(args.execute)
    if args.execute:
        execute(args.execute, args.gorgon, args.command)
    else:
        window(args.window, args.gorgon, args.command)
