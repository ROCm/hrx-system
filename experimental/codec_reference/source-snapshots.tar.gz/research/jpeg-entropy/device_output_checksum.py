"""Construct an explicitly non-decoder attribution control with exact checksums."""
import array
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess

from device_fixture import input_bytes
from sequential import decode, parse

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
tags = json.loads(os.environ['BUREAU_TAG_ROOTS'])
base = Path(tags['codec-jpeg-rebased-tools'])
native = Path(tags['codec-jpeg-unsigned-opt'])
source = (notes / 'device_reconstruct.cxx').read_text()
first = source.index('  if (!any_ac) {')
last = source.index('\nstatic LOOM_FORCE_INLINE Symbol output_symbol')
checksum = '''  unsigned checksum = 0;
  [[loom::unroll]]
  for (unsigned index = 0; index < 64; ++index) {
    checksum ^= static_cast<unsigned>(coefficients[index * threads + lane]);
  }
  [[loom::unroll]]
  for (unsigned index = 0; index < 16; ++index) pixels[index] = checksum;
}
'''
source = source[:first] + checksum + source[last:]
(notes / 'device_reconstruct_checksum.cxx').write_text(source)
pipeline = (notes / 'device_output_pipeline.cxx').read_text().replace(
    'device_reconstruct.cxx', 'device_reconstruct_checksum.cxx')
(notes / 'device_checksum_pipeline.cxx').write_text(pipeline)
commands = [
    [str(base / 'loom/src/loom/tools/loom-import-cxx/loom-import-cxx'),
     str(notes / 'device_checksum_pipeline.cxx'), '--output=' + str(root / 'entropy-checksum.loom')],
    [str(base / 'loom/src/loom/tools/loom-link/loom-link'), str(root / 'entropy-checksum.loom'),
     '--to=bc', '--output=' + str(root / 'entropy-checksum.loombc')],
    [str(native / 'loom/src/loom/tools/loom-compile/loom-compile'), str(root / 'entropy-checksum.loombc'),
     '--root=jpeg_reconstruct', '--target=amdgpu:gfx1151',
     '--config-file=' + str(root / 'output-config.json'),
     '--output=' + str(root / 'jpeg_reconstruct-checksum.hsaco'),
     '--compile-report=details', '--compile-report-output=' + str(root / 'checksum-report.json')]]
for command in commands:
    subprocess.run(command, check=True)
metrics = json.loads((root / 'checksum-report.json').read_text())['entries']['rows'][0]
print(json.dumps({key: metrics[key] for key in ('instruction_count', 'code_byte_count',
                  'private_memory_bytes', 'local_memory_bytes', 'target_resources')}), flush=True)

frame = parse(input_bytes('012mp-bus.jpg.r0.jpg'))
planes, unused = decode(frame)
pixels = array.array('I')
for component, plane in zip(frame.components, planes):
    for offset in range(0, len(plane), 64):
        checksum = 0
        for index in range(64):
            checksum ^= (plane[offset + index] * component.quantization[index]) & 0xffffffff
        pixels.extend([checksum] * 16)
assert len(pixels) * 4 == 18289152
original = root / 'output-batch16-1024'
fixture = root / 'checksum-batch16-1024'
fixture.mkdir(exist_ok=True)
header = repr({'descr': '<i4', 'fortran_order': False, 'shape': (len(pixels) * 16,)}).encode()
header += b' ' * ((64 - ((10 + len(header) + 1) % 64)) % 64) + b'\n'
with (fixture / 'pixels.npy').open('wb') as stream:
    stream.write(b'\x93NUMPY\x01\x00' + struct.pack('<H', len(header)) + header)
    for image in range(16):
        pixels.tofile(stream)
text = (original / 'summary.loom').read_text()
pattern = re.compile(r'check.file.read.npy path\("([^"]+)"\)')
paths = {}
def relocate(match):
    path = fixture / 'pixels.npy' if match[1] == 'pixels.npy' else (original / match[1]).resolve()
    name = os.path.relpath(path, fixture)
    paths[name] = path
    return 'check.file.read.npy path("' + name + '")'
text = pattern.sub(relocate, text)
(fixture / 'summary.loom').write_text(text)
(fixture / 'config.json').write_bytes((original / 'config.json').read_bytes())
command = [str(base / 'loom/src/loom/tools/loom-link/loom-link'), str(fixture / 'summary.loom'),
           str(root / 'entropy-checksum.loombc'), '--to=bc', '--output=' + str(fixture / 'summary.loombc')]
subprocess.run(command, check=True)
commands.append(command)
stage = json.loads((original / 'stage.json').read_text())
stage['files'] = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in paths.items()}
stage['files'].update({path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                      for path in fixture.iterdir() if path.is_file() and path.name != 'stage.json'})
stage['library'] = {'path': 'entropy-checksum.loombc',
                    'sha256': hashlib.sha256((root / 'entropy-checksum.loombc').read_bytes()).hexdigest()}
stage['scope'] = 'Diagnostic only: complete entropy/dequantization and checksum over every shared coefficient block; same 64-byte output/block, no IDCT. Independently checked against CPU coefficient-plane XORs. Not JPEG samples.'
stage['retention'] = 'One additional reusable 292626432-byte checksum expectation in /tmp, retired after this diagnostic.'
stage['link_command'] = command
(fixture / 'stage.json').write_text(json.dumps(stage, indent=2) + '\n')
record = {'commands': commands, 'stage': stage,
          'metrics': {key: metrics[key] for key in ('instruction_count', 'code_byte_count',
                       'private_memory_bytes', 'local_memory_bytes', 'target_resources')},
          'native_sha256': hashlib.sha256((root / 'jpeg_reconstruct-checksum.hsaco').read_bytes()).hexdigest(),
          'sources': {name: hashlib.sha256((notes / name).read_bytes()).hexdigest() for name in
                      ('device_output_checksum.py', 'device_reconstruct_checksum.cxx',
                       'device_checksum_pipeline.cxx', 'device_entropy_cursor.h', 'sequential.py')}}
(notes / 'device-output-checksum.json').write_text(json.dumps(record, indent=2) + '\n')
print('Checksum diagnostic ready', flush=True)
