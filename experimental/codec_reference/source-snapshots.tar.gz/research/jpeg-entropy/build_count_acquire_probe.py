"""Restore a bounded source overlay after capturing one Fabric-built probe."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

notes = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--config', choices=('asan', 'opt'), default='opt')
arguments = parser.parse_args()
suffix = '-asan' if arguments.config == 'asan' else ''
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
build = Path('loom/src/loom/tooling/target/amdgpu/serve/BUILD.bazel')
source = build.parent / 'codec_command_probe.cc'
runtime = Path('runtime/src/iree/hal/drivers/amdgpu/aql_block_processor.c')
runtime_profile = Path('runtime/src/iree/hal/drivers/amdgpu/aql_block_processor_profile.c')
assert not source.exists()
assert subprocess.check_output(['git', 'status', '--porcelain'], text=True) == ''
build_original = build.read_bytes()
runtime_original = runtime.read_bytes()
profile_original = runtime_profile.read_bytes()
target = b'''
loom_cc_binary(
    name = "codec_command_probe",
    testonly = True,
    srcs = ["codec_command_probe.cc"],
    deps = [
        ":test_compiler",
        ":test_device",
        "//loom/binding/c:loomc",
        "//loom/src/loom/serve/runtime/device",
        "//loom/src/loom/serve/runtime/execution",
        "//loom/src/loom/serve/runtime/host",
        "//loom/src/loom/serve/runtime/program:jit",
        "//loom/src/loom/serve/testing:compiler",
        "//loom/src/loom/serve/testing:device",
        "//runtime/src/iree/base",
        "//runtime/src/iree/base/tooling:flags",
        "//runtime/src/iree/hal",
        "//runtime/src/iree/hal/utils:statistics_sink",
        "//runtime/src/iree/testing:gtest",
        "//runtime/src/iree/testing:gtest_main",
    ],
)
'''
build_overlay = build_original + target
needle = b'processor, dispatch_packet_index, IREE_HSA_FENCE_SCOPE_NONE,\n          dispatch_packet_flags);'
assert runtime_original.count(needle) == 1
runtime_overlay = runtime_original.replace(needle, b'processor, dispatch_packet_index, IREE_HSA_FENCE_SCOPE_AGENT,\n          dispatch_packet_flags);')
assert profile_original.count(needle) == 1
profile_overlay = profile_original.replace(needle, b'processor, dispatch_packet_index, IREE_HSA_FENCE_SCOPE_AGENT,\n          dispatch_packet_flags);')
probe = (notes / 'command_probe.cc').read_bytes()
record = {'objective': 'Test indirect target packet AGENT acquire as the only runtime change.',
          'runtime_original_sha256': hashlib.sha256(runtime_original).hexdigest(),
          'runtime_candidate_sha256': hashlib.sha256(runtime_overlay).hexdigest(),
          'profile_original_sha256': hashlib.sha256(profile_original).hexdigest(),
          'profile_candidate_sha256': hashlib.sha256(profile_overlay).hexdigest(),
          'source_sha256': hashlib.sha256(probe).hexdigest(), 'restored': False}
record['build_config'] = arguments.config
record_path = notes / ('count-acquire-overlay' + suffix + '.json')
record_path.write_text(json.dumps(record, indent=2) + '\n')
build.write_bytes(build_overlay)
runtime.write_bytes(runtime_overlay)
runtime_profile.write_bytes(profile_overlay)
source.write_bytes(probe)
try:
    result = subprocess.run(['bureau-bazel', 'build', '--tag=codec-jpeg-acquire-probe' + suffix,
                             '--config=' + arguments.config,
                             '//loom/src/loom/tooling/target/amdgpu/serve:codec_command_probe'])
    record['build_returncode'] = result.returncode
finally:
    assert build.read_bytes() == build_overlay
    assert runtime.read_bytes() == runtime_overlay
    assert runtime_profile.read_bytes() == profile_overlay
    assert source.read_bytes() == probe
    build.write_bytes(build_original)
    runtime.write_bytes(runtime_original)
    runtime_profile.write_bytes(profile_original)
    source.unlink()
    record['restored'] = True
    record_path.write_text(json.dumps(record, indent=2) + '\n')
assert result.returncode == 0
