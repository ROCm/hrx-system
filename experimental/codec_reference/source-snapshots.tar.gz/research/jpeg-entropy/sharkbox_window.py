"""Bounded native worker drain, foreground benchmark lease, and exact resume."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import statistics
import subprocess
import time


ROOT = Path('/tmp/codec-gfx1100-oc5uvhRq')
OWNER = 'codec-gfx1100-20261018'
GPU_UUID = 'GPU-4939e1d93d24ff77'
BROKER = '/home/ben/.dotfiles/bin/benchmark-lock'


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def control(worker, operation, timeout=45):
    command = [worker['binary'], 'control', '--socket',
               '/proc/self/cwd/control.sock', '--timeout', str(timeout) + 's',
               operation]
    if operation != 'status':
        command.append(OWNER)
    result = subprocess.run(command, cwd=worker['storage'], capture_output=True,
                            text=True, timeout=timeout + 5)
    row = {'operation': operation, 'command': command,
           'returncode': result.returncode, 'stdout': result.stdout,
           'stderr': result.stderr}
    print(json.dumps({'control': worker['kind'], **row}), flush=True)
    if result.returncode:
        raise RuntimeError(row)
    return json.loads(result.stdout)


def workers():
    selected = {}
    for proc in Path('/proc').iterdir():
        if not proc.name.isdecimal():
            continue
        try:
            # Reading an unrelated process's argv may fault its inaccessible
            # userspace pages. Identify native workers before touching argv.
            if (proc / 'comm').read_text().strip() != 'bureau-build-ce':
                continue
            args = (proc / 'cmdline').read_bytes().split(b'\0')
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
        if not args or args[0] != b'/run/bureau/package/fabric-cell-runtime/bin/bureau-build-cell':
            continue
        args = [value.decode() for value in args if value]
        for kind, volume in (('gpu', 'fabric-sharkbox-gpu-kfd'), ('cpu', 'fabric-pilot-cache')):
            storage = '/run/bureau/volume/' + volume + '/storage'
            if '--storage=' + storage in args:
                assert kind not in selected
                selected[kind] = {'kind': kind, 'pid': int(proc.name),
                                  'binary': str(proc / 'root' / args[0][1:]),
                                  'storage': str(proc / 'root' / storage[1:])}
    assert set(selected) == {'cpu', 'gpu'}, selected
    # Stop new cell assignments before draining its independent GPU worker.
    return [selected['cpu'], selected['gpu']]


def state():
    gpus = {}
    for bdf in ('0000:c3:00.0', '0000:e3:00.0'):
        root = Path('/sys/bus/pci/devices') / bdf
        gpus[bdf] = {name: (root / name).read_text().strip() for name in
                     ('unique_id', 'gpu_busy_percent', 'mem_info_vram_used',
                      'power_dpm_force_performance_level')}
    owners = []
    for path in Path('/sys/class/kfd/kfd/proc').iterdir():
        process = Path('/proc') / path.name
        if process.exists():
            owners.append({'pid': int(path.name),
                           'comm': (process / 'comm').read_text().strip()})
    return {'gpus': gpus, 'live_kfd': owners,
            'governor': Path('/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor').read_text().strip(),
            'loadavg': Path('/proc/loadavg').read_text().strip(),
            'cpu_stat': Path('/proc/stat').read_text(),
            'personality': Path('/proc/self/personality').read_text().strip()}


def validate_files():
    for name in ('manifest.json', 'primary-manifest.json'):
        manifest = json.loads((ROOT / name).read_text())
        for relative, row in manifest['files'].items():
            path = ROOT / relative
            assert path.stat().st_size == row['bytes'], relative
            assert digest(path) == row['sha256'], relative
    manifest = json.loads((ROOT / 'primary-manifest.json').read_text())
    assert manifest['logical_device_binding_bytes'] < 512 * 1024 * 1024
    return manifest


def execute_check():
    assert os.environ['BENCHMARK_LOCK_LEASE_ID']
    record = {'scope': 'Full sixteen-image correctness, host ASAN and device access checks; no timing qualification.',
              'before': state()}
    assert not record['before']['live_kfd']
    command = [str(ROOT / 'codec_command_probe_asan'),
               '--jpeg_fixture=' + str(ROOT / 'primary'), '--jpeg_access=true',
               '--amdgpu_asan=true', '--amdgpu_asan_report_policy=fail-device',
               '--gtest_filter=JpegCommandTest.CompressedToRgb']
    result = subprocess.run(command, capture_output=True, text=True, timeout=100)
    (ROOT / 'check-output.log').write_text(result.stdout + result.stderr)
    records = [json.loads(line) for line in result.stdout.splitlines() if line.startswith('{')]
    record.update(command=command, returncode=result.returncode,
                  records=records, after=state(), log_sha256=digest(ROOT / 'check-output.log'))
    save(ROOT / 'check-result.json', record)
    print(result.stdout + result.stderr, flush=True)
    assert result.returncode == 0
    assert len([row for row in records if row.get('phase') == 'exact']) == 26
    assert not record['after']['live_kfd']


def execute_measure():
    assert os.environ['BENCHMARK_LOCK_LEASE_ID']
    assert not any(name.startswith('JSIMD_') for name in os.environ)
    qualification = json.loads((ROOT / 'check-result.json').read_text())
    assert qualification['returncode'] == 0
    assert len([row for row in qualification['records'] if row.get('phase') == 'exact']) == 26
    manifest = json.loads((ROOT / 'primary-manifest.json').read_text())
    images = [ROOT / 'images' / row['name'] for row in manifest['fixture']['images'][:4]]
    expected_rgb_bytes = 32 * sum(row['header'][12] * row['header'][13] * 3
                                  for row in manifest['fixture']['images'][:4])
    before = state()
    assert not before['live_kfd']
    assert before['governor'] == 'performance'
    assert before['gpus']['0000:c3:00.0']['power_dpm_force_performance_level'] == 'high'
    assert int(before['personality'], 16) & 0x40000
    record = {'before': before, 'routes': {}, 'rows': [],
              'scope': {'images_per_completion': 128, 'gpu_images_per_command': 16,
                        'gpu_commands_per_completion': 8, 'warmups': 2, 'samples': 9,
                        'gpu_logical_binding_bytes': manifest['logical_device_binding_bytes'],
                        'cpu_rgb_bytes_per_completion': expected_rgb_bytes,
                        'cpu': '128 queued jobs through one completion; codec creation, header, decode, finish, destruction and internal allocations timed. Disjoint preallocated RGB outputs.',
                        'gpu': 'Eight serial sixteen-image commands through one completion, reusing sixteen output spans; compressed bytes resident. Header, JIT, allocation, upload and verification download excluded.',
                        'numerics': 'Float32 GPU reconstruction independently checked; ISLOW and IFAST retain their separately measured numerical behavior. No general image/model tolerance selected.',
                        'isolation': 'Native cell and independent GPU worker held at zero active work, foreground benchmark broker lease, selected spare GPU UUID; no service restart.'}}
    output = ROOT / 'measure-result.json'
    save(output, record)
    for policy, symbol in (('islow', 'jsimd_idct_islow_avx2'), ('ifast', 'jsimd_idct_ifast_sse2')):
        binary = ROOT / ('jpeg_pipeline_' + policy)
        command = ['gdb', '--nx', '-q', '-batch', '-ex', 'set pagination off',
                   '-ex', 'set confirm off', '-ex', 'break ' + symbol,
                   '-ex', 'run qualify ' + str(images[0]), '-ex', 'bt 3',
                   '-ex', 'x/12i $pc', '-ex', 'quit', str(binary)]
        result = subprocess.run(command, capture_output=True, text=True, timeout=20)
        assert result.returncode == 0 and 'Breakpoint 1,' in result.stdout and symbol in result.stdout, result.stdout + result.stderr
        assembly = subprocess.check_output(['objdump', '-d', '--disassemble=' + symbol, str(binary)], text=True)
        native_path = ROOT / (policy + '-idct.native.s')
        native_path.write_text(assembly)
        record['routes'][policy] = {'symbol': symbol, 'command': command,
                                    'output': result.stdout + result.stderr,
                                    'native_sha256': digest(native_path)}
        save(output, record)
    sequence = [('gpu', 0), ('ifast', 16), ('islow', 16),
                ('ifast', 32), ('islow', 32), ('gpu', 0),
                ('ifast', 64), ('islow', 64), ('ifast', 96),
                ('islow', 96), ('gpu', 0)]
    for ordinal, (policy, count) in enumerate(sequence):
        if policy == 'gpu':
            command = [str(ROOT / 'codec_command_probe_opt'),
                       '--jpeg_fixture=' + str(ROOT / 'primary'),
                       '--gtest_filter=JpegCommandTest.CompressedToRgb', '--jpeg_benchmark=true']
        else:
            command = ['taskset', '-c', '0-' + str(count - 1),
                       str(ROOT / ('jpeg_pipeline_' + policy)), 'bench',
                       '128', str(count), '9', *(str(image) for image in images)]
        start = time.monotonic()
        result = subprocess.run(command, capture_output=True, text=True, timeout=55)
        path = ROOT / ('measure-' + str(ordinal) + '-' + policy + '.log')
        path.write_text(result.stdout + result.stderr)
        assert result.returncode == 0, result.stdout + result.stderr
        rows = [json.loads(line) for line in result.stdout.splitlines() if line.startswith('{')]
        if policy == 'gpu':
            measurement, = [row for row in rows if row.get('phase') == 'measurement']
            assert measurement['operations_per_submission'] == 8
            assert len([row for row in rows if row.get('phase') == 'exact']) == 52
            samples = measurement['batch_ns']
        else:
            row, = rows
            assert row['workers'] == count and row['batch'] == 128
            assert row['full_rgb_and_guards'] and row['rgb_bytes'] == expected_rgb_bytes
            samples = row['batch_ns']
        assert len(samples) == 9
        row = {'policy': policy, 'workers': count, 'command': command,
               'median_128_image_ns': statistics.median(samples), 'result': rows,
               'process_wall_seconds': time.monotonic() - start,
               'children_peak_rss_kib': resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
               'log_sha256': digest(path), 'state_after': state()}
        assert not row['state_after']['live_kfd']
        record['rows'].append(row)
        save(output, record)
        print(json.dumps({k: row[k] for k in ('policy', 'workers', 'median_128_image_ns', 'process_wall_seconds')}), flush=True)
    record['after'] = state()
    save(output, record)


def execute_profile():
    assert os.environ['BENCHMARK_LOCK_LEASE_ID']
    before = state()
    assert not before['live_kfd']
    command = [str(ROOT / 'codec_command_probe_opt'),
               '--jpeg_fixture=' + str(ROOT / 'primary'),
               '--gtest_filter=JpegCommandTest.CompressedToRgb', '--jpeg_profile=true']
    result = subprocess.run(command, capture_output=True, text=True, timeout=55)
    path = ROOT / 'profile-output.log'
    path.write_text(result.stdout + result.stderr)
    records = [json.loads(line) for line in result.stdout.splitlines() if line.startswith('{')]
    record = {'scope': 'Separate GPU timestamp attribution over eight sixteen-image commands; not the unprofiled latency result.',
              'command': command, 'returncode': result.returncode, 'before': before,
              'after': state(), 'records': records, 'log_sha256': digest(path)}
    save(ROOT / 'profile-result.json', record)
    assert result.returncode == 0, result.stdout + result.stderr
    assert len([row for row in records if row.get('phase') == 'exact']) == 52
    profiles = [row for row in records if row.get('phase') == 'profile']
    assert profiles and not record['after']['live_kfd']
    for row in profiles:
        print(json.dumps(row), flush=True)


def window(phase):
    validate_files()
    selected = workers()
    record = {'owner': OWNER, 'phase': phase, 'workers': selected,
              'before': state(), 'controls': [], 'attempted_holds': []}
    path = ROOT / (phase + '-window.json')
    save(path, record)
    start = time.monotonic()
    try:
        for worker in selected:
            observed = control(worker, 'status')
            assert observed['State'] == 'accepting' and not observed['Owner'], observed
        for worker in selected:
            record['attempted_holds'].append(worker['kind'])
            save(path, record)
            observed = control(worker, 'hold')
            record['controls'].append({'kind': worker['kind'], 'hold': observed})
            save(path, record)
            assert observed['Owner'] == OWNER and observed['Active'] == 0, observed
        for worker in selected:
            observed = control(worker, 'verify')
            assert observed['Owner'] == OWNER and observed['Active'] == 0, observed
        command = [BROKER, '--label=codec-gfx1100-' + phase, '--',
                   'env', 'LD_LIBRARY_PATH=' + str(ROOT / 'lib'),
                   'ROCR_VISIBLE_DEVICES=' + GPU_UUID,
                   'python3', '-B', str(Path(__file__).resolve()), '--execute', phase]
        result = subprocess.run(command, timeout=120 if phase == 'check' else 230)
        record['returncode'] = result.returncode
        save(path, record)
        assert result.returncode == 0
    finally:
        failures = []
        for worker in reversed(selected):
            if worker['kind'] not in record['attempted_holds']:
                continue
            try:
                observed = control(worker, 'status')
                if observed['Owner'] == OWNER:
                    record['controls'].append({'kind': worker['kind'], 'resume': control(worker, 'resume')})
                elif observed['Owner']:
                    raise RuntimeError(observed)
                observed = control(worker, 'status')
                assert observed['State'] == 'accepting' and not observed['Owner'], observed
            except Exception as error:
                failures.append(repr(error))
        record['resume_failures'] = failures
        record['window_wall_seconds'] = time.monotonic() - start
        result = subprocess.run([BROKER, '--status'], capture_output=True, text=True)
        record['broker_status_after'] = result.stdout + result.stderr
        save(path, record)
        print(json.dumps({'window': phase, 'seconds': record['window_wall_seconds'],
                          'resume_failures': failures, 'broker': record['broker_status_after']}), flush=True)
        if failures:
            raise RuntimeError(failures)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--execute', choices=('check', 'measure', 'profile'))
    parser.add_argument('--window', choices=('check', 'measure', 'profile'))
    arguments = parser.parse_args()
    assert bool(arguments.execute) != bool(arguments.window)
    if arguments.execute:
        if arguments.execute == 'check':
            execute_check()
        elif arguments.execute == 'measure':
            execute_measure()
        else:
            execute_profile()
    else:
        window(arguments.window)
