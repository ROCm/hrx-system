"""Bound the first failing connected dispatch using exact intermediate files."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
count = int(sys.argv[1])
assert count in (4, 6, 9, 10)
original = root / 'connected-batch16'
directory = root / ('connected-through-' + str(count))
directory.mkdir(exist_ok=True)
source = (original / 'summary.loom').read_text()
body = source.split('  command.serial {', 1)[1].split('\n  }', 1)[0]
calls = body.strip().splitlines()[:count]
used = set(re.findall(r'%(\w+)', '\n'.join(calls))) - {'schedule_offset'}
bindings = [line.split() for line in (original / 'bindings.txt').read_text().splitlines() if line.split()[0] in used]
assert {row[0] for row in bindings} == used
declaration = ', '.join('%' + row[0] + ': buffer' for row in bindings)
text = source.split('func.def @fixture_values', 1)[0] + '\ncommand.program.def public @jpeg_decode() launch(' + declaration + ') {\n  %schedule_offset = index.constant 0 : offset\n  command.serial {\n    ' + '\n'.join(calls) + '\n  }\n  command.return\n}\n'
(directory / 'summary.loom').write_text(text)
(directory / 'config.json').write_bytes((original / 'config.json').read_bytes())
files = {}
for row in bindings:
    path = (original / row[4]).resolve()
    row[4] = os.path.relpath(path, directory)
    files[row[4]] = hashlib.sha256(path.read_bytes()).hexdigest()
(directory / 'bindings.txt').write_text('\n'.join(' '.join(row) for row in bindings) + '\n')
link = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['codec-jpeg-rebased-tools']) / 'loom/src/loom/tools/loom-link/loom-link'
subprocess.run([str(link), str(directory / 'summary.loom'), str(root / 'entropy-connected.loombc'),
               '--to=bc', '--output=' + str(directory / 'summary.loombc')], check=True)
files.update({path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in directory.iterdir() if path.name != 'stage.json'})
stage = {'files': files, 'scope': f'Only first{count} authored connected stages, exact intermediate boundaries; no performance result.'}
(directory / 'stage.json').write_text(json.dumps(stage, indent=2) + '\n')
print(directory, len(bindings), 'bindings', flush=True)
