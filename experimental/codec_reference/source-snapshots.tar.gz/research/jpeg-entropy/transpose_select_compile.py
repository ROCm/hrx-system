import hashlib,json,os,subprocess
from pathlib import Path
p=Path(__file__).resolve().parent
root=Path(json.loads((p/'device-active.json').read_text())['directory'])
tags=json.loads(os.environ['BUREAU_TAG_ROOTS'])
base=Path(tags['codec-jpeg-rebased-tools'])/'loom/src/loom/tools'
native=Path(tags['codec-jpeg-unsigned-opt'])/'loom/src/loom/tools'
source=p/'transpose_select_repro.cxx'
subprocess.run([str(base/'loom-import-cxx/loom-import-cxx'),str(source),'--output='+str(root/'transpose-select.loom')],check=True)
rows=[]
for name in ('indexed_select','masked_select'):
 report=root/(name+'-report.json')
 command=[str(native/'loom-compile/loom-compile'),str(root/'transpose-select.loom'),'--root='+name,'--target=amdgpu:gfx1151','--output='+str(root/(name+'.hsaco')),'--compile-report=details','--compile-report-output='+str(report)]
 subprocess.run(command,check=True)
 d=json.loads(report.read_text())['entries']['rows'][0]
 rows.append({'kernel':name,'command':command,'metrics':{k:d[k] for k in ('instruction_count','code_byte_count','private_memory_bytes','local_memory_bytes','target_resources')},'native_sha256':hashlib.sha256((root/(name+'.hsaco')).read_bytes()).hexdigest()})
result={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'rows':rows}
(p/'transpose-select-repro.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
