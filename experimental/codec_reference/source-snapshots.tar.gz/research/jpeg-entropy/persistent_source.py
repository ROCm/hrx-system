"""Derive a bounded persistent consumer while retaining the qualified math.

Generated IR/native objects live in the active /tmp directory, capped at 64 MiB
for this compiler/progress experiment. Existing corpus arrays are reused.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re

NOTES = Path(__file__).resolve().parent
ROOT = Path(json.loads((NOTES / 'device-active.json').read_text())['directory'])
BASE = ROOT / 'mixed-current'
parser = argparse.ArgumentParser()
parser.add_argument('--connected', action='store_true')
arguments = parser.parse_args()
OUTPUT = ROOT / 'persistent'
if arguments.connected:
    OUTPUT /= 'connected'
OUTPUT.mkdir(exist_ok=True)
source = (BASE / 'mixed_pipeline.cxx').read_text()
assert hashlib.sha256(source.encode()).hexdigest() == json.loads((NOTES / 'persistent-budget.json').read_text())['current_source_sha256']['mixed_pipeline.cxx']

def function(name):
    begin = source.index('void ' + name + '(')
    opening = source.index('{', begin)
    depth = 1
    end = opening + 1
    while depth:
        depth += (source[end] == '{') - (source[end] == '}')
        end += 1
    return source[begin:end]

original = function('jpeg_reconstruct')
body = original[original.index('    Cursor cursor = {};'):original.index('    if (present) {\n      if (interval ==')]
body = body.replace('intervals + (first_interval + interval) * stride', 'cursors + task * 8')
body = body.replace('descriptor[7] + shape[0] + (row * shape[1] + column) * 16',
                    'stream->pixel_offset + shape[0] + (((mcu_row % stream_rows) * shape[4] + shape[6]) * shape[1] + column) * 16')
marker = '      active = present && cursor.blocks < total_blocks && cursor.position < end && cursor.error == 0;'
assert body.count(marker) == 1
body = body.replace(marker, '''      if (active && cursor.error == 0) ++produced;
      active = present && cursor.blocks < total_blocks && cursor.position < end && cursor.error == 0 &&
          cursor.blocks / layout.count / image.mcu_columns == selected_row;''')
body = body.replace('    while (loom::kernel::subgroup::vote::any(active))',
                    '    active = active && cursor.blocks / layout.count / image.mcu_columns == selected_row;\n    while (loom::kernel::subgroup::vote::any(active))')
decode = '''
static LOOM_FORCE_INLINE unsigned stream_decode(const unsigned* entropy,
    const unsigned* segments, const unsigned* all_tables, const unsigned* blocks,
    const unsigned* intervals, const unsigned* all_geometry,
    const unsigned* all_quantization, const unsigned* zigzag, unsigned* pixels,
    const Image* images, unsigned segment, unsigned selected_row, unsigned task,
    short* coefficients, unsigned* cursors, Stream* streams, unsigned* heads,
    unsigned* pending, unsigned* links) {
  unsigned lane = loom::kernel::workitem::id.x;
  unsigned threads = 32;
  unsigned coefficient_stride = 32;
  Stream* stream = streams + segment;
  Image image = images[segment];
  BlockLayout layout = reinterpret_cast<const BlockLayout*>(blocks)[segment];
  const unsigned* tables = all_tables + image.table_word_offset;
  const unsigned* geometry = all_geometry + image.geometry_word_offset;
  const unsigned* quantization = all_quantization + image.quantization_word_offset;
  const unsigned* descriptor = segments + segment * 8;
  unsigned total_blocks = descriptor[4];
  unsigned first_interval = descriptor[2] * (output_partitions + 1) + segment;
  unsigned terminal = first_interval + descriptor[3] * (output_partitions + 1);
  unsigned certified_end = intervals[terminal * 8];
  unsigned certified_blocks = intervals[terminal * 8 + 2];
  const unsigned* words = entropy + descriptor[0];
  unsigned bit_limit = descriptor[1];
  bool present = task != absent;
  unsigned produced = 0;
''' + body + '''
  if (present) {
    bool continued = cursor.blocks < total_blocks && cursor.position < end && cursor.error == 0;
    if (continued) {
      unsigned* entry = cursors + task * 8;
      entry[0] = cursor.position;
      entry[2] = cursor.blocks;
      entry[3] = cursor.block_index * 64 + cursor.coefficient;
      for (unsigned component = 0; component < 3; ++component) entry[4 + component] = cursor.predictors[component];
      unsigned row = cursor.blocks / layout.count / image.mcu_columns;
      add(row_address(pending, stream->row_offset + row), 1);
      enqueue(row_address(heads, stream->row_offset + row), links, task);
    } else {
      if (task == terminal && cursor.error == 0) {
        if (cursor.blocks != total_blocks || cursor.coefficient != 0) {
          cursor.error = 3;
        } else {
          unsigned padding = bit_limit - cursor.position;
          if (padding > 7) {
            cursor.error = 3;
          } else if (padding != 0) {
            Read input = peek(words, cursor);
            if ((input.value >> (32 - padding)) != ((1u << padding) - 1)) cursor.error = 4;
          }
        }
      }
      if (cursor.error != 0) compare(&stream->error, 0, cursor.error);
      add(&stream->interval_done, 1);
    }
  }
  return produced;
}
'''

color = source[source.index('struct ColorGeometry'):source.index('static loom::kernel::configuration configure_color')]
color = color.replace('color_', 'stream_color_').replace('ColorGeometry', 'StreamColorGeometry')
color = color.replace('  unsigned height;\n};', '  unsigned height;\n  // Encoded luma rows per interleaved MCU.\n  unsigned mcu_height;\n};')
color = color.replace('StreamColorGeometry dimensions{image.width, image.height};',
    'StreamColorGeometry dimensions{image.width, image.height, image.color_kind == 5 || image.color_kind == 6 || image.color_kind == 8 ? 16u : 8u};')
color = color.replace('unsigned row, unsigned width) {', 'unsigned row, unsigned width, unsigned vertical) {\n  row %= stream_rows * (dimensions.mcu_height / vertical);')
color = color.replace('column, row, width)', 'column, row, width, vertical)')
color = color.replace('x, y, dimensions.width)', 'x, y, dimensions.width, vertical)')
color = color.replace('dimensions, 16, vertical)', 'dimensions, 8, vertical)')
color = color.replace('const unsigned* tile, unsigned* cache)', 'unsigned first_x, unsigned first_y, unsigned* cache)')
color = color.replace('  unsigned first_x = tile[1];\n  unsigned first_y = tile[2];\n', '')
color = color.replace('cache + 640', 'cache + 512')
color = color.replace('loom::assume(position < cache_count);',
    'loom::assume(position < cache_count);\n      loom::assume(position < 512u);')
color = color.replace('loom::assume(neighbor < cache_count);',
    'loom::assume(neighbor < cache_count);\n        loom::assume(neighbor < 512u);')
color = color.replace('  loom::kernel::workgroup::barrier();', '''  loom::kernel::barrier<loom::memory_space::workgroup,
      loom::atomic::scope::subgroup, loom::atomic::ordering::acq_rel>();''')
color = color.replace('  unsigned x = first_x + (lane & 15u) * 4;', '  for (unsigned item = lane; item < 128; item += 32) {\n  unsigned x = first_x + (item & 15u) * 4;')
color = color.replace('first_y + (lane >> 4)', 'first_y + (item >> 4)')
color = color.replace('  if (x >= dimensions.width || y >= dimensions.height) return;', '  if (x < dimensions.width && y < dimensions.height) {')
color = color.rstrip()[:-1] + '}\n}\n}\n'
color += '''
static LOOM_FORCE_INLINE void stream_color(const unsigned char* components,
    unsigned char* rgb, Image image, unsigned first_x, unsigned first_y, unsigned* cache) {
'''
for kind, parameters in enumerate(((1,1,1,1,1,1,1),(2,1,1,1,1,1,1),(3,1,1,1,1,1,1),
                                    (3,1,1,2,1,2,1),(3,1,1,2,2,2,2),(3,1,1,1,2,1,2),
                                    (3,1,1,4,1,4,1),(3,1,1,4,2,4,2)), 1):
    color += f'  if (image.color_kind == {kind}) stream_color_run<{", ".join(map(str,parameters))}>(components, rgb, image, first_x, first_y, cache);\n'
color += '}\n'

native = (NOTES / 'persistent_native.cxx').read_text()
marker = 'static loom::kernel::configuration configure_stream_workers()'
native = native.replace(marker, decode + '\n' + color + '\n' + marker)
inputs = ['entropy', 'segments', 'tables', 'blocks', 'intervals', 'geometry',
          'quantization', 'zigzag', 'images', 'plans']
outputs = ['pixels', 'rgb', 'streams', 'heads', 'pending', 'decoded',
           'color_claimed', 'color_done', 'links', 'cursors']
front = ['jpeg_classify_bytes', 'jpeg_prefix_bytes', 'jpeg_plan_jobs',
         'jpeg_compact_bytes', 'jpeg_speculate', 'jpeg_bridge', 'jpeg_index',
         'jpeg_certify', 'jpeg_intervals']
if arguments.connected:
    inputs = ['tables', 'blocks', 'geometry', 'quantization', 'zigzag',
              'images', 'plans', 'compressed']
    outputs = ['entropy', 'segments', 'intervals'] + outputs + [
        'records', 'prefixes', 'errors', 'schedule', 'jobs', 'expected',
        'points', 'bridges', 'suffixes', 'ranges']
    native = source + '\n' + native
    source = ''
directory = inputs + outputs
entries = []
def wrap(match):
    configure, name, signature = match.groups()
    if not name.startswith('jpeg_stream') and name not in front:
        return match.group(0)
    arguments = []
    for parameter in signature.split(','):
        spelling, variable = parameter.strip().rsplit('*', 1)
        variable = variable.strip()
        variable = {'headers': 'images', 'summaries': 'expected'}.get(variable, variable)
        owner = 'input' if variable in inputs else 'output'
        arguments.append(f'reinterpret_cast<{spelling.strip()}*>({owner} + stream_offset(input, {directory.index(variable)}))')
    entries.append((configure, name, arguments))
    return f'static LOOM_FORCE_INLINE void {name}_body({signature}) {{'
native = re.sub(r'\[\[loom::kernel\((\w+)\)\]\]\s*void (jpeg_\w+)\(([^)]*)\)\s*\{', wrap, native)
assert len(entries) == (11 if arguments.connected else 2)
if arguments.connected:
    for configure in ('configure_chunks', 'configure_bridges'):
        signature = f'static loom::kernel::configuration {configure}(const unsigned* schedule) {{'
        assert native.count(signature) == 1
        native = native.replace(signature,
            f'static loom::kernel::configuration {configure}(const unsigned* input, const unsigned* output) {{\n'
            f'  const unsigned* schedule = output + input[{directory.index("schedule")}] / 4;')
native += '''
static LOOM_FORCE_INLINE unsigned stream_offset(const unsigned* input, unsigned index) {
  unsigned offset = loom::kernel::subgroup::broadcast_first(input[index]);
  // The bounded probe's complete roots are checked below 1 GiB when packed.
  loom::assume(offset < 1073741824u);
  loom::assume(loom::predicate::multiple_of(offset, 16u));
  return offset / 4;
}
'''
for configure, name, entry_arguments in entries:
    native += f'\n[[loom::kernel({configure})]]\nvoid {name}(const unsigned* input, unsigned* output) {{\n  {name}_body({", ".join(entry_arguments)});\n}}\n'
(OUTPUT / 'directory.json').write_text(json.dumps({'inputs': inputs, 'outputs': outputs}, indent=2) + '\n')
if len(entries) == 11:
    declarations = []
    launches = []
    configurations = {name: configure for configure, name, _ in entries}
    for name in front + ['jpeg_stream_init', 'jpeg_stream']:
        dynamic = configurations[name] in ('configure_chunks', 'configure_bridges')
        configuration = '%launch_input: buffer, %input_offset: offset, %launch_output: buffer, %output_offset: offset' if dynamic else ''
        declarations.append(f'kernel.decl @{name}({configuration}) launch(%input: buffer, %output: buffer)')
        values = '[%input, %zero, %output, %zero]' if dynamic else ''
        types = '[buffer, offset, buffer, offset]' if dynamic else ''
        launches.append(f'    kernel.launch @{name}{values}(%input, %output) : {types}(buffer, buffer)')
    program = '\n'.join(declarations) + '''

command.program.def public @jpeg_stream_decode() launch(%input: buffer, %output: buffer) {
  %zero = index.constant 0 : offset
  command.serial {
''' + '\n'.join(launches) + '''
  }
  command.return
}
'''
    (OUTPUT / 'command.loom').write_text(program)
(OUTPUT / 'persistent.cxx').write_text(source + '\n' + native)
for name in ('mixed_cursor.h', 'mixed_image.h'):
    (OUTPUT / name).write_bytes((BASE / name).read_bytes())
configuration = json.loads((BASE / 'config.json').read_text())
configuration['stream'] = {'rows': 8, 'workers': 128}
(OUTPUT / 'config.json').write_text(json.dumps(configuration, indent=2) + '\n')
print(json.dumps({'source_bytes': (OUTPUT / 'persistent.cxx').stat().st_size,
                  'source_sha256': hashlib.sha256((OUTPUT / 'persistent.cxx').read_bytes()).hexdigest()}))
