"""Exercise original compressed input through the real trained HTTP service."""
import argparse
import base64
import hashlib
import http.client
import json
import os
from pathlib import Path
import signal
import subprocess
import time


parser = argparse.ArgumentParser()
parser.add_argument("directory", type=Path)
parser.add_argument("--mode", choices=("control", "candidate"), required=True)
arguments = parser.parse_args()
directory = arguments.directory.resolve()
mode = arguments.mode
manifest = json.loads((directory / "stage-manifest.json").read_text())
for name, expected in manifest["files"].items():
    with (directory / name).open("rb") as stream:
        assert hashlib.file_digest(stream, "sha256").hexdigest() == expected, name

port = 18185
prompt = "Describe the vehicle in the foreground and any readable text on it. Answer in one short sentence."
command = [str(directory / "loom-serve"), "--device=amdgpu", "--workers=16",
           "--pool_backing=fixed", f"--listen=127.0.0.1:{port}", "--connections=16",
           "--request_body_bytes=67108864", "--heartbeat_ms=0",
           "--amdgpu_asan=true", "--amdgpu_asan_report_policy=fail-device",
           "--codec_jpeg=" + str(mode == "candidate").lower(),
           "--model=" + str(directory / ("control-deployment.json" if mode == "control" else "deployment.json"))]
receipt = {"mode": mode, "command": command,
           "manifest_sha256": hashlib.sha256((directory / "stage-manifest.json").read_bytes()).hexdigest(),
           "lease": os.environ.get("BENCHMARK_LOCK_LEASE_ID"), "cases": []}
result_path = directory / (mode + "-result.json")
log_path = directory / (mode + ".log")


def record():
    result_path.write_text(json.dumps(receipt, indent=2) + "\n")


def request(path, payload=None):
    connection = http.client.HTTPConnection("127.0.0.1", port)
    try:
        body = None if payload is None else json.dumps(payload, separators=(",", ":")).encode()
        connection.request("GET" if payload is None else "POST", path, body,
                           {"Content-Type": "application/json", "Connection": "close"})
        response = connection.getresponse()
        data = response.read()
        content_type = response.getheader("Content-Type")
        return {"http_status": response.status, "content_type": response.getheader("Content-Type"),
                "body": json.loads(data) if content_type and "application/json" in content_type
                else data.decode("utf-8")}
    finally:
        connection.close()


def payload(names, streaming=False):
    content = []
    for name in names:
        mime = "image/x-portable-arbitrarymap" if name.endswith(".pam") else "image/jpeg"
        encoded = base64.b64encode((directory / name).read_bytes()).decode("ascii")
        content.append({"type": "image_url", "image_url": {"url": f"data:{mime};base64,{encoded}"}})
    content.append({"type": "text", "text": prompt})
    return {"model": "codec-jpeg-publication", "temperature": 0,
            "max_tokens": 32 if len(names) > 1 else 64, "enable_thinking": False,
            "stream": streaming, "messages": [{"role": "user", "content": content}]}


def events():
    return [json.loads(line) for line in log_path.read_text().splitlines()
            if line.startswith('{"phase":"jpeg_http_')]


def normalized(response):
    body = response["body"]
    assert response["http_status"] == 200, response
    assert body["usage"]["prompt_tokens_details"]["cached_tokens"] == 0, body
    return {"choices": body["choices"], "usage": body["usage"]}


def check(name, names, expected, oracle=None):
    before = len(events())
    print(json.dumps({"case": name, "phase": "request", "mode": mode}), flush=True)
    response = request("/v1/chat/completions", payload(names, streaming=expected != 200))
    row = {"case": name, "inputs": names, "stream_requested": expected != 200,
           "response": response, "events": events()[before:]}
    receipt["cases"].append(row)
    record()
    print(json.dumps(row), flush=True)
    assert response["http_status"] == expected, row
    if expected == 400:
        assert "source rejected input (code 768)" in json.dumps(response["body"]), row
        assert any(event.get("status") == 3 for event in row["events"]), row
    elif oracle is not None:
        assert normalized(response) == oracle, row
    else:
        normalized(response)
    return response


with log_path.open("w") as log:
    server = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT)
    receipt["server_pid"] = server.pid
    previous = None
    try:
        while True:
            if server.poll() is not None:
                raise RuntimeError(f"server exited during registration: {server.returncode}")
            try:
                response = request("/v1/status")
            except ConnectionRefusedError:
                time.sleep(0.05)
                continue
            assert response["http_status"] == 200, response
            state = response["body"]["data"][0]["loom"]
            current = state.get("registration")
            if current != previous:
                print(json.dumps({"mode": mode, "registration": current}), flush=True)
                previous = current
            if state.get("error") or current == "failed":
                raise RuntimeError(f"model registration failed: {state}")
            if current == "ready":
                receipt["ready"] = response["body"]
                break
            time.sleep(0.05)
        if mode == "control":
            response = check("lossless-control", ["loom-float32.pam"], 200)
            receipt["oracle"] = normalized(response)
        else:
            control = json.loads((directory / "control-result.json").read_text())
            assert control["passed"]
            oracle = control["oracle"]
            check("original-jpeg", ["original.jpg"], 200, oracle)
            check("invalid-stream", ["empty-entropy.jpg"], 400)
            check("invalid-first-sibling", ["empty-entropy.jpg", "original.jpg"], 400)
            check("invalid-last-sibling", ["original.jpg", "empty-entropy.jpg"], 400)
            check("valid-after-rejections", ["original.jpg"], 200, oracle)
        receipt["final_status"] = request("/v1/status")["body"]
        receipt["passed"] = True
    except BaseException as error:
        receipt["error"] = repr(error)
        raise
    finally:
        if server.poll() is None:
            server.send_signal(signal.SIGINT)
        receipt["server_exit"] = server.wait()
        record()
if receipt["server_exit"] != 0:
    raise RuntimeError(f"server shutdown failed: {receipt['server_exit']}")
print(json.dumps({"mode": mode, "passed": True, "server_exit": receipt["server_exit"]}), flush=True)
