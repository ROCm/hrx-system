"""Compare compiler size and native resources at a pinned parent/candidate pair."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile

notes = Path(__file__).resolve().parent
roots = json.loads(os.environ['BUREAU_TAG_ROOTS'])
source = notes / 'buffer_descriptor_extents.loom'
result = {'baseline_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD^'], text=True).strip(),
          'candidate_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
          'build_configuration': '--config=opt',
          'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest()}
with tempfile.TemporaryDirectory(prefix='codec-buffer-extents-') as directory:
    for label in ('baseline', 'candidate'):
        compiler = Path(roots['codec-buffer-extent-' + label]) / 'loom/src/loom/tools/loom-compile/loom-compile'
        report_path = notes / ('buffer-extent-rebased-' + label + '-report.json')
        command = [str(compiler), str(source), '--root=@atomic_record_fields',
                   '--target=amdgpu:gfx1100', '--output=' + directory + '/' + label + '.hsaco',
                   '--compile-report=details', '--compile-report-output=' + str(report_path)]
        subprocess.run(command, check=True)
        report = json.loads(report_path.read_text())
        row = report['entries']['rows'][0]
        sections = {}
        for line in subprocess.check_output(['size', '-A', str(compiler)], text=True).splitlines():
            fields = line.split()
            if fields and fields[0] in ('.text', '.rodata', '.data', '.bss'):
                sections[fields[0]] = int(fields[1])
        result[label] = {
            'compiler_sha256': hashlib.sha256(compiler.read_bytes()).hexdigest(),
            'compiler_bytes': compiler.stat().st_size,
            'sections': sections,
            'kernel': {key: row[key] for key in ('instruction_count', 'code_byte_count',
                       'private_memory_bytes', 'local_memory_bytes', 'target_resources')},
        }
(notes / 'buffer-extent-rebased-cost.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
