"""Check independent bridge paths against certified states and full MCU output."""
import argparse
import hashlib
import json
from pathlib import Path

from bounded import State, Summary
from device_fixture import input_bytes, read_words
from mcu_output import emit_mcus
from parallel_bridges import construct
from sequential import decode, parse

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
parser = argparse.ArgumentParser()
parser.add_argument('--fixtures', action='append', required=True)
parser.add_argument('--input', action='append')
parser.add_argument('--full-output', action='store_true')
parser.add_argument('--output', required=True)
arguments = parser.parse_args()
groups = {}
for filename in arguments.fixtures:
    fixture = root / filename
    for case in json.loads(fixture.read_text())['cases']:
        if arguments.input and case['name'] not in arguments.input:
            continue
        groups.setdefault(case['name'], {}).setdefault(case['chunk_bytes'], []).append((fixture.parent, case))
references = {}
for filename, keys in (('sequential-small.json', ('exact_public_oracle_cases', 'exact_periodic_cases')),
                       ('sequential-large.json', ('coefficient_signature_cases',))):
    record = json.loads((notes / filename).read_text())
    for key in keys:
        references.update({case['name']: case for case in record[key]})
result = {'state': 'Independent bounded bridge candidate; no GPU timing or production selection.',
          'sources': {name: hashlib.sha256((notes / name).read_bytes()).hexdigest() for name in
                      ('parallel_bridges.py', 'qualify_parallel_bridges.py', 'device_fixture.py',
                       'bounded.py', 'recover_prefix.py', 'sequential.py', 'mcu_output.py')},
          'full_output': arguments.full_output, 'cases': []}


def signed(value):
    return value if value < 0x80000000 else value - 0x100000000


for name, chunk_cases in groups.items():
    data = input_bytes(name)
    assert hashlib.sha256(data).hexdigest() == references[name]['input_sha256']
    frame = parse(data)
    planes = None
    if arguments.full_output:
        planes, unused = decode(frame)
        assert [hashlib.sha256(plane.tobytes()).hexdigest() for plane in planes] == references[name]['coefficient_planes_sha256']
    for chunk_bytes, cases in chunk_cases.items():
        coverage = [bytearray(len(plane) // 64) for plane in planes] if planes else None
        totals = {}
        segment_rows = []
        for source, case in cases:
            key = case['key']
            scan = frame.scans[case['scan']]
            components = len(frame.components)
            summary_stride = (5 + components + 3) & ~3
            checkpoint_stride = (3 + components + 3) & ~3
            words = read_words(source / (key + '-expected.npy'))
            canonical_source = root / ('anchor-large' if source.name == 'large' else 'anchor-small')
            descriptors = read_words(canonical_source / (key + '-segments.npy'))
            canonical_words = read_words(canonical_source / (key + '-checkpoints.npy'))
            for segment_index, segment in enumerate(scan.segments):
                descriptor = descriptors[segment_index * 8:(segment_index + 1) * 8]
                first_job, intervals = descriptor[2:4]
                summaries = []
                for index in range(first_job, first_job + intervals):
                    record = words[index * summary_stride:(index + 1) * summary_stride]
                    if record[0] == 0xffffffff:
                        summaries.append(None)
                    else:
                        blocks = record[1] // 64
                        first = State(record[0], blocks, record[1] & 63, (0,) * components)
                        last = State(record[2], blocks + record[4], record[3] & 63,
                                     tuple(signed(value) for value in record[5:5 + components]))
                        summaries.append(Summary(first, last))
                checkpoints, counts, transitions = construct(
                    segment, scan, components, summaries, chunk_bytes * 8, chunk_bytes * 8 * 4)
                canonical = {}
                for index in range(descriptor[5], descriptor[5] + intervals + 1):
                    record = canonical_words[index * checkpoint_stride:(index + 1) * checkpoint_stride]
                    canonical[record[0]] = State(record[0], record[1], record[2] & 63,
                                               tuple(signed(value) for value in record[3:3 + components]))
                for state in checkpoints:
                    assert canonical.get(state.position) == state, (name, chunk_bytes, segment_index, state, canonical.get(state.position))
                if planes is not None:
                    output = emit_mcus(frame, scan, segment, checkpoints, planes, coverage)
                    assert output['emitted_mcus'] == segment.mcu_count
                    counts.update(output)
                for field, value in counts.items():
                    if field.startswith('maximum_') or field == 'coefficient_buffer_bytes_per_worker':
                        totals[field] = max(totals.get(field, 0), value)
                    else:
                        totals[field] = totals.get(field, 0) + value
                segment_rows.append({'scan': case['scan'], 'segment': segment_index,
                                     'intervals': intervals, **counts})
        if coverage is not None:
            assert all(all(plane) for plane in coverage), (name, 'unowned real coefficient block')
        row = {'name': name, 'chunk_bytes': chunk_bytes, 'bridge_cap_bytes': chunk_bytes * 4,
               'input_sha256': references[name]['input_sha256'], 'all_checkpoints_equal': True,
               'full_mcu_output_equal': arguments.full_output, 'totals': totals, 'segments': segment_rows}
        result['cases'].append(row)
        (notes / arguments.output).write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps({key: row[key] for key in ('name', 'chunk_bytes', 'all_checkpoints_equal', 'full_mcu_output_equal')} | {'totals': totals}), flush=True)
    del frame, planes, data
