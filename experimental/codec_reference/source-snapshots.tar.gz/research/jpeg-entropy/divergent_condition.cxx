#include <loomcxx/kernel.h>

[[loom::kernel, loom::workgroup_count(1, 1, 1), loom::workgroup_size(32, 1, 1)]]
void divergent_condition(const unsigned* input, unsigned* output) {
  unsigned lane = loom::kernel::workitem::id.x;
  if (lane >= 2) return;
  unsigned position = input[lane * 4];
  unsigned limit = input[lane * 4 + 1];
  unsigned stop = input[lane * 4 + 2];
  unsigned error = input[lane * 4 + 3];
  while (position < limit && error == 0) {
    ++position;
    if (position == stop) error = 1;
  }
  output[lane * 3] = position;
  output[lane * 3 + 1] = error;
  output[lane * 3 + 2] = 0xffffffffu;
  if (error == 0) output[lane * 3 + 2] = position;
}
