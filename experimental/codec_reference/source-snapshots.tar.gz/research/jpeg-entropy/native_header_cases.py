"""Freeze independent header facts for native ASAN qualification."""
import hashlib
from itertools import product
import json
from pathlib import Path

from device_fixture import input_bytes, table_words as canonical_words
from sequential import decode, parse
from twolevel_fixtures import table_words as device_words

notes = Path(__file__).resolve().parent
metadata_by_header = {}
unique_tables = {}


def device_metadata(frame):
    scan = frame.scans[0]
    tables = {}
    table_indices = []
    layout = [0, 0, 0, len(scan.blocks)]
    geometry = []
    offsets = []
    plane_words = []
    for component in frame.components:
        offsets.append(sum(plane_words))
        plane_words.append(component.block_width * component.block_height * 16)
    for ordinal, block in enumerate(scan.blocks):
        selections = []
        for table in (block.dc, block.ac):
            key = tuple(sorted(table.symbols.items()))
            if key not in tables:
                tables[key] = len(tables)
                if key not in unique_tables:
                    unique_tables[key] = (len(unique_tables), device_words(canonical_words(table)))
                table_indices.append(unique_tables[key][0])
            selections.append(tables[key])
        packed = block.component | (selections[0] << 2) | (selections[1] << 5)
        layout[ordinal // 4] |= packed << ((ordinal % 4) * 8)
        component = frame.components[block.component]
        geometry.extend([offsets[block.component], component.block_width,
                         component.block_height, component.horizontal if scan.interleaved else 1,
                         component.vertical if scan.interleaved else 1, block.column, block.row, 0])
    count = sum(segment.mcu_count for segment in scan.segments) * len(scan.blocks)
    words = [len(tables), count, sum(plane_words), *(plane_words + [0] * (3 - len(plane_words))),
             *layout, *geometry,
             *(value for component in frame.components for value in component.quantization)]
    return words, table_indices


def markers(data):
    position = 2
    while True:
        begin = position
        assert data[position] == 255
        while data[position] == 255:
            position += 1
        marker = data[position]
        position += 1
        length = int.from_bytes(data[position:position + 2], 'big')
        yield marker, begin, position + 2, position + length
        position += length
        if marker == 0xda:
            return


def segment(marker, payload):
    return bytes([255, marker]) + (len(payload) + 2).to_bytes(2, 'big') + bytes(payload)


def insert_before_scan(data, extra):
    begin = next(row[1] for row in markers(data) if row[0] == 0xda)
    return data[:begin] + extra + data[begin:]


def replace_segment(data, selected, payload):
    rows = list(markers(data))
    marker, begin, _, end = rows[selected]
    return data[:begin] + segment(marker, payload) + data[end:]


def huffman_definition(kind, destination, counts, values):
    assert len(counts) == 16 and sum(counts) == len(values)
    return bytes([kind * 16 + destination, *counts, *values])


def facts(data):
    frame = parse(data)
    assert len(frame.scans) == 1 and len(frame.components) in (1, 3)
    scan = frame.scans[0]
    marker_rows = list(markers(data))
    start = scan.segments[0].source_start
    assert start == marker_rows[-1][3]
    restart = 0
    for marker, _, begin, end in marker_rows:
        if marker == 0xdd:
            restart = int.from_bytes(data[begin:end], 'big')
    _, _, scan_begin, _ = marker_rows[-1]
    words = [frame.width, frame.height, frame.process, len(frame.components),
             start, restart, scan.mcu_width,
             sum(segment.mcu_count for segment in scan.segments) // scan.mcu_width,
             len(scan.blocks)]
    for ordinal, component in enumerate(frame.components):
        selectors = data[scan_begin + 2 + ordinal * 2]
        words.extend([component.identifier, component.horizontal, component.vertical,
                      component.quantization_id, selectors >> 4, selectors & 15,
                      component.block_width, component.block_height])
        words.extend(component.quantization)
        block = next(block for block in scan.blocks if block.component == ordinal)
        for table in (block.dc, block.ac):
            words.append(len(table.symbols))
            for key, value in sorted(table.symbols.items()):
                length = key.bit_length() - 1
                words.extend([length, key - (1 << length), value])
    for block in scan.blocks:
        words.extend([block.component, block.column, block.row])
    metadata_by_header[bytes(data[:start])] = device_metadata(frame)
    return data[:start], words


names = ['existing_exif_fixture', 'ycbcr_444', 'ycbcr_422', 'ycbcr_420',
         'ycbcr_440', 'ycbcr_411', 'ycbcr_410', 'ycbcr_444_extended_quantization',
         'rgb_sequential', 'grayscale', 'dense-periodic', 'mcu-phase']
names += [name + '.r' + str(restart) + '.jpg'
          for name in ['012mp-bus.jpg', '006mp-cathedral.jpg',
                       'synthetic-1024.jpg', 'synthetic-256.jpg']
          for restart in (0, 64)]
cases = [(name, *facts(input_bytes(name))) for name in names]
baseline = input_bytes('grayscale')
frame = next(row for row in markers(baseline) if row[0] in (0xc0, 0xc1))

# All grayscale factors describe the same full-resolution component; the scan
# still contains one block per MCU, including non-unit SOF sampling factors.
for horizontal, vertical in product(range(1, 5), repeat=2):
    changed = bytearray(baseline)
    changed[frame[2] + 7] = horizontal * 16 + vertical
    cases.append((f'gray-sampling-{horizontal}-{vertical}', *facts(changed)))

baseline_rgb = input_bytes('ycbcr_444')
frame_rgb = next(row for row in markers(baseline_rgb) if row[0] in (0xc0, 0xc1))
for sampling in product(range(1, 5), repeat=6):
    if sum(sampling[index] * sampling[index + 1] for index in (0, 2, 4)) > 10:
        continue
    changed = bytearray(baseline_rgb)
    for ordinal in range(3):
        changed[frame_rgb[2] + 7 + ordinal * 3] = sampling[ordinal * 2] * 16 + sampling[ordinal * 2 + 1]
    cases.append(('sampling-' + '-'.join(map(str, sampling)), *facts(changed)))

# Independent DC, AC, and quantizer destinations preserve the same codebooks.
for dc, ac, quantizer in product(range(4), repeat=3):
    changed = bytearray(baseline)
    for marker, begin, payload, end in markers(baseline):
        if marker in (0xc0, 0xc1):
            changed[begin + 1] = 0xc1
            changed[payload + 8] = quantizer
        elif marker == 0xdb:
            assert end - payload == 65
            changed[payload] = quantizer
        elif marker == 0xc4:
            changed[payload] = (changed[payload] & 0xf0) | (ac if changed[payload] & 0xf0 else dc)
        elif marker == 0xda:
            changed[payload + 2] = dc * 16 + ac
    cases.append((f'extended-destinations-{dc}-{ac}-{quantizer}', *facts(changed)))

gray_rows = list(markers(baseline))
quantizer_row = next(row for row in gray_rows if row[0] == 0xdb)
quantizer = baseline[quantizer_row[2]:quantizer_row[3]]
huffman_rows = [row for row in gray_rows if row[0] == 0xc4]
huffman = b''.join(baseline[row[2]:row[3]] for row in huffman_rows)
short_counts = [1] + [0] * 15
long_counts = [0] * 15 + [1]

# Table installation is last-definition-wins, including representation width.
for name, replacements in [
    ('quantizer-narrow-replaced', segment(0xdb, [0, *([255] * 64)]) + segment(0xdb, quantizer)),
    ('quantizer-wide-replaced', segment(0xdb, [16, *([1, 1] * 64)]) + segment(0xdb, quantizer)),
    ('huffman-short-replaced', segment(0xc4,
        huffman_definition(0, 0, short_counts, [0]) +
        huffman_definition(1, 0, short_counts, [0])) + segment(0xc4, huffman)),
    ('huffman-long-replaced', segment(0xc4,
        huffman_definition(0, 0, long_counts, [0]) +
        huffman_definition(1, 0, long_counts, [0])) + segment(0xc4, huffman)),
    ('restart-disabled-after-definition', segment(0xdd, [255, 255]) + segment(0xdd, [0, 0])),
]:
    cases.append((name, *facts(insert_before_scan(baseline, replacements))))

# Multiple definitions inside one marker and marker fill bytes are independent
# of MCU semantics. Moving tables across SOF preserves their final destinations.
grouped = bytearray(b'\xff\xd8')
for marker, begin, payload, end in gray_rows:
    if marker not in (0xdb, 0xc4, 0xda):
        grouped.extend(baseline[begin:end])
grouped.extend(segment(0xc4, huffman))
grouped.extend(segment(0xdb, quantizer + bytes([1]) + quantizer[1:]))
scan_begin = gray_rows[-1][1]
grouped.extend(baseline[scan_begin:])
cases.append(('combined-tables-after-frame', *facts(grouped)))
filled = b'\xff\xd8' + b''.join(
    b'\xff' * ((ordinal % 4) + 1) + baseline[begin:end]
    for ordinal, (_, begin, _, end) in enumerate(gray_rows)
) + baseline[gray_rows[-1][3]:]
cases.append(('marker-fill-bytes', *facts(filled)))
for marker in [*range(0xe0, 0xf0), 0xfe]:
    cases.append((f'opaque-marker-{marker:02x}', *facts(insert_before_scan(
        baseline, segment(marker, [0, 255, 0, 255, 218, 255, 216])))))
cases.append(('empty-opaque-markers', *facts(insert_before_scan(
    baseline, segment(0xe0, []) + segment(0xfe, [])))))

for width, height in [(1, 1), (65535, 1), (1, 65535), (65535, 65535)]:
    changed = bytearray(baseline_rgb)
    changed[frame_rgb[2] + 1:frame_rgb[2] + 5] = height.to_bytes(2, 'big') + width.to_bytes(2, 'big')
    cases.append((f'frame-extents-{width}-{height}', *facts(changed)))

# Codeword lengths, aliases, and maximum symbol count exercise every lookup
# width and the distinction between a decoder map and an encoder inverse map.
for length in range(1, 17):
    counts = [0] * 16
    counts[length - 1] = 1
    definitions = b''.join(huffman_definition(kind, 0, counts, [0]) for kind in (0, 1))
    cases.append((f'codeword-length-{length}', *facts(insert_before_scan(baseline, segment(0xc4, definitions)))))
maximum_counts = [0] * 7 + [255] + [0] * 7 + [1]
definitions = b''.join(huffman_definition(kind, 0, maximum_counts, [0] * 256) for kind in (0, 1))
cases.append(('maximum-aliased-codebook', *facts(insert_before_scan(baseline, segment(0xc4, definitions)))))
definitions = b''
for kind, symbols in [(0, list(range(12))),
                      (1, [0, 240] + [run * 16 + size for run in range(16) for size in range(1, 11)])]:
    counts = [0] * 7 + [len(symbols)] + [0] * 8
    definitions += huffman_definition(kind, 0, counts, symbols)
cases.append(('complete-dct-symbol-alphabets', *facts(insert_before_scan(baseline, segment(0xc4, definitions)))))

changed = bytearray(baseline_rgb)
definitions = b''
for marker, begin, payload, end in list(markers(baseline_rgb)):
    if marker == 0xc0:
        changed[begin + 1] = 0xc1
    elif marker == 0xda:
        for component in range(3):
            changed[payload + 2 + component * 2] = component * 17
for component in range(3):
    for kind in range(2):
        counts = [0] * 16
        counts[10 + component * 2 + kind] = 1
        definitions += huffman_definition(kind, component, counts, [0])
cases.append(('six-distinct-codebooks', *facts(insert_before_scan(changed, segment(0xc4, definitions)))))

# Two zero-coefficient blocks use both aliases in both codebooks. The first
# block uses code 0 twice; the second uses code 10 twice, then two padding ones.
aliases = b''.join(huffman_definition(kind, 0, [1, 1] + [0] * 14, [0, 0])
                   for kind in (0, 1))
aliased_image = (b'\xff\xd8' + segment(0xdb, [0, *([1] * 64)]) +
                 segment(0xc0, [8, 0, 16, 0, 8, 1, 1, 0x11, 0]) +
                 segment(0xc4, aliases) + segment(0xda, [1, 1, 0, 0, 63, 0]) +
                 b'\x2b\xff\xd9')
planes, _ = decode(parse(aliased_image))
assert len(planes) == 1 and list(planes[0]) == [0] * 128
cases.append(('aliased-symbol-image', *facts(aliased_image)))

def without_color_markers(data):
    rows = list(markers(data))
    return (b'\xff\xd8' + b''.join(data[begin:end] for marker, begin, _, end in rows
                                   if marker not in (0xe0, 0xee)) + data[rows[-1][3]:])


def component_identifiers(data, identifiers):
    changed = bytearray(data)
    for marker, _, payload, _ in markers(data):
        if marker in (0xc0, 0xc1):
            for index, identifier in enumerate(identifiers):
                changed[payload + 6 + index * 3] = identifier
        if marker == 0xda:
            for index, identifier in enumerate(identifiers):
                changed[payload + 1 + index * 2] = identifier
    return changed


unmarked_ycbcr = without_color_markers(baseline_rgb)
unmarked_rgb = component_identifiers(unmarked_ycbcr, b'RGB')
jfif_payload = b'JFIF\0\x01\x01\0\0\x01\0\x01\0\0'
adobe_payload = b'Adobe\0\x64\0\0\0\0'
jfif_marker = segment(0xe0, jfif_payload)
adobe_rgb = segment(0xee, adobe_payload + b'\0')
adobe_ycbcr = segment(0xee, adobe_payload + b'\x01')
color_inputs = [
    ('unmarked-ycbcr', unmarked_ycbcr),
    ('unmarked-rgb', unmarked_rgb),
    ('unmarked-unknown-ids', component_identifiers(unmarked_ycbcr, [18, 128, 242])),
    ('jfif-over-rgb-identifiers', insert_before_scan(unmarked_rgb, jfif_marker)),
    ('adobe-over-ycbcr-identifiers', insert_before_scan(unmarked_ycbcr, adobe_rgb)),
    ('adobe-over-rgb-identifiers', insert_before_scan(unmarked_rgb, adobe_ycbcr)),
    ('jfif-before-adobe', insert_before_scan(unmarked_rgb, jfif_marker + adobe_rgb)),
    ('jfif-after-adobe', insert_before_scan(unmarked_rgb, adobe_rgb + jfif_marker)),
    ('adobe-rgb-replaced', insert_before_scan(unmarked_rgb, adobe_rgb + adobe_ycbcr)),
    ('adobe-ycbcr-replaced', insert_before_scan(unmarked_ycbcr, adobe_ycbcr + adobe_rgb)),
    ('short-jfif', insert_before_scan(unmarked_rgb, segment(0xe0, jfif_payload[:-1]))),
    ('short-adobe-after-rgb', insert_before_scan(unmarked_ycbcr, adobe_rgb + segment(0xee, adobe_payload))),
    ('unknown-jfif-signature', insert_before_scan(unmarked_rgb, segment(0xe0, b'X' + jfif_payload[1:]))),
    ('unknown-adobe-signature', insert_before_scan(unmarked_ycbcr, segment(0xee, b'X' + adobe_payload[1:] + b'\0'))),
]
for transform in (2, 255):
    marker = segment(0xee, adobe_payload + bytes([transform]))
    color_inputs.extend([
        (f'unsupported-adobe-{transform}', insert_before_scan(unmarked_ycbcr, marker)),
        (f'jfif-over-adobe-{transform}', insert_before_scan(unmarked_ycbcr, marker + jfif_marker)),
        (f'gray-adobe-{transform}', insert_before_scan(baseline, marker)),
    ])
for name, data in color_inputs:
    cases.append((name, *facts(data)))

negative = []
header, _ = facts(baseline)
locations = {marker: (begin, payload, end) for marker, begin, payload, end in markers(baseline)}


def reject(name, edits, status=3):
    changed = bytearray(header)
    for offset, value in edits:
        changed[offset] = value
    negative.append((name, bytes(changed), status))


reject('missing-soi', [(0, 0)])
begin, payload, end = locations[0xdb]
reject('zero-quantizer', [(payload + 1, 0)])
reject('bad-quantizer-precision', [(payload, 0x20)])
reject('bad-quantizer-destination', [(payload, 4)])
reject('empty-quantizer', [(begin + 2, 0), (begin + 3, 2)])
begin, payload, end = locations[0xc4]
reject('overfull-huffman', [(payload + 1, 2)])
reject('bad-huffman-class', [(payload, 0x20)])
reject('bad-huffman-destination', [(payload, 4)])
reject('bad-ac-symbol', [(payload + 17, 0x10)])
begin, payload, end = locations[0xc0]
reject('zero-width', [(payload + 3, 0), (payload + 4, 0)])
reject('zero-sampling', [(payload + 7, 0)])
reject('large-sampling', [(payload + 7, 0x51)])
reject('missing-quantizer', [(payload + 8, 3)])
reject('deferred-height', [(payload + 1, 0), (payload + 2, 0)], 12)
reject('wide-precision', [(payload, 12)], 12)
for marker in [0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf]:
    reject(f'unsupported-process-{marker:02x}', [(begin + 1, marker)], 12)
begin, payload, end = locations[0xda]
reject('unknown-scan-component', [(payload + 1, 255)])
reject('baseline-destination-two', [(payload + 2, 0x22)])
reject('undefined-dc-table', [(payload + 2, 0x10)])
reject('bad-spectral-start', [(end - 3, 1)])
reject('bad-spectral-end', [(end - 2, 62)])
reject('bad-approximation', [(end - 1, 1)])

def reject_bytes(name, data, status=3):
    negative.append((name, bytes(data), status))


for marker in [0, 1, *range(0xd0, 0xda)]:
    reject_bytes(f'standalone-header-marker-{marker:02x}', header[:2] + bytes([255, marker]) + header[2:])
for length in (0, 1, 65535):
    reject_bytes(f'invalid-marker-length-{length}', header[:2] + bytes([255, 254]) + length.to_bytes(2, 'big') + header[2:])
for length in range(17):
    reject_bytes(f'truncated-huffman-counts-{length}', insert_before_scan(header, segment(0xc4, [0] * length)))
for length in (0, 1, 3):
    reject_bytes(f'invalid-restart-length-{length}', insert_before_scan(header, segment(0xdd, [0] * length)))
reject_bytes('empty-huffman-tree', insert_before_scan(header, segment(0xc4, [0] * 17)))
reject_bytes('truncated-huffman-symbols', insert_before_scan(header, segment(0xc4, [0, *short_counts])))
reject_bytes('huffman-symbol-count-257', insert_before_scan(header, segment(0xc4,
    huffman_definition(0, 0, [0] * 8 + [255, 2] + [0] * 6, [0] * 257))))
reject_bytes('all-ones-deep-huffman', insert_before_scan(header, segment(0xc4,
    huffman_definition(0, 0, [1] * 15 + [2], [0] * 17))))
for width in (1, 2):
    reject_bytes(f'truncated-quantizer-{width}', insert_before_scan(header, segment(0xdb, [(width - 1) << 4, *([1] * (64 * width - 1))])))
reject_bytes('zero-wide-quantizer', insert_before_scan(header, segment(0xdb, [16, *([0, 0] * 64)])))
reject_bytes('baseline-wide-quantizer', insert_before_scan(header, segment(0xdb, [16, *([1, 1] * 64)])))
reject_bytes('quantizer-trailing-descriptor', insert_before_scan(header, segment(0xdb, [*quantizer, 1])))
for kind in (0, 1):
    for symbol in range(256):
        allowed = symbol <= 11 if kind == 0 else symbol in (0, 240) or 1 <= (symbol & 15) <= 10
        if not allowed:
            reject_bytes(f'invalid-symbol-{kind}-{symbol:02x}', insert_before_scan(header,
                segment(0xc4, huffman_definition(kind, 0, short_counts, [symbol]))))
frame_row = next(row for row in gray_rows if row[0] == 0xc0)
frame_index = gray_rows.index(frame_row)
for length in range(6):
    reject_bytes(f'truncated-frame-fields-{length}', replace_segment(header, frame_index,
        baseline[frame_row[2]:frame_row[2] + length]))
for count in (0, 2, 4):
    payload_bytes = [8, 0, 16, 0, 8, count]
    for component in range(count):
        payload_bytes.extend([component, 0x11, 0])
    reject_bytes(f'frame-component-count-{count}', replace_segment(header, frame_index, payload_bytes), 3 if count == 0 else 12)
reject_bytes('frame-component-extent', replace_segment(header, frame_index, [8, 0, 16, 0, 8, 3, 1, 0x11, 0]))
for marker in (0xc8, 0xcc, 0xdc, 0xde, 0xdf):
    reject_bytes(f'unsupported-header-marker-{marker:02x}', insert_before_scan(header, segment(marker, [0, 0])), 12)
reject_bytes('duplicate-frame', insert_before_scan(header, baseline[frame_row[1]:frame_row[3]]))
reject_bytes('scan-without-frame', header[:frame_row[1]] + header[frame_row[3]:])
for count in (0, 5):
    reject_bytes(f'invalid-scan-component-count-{count}', replace_segment(header, len(gray_rows) - 1, [count, *([0, 0] * count), 0, 63, 0]))
reject_bytes('separated-scan', replace_segment(facts(baseline_rgb)[0], len(list(markers(baseline_rgb))) - 1, [1, 1, 0, 0, 63, 0]), 12)
for name, changes in [
    ('duplicate-frame-component', [(frame_rgb[2] + 9, baseline_rgb[frame_rgb[2] + 6])]),
    ('excess-mcu-blocks', [(frame_rgb[2] + 7, 0x44)]),
    ('out-of-range-quantizer-selector', [(frame_rgb[2] + 8, 4)]),
]:
    changed = bytearray(facts(baseline_rgb)[0])
    for offset, value in changes:
        changed[offset] = value
    reject_bytes(name, changed)
scan_row = list(markers(baseline_rgb))[-1]
for name, identifiers in [('duplicate-scan-component', [1, 1, 3]),
                          ('out-of-order-scan-components', [2, 1, 3])]:
    changed = bytearray(facts(baseline_rgb)[0])
    for index, identifier in enumerate(identifiers):
        changed[scan_row[2] + 1 + index * 2] = identifier
    reject_bytes(name, changed)
begin, payload, end = locations[0xda]
reject('undefined-ac-table', [(payload + 2, 1)])
for kind in (0, 1):
    reject(f'out-of-range-scan-selector-{kind}', [(payload + 2, 4 << (4 if kind == 0 else 0))])

root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
fixture_colors = {}
color_stage_hashes = {}
for directory in ('mixed-current', 'mixed-negative-base'):
    path = root / directory / 'stage.json'
    color_stage_hashes[directory] = hashlib.sha256(path.read_bytes()).hexdigest()
    for image in json.loads(path.read_text())['images']:
        assert hashlib.sha256(input_bytes(image['name'])).hexdigest() == image['input_sha256']
        fixture_colors[image['name']] = image['header'][-1]
lines = [f'static const uint8_t aliased_image[] = {{{",".join(map(str, aliased_image))}}};']
for index, table in unique_tables.values():
    lines.append(f'static const uint32_t table_{index}[] = {{{",".join(map(str, table))}}};')
lines.append('static const uint32_t* const expected_tables[] = {' +
             ','.join(f'table_{index}' for index,_ in unique_tables.values()) + '};')
for index, (_, data, expected) in enumerate(cases):
    lines.append(f'static const uint8_t input_{index}[] = {{{",".join(map(str, data))}}};')
    lines.append(f'static const uint32_t expected_{index}[] = {{{",".join(map(str, expected))}}};')
    metadata, table_indices = metadata_by_header[bytes(data)]
    lines.append(f'static const uint32_t metadata_{index}[] = {{{",".join(map(str, metadata))}}};')
    lines.append(f'static const uint8_t table_indices_{index}[] = {{{",".join(map(str, table_indices))}}};')
lines.append('static const HeaderCase positive_cases[] = {')
for index, (name, _, _) in enumerate(cases):
    lines.append(f'{{"{name}", input_{index}, sizeof(input_{index}), expected_{index}, IREE_ARRAYSIZE(expected_{index}), metadata_{index}, IREE_ARRAYSIZE(metadata_{index}), table_indices_{index}, {fixture_colors.get(name, 0)}}},')
lines.append('};')
for index, (_, data, _) in enumerate(negative):
    lines.append(f'static const uint8_t invalid_{index}[] = {{{",".join(map(str, data))}}};')
lines.append('static const InvalidCase negative_cases[] = {')
for index, (name, _, status) in enumerate(negative):
    lines.append(f'{{"{name}", invalid_{index}, sizeof(invalid_{index}), {status}}},')
lines.append('};')
output = notes / 'native_header_cases.inc'
output.write_text('\n'.join(lines) + '\n')
record = {'positive_cases':len(cases), 'negative_cases':len(negative),
          'header_bytes':sum(len(data) for _,data,_ in cases),
          'source_bytes':output.stat().st_size,
          'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'oracle_sha256':hashlib.sha256((notes/'sequential.py').read_bytes()).hexdigest(),
          'cases_sha256':hashlib.sha256(output.read_bytes()).hexdigest(),
          'corpus':names,'sampling_combinations':515,
          'extended_destination_combinations':64,
          'alias_image_sha256':hashlib.sha256(aliased_image).hexdigest(),
          'device_color_stage_sha256':color_stage_hashes,
          'device_color_cases':len(fixture_colors),
          'unique_device_codebooks':len(unique_tables),
          'device_prefixes_checked':len(unique_tables)*65536,
          'device_oracle_sha256':hashlib.sha256((notes/'twolevel_fixtures.py').read_bytes()).hexdigest(),
          'scope':'Header facts only; sampling mutations are not claimed to have a valid compressed body.'}
assert record['header_bytes'] < 1024**2
(notes/'native-header-cases.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
