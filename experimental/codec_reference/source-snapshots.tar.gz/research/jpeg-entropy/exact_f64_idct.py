"""Bound exact integer-valued binary64 arithmetic and author its native probe."""
import hashlib
import json
from pathlib import Path

from integer_idct import transform

notes = Path(__file__).resolve().parent

class Magnitude:
    maximum = 0

    def __init__(self, magnitude):
        self.magnitude = abs(magnitude)
        Magnitude.maximum = max(Magnitude.maximum, self.magnitude)

    def __add__(self, other):
        return Magnitude(self.magnitude + other.magnitude)

    def __sub__(self, other):
        return Magnitude(self.magnitude + other.magnitude)

    def __mul__(self, constant):
        return Magnitude(self.magnitude * abs(constant))

matrix = [transform([int(i == j) for i in range(8)]) for j in range(8)]
row_norm = max(sum(abs(matrix[j][i]) for j in range(8)) for i in range(8))
first_input = 1024 * 65535
first_output = (first_input * row_norm + 1024 + 2047) // 2048
assert first_output < 2**31
records = []
for input_bound, rounding, shift in ((first_input, 1024, 11), (first_output, 131072, 18)):
    Magnitude.maximum = 0
    outputs = transform([Magnitude(input_bound) for _ in range(8)])
    maximum = max(Magnitude.maximum, max(value.magnitude for value in outputs) + rounding)
    assert maximum < 2**53
    records.append({'input_bound': input_bound, 'intermediate_integer_bound': maximum,
                    'rounding': rounding, 'shift': shift})
source = (notes / 'device_reconstruct_twolevel.cxx').read_text()
candidate = source.replace('#include "device_entropy_cursor.h"',
                           '#include "device_entropy_cursor.h"\n#include <loomcxx/scalar.h>')
candidate = candidate.replace('using WideValues = long long ', 'using WideValues = double ')
start = candidate.index('static LOOM_FORCE_INLINE WideValues transform_block_axis(')
end = candidate.index('\nstatic LOOM_FORCE_INLINE unsigned sample_byte', start)
candidate = candidate[:start] + candidate[start:end].replace('long long ', 'double ') + candidate[end:]
candidate = candidate.replace('static_cast<int>((result[row] + 1024) >> 11)',
                              'static_cast<int>(loom::scalar::floorf((result[row] + 1024.0) * 0x1p-11))')
candidate = candidate.replace('static_cast<int>((result[column] + 131072) >> 18)',
                              'static_cast<int>(loom::scalar::floorf((result[column] + 131072.0) * 0x1p-18))')
assert 'result[row] + 1024) >> 11' not in candidate
assert 'result[column] + 131072) >> 18' not in candidate
(notes / 'device_reconstruct_exact_f64.cxx').write_text(candidate)
pipeline = (notes / 'device_twolevel_pipeline.cxx').read_text()
original = source.replace('#include "device_entropy_cursor.h"', '')
assert pipeline.count(original) == 1
(notes / 'device_exact_f64_pipeline.cxx').write_text(pipeline.replace(
    original, candidate.replace('#include "device_entropy_cursor.h"', '')))
record = {'row_l1_norm': row_norm, 'passes': records,
          'argument': 'All values before each power-of-two scaling are integers. Each product, addition, and rounding-bias sum has magnitude below 2^53, so binary64 represents every result exactly. Power-of-two scaling is exact; floor preserves the signed arithmetic-shift rounding. No relaxed floating-point contract is used.',
          'sources': {name: hashlib.sha256((notes / name).read_bytes()).hexdigest()
                      for name in ('integer_idct.py', 'exact_f64_idct.py', 'device_reconstruct_exact_f64.cxx')}}
(notes / 'exact-f64-bound.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
