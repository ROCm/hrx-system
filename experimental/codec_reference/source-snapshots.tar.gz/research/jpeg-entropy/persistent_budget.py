"""Account for storage and available entropy streams in the captured GPU shape.

This is a cold ownership calculation, not a simulated GPU or a timing model.
The interval table has already passed complete native output checks. Sorting it
here recovers its exact MCU ownership without reparsing or changing the decoder.
"""

import hashlib
import json
from pathlib import Path
import statistics

import numpy as np

from device_fixture import input_bytes
from sequential import parse


NOTES = Path(__file__).resolve().parent
ROOT = Path(json.loads((NOTES / "device-active.json").read_text())["directory"])
FIXTURE = ROOT / "mixed-current"


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def first_mcu(entry, blocks_per_mcu):
    # A partial block or an interior MCU block belongs to the preceding owner.
    return int(entry[2]) // blocks_per_mcu + (int(entry[3]) != 0)


def main():
    stage = json.loads((NOTES / "sharkbox-primary-stage.json").read_text())
    for name in ("segments.npy", "intervals.npy", "expected.npy", "headers.npy"):
        assert digest(FIXTURE / name) == stage["files"]["primary/" + name]["sha256"]
    segments = np.load(FIXTURE / "segments.npy").reshape(-1, 8)
    intervals = np.load(FIXTURE / "intervals.npy").reshape(-1, 8)
    summaries = np.load(FIXTURE / "expected.npy")
    key = "012mp-bus.jpg.r0.jpg-scan0-chunk1024"
    previous = ROOT / "partitions4-large" / (key + "-intervals.npy")
    original_intervals = np.load(previous).reshape(-1, 8)
    assert np.array_equal(intervals[:len(original_intervals)], original_intervals)
    previous_summary = ROOT / "large" / (key + "-expected.npy")
    original_summaries = np.load(previous_summary)
    assert np.array_equal(summaries[:len(original_summaries)], original_summaries)
    speculation = next(case for case in json.loads((ROOT / "twolevel-large/fixtures.json").read_text())["cases"]
                       if case["key"] == key)["counters"]
    lane = json.loads((NOTES / "entropy-lane-model.json").read_text())["rows"][1]
    assert lane["family"] == "partitions4-large" and lane["intervals_sha256"] == digest(previous)
    rows = json.loads((NOTES / "persistent-rows.json").read_text())["rows"]
    result = {
        "scope": "Logical payload capacity, symbol work, and checkpoint concurrency; not measured traffic, GPU occupancy, or latency.",
        "source_sha256": digest(Path(__file__)),
        "current_source_sha256": {name: digest(FIXTURE / name) for name in
                                  ("mixed_pipeline.cxx", "mixed_cursor.h", "mixed_image.h", "summary.loom")},
        "evidence_sha256": {name: digest(NOTES / name) for name in
                            ("sharkbox-primary-stage.json", "persistent-rows.json", "entropy-lane-model.json")},
        "counter_fixture_sha256": digest(ROOT / "twolevel-large/fixtures.json"),
        "matched_bus_interval_file_sha256": digest(previous),
        "matched_bus_summary_file_sha256": digest(previous_summary),
        "bus_entropy_work": {
            "useful_symbols": lane["useful_symbols"],
            "speculative_successful_symbols": speculation["speculative_symbols"],
            "speculative_lookbehind_symbols": speculation["speculative_overlap_symbols"],
            "reconstruction_leading_mcu_reread_symbols": lane["leading_mcu_reread_symbols"],
            "successful_symbol_ratio_before_bridge_work":
                (speculation["speculative_symbols"] + lane["useful_symbols"] +
                 lane["leading_mcu_reread_symbols"]) / lane["useful_symbols"],
        },
        "images": [],
    }
    for image_index, image in enumerate(stage["fixture"]["images"][:4]):
        encoded = input_bytes(image["name"])
        assert hashlib.sha256(encoded).hexdigest() == image["input_sha256"]
        frame = parse(encoded)
        assert len(frame.scans) == len(frame.scans[0].segments) == 1
        blocks_per_mcu = len(frame.scans[0].blocks)
        segment = segments[image_index]
        count = int(segment[3])
        first = int(segment[2]) * 5 + image_index
        entries = intervals[first:first + count * 5 + 1]
        ordered = sorted((entry for entry in entries if entry[0] < entry[1]), key=lambda entry: int(entry[0]))
        assert ordered[0][0] == 0 and ordered[-1][1] == segment[1]
        assert all(left[1] == right[0] for left, right in zip(ordered, ordered[1:]))
        total_mcus = int(segment[4]) // blocks_per_mcu
        starts = [first_mcu(entry, blocks_per_mcu) for entry in ordered] + [total_mcus]
        assert starts[0] == 0 and all(left <= right for left, right in zip(starts, starts[1:]))
        owners = [(first, last) for first, last in zip(starts, starts[1:]) if first < last]
        assert sum(last - first for first, last in owners) == total_mcus
        columns = image["header"][11]
        mcu_rows = (total_mcus + columns - 1) // columns
        bytes_per_row = rows[image_index]["component_ring_bytes"] // 3
        windows = []
        for capacity in (3, 8, 16, 32):
            if capacity > mcu_rows:
                continue
            available = [sum(first < (row + capacity) * columns and last > row * columns
                             for first, last in owners)
                         for row in range(mcu_rows - capacity + 1)]
            windows.append({
                "resident_mcu_rows": capacity,
                "component_payload_bytes": capacity * bytes_per_row,
                "intersecting_entropy_streams_minimum": min(available),
                "intersecting_entropy_streams_median": statistics.median(available),
                "intersecting_entropy_streams_maximum": max(available),
            })
        result["images"].append({"image": image["name"], "mcu_columns": columns,
                                 "mcu_rows": mcu_rows, "nonempty_intervals": len(ordered),
                                 "intervals_owning_mcus": len(owners), "windows": windows})
    bus = rows[0]
    resize = bus["resize"]
    candidate = (bus["component_ring_bytes"] + bus["rgb_row_bytes"] +
                 resize["horizontal_ring_bytes"] + resize["vertical_accumulator_bytes"] + resize["output_row_bytes"])
    full = bus["full_component_bytes"] + bus["full_rgb_bytes"]
    result["bus_image_payload"] = {
        "full_component_plus_rgb_bytes": full,
        "bounded_components_and_resize_bytes": candidate,
        "capacity_reduction_ratio": full / candidate,
        "excluded": "Entropy state, tables, filter plans, queues, coefficient LDS, implementation temporaries, final tensor, and downstream model features.",
    }
    result["sixteen_image_three_row_component_payload_bytes"] = 4 * sum(row["component_ring_bytes"] for row in rows)
    result["concurrency_limits"] = (
        "Counts assume all intersecting certified streams are available, packed without empty lanes, "
        "and resumable at MCU boundaries. They are an upper bound on independent entropy work in the "
        "resident rows, not a scheduler implementation or achieved occupancy. Chroma/consumer halos, "
        "ordered retirement, unequal work, and slot contention can reduce actual progress."
    )
    path = NOTES / "persistent-budget.json"
    path.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
