"""Hold operations fixed while probing callable entry requirements."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile

notes = Path(__file__).resolve().parent
source = Path('loom/src/loom/tooling/target/amdgpu/test/buffer_descriptor_extents.loom')
original = source.read_text()
start = original.index('kernel.def @atomic_record_fields() {')
body = original.index('} launch(%bits: i64, %storage: buffer) {', start)
function = (original[:start] + 'func.def @atomic_record_fields(%bits: i64, %storage: buffer) {'
            + original[body + len('} launch(%bits: i64, %storage: buffer) {'):])
assert function.count('kernel.return') == 1
function = function.replace('kernel.return', 'func.return')
function_path = notes / 'atomic_record_function.loom'
function_path.write_text(function)
tag = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['codec-buffer-extent-candidate'])
compiler = tag / 'loom/src/loom/tools/loom-compile/loom-compile'
runner = tag / 'loom/src/loom/tools/iree-test-loom/iree-test-loom'
result = {'compiler_sha256': hashlib.sha256(compiler.read_bytes()).hexdigest(),
          'runner_sha256': hashlib.sha256(runner.read_bytes()).hexdigest(),
          'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
          'function_sha256': hashlib.sha256(function_path.read_bytes()).hexdigest(),
          'compilations': []}
with tempfile.TemporaryDirectory(prefix='codec-corpus-entry-') as directory:
    for form, path in [('kernel', source), ('function', function_path)]:
        for target in ['vm:core', 'wasm:simd128', 'amdgpu:gfx1100',
                       'spirv:vulkan1.3+bda', 'spirv:vulkan1.3+bda+extended-types',
                       'spirv:vulkan1.3+bda+subgroup32+ballot+hal']:
            command = [str(compiler), str(path), '--root=@atomic_record_fields',
                       '--target=' + target, '--output=' + directory + '/artifact',
                       '--compile-report=details', '--compile-report-output=' + directory + '/report.json']
            report = Path(directory) / 'report.json'
            if report.exists():
                report.unlink()
            completed = subprocess.run(command, text=True, capture_output=True)
            entry = {'form': form, 'target': target, 'exit_code': completed.returncode,
                     'stderr': completed.stderr}
            if report.exists():
                details = json.loads(report.read_text())
                entry['diagnostics'] = details.get('diagnostics', [])
            result['compilations'].append(entry)
            print(form, target, completed.returncode, completed.stderr[:500], flush=True)
    command = [str(runner), str(function_path)]
    completed = subprocess.run(command, text=True, capture_output=True)
    result['vm_execution'] = {'command': command, 'exit_code': completed.returncode,
                              'stdout': completed.stdout, 'stderr': completed.stderr}
    print('VM execution', completed.returncode, completed.stdout, completed.stderr, flush=True)
(notes / 'corpus-entry-probe.json').write_text(json.dumps(result, indent=2) + '\n')
