"""Qualify and capture the experimental server, then restore every owned byte."""
import hashlib
import json
from pathlib import Path
import subprocess

notes = Path(__file__).resolve().parent
assert not subprocess.check_output(["git", "status", "--porcelain"], text=True)
manifest = json.loads((notes / "http-publication-source.json").read_text())
directory = Path(manifest["directory"])
originals = {}
overlays = {}
for name, digest in manifest["overlays"].items():
    path = Path(name)
    overlay = (directory / "overlays" / name).read_bytes()
    assert hashlib.sha256(overlay).hexdigest() == digest
    overlays[name] = overlay
    if name in manifest["originals"]:
        originals[name] = path.read_bytes()
        assert hashlib.sha256(originals[name]).hexdigest() == manifest["originals"][name]
    else:
        assert not path.exists(), name
commands = [
    ["iree-bazel-test", "--config=asan", "//loom/src/loom/serve/service/finite:result_test",
     "//loom/src/loom/serve/media:image_request_test",
     "//loom/src/loom/tooling/target/amdgpu/serve:weights_test"],
    ["bureau-bazel", "build", "--tag=codec-jpeg-http", "--config=asan",
     "//loom/src/loom/tools/loom-serve"],
]
record = {"compiler_commit": manifest["compiler_commit"], "configuration": "asan",
          "gpu_checks": "access", "restored": False,
          "source_manifest_sha256": hashlib.sha256((notes / "http-publication-source.json").read_bytes()).hexdigest(),
          "commands": []}
receipt = notes / "http-publication-build.json"
receipt.write_text(json.dumps(record, indent=2) + "\n")
applied = []
try:
    for name, data in overlays.items():
        Path(name).write_bytes(data)
        applied.append(name)
    for command in commands:
        result = subprocess.run(command)
        record["commands"].append({"command": command, "returncode": result.returncode})
        receipt.write_text(json.dumps(record, indent=2) + "\n")
        if result.returncode:
            break
finally:
    for name in applied:
        assert Path(name).read_bytes() == overlays[name], name
    for name in applied:
        if name in originals:
            Path(name).write_bytes(originals[name])
        else:
            Path(name).unlink()
    record["restored"] = True
    receipt.write_text(json.dumps(record, indent=2) + "\n")
assert not subprocess.check_output(["git", "status", "--porcelain"], text=True)
if result.returncode:
    raise SystemExit(result.returncode)
record["capture"] = json.loads(subprocess.check_output(["bureau-bazel", "tag", "inspect", "codec-jpeg-http", "--json"], text=True))
receipt.write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"passed": True, "restored": True, "capture": record["capture"]["capture"]}))
