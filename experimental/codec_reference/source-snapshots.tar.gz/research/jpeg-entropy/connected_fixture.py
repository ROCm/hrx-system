"""Original bytes through exact RGB; body-derived fixtures never enter inputs."""
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess

from device_fixture import input_bytes, read_words, write_words
from unstuff_fixtures import entropy_start

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])


def header_geometry(data):
    """Read marker lengths and SOF only, stopping before entropy."""
    start = entropy_start(data)
    position = 2
    geometry = None
    while position < start:
        assert data[position] == 255
        while data[position] == 255:
            position += 1
        marker = data[position]
        length = int.from_bytes(data[position + 1:position + 3], 'big')
        payload = data[position + 3:position + 1 + length]
        if marker in (0xc0, 0xc1):
            assert payload[0] == 8
            height, width = struct.unpack('>HH', payload[1:5])
            count = payload[5]
            sampling = [(payload[7 + i * 3] >> 4, payload[7 + i * 3] & 15) for i in range(count)]
            horizontal = max(h for h, v in sampling)
            vertical = max(v for h, v in sampling)
            mcus = ((width + horizontal * 8 - 1) // (horizontal * 8)) * ((height + vertical * 8 - 1) // (vertical * 8))
            blocks = mcus * sum(h * v for h, v in sampling)
            pixels = sum(((width * h + horizontal * 8 - 1) // (horizontal * 8)) *
                         ((height * v + vertical * 8 - 1) // (vertical * 8)) * 16 for h, v in sampling)
            geometry = {'width': width, 'height': height, 'blocks': blocks,
                        'pixel_words': pixels, 'sampling': sampling}
        if marker == 0xdd:
            assert payload == b'\x00\x00'
        position += 1 + length
    assert geometry is not None
    return start, geometry


def shape(path):
    with path.open('rb') as stream:
        assert stream.read(8) == b'\x93NUMPY\x01\x00'
        header = ast.literal_eval(stream.read(struct.unpack('<H', stream.read(2))[0]).decode())
    assert not header['fortran_order'] and len(header['shape']) == 1
    return header['shape'][0], 'i8' if header['descr'] == '|i1' else 'i32'


def generate(small):
    directory = root / ('connected-small' if small else 'connected-batch16')
    directory.mkdir(exist_ok=True)
    name = 'existing_exif_fixture' if small else '012mp-bus.jpg.r0.jpg'
    original = (root / 'twolevel-small/existing_exif_fixture-scan0-chunk1024.loom' if small
                else root / 'twolevel-batch16-1024/summary.loom')
    config_path = original.with_suffix('.json') if small else original.parent / 'config.json'
    configuration = json.loads(config_path.read_text())
    if small:
        configuration.update(json.loads((root / 'color-small/existing_exif_fixture.json').read_text()))
    batch = configuration['jpeg']['segments']
    data = input_bytes(name)
    start, geometry = header_geometry(data)
    tiles = (len(data) + 4095) // 4096
    chunk_bytes = configuration['jpeg']['chunk_bytes']
    capacity_per_image = (tiles * 4096 + chunk_bytes - 1) // chunk_bytes
    capacity = batch * capacity_per_image
    configuration['input'] = {'tiles': tiles}
    configuration['jpeg']['chunks'] = capacity
    (directory / 'config.json').write_text(json.dumps(configuration, indent=2) + '\n')
    paths = {key: (original.parent / path).resolve() for key, path in re.findall(
        r'%([a-z_]+) = check.file.read.npy path\("([^"]+)"\)', original.read_text())}
    unstuff = root / ('unstuff-small' if small else 'unstuff-batch16')
    prefix = 'existing-exif' if small else 'summary'
    for key in ('compressed', 'entropy', 'records', 'prefixes', 'errors'):
        paths[key] = unstuff / (prefix + '-' + key + '.npy')
    if small:
        paths['rgb'] = root / 'color-small/existing_exif_fixture-rgb.npy'
    errors = read_words(paths['errors'])
    assert all(errors[image * 4] == 0 for image in range(batch))
    # These exact body counts are oracle-only. Configurations use allocation capacity.
    counts = [(errors[image * 4 + 3] + chunk_bytes - 1) // chunk_bytes for image in range(batch)]
    total = sum(counts)
    partitions = configuration['jpeg']['output_partitions']
    word_stride = tiles * 1024 + 2
    values = {'headers': [], 'segments': [], 'jobs': []}
    first = 0
    for image, count in enumerate(counts):
        values['headers'].extend([len(data), start, geometry['blocks'], image * geometry['pixel_words']])
        bit_limit = errors[image * 4 + 3] * 8
        values['segments'].extend([image * word_stride, bit_limit, first, count,
                                  geometry['blocks'], first + image, 0, image * geometry['pixel_words']])
        values['jobs'].extend(value for job in range(count) for value in (image * word_stride, bit_limit, job))
        first += count
    values['jobs'].extend([17] * ((capacity - total) * 3))
    intervals = total * (partitions + 1) + batch
    values['schedule'] = [total, (total + 127) // 128, 1, 1,
                          (intervals + 32 * batch - 1) // (32 * batch), batch, 1, intervals]
    for key, words in values.items():
        path = directory / (key + '.npy')
        write_words(path, words)
        paths[key] = path
    padded = {'expected': capacity * 8, 'bridges': capacity * 8,
              'suffixes': (capacity + batch) * 8, 'ranges': (capacity + batch) * 8,
              'points': capacity * (partitions - 1) * 8,
              'intervals': (capacity * (partitions + 1) + batch) * 8,
              'status': capacity * (partitions + 1) + batch}
    for key, count in padded.items():
        words = read_words(paths[key])
        assert count >= len(words)
        path = directory / (key + '.npy')
        write_words(path, list(words) + [17] * (count - len(words)))
        paths[key] = path
    inputs = {'compressed', 'headers', 'tables', 'blocks', 'geometry', 'quantization', 'zigzag'}
    shapes = {key: shape(path) for key, path in paths.items()}
    calls = [
        ('jpeg_classify_bytes', ['compressed', 'headers', 'records'], None),
        ('jpeg_prefix_bytes', ['compressed', 'headers', 'records', 'prefixes', 'segments', 'errors'], None),
        ('jpeg_plan_jobs', ['segments', 'schedule'], None),
        ('jpeg_compact_bytes', ['compressed', 'headers', 'records', 'prefixes', 'segments', 'errors', 'entropy', 'jobs'], None),
        ('jpeg_speculate', ['entropy', 'jobs', 'tables', 'blocks', 'expected', 'points', 'schedule'], 'jobs_grid'),
        ('jpeg_bridge', ['entropy', 'jobs', 'tables', 'blocks', 'expected', 'bridges', 'schedule'], 'jobs_grid'),
        ('jpeg_index', ['segments', 'expected', 'suffixes', 'ranges', 'intervals'], None),
        ('jpeg_certify', ['segments', 'expected', 'bridges', 'suffixes', 'ranges', 'intervals'], None),
        ('jpeg_intervals', ['segments', 'expected', 'suffixes', 'ranges', 'points', 'intervals'], None),
        ('jpeg_reconstruct', ['entropy', 'segments', 'tables', 'blocks', 'intervals', 'geometry', 'quantization', 'zigzag', 'pixels', 'status'], 'reconstruction_grid'),
        ('jpeg_color', ['pixels', 'rgb'], None)]
    declaration = ', '.join('%' + key + ': buffer' for key in paths)
    text = ['kernel.decl @' + kernel + ('(%launch_schedule: buffer, %launch_offset: offset)' if grid else '()') + ' launch(' + ', '.join('%' + key + ': buffer' for key in keys) + ')'
            for kernel, keys, grid in calls]
    text.extend(['', 'func.def @fixture_values(' + declaration + ') {', '  func.return', '}', '',
                 'command.program.def public @jpeg_decode() launch(' + declaration + ') {',
                 '  %schedule_offset = index.constant 0 : offset',
                 '  command.serial {'])
    for kernel, keys, grid in calls:
        operation = 'kernel.launch'
        launch = '[%schedule, %schedule_offset]' if grid else ''
        types = '[buffer, offset]' if grid else ''
        text.append('    ' + operation + ' @' + kernel + launch + '(' + ', '.join('%' + key for key in keys) + ') : ' + types + '(' + ', '.join('buffer' for key in keys) + ')')
    text.extend(['  }', '  command.return', '}', '',
                 'command.program.def public @jpeg_batch() launch(' + declaration + ') {',
                 '  %zero = index.constant 0 : index',
                 '  %one = index.constant 1 : index',
                 '  %eight = index.constant 8 : index',
                 '  scf.for %repeat = [%zero to %eight step %one] unroll {',
                 '    command.program.launch @jpeg_decode(' + ', '.join('%' + key for key in paths) + ') : (' + ', '.join('buffer' for key in paths) + ')',
                 '  }', '  command.return', '}', '', 'check.scenario @summary {',
                 '  check.trial[1](%trial: index, %trial_entropy: check.entropy) {'])
    for key, path in paths.items():
        count, dtype = shapes[key]
        relative = os.path.relpath(path, directory)
        text.append(f'    %{key} = check.file.read.npy path("{relative}") : tensor<{count}x{dtype}>')
        if key not in inputs:
            text.append(f'    %{key}_output = check.generate.fill value(17) : tensor<{count}x{dtype}>')
    actual = ['%' + key + ('' if key in inputs else '_output') for key in paths]
    types = [f'tensor<{count}x{dtype}>' for count, dtype in shapes.values()]
    text.append('    check.compare<@jpeg_decode, @fixture_values>(' + ', '.join(actual) + ') : (' + ', '.join(types) + ') -> () {')
    for key, (count, dtype) in shapes.items():
        if key not in inputs:
            text.append(f'      check.expect.bitwise actual(%{key}_output) expected(%{key}) : tensor<{count}x{dtype}>')
    text.extend(['    }', '  }', '  check.return', '}', '', 'check.benchmark<@summary> @summary_latency', ''])
    (directory / 'summary.loom').write_text('\n'.join(text))
    bindings = []
    for key, path in paths.items():
        count, dtype = shapes[key]
        bindings.append(f'{key} {int(key in inputs)} {1 if dtype == "i8" else 4} {count} {os.path.relpath(path, directory)}')
    (directory / 'bindings.txt').write_text('\n'.join(bindings) + '\n')
    tags = json.loads(os.environ['BUREAU_TAG_ROOTS'])
    link = Path(tags['codec-jpeg-rebased-tools']) / 'loom/src/loom/tools/loom-link/loom-link'
    library = root / 'entropy-connected.loombc'
    command = [str(link), str(directory / 'summary.loom'), str(library), '--to=bc', '--output=' + str(directory / 'summary.loombc')]
    subprocess.run(command, check=True)
    files = {os.path.relpath(path, directory): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths.values()}
    files.update({path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in directory.iterdir()
                  if path.is_file() and path.name != 'stage.json'})
    stage = {'files': files, 'jobs': total, 'sizes': {key: count for key, (count, dtype) in shapes.items()},
             'library': {'path': library.name, 'sha256': hashlib.sha256(library.read_bytes()).hexdigest()},
             'scope': 'Eleven ordered GPU dispatches from resident original JPEG bytes and header-only facts to exact RGB. GPU owns unstuffing, entropy extent, compact jobs, and three indirect launch grids. No CPU entropy walk or intermediate readback. Header parsing, allocation, upload, and model consumption remain outside this measurement.',
             'geometry': geometry, 'configuration': configuration, 'expected_schedule': values['schedule'],
             'source_sha256': hashlib.sha256(data).hexdigest(), 'link_command': command,
             'retention': 'Reuses existing compressed, unstuffed, component, and RGB arrays; only metadata expectations are padded to capacity.'}
    (directory / 'stage.json').write_text(json.dumps(stage, indent=2) + '\n')
    (notes / ('connected-' + ('small' if small else 'batch16') + '-stage.json')).write_text(json.dumps(stage, indent=2) + '\n')
    print(json.dumps({'directory': str(directory), 'schedule': values['schedule'], 'capacity': capacity}), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--small', action='store_true')
    arguments = parser.parse_args()
    generate(arguments.small)
