"""Specialize the header-owned MCU component/Huffman-table mapping."""
from pathlib import Path

notes = Path(__file__).resolve().parent
source = (notes / 'device_entropy_cursor_short.h').read_text()
certified = (notes / 'device_entropy_cursor_certified.h').read_text()
certified = certified[certified.index('// The restart-rooted certificate'):]
source += '\n' + certified
marker = 'using Predictors = int __attribute__((ext_vector_type(4)));'
helper = '''[[loom::config("jpeg.layout0")]] extern const unsigned layout0;
[[loom::config("jpeg.layout1")]] extern const unsigned layout1;
[[loom::config("jpeg.layout2")]] extern const unsigned layout2;

// Each header-owned block uses two component bits and two three-bit table
// indices. Four descriptors share a word; the three words cover ten blocks.
static LOOM_FORCE_INLINE unsigned block_descriptor(unsigned block) {
  unsigned word = block < 4 ? layout0 : (block < 8 ? layout1 : layout2);
  return (word >> ((block & 3u) * 8u)) & 255u;
}

'''
assert source.count(marker) == 1
source = source.replace(marker, helper + marker)
assert source.count('blocks[block_index]') == 3
source = source.replace('blocks[block_index]', 'block_descriptor(block_index)')
source = source.replace('(descriptor >> 8) & 255', '(descriptor >> 2) & 7')
source = source.replace('descriptor >> 16', 'descriptor >> 5')
source = source.replace('descriptor & 255', 'descriptor & 3')
(notes / 'device_entropy_cursor_layout.h').write_text(source)

speculate = (notes / 'device_entropy_partitioned.cxx').read_text()
old = '''    auto* block_storage =
        loom::buffer::alloca<unsigned, loom::memory_space::workgroup, 16>(
            blocks_per_mcu);
'''
assert speculate.count(old) == 1
speculate = speculate.replace(old, '')
old = '''    for (unsigned index = lane; index < blocks_per_mcu; index += threads) {
      block_storage[index] = blocks[index];
    }
'''
assert speculate.count(old) == 1
speculate = speculate.replace(old, '').replace('    blocks = block_storage;\n', '')
(notes / 'device_entropy_layout.cxx').write_text(speculate)
reconstruct = (notes / 'device_reconstruct_compact.cxx').read_text()
assert reconstruct.count('blocks[block]') == 2
reconstruct = reconstruct.replace('blocks[block] >> 16', 'block_descriptor(block) >> 5')
reconstruct = reconstruct.replace('blocks[block] & 255', 'block_descriptor(block) & 3')
(notes / 'device_reconstruct_layout.cxx').write_text(reconstruct)
pipeline = '#include "device_entropy_cursor_layout.h"\n'
pipeline += '''[[loom::config("jpeg.output_partitions"), loom::where(loom::predicate::range(2u, 8u))]]
extern const unsigned output_partitions;
'''
for name in ('device_entropy_layout.cxx', 'device_bridge.cxx',
             'device_certify_partitioned.cxx', 'device_reconstruct_layout.cxx'):
    pipeline += '\n' + (notes / name).read_text().replace('#include "device_entropy_cursor.h"', '') + '\n'
assert 'blocks[' not in pipeline
(notes / 'device_layout_pipeline.cxx').write_text(pipeline)
