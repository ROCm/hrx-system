"""Numerical model of the existing 8-bit integer component contract.

The separable transform retains 13-bit cosine factors, scales the first pass
by four, and rounds after each pass. This cold reference does not select a
GPU storage/launch policy or a relaxed model-input error envelope.
"""


def transform(values):
    # Four even-frequency outputs and the symmetric odd-frequency rotations.
    dc_sum = (values[0] + values[4]) * 8192
    dc_difference = (values[0] - values[4]) * 8192
    even_rotation = (values[2] + values[6]) * 4433
    even_two = even_rotation - values[6] * 15137
    even_six = even_rotation + values[2] * 6270
    even = (dc_sum + even_six, dc_difference + even_two,
            dc_difference - even_two, dc_sum - even_six)
    odd_rotation = (values[1] + values[3] + values[5] + values[7]) * 9633
    odd_seven_three = odd_rotation - (values[7] + values[3]) * 16069
    odd_five_one = odd_rotation - (values[5] + values[1]) * 3196
    odd_seven_one = (values[7] + values[1]) * -7373
    odd_five_three = (values[5] + values[3]) * -20995
    odd = (values[1] * 12299 + odd_seven_one + odd_five_one,
           values[3] * 25172 + odd_five_three + odd_seven_three,
           values[5] * 16819 + odd_five_three + odd_five_one,
           values[7] * 2446 + odd_seven_one + odd_seven_three)
    return ([left + right for left, right in zip(even, odd)] +
            [left - right for left, right in reversed(tuple(zip(even, odd)))])


def reconstruct(coefficients, quantization):
    assert len(coefficients) == len(quantization) == 64
    intermediate = [0] * 64
    for column in range(8):
        values = [coefficients[row * 8 + column] * quantization[row * 8 + column]
                  for row in range(8)]
        for row, value in enumerate(transform(values)):
            intermediate[row * 8 + column] = (value + 1024) >> 11
    result = bytearray(64)
    for row in range(8):
        for column, value in enumerate(transform(intermediate[row * 8:row * 8 + 8])):
            result[row * 8 + column] = min(255, max(0, ((value + 131072) >> 18) + 128))
    return result
