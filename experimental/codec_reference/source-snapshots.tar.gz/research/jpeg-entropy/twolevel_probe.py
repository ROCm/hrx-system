"""Compare every cursor field against the original canonical-table transition."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

from twolevel_fixtures import convert_table

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
reference = (notes / 'device_entropy_cursor_short.h').read_text()
codeword = reference[reference.index('static LOOM_FORCE_INLINE Codeword codeword('):
                     reference.index('static LOOM_FORCE_INLINE Read amplitude(')]
codeword = codeword.replace('Codeword codeword(', 'Codeword reference_codeword(')
transition = reference[reference.index('static LOOM_FORCE_INLINE Symbol advance_symbol_slow('):
                       reference.index('// The fast admission')]
transition = transition.replace('Symbol advance_symbol_slow(', 'Symbol reference_advance(')
transition = transition.replace('= codeword(', '= reference_codeword(')
source = (notes / 'short_transition_probe.cxx').read_text()
source = source.replace('#include "device_entropy_cursor_short.h"',
                        '#include "device_entropy_cursor_twolevel.h"\n' + codeword + transition)
source = source.replace('const unsigned* blocks, const unsigned* states, unsigned* output)',
                        'const unsigned* blocks, const unsigned* states, const unsigned* twolevel_tables, unsigned* output)')
source = source.replace('advance_symbol_slow(entropy, tables, blocks, limit, left)',
                        'reference_advance(entropy, tables, blocks, limit, left)')
source = source.replace('advance_symbol(entropy, tables, blocks, limit, right)',
                        'advance_symbol(entropy, twolevel_tables, blocks, limit, right)')
(notes / 'twolevel_transition_probe.cxx').write_text(source)
original = root / 'short-probe'
output = root / 'twolevel-probe'
output.mkdir(exist_ok=True)
paths = {}
def relocate(match):
    path = (original / match[1]).resolve()
    paths[str(path.relative_to(root))] = hashlib.sha256(path.read_bytes()).hexdigest()
    return 'check.file.read.npy path("' + os.path.relpath(path, output) + '")'
scenario = re.sub(r'check.file.read.npy path\("([^"]+)"\)', relocate, (original / 'check.loom').read_text())
match = re.search(r'%tables = check.file.read.npy path\("([^"]+)"\)', scenario)
table, size = convert_table((output / match[1]).resolve())
paths[str(table.relative_to(root))] = hashlib.sha256(table.read_bytes()).hexdigest()
scenario = scenario.replace('%output: buffer)', '%twolevel_tables: buffer, %output: buffer)')
position = scenario.index('  kernel.launch')
scenario = scenario[:position] + f'  %twolevel_tables = check.file.read.npy path("{os.path.relpath(table, output)}") : tensor<{size}xi32>\n' + scenario[position:]
lines = []
for line in scenario.splitlines():
    if line.startswith('  kernel.launch'):
        match = re.fullmatch(r'(  kernel.launch @\w+)\((.*)\) : \((.*)\)', line)
        names = match[2].split(', ')
        types = match[3].split(', ')
        names.insert(-1, '%twolevel_tables')
        types.insert(-1, f'tensor<{size}xi32>')
        line = match[1] + '(' + ', '.join(names) + ') : (' + ', '.join(types) + ')'
    lines.append(line)
(output / 'check.loom').write_text('\n'.join(lines) + '\n')
config = json.loads((original / 'config.json').read_text())
layout = json.loads((root / 'layout-batch16-1024/config.json').read_text())['jpeg']
config['jpeg'].update({key: value for key, value in layout.items() if key.startswith('layout')})
(output / 'config.json').write_text(json.dumps(config, indent=2) + '\n')
base = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['codec-jpeg-rebased-tools']) / 'loom/src/loom/tools'
commands = [[str(base / 'loom-import-cxx/loom-import-cxx'), str(notes / 'twolevel_transition_probe.cxx'), '--output=' + str(output / 'library.loom')],
            [str(base / 'loom-link/loom-link'), str(output / 'library.loom'), str(output / 'check.loom'), '--to=bc', '--output=' + str(output / 'check.loombc')]]
for command in commands:
    subprocess.run(command, check=True)
paths.update({str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
              for path in output.iterdir() if path.is_file()})
(notes / 'twolevel-probe-stage.json').write_text(json.dumps({'count': 32768, 'commands': commands, 'files': paths,
    'scope': 'All cursor fields and symbol index/value against the original canonical-table slow transition over arbitrary phases, real offsets, extent/read-cap limits, and 1-8 transitions.',
    'sources': {name: hashlib.sha256((notes / name).read_bytes()).hexdigest() for name in
                ('twolevel_probe.py', 'twolevel_transition_probe.cxx', 'device_entropy_cursor_twolevel.h')}}, indent=2) + '\n')
print('32768 two-level differential probes ready', flush=True)
