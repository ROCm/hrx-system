"""Run exact-output, bounded-work candidate comparisons; no timing claims."""

import argparse
import hashlib
import json
from pathlib import Path

from bounded import evaluate, speculate
from sequential import decode, parse


ROOT = Path(__file__).resolve().parent
BASELINE = ROOT.parent / "jpeg-baseline"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", action="append", required=True)
    parser.add_argument("--chunk-bytes", type=int, nargs="+", default=[256, 1024, 4096])
    parser.add_argument("--lookbehind", type=int, nargs="+", default=[1])
    parser.add_argument("--recover-prefix", action="store_true")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    speculator = speculate
    if args.recover_prefix:
        from recover_prefix import speculate as recover
        speculator = recover
    assert all(value > 0 for value in args.chunk_bytes)
    assert all(value >= 0 for value in args.lookbehind)
    small = json.loads((ROOT / "sequential-small.json").read_text())
    large = json.loads((ROOT / "sequential-large.json").read_text())
    source_hash = digest((ROOT / "sequential.py").read_bytes())
    assert small["sources"]["sequential.py"] == large["sources"]["sequential.py"] == source_hash
    cases = {r["name"]: r for r in [*large["coefficient_signature_cases"],
                                     *small["exact_periodic_cases"], *small["exact_public_oracle_cases"]]}
    records = [json.loads(line) for line in (ROOT.parent / "jpeg-reference/probe.log").read_text().splitlines()
               if line.startswith('{"kind":')]
    generated = {r["name"]: bytes.fromhex(r["hex"]) for r in records if r["kind"] == "input"}
    output = {"state": "Checkpoint candidate experiment; exact output and logical work, no GPU performance.",
              "candidate": "C2 bounded prefix recovery" if args.recover_prefix else "C1 abort invalid prefix",
              "sources": {name: digest((ROOT / name).read_bytes())
                          for name in ("sequential.py", "bounded.py", "recover_prefix.py", "evaluate_bounded.py")},
              "qualification": {name: digest((ROOT / name).read_bytes())
                                for name in ("sequential-small.json", "sequential-large.json")},
              "cases": []}
    for name in args.input:
        if name in generated:
            data = generated[name]
        elif name in ("dense-periodic", "mcu-phase"):
            data = (ROOT / (name + ".jpg")).read_bytes()
        else:
            data = (BASELINE / "inputs" / name).read_bytes()
        reference = cases[name]
        assert digest(data) == reference["input_sha256"]
        frame = parse(data)
        planes, traces = decode(frame, True)
        assert [digest(p.tobytes()) for p in planes] == reference["coefficient_planes_sha256"]
        record = {"name": name, "input_sha256": digest(data),
                  "compressed_bytes": len(data), "dimensions": [frame.width, frame.height],
                  "baseline_symbols": reference["symbols"], "variants": []}
        for chunk_bytes in args.chunk_bytes:
            for lookbehind in args.lookbehind:
                result = evaluate(frame, chunk_bytes, lookbehind, planes, traces, speculator)
                record["variants"].append(result)
                print(json.dumps({"name": name, **result}), flush=True)
        output["cases"].append(record)
        # Retain one corpus member's compact trace and two output planes only.
        del frame, planes, traces, data
        (ROOT / args.output).write_text(json.dumps(output, indent=2) + "\n")
    print("All candidate coefficients match the qualified sequential reference.", flush=True)


if __name__ == "__main__":
    main()
