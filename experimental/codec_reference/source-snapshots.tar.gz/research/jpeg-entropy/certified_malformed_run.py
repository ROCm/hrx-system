"""Compare the full malformed entropy pipeline across the certificate boundary."""
from collections import Counter
import argparse
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess

root = Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--candidate',default='certified')
parser.add_argument('--candidate-config-directory')
parser.add_argument('--candidate-fixture-directory')
arguments=parser.parse_args()
candidate=arguments.candidate
assert os.environ['BENCHMARK_LOCK_LEASE_ID']
assert not list(Path('/sys/class/kfd/kfd/proc').iterdir())
directory = root/'certified-malformed'
stage = json.loads((directory/'stage.json').read_text())
for name,digest in stage['files'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
runner=root/'iree-test-loom-unsigned'
assert hashlib.sha256(runner.read_bytes()).hexdigest()=='5e267978d7e937b1009f64a2e005913a4cc36c002b1f24eef44776cc4683a632'
libraries=json.loads((root/'certified-malformed-libraries.json').read_text())
for name,digest in libraries.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
assert not (arguments.candidate_config_directory and arguments.candidate_fixture_directory)
override=arguments.candidate_config_directory or arguments.candidate_fixture_directory
configuration_directory=root/override if override else directory
candidate_directory=root/arguments.candidate_fixture_directory if arguments.candidate_fixture_directory else directory
configuration_manifest={}
if override:
    configuration_manifest=json.loads((configuration_directory/'manifest.json').read_text())
    for name,digest in configuration_manifest.items():
        assert hashlib.sha256((configuration_directory/name).read_bytes()).hexdigest()==digest,name

def words(path):
    data=path.read_bytes()
    assert data[:8]==b'\x93NUMPY\x01\x00'
    size=struct.unpack_from('<H',data,8)[0]
    return struct.unpack_from('<'+'I'*((len(data)-10-size)//4),data,10+size)

rows=[]
for case in stage['cases']:
    key=case['key']
    records={}
    for variant in ('short',candidate):
        output=root/('malformed-'+variant+'-actual')
        output.mkdir(exist_ok=True)
        command=[str(runner),str((candidate_directory if variant==candidate else directory)/(key+'.loom')),
                 '--library='+str(root/('entropy-'+variant+'.loombc')),
                 '--config-file='+str((configuration_directory if variant==candidate else directory)/(key+'.json')),
                 '--target=amdgpu:gfx1151','--device=amdgpu','--sanitizer=access',
                 '--file-output-root='+str(output)]
        result=subprocess.run(command,capture_output=True,text=True)
        (output/(key+'.log')).write_text(result.stdout+result.stderr)
        if result.returncode:
            print(result.stdout+result.stderr,flush=True)
            raise SystemExit(result.returncode)
        records[variant]={'command':command,'report':json.loads(result.stdout),
                          'files':{name:output/(key+'-'+name+'.npy') for name in ('pixels','status','intervals')}}
    for name in ('pixels','status','intervals'):
        left=records['short']['files'][name]
        right=records[candidate]['files'][name]
        assert left.read_bytes()==right.read_bytes(),(key,name)
    status=Counter(words(records[candidate]['files']['status']))
    assert sum(count for value,count in status.items() if value!=0)>0,(key,status)
    assert set(status).issubset({0,1,2,3,4,5}),(key,status)
    expected_code={'DC outside 8-bit DCT range':5,'non-ones entropy padding':4}.get(case['independent_error'],1)
    assert status[expected_code]>0,(key,expected_code,status)
    descriptors=words(directory/(key+'-segments.npy'))
    intervals=words(records[candidate]['files']['intervals'])
    stride=(4+case['components']+3)&~3
    frontiers=[]
    for index in range(case['segments']):
        first_job,count=descriptors[index*8+2:index*8+4]
        frontiers.append(intervals[(first_job*5+index+count*5)*stride])
    row={'key':key,'independent_error':case['independent_error'],'status_counts':dict(status),
         'certified_frontiers':frontiers,'exact_checked_consumer':True,
         'files':{name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in records[candidate]['files'].items()},
         'commands':{variant:record['command'] for variant,record in records.items()}}
    rows.append(row)
    print(json.dumps(row),flush=True)
assert any(any(row['certified_frontiers']) for row in rows)
assert any(not any(row['certified_frontiers']) for row in rows)
dc=next(row for row in rows if row['key'].endswith('dc-range'))
assert any(dc['certified_frontiers']),dc
(root/(candidate+'-malformed-qualified.json')).write_text(json.dumps({
    'lease':os.environ['BENCHMARK_LOCK_LEASE_ID'],'libraries':libraries,'rows':rows,
    'candidate_configuration':configuration_manifest,
    'runner_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2)+'\n')
