"""Independent tile compaction model for the bounded single-scan witness."""
import hashlib
import itertools
import json
from pathlib import Path

from sequential import InvalidJPEG, split_entropy

notes = Path(__file__).resolve().parent
NONE = 0xffffffff


def reference(data, start):
    try:
        segments, prefix = split_entropy(data, start)
        marker = prefix
        while marker < len(data) and data[marker] == 255:
            marker += 1
        if len(segments) != 1 or marker + 1 != len(data) or data[marker] != 0xd9:
            return False, b''
        return True, segments[0][0]
    except InvalidJPEG:
        return False, b''


def model(data, start, tile_size=4096):
    records = []
    retained = []
    for first in range(0, len(data), tile_size):
        marker_prefix = marker_code = invalid = NONE
        positions = []
        for position in range(max(start, first), min(len(data), first + tile_size)):
            value = data[position]
            previous = data[position - 1] if position > start else 0
            if value == 255:
                following = data[position + 1] if position + 1 < len(data) else 255
                if following != 0:
                    marker_prefix = min(marker_prefix, position)
                    if following != 255:
                        marker_code = min(marker_code, position)
                else:
                    positions.append(position)
            elif value == 0 and previous == 255:
                if position > start + 1 and data[position - 2] == 255:
                    invalid = min(invalid, position)
            else:
                positions.append(position)
        positions = [position for position in positions if position < marker_prefix]
        records.append((len(positions), marker_prefix, marker_code, invalid))
        retained.append(bytes(data[position] for position in positions))
    marker_prefix = min((row[1] for row in records), default=NONE)
    marker_code = min((row[2] for row in records), default=NONE)
    invalid = min((row[3] for row in records), default=NONE)
    valid = (marker_prefix != NONE and marker_code != NONE and
             marker_code + 2 == len(data) and data[marker_code + 1] == 0xd9 and
             invalid >= marker_code)
    output = bytearray()
    prefixes = []
    for index, (record, payload) in enumerate(zip(records, retained)):
        prefixes.append(len(output))
        if index * tile_size <= marker_prefix:
            output.extend(payload)
    return valid, bytes(output) if valid else b'', records, prefixes


def cases():
    alphabet = (0, 1, 0xff, 0xd0, 0xd9)
    for length in range(7):
        for index, values in enumerate(itertools.product(alphabet, repeat=length)):
            yield f'exhaustive-{length}-{index}', bytes(values), 0
    # Vary both header alignment and escapes/markers at packet/tile boundaries.
    for header in (0, 1, 2, 3, 7, 15, 16, 17, 31):
        for boundary in (15, 16, 31, 32, 255, 256, 4095, 4096, 4097, 8191):
            prefix = bytes([255, 218, 0, 5, 255, 0, 217] * ((header + 6) // 7))[:header]
            body = b'\x23' * boundary
            for name, suffix in (
                ('stuffed', b'\xff\x00\x44\xff\x00\xff\xd9'),
                ('fill', b'\xff' * 37 + b'\xd9'),
                ('long-fill', b'\xff' * 4100 + b'\xd9'),
                ('fill-stuffed', b'\xff\xff\x00\xff\xd9'),
                ('truncated', b'\xff'),
                ('restart', b'\xff\xd0\x32\xff\xd9'),
                ('following-scan', b'\xff\xda'),
                ('trailing', b'\xff\xd9\x12'),
            ):
                yield f'{name}-{header}-{boundary}', prefix + body + suffix, header


if __name__ == '__main__':
    count = valid_count = 0
    for name, data, start in cases():
        expected = reference(data, start)
        actual = model(data, start)
        assert actual[:2] == expected, (name, expected, actual[:2])
        count += 1
        valid_count += expected[0]
    record = {'cases': count, 'valid_cases': valid_count,
              'scope': 'Independent serial marker parser versus tile classification, reduction, prefix, and compaction; no GPU performance conclusion.',
              'sources': {name: hashlib.sha256((notes / name).read_bytes()).hexdigest()
                          for name in ('byte_compaction_model.py', 'sequential.py')}}
    (notes / 'byte-compaction-model.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)
