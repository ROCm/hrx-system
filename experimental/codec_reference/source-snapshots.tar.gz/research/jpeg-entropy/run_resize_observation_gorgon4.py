"""Move the weight-free resize observation to the available correctness host."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess

notes = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--reuse', action='store_true')
arguments = parser.parse_args()
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
original = root / 'vision-accuracy'
directory = root / 'vision-resize'
tag = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['codec-jpeg-vision-tools'])
tool = tag / 'loom/src/loom/tools/iree-test-loom/iree-test-loom'
if not arguments.reuse:
    subprocess.run(['ssh', 'hrx-gorgon-4', 'mkdir -p ' + shlex.quote(str(directory))], check=True)
    producer = subprocess.Popen(['ssh', 'hrx-gorgon-3', shlex.join(
        ['tar', '-C', str(original), '-cf', '-', 'observations', 'sources',
         'manifest.json', 'projector-metrics.json'])], stdout=subprocess.PIPE)
    consumer = subprocess.run(['ssh', 'hrx-gorgon-4', shlex.join(
        ['tar', '-C', str(directory), '-xf', '-'])], stdin=producer.stdout)
    producer.stdout.close()
    assert producer.wait() == 0 and consumer.returncode == 0
    subprocess.run(['scp', str(tool), 'hrx-gorgon-4:' + str(directory / 'resize-check')], check=True)
subprocess.run(['scp', str(notes / 'observe_model_resize.py'),
                'hrx-gorgon-4:' + str(directory / 'observe_model_resize.py')], check=True)
print('Pinned packets, source, and checker staged; no setup lease held.', flush=True)
subprocess.run(['ssh', 'hrx-gorgon-4', shlex.join(
    ['python3', '-B', str(directory / 'observe_model_resize.py'), str(directory), 'prepare'])], check=True)
command = ['ssh', 'hrx-gorgon-4', shlex.join(
    ['/home/benvanik/.dotfiles/bin/benchmark-lock', '--label=codec-jpeg-resize-observation',
     '--', 'env', 'LD_LIBRARY_PATH=/opt/rocm/lib', 'python3', '-B',
     str(directory / 'observe_model_resize.py'), str(directory), 'execute'])]
with (notes / 'gorgon4-resize-observation.log').open('w') as log:
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    for line in process.stdout:
        log.write(line)
        log.flush()
        print(line, end='', flush=True)
    result = process.wait()
status = subprocess.run(['ssh', 'hrx-gorgon-4',
                         '/home/benvanik/.dotfiles/bin/benchmark-lock --status'],
                        capture_output=True, text=True)
receipt = {'command': command, 'returncode': result,
           'broker_status_after': status.stdout + status.stderr,
           'broker_status_returncode': status.returncode,
           'tool_sha256': hashlib.file_digest(tool.open('rb'), 'sha256').hexdigest(),
           'script_sha256': hashlib.sha256((notes / 'observe_model_resize.py').read_bytes()).hexdigest()}
(notes / 'gorgon4-resize-observation-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
subprocess.run(['scp', 'hrx-gorgon-4:' + str(directory / 'resize-observations/runs.json'),
                str(notes / 'gorgon4-resize-observation-runs.json')], check=True)
if not result:
    subprocess.run(['ssh', 'hrx-gorgon-4', shlex.join(
        ['python3', '-B', str(directory / 'observe_model_resize.py'), str(directory), 'analyze'])], check=True)
    subprocess.run(['scp', 'hrx-gorgon-4:' + str(directory / 'resize-metrics.json'),
                    str(notes / 'gorgon4-resize-metrics.json')], check=True)
raise SystemExit(result or status.returncode)
