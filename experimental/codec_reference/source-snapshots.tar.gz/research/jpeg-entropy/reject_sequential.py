"""Malformed-input checks that reach entropy decoding, beyond missing EOI."""

from collections import Counter
import hashlib
import json
from pathlib import Path

from sequential import decode, parse, InvalidJPEG


ROOT = Path(__file__).resolve().parent
records = [json.loads(line) for line in (ROOT.parent / "jpeg-reference/probe.log").read_text().splitlines()
           if line.startswith('{"kind":')]
inputs = {r["name"]: bytes.fromhex(r["hex"]) for r in records if r["kind"] == "input"}
failures = Counter()
named = []


def rejected(data, expected=None):
    try:
        decode(parse(data))
    except InvalidJPEG as error:
        message = str(error)
        if expected is not None:
            assert message == expected, (message, expected)
        failures[message] += 1
        return message
    raise AssertionError("accepted malformed input")


for name in ("ycbcr_420", "ycbcr_420_restart_1", "ycbcr_420_separate_scans"):
    data = inputs[name]
    frame = parse(data)
    first = frame.scans[0].segments[0].source_start
    # Append EOI after truncation, so a missing terminator is not the reason
    # these fail. Retain the original frame geometry and exact MCU counts.
    cuts = sorted(set(range(first, len(data) - 2, 17)) |
                  set(range(max(first, len(data) - 18), len(data) - 2)))
    for cut in cuts:
        rejected(data[:cut] + b"\xff\xd9")
    named.append({"case": name + "/truncated-entropy-with-eoi", "rejections": len(cuts)})

data = bytearray(inputs["ycbcr_420_restart_1"])
segment = parse(data).scans[0].segments[0]
marker = segment.source_start + segment.source_bytes
assert data[marker:marker + 2] == b"\xff\xd0"
data[marker + 1] = 0xD2
rejected(bytes(data), "restart sequence mismatch")
named.append({"case": "wrong-restart-number", "rejections": 1})

dense = (ROOT / "dense-periodic.jpg").read_bytes()
huffman = dense.index(b"\xff\xc4")
huffman_end = huffman + 2 + int.from_bytes(dense[huffman + 2:huffman + 4], "big")
data = bytearray(dense)
assert data[huffman_end - 1] == 1
data[huffman_end - 1] = 0xF1
rejected(bytes(data), "AC run exceeds block")
named.append({"case": "ac-run-overflow", "rejections": 1})

data = bytearray(dense)
data[huffman + 5] = 2
rejected(bytes(data), "overfull/all-ones Huffman tree")
named.append({"case": "reserved-all-ones-code", "rejections": 1})
rejected(dense[:huffman] + dense[huffman_end:], "missing Huffman table")
named.append({"case": "missing-huffman-table", "rejections": 1})

data = bytearray(dense)
data[dense.index(b"\xff\xdb") + 5] = 0
rejected(bytes(data), "zero quantization entry")
named.append({"case": "zero-quantization", "rejections": 1})

for name in ("ycbcr_420", "grayscale"):
    data = inputs[name]
    frame = parse(data)
    _, traces = decode(frame, True)
    segment = frame.scans[0].segments[-1]
    assert traces[-1].positions[-1] % 8 != 0
    tail = segment.source_start + segment.source_bytes - 1
    # A stuffed final FF has a zero transport byte following its data byte.
    if data[tail] == 0:
        assert data[tail - 1] == 255
        damaged = data[:tail - 1] + b"\xfe" + data[tail + 1:]
    else:
        damaged = data[:tail] + bytes([data[tail] & 254]) + data[tail + 1:]
    rejected(damaged, "non-ones entropy padding")
    named.append({"case": name + "/zero-padding-bit", "rejections": 1})

result = {"state": "Malformed-input checks of the independent experiment parser.",
          "sources": {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                      for name in ("sequential.py", "reject_sequential.py")},
          "cases": named, "rejection_reasons": dict(failures),
          "total_rejections": sum(failures.values())}
(ROOT / "sequential-rejections.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
