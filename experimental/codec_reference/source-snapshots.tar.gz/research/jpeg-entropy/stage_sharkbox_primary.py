"""Stage one 16-image gfx1100 corpus and the same-machine CPU comparators."""
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import tarfile

notes = Path(__file__).resolve().parent
stage = json.loads((notes / 'noxa-sharkbox-stage.json').read_text())
assert stage['staging_returncode'] == 0
qualification = json.loads((notes / 'sharkbox-small-correctness-3-receipt.json').read_text())
assert qualification['returncode'] == 0
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
primary = root / 'mixed-current'
fixture = json.loads((primary / 'stage.json').read_text())
assert fixture['cohort'] == 'primary' and len(fixture['images']) == 16 and fixture['invalid_index'] is None
assert sum(fixture['bytes'].values()) < 512 * 1024 * 1024
tags = {key: Path(value) for key, value in json.loads(os.environ['BUREAU_TAG_ROOTS']).items()}
files = {}
for name in ['summary.loombc', 'config.json', 'bindings.txt']:
    files['primary/' + name] = primary / name
for line in (primary / 'bindings.txt').read_text().splitlines():
    name, is_input, width, count, relative = line.split()
    assert fixture['bytes'][name] == int(width) * int(count)
    files['primary/' + relative] = primary / relative
files['codec_command_probe_opt'] = tags['codec-jpeg-rebased-tools'] / 'loom/src/loom/tooling/target/amdgpu/serve/codec_command_probe'
for policy in ('islow', 'ifast'):
    files['jpeg_pipeline_' + policy] = tags['codec-jpeg-gfx1100-cpu'] / 'experimental/codec_reference/research/jpeg-baseline' / ('jpeg_pipeline_' + policy)
for image in fixture['images'][:4]:
    path = Path('experimental/codec_reference/research/jpeg-baseline/inputs') / image['name']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == image['input_sha256']
    files['images/' + image['name']] = path
for name, path in files.items():
    if name.startswith('primary/') and path.name in fixture['files']:
        assert hashlib.sha256(path.read_bytes()).hexdigest() == fixture['files'][path.name]
record = {'host': stage['host'], 'directory': stage['directory'], 'fixture': fixture,
          'logical_device_binding_bytes': sum(fixture['bytes'].values()),
          'gpu_build': json.loads((notes / 'current-probe-opt-build.json').read_text()),
          'cpu_build': json.loads((notes / 'gfx1100-cpu-build.json').read_text()),
          'native': json.loads((notes / 'gfx1100-native.json').read_text()),
          'files': {name: {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
                    for name, path in files.items()}}
assert record['cpu_build']['returncode'] == 0
record['aggregate_staged_bytes'] = sum(row['bytes'] for row in stage['files'].values()) + sum(row['bytes'] for row in record['files'].values())
assert record['aggregate_staged_bytes'] < 1024 * 1024 * 1024
manifest = root / 'gfx1100-primary-manifest.json'
manifest.write_text(json.dumps(record, indent=2) + '\n')
files['primary-manifest.json'] = manifest
process = subprocess.Popen(['ssh', stage['host'], shlex.join(['tar', '-xf', '-', '-C', stage['directory']])], stdin=subprocess.PIPE)
with tarfile.open(fileobj=process.stdin, mode='w|', dereference=True) as archive:
    for name, path in files.items():
        archive.add(path, arcname=name, recursive=False)
process.stdin.close()
assert process.wait() == 0
verify = r'''
import hashlib,json,sys
from pathlib import Path
r=Path(sys.argv[1]);m=json.loads((r/'primary-manifest.json').read_text())
for name,entry in m['files'].items():
 p=r/name
 assert p.stat().st_size==entry['bytes'],name
 with p.open('rb') as f: assert hashlib.file_digest(f,'sha256').hexdigest()==entry['sha256'],name
print(json.dumps({'staged_bytes':m['aggregate_staged_bytes'],'logical_device_binding_bytes':m['logical_device_binding_bytes']}))
'''
result = subprocess.run(['ssh', stage['host'], shlex.join(['python3', '-B', '-c', verify, stage['directory']])], capture_output=True, text=True)
record['staging_returncode'] = result.returncode
record['staging_verification'] = result.stdout + result.stderr
(notes / 'sharkbox-primary-stage.json').write_text(json.dumps(record, indent=2) + '\n')
print(result.stdout + result.stderr, end='')
assert result.returncode == 0
