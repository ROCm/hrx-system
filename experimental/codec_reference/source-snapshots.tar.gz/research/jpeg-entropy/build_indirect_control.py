import hashlib
import json
from pathlib import Path
import subprocess

root = Path.cwd()
note = root / 'experimental/codec_reference/research/jpeg-entropy'
sources = [root / 'runtime/src/iree/hal/drivers/amdgpu' / name for name in ('aql_block_processor.c', 'aql_block_processor_profile.c')]
candidate = {source: source.read_bytes() for source in sources}
record = {'base': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(), 'restored': False, 'sources': {}}
command = ['bureau-bazel', 'build', '--tag=codec-indirect-baseline', '--config=asan', '--repo_env=IREE_ROCM_PATH=/home/ben/tools/rocm/10.1.0a20260822', '--repo_env=IREE_ROCM_DEPENDENCY_MODE=pinned', '--repo_env=IREE_HAL_AMDGPU_DEVICE_TOOLCHAIN=rocm', '--//runtime/src/iree/hal/drivers/amdgpu:targets=gfx1100,gfx1151', '//runtime/src/iree/hal/drivers/amdgpu:indirect_dispatch_test']
record['command'] = command
try:
    for source in sources:
        relative = str(source.relative_to(root))
        original = subprocess.check_output(['git', 'show', f'HEAD:{relative}'])
        assert candidate[source].count(b'// The patch kernel publishes both the dispatch packet and implicit counts.') == 1
        record['sources'][relative] = {'baseline': hashlib.sha256(original).hexdigest(), 'candidate': hashlib.sha256(candidate[source]).hexdigest()}
        source.write_bytes(original)
    subprocess.run(command, check=True)
finally:
    for source, data in candidate.items():
        source.write_bytes(data)
    record['restored'] = all(source.read_bytes() == data for source, data in candidate.items())
    (note / 'indirect-baseline-build.json').write_text(json.dumps(record, indent=2) + '\n')
