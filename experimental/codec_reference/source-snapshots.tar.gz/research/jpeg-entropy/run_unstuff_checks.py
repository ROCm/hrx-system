"""Stage small byte fixtures and run a foreground correctness lease."""
import argparse
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import tarfile

parser = argparse.ArgumentParser()
parser.add_argument('--witness', action='store_true')
arguments = parser.parse_args()
notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
stage = root / 'unstuff-small-stage.json'
files = {name: root / name for name in json.loads(stage.read_text())['files']}
files[stage.name] = stage
library = root / 'entropy-unstuff.loombc'
files[library.name] = library
assert sum(path.stat().st_size for path in files.values()) < 16 * 1024 * 1024
process = subprocess.Popen(['ssh', 'hrx-gorgon-4', 'tar -xf - -C ' + shlex.quote(str(root))], stdin=subprocess.PIPE)
with tarfile.open(fileobj=process.stdin, mode='w|') as archive:
    for name, path in files.items():
        archive.add(path, arcname=name, recursive=False)
process.stdin.close()
assert process.wait() == 0
suffix = 'witness' if arguments.witness else 'small'
command = ['/home/benvanik/.dotfiles/bin/benchmark-lock', '--label=codec-jpeg-unstuff-' + suffix,
           '--', 'env', 'LD_LIBRARY_PATH=/opt/rocm/lib', 'python3', '-B',
           str(root / 'device_tables_qualify.py'), '--stage=unstuff-small-stage.json',
           '--fixtures=unstuff-small/fixtures.json', '--runner=iree-test-loom-unsigned',
           '--runner-sha256=5e267978d7e937b1009f64a2e005913a4cc36c002b1f24eef44776cc4683a632',
           '--library=entropy-unstuff.loombc',
           '--library-sha256=' + hashlib.sha256(library.read_bytes()).hexdigest(),
           '--output-directory=unstuff-' + suffix + '-actual']
if arguments.witness:
    command.append('existing-exif')
with (notes / ('gorgon4-unstuff-' + suffix + '.log')).open('w') as stream:
    result = subprocess.run(['ssh', 'hrx-gorgon-4', shlex.join(command)], stdout=stream, stderr=subprocess.STDOUT)
status = subprocess.run(['ssh', 'hrx-gorgon-4', '/home/benvanik/.dotfiles/bin/benchmark-lock --status'], capture_output=True, text=True)
record = {'command': command, 'returncode': result.returncode, 'broker_status_after': status.stdout + status.stderr}
(notes / ('gorgon4-unstuff-' + suffix + '-lease.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
if result.returncode:
    print((notes / ('gorgon4-unstuff-' + suffix + '.log')).read_text()[-6000:])
    raise SystemExit(result.returncode)
output = notes / ('gorgon4-unstuff-' + suffix + '-qualified.json')
subprocess.run(['scp', 'hrx-gorgon-4:' + str(root / ('unstuff-' + suffix + '-actual/qualified.json')), str(output)], check=True)
print(len(json.loads(output.read_text())['rows']), 'exact cases', flush=True)
