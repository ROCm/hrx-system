"""Reuse the qualified disjoint batch for summary plus local-bridge timing."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

from device_fixture import read_words, write_words

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
tag = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['codec-jpeg-rebased-tools'])
linker = tag / 'loom/src/loom/tools/loom-link/loom-link'
records = []
for chunk_bytes, source_name in ((4096, 'batch16'), (1024, 'batch16-1024')):
    source = root / source_name
    output = root / ('bridge-' + source_name)
    output.mkdir(exist_ok=True)
    original = json.loads((source / 'stage.json').read_text())
    key = f'012mp-bus.jpg.r0.jpg-scan0-chunk{chunk_bytes}'
    bridge = read_words(root / 'bridge-large' / (key + '-bridges.npy'))
    write_words(output / 'bridges.npy', bridge * 16)
    sizes = dict(original['sizes'])
    sizes['bridges'] = len(bridge) * 16
    text = (source / 'summary.loom').read_text()
    for name in original['sizes']:
        old = f'path("{name}.npy")'
        assert text.count(old) == 1
        text = text.replace(old, f'path("../{source_name}/{name}.npy")')
    position = text.index('\n')
    text = text[:position] + '\nkernel.decl @jpeg_bridge() launch(%entropy: buffer, %jobs: buffer, %tables: buffer, %blocks: buffer, %summaries: buffer, %bridges: buffer)' + text[position:]
    insert = [f'  %bridges = check.file.read.npy path("bridges.npy") : tensor<{sizes["bridges"]}xi32>',
              f'  %bridge_output = check.generate.fill value(17) : tensor<{sizes["bridges"]}xi32>']
    position = text.index('  kernel.launch @jpeg_speculate')
    text = text[:position] + '\n'.join(insert) + '\n' + text[position:]
    types = ', '.join(f'tensor<{sizes[name]}xi32>' for name in ('entropy', 'jobs', 'tables', 'blocks', 'expected', 'bridges'))
    insert = [f'  kernel.launch @jpeg_bridge(%entropy, %jobs, %tables, %blocks, %output, %bridge_output) : ({types})',
              f'  check.expect.bitwise actual(%bridge_output) expected(%bridges) : tensor<{sizes["bridges"]}xi32>']
    position = text.index('  check.expect.bitwise actual(%output)')
    text = text[:position] + '\n'.join(insert) + '\n' + text[position:]
    (output / 'summary.loom').write_text(text)
    config = json.loads((source / 'config.json').read_text())
    config['jpeg'].update({'segments': 16, 'table_count': sizes['tables'] // 832, 'cache_tables': 0})
    (output / 'config.json').write_text(json.dumps(config, indent=2) + '\n')
    command = [str(linker), str(output / 'summary.loom'), str(root / 'entropy-bridges.loombc'),
               '--to=bc', '--output=' + str(output / 'summary.loombc')]
    subprocess.run(command, check=True)
    files = {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
             for path in output.iterdir() if path.is_file() and path.name != 'stage.json'}
    files.update({'../' + source_name + '/' + name + '.npy': original['files'][name + '.npy']
                  for name in original['sizes']})
    stage = {'batch': 16, 'jobs': original['jobs'], 'sizes': sizes, 'files': files,
             'library': {'path': 'entropy-bridges.loombc',
                         'sha256': hashlib.sha256((root / 'entropy-bridges.loombc').read_bytes()).hexdigest()},
             'scope': 'GPU speculation followed by bounded independent bridges from advertised summary exits. The wide launch rejects connected/ineligible entries. Root certification, coefficient output, IDCT, RGB, and device destuffing are absent; local bridges do not authorize output.',
             'link_command': command, 'source_fixture': key}
    (output / 'stage.json').write_text(json.dumps(stage, indent=2) + '\n')
    records.append({'directory': output.name, 'stage': stage})
    print(json.dumps({'directory': output.name, 'jobs': stage['jobs'], 'bridge_bytes': sizes['bridges'] * 4}), flush=True)
(notes / 'device-bridge-batches.json').write_text(json.dumps(records, indent=2) + '\n')
