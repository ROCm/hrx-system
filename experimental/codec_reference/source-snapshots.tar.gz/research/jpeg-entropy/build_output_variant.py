"""Build a bounded scratch variant against an existing exact-output fixture."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
parser = argparse.ArgumentParser()
parser.add_argument('name')
parser.add_argument('source')
parser.add_argument('base_fixture')
parser.add_argument('scope')
parser.add_argument('--pipeline')
arguments = parser.parse_args()
name = arguments.name
tags = json.loads(os.environ['BUREAU_TAG_ROOTS'])
base = Path(tags['codec-jpeg-rebased-tools'])
native = Path(tags['codec-jpeg-unsigned-opt'])
if arguments.pipeline:
    pipeline_path = notes / arguments.pipeline
else:
    pipeline = (notes / 'device_output_pipeline.cxx').read_text().replace('device_reconstruct.cxx', arguments.source)
    pipeline_path = notes / ('device_' + name.replace('-', '_') + '_pipeline.cxx')
    pipeline_path.write_text(pipeline)
library = root / ('entropy-' + name + '.loombc')
commands = [
    [str(base / 'loom/src/loom/tools/loom-import-cxx/loom-import-cxx'), str(pipeline_path),
     '--output=' + str(root / ('entropy-' + name + '.loom'))],
    [str(base / 'loom/src/loom/tools/loom-link/loom-link'), str(root / ('entropy-' + name + '.loom')),
     '--to=bc', '--output=' + str(library)],
    [str(native / 'loom/src/loom/tools/loom-compile/loom-compile'), str(library),
     '--root=jpeg_reconstruct', '--target=amdgpu:gfx1151',
     '--config-file=' + str(root / arguments.base_fixture / 'config.json'),
     '--output=' + str(root / ('jpeg_reconstruct-' + name + '.hsaco')),
     '--compile-report=details', '--compile-report-output=' + str(root / (name + '-report.json'))]]
for command in commands:
    subprocess.run(command, check=True)
metrics = json.loads((root / (name + '-report.json')).read_text())['entries']['rows'][0]
metrics = {key: metrics[key] for key in ('instruction_count', 'code_byte_count',
           'private_memory_bytes', 'local_memory_bytes', 'target_resources')}
print(json.dumps(metrics), flush=True)
original = root / arguments.base_fixture
fixture = root / (name + '-batch16-1024')
fixture.mkdir(exist_ok=True)
paths = {}
def relocate(match):
    path = (original / match[1]).resolve()
    relative = os.path.relpath(path, fixture)
    paths[relative] = path
    return 'check.file.read.npy path("' + relative + '")'
text = re.sub(r'check.file.read.npy path\("([^"]+)"\)', relocate, (original / 'summary.loom').read_text())
(fixture / 'summary.loom').write_text(text)
(fixture / 'config.json').write_bytes((original / 'config.json').read_bytes())
command = [str(base / 'loom/src/loom/tools/loom-link/loom-link'), str(fixture / 'summary.loom'),
           str(library), '--to=bc', '--output=' + str(fixture / 'summary.loombc')]
subprocess.run(command, check=True)
commands.append(command)
stage = json.loads((original / 'stage.json').read_text())
stage['files'] = {relative: hashlib.sha256(path.read_bytes()).hexdigest() for relative, path in paths.items()}
stage['files'].update({path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                      for path in fixture.iterdir() if path.is_file() and path.name != 'stage.json'})
stage['library'] = {'path': library.name, 'sha256': hashlib.sha256(library.read_bytes()).hexdigest()}
stage['scope'] = arguments.scope
stage['link_command'] = command
stage['retention'] = 'Reuses existing expected-output arrays; no additional large payload.'
(fixture / 'stage.json').write_text(json.dumps(stage, indent=2) + '\n')
record = {'commands': commands, 'stage': stage, 'metrics': metrics,
          'native_sha256': hashlib.sha256((root / ('jpeg_reconstruct-' + name + '.hsaco')).read_bytes()).hexdigest(),
          'sources': {filename: hashlib.sha256((notes / filename).read_bytes()).hexdigest() for filename in
                      ('build_output_variant.py', arguments.source, pipeline_path.name, 'device_entropy_cursor.h')}}
(notes / ('device-output-' + name + '.json')).write_text(json.dumps(record, indent=2) + '\n')
print(name + ' ready', flush=True)
