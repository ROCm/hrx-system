"""Derive compact tables and exhaust all 16-bit prefixes before GPU execution."""
import hashlib
import json
import os
from pathlib import Path
import re

from device_fixture import read_words, write_words

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
table_directory = root / 'twolevel-tables'
table_directory.mkdir(exist_ok=True)
converted = {}
table_records = {}
read_pattern = re.compile(r'%([a-z_]+) = check.file.read.npy path\("([^"]+)"\) : tensor<(\d+)x(i\d+)>')


def table_words(original):
    key = hashlib.sha256(b''.join(value.to_bytes(4, 'little') for value in original)).hexdigest()
    if key in table_records:
        return table_records[key]['words']
    codes = []
    for length in range(1, 17):
        first, count, base = original[512 + length * 3:515 + length * 3]
        codes.extend((length, first + index, original[563 + base + index]) for index in range(count))
    assert len(codes) <= 256
    words = list(original[:512])
    groups = {}
    for length, code, symbol in codes:
        if length > 9:
            groups.setdefault(code >> (length - 9), []).append((length, code, symbol))
    for prefix, entries in sorted(groups.items()):
        assert words[prefix] == 0
        width = max(length for length, code, symbol in entries) - 9
        offset = len(words)
        words.extend([0] * (1 << width))
        words[prefix] = 0x80000000 | ((23 - width) << 24) | (((1 << width) - 1) << 16) | offset
        for length, code, symbol in entries:
            suffix = code & ((1 << (length - 9)) - 1)
            begin = suffix << (width - (length - 9))
            end = (suffix + 1) << (width - (length - 9))
            for index in range(begin, end):
                assert words[offset + index] == 0
                words[offset + index] = (length << 8) | symbol
    used = len(words)
    # Canonical code ordering permits at most one mixed/partial nine-bit prefix
    # at each of the seven long lengths. All other allocated suffix entries
    # correspond one-for-one to symbols: <=256 + 7*127 secondary entries.
    assert used <= 512 + 256 + 7 * 127 < 2048
    words.extend([0] * (2048 - len(words)))
    expected = [0] * 65536
    for length, code, symbol in codes:
        for index in range(code << (16 - length), (code + 1) << (16 - length)):
            assert expected[index] == 0
            expected[index] = (length << 8) | symbol
    for prefix, reference in enumerate(expected):
        bits = prefix << 16
        packed = words[bits >> 23]
        if packed & 0x80000000:
            index = (packed & 2047) + ((bits >> ((packed >> 24) & 31)) & ((packed >> 16) & 127))
            assert index < used
            packed = words[index]
        assert packed == reference, (prefix, packed, reference)
    table_records[key] = {'words': words, 'used_words': used, 'symbols': len(codes),
                          'secondary_groups': len(groups), 'prefixes_checked': 65536}
    return words


def convert_table(path):
    if path not in converted:
        original = read_words(path)
        assert len(original) % 832 == 0
        data = []
        for begin in range(0, len(original), 832):
            data.extend(table_words(original[begin:begin + 832]))
        name = hashlib.sha256(path.read_bytes()).hexdigest() + '.npy'
        target = table_directory / name
        write_words(target, data)
        converted[path] = target, len(data)
    return converted[path]


def scenario(source, destination):
    paths = {}
    table_size = None
    def relocate(match):
        nonlocal table_size
        name, relative, size, element = match.groups()
        path = (source.parent / relative).resolve()
        if name == 'tables':
            path, size = convert_table(path)
            table_size = size
        paths[str(path.relative_to(root))] = hashlib.sha256(path.read_bytes()).hexdigest()
        return f'%{name} = check.file.read.npy path("{os.path.relpath(path, destination.parent)}") : tensor<{size}x{element}>'
    text = read_pattern.sub(relocate, source.read_text())
    assert table_size
    lines = []
    for line in text.splitlines():
        if line.startswith('  kernel.launch '):
            match = re.fullmatch(r'(  kernel.launch @\w+)\((.*)\) : \((.*)\)', line)
            assert match, line
            names = match[2].split(', ')
            types = match[3].split(', ')
            if '%tables' in names:
                types[names.index('%tables')] = f'tensor<{table_size}xi32>'
            line = match[1] + '(' + ', '.join(names) + ') : (' + ', '.join(types) + ')'
        lines.append(line)
    destination.write_text('\n'.join(lines) + '\n')
    return paths, table_size


if __name__ == '__main__':
    for family in ('small', 'large'):
        original = root / ('layout-' + family)
        output = root / ('twolevel-' + family)
        output.mkdir(exist_ok=True)
        metadata = json.loads((original / 'fixtures.json').read_text())
        paths = {}
        for case in metadata['cases']:
            key = case['key']
            found, size = scenario(original / (key + '.loom'), output / (key + '.loom'))
            paths.update(found)
            case['sizes']['tables'] = size
            (output / (key + '.json')).write_bytes((original / (key + '.json')).read_bytes())
        (output / 'fixtures.json').write_text(json.dumps(metadata, indent=2) + '\n')
        paths.update({str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
                      for path in output.iterdir() if path.is_file()})
        (root / (output.name + '-stage.json')).write_text(json.dumps({'files': paths}, indent=2) + '\n')
        print(family, len(metadata['cases']), flush=True)
    original = root / 'certified-malformed'
    output = root / 'twolevel-malformed'
    output.mkdir(exist_ok=True)
    paths = {}
    for case in json.loads((original / 'stage.json').read_text())['cases']:
        key = case['key']
        found, size = scenario(original / (key + '.loom'), output / (key + '.loom'))
        paths.update(found)
        (output / (key + '.json')).write_bytes((root / 'layout-malformed-config' / (key + '.json')).read_bytes())
    manifest = {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                for path in output.iterdir() if path.is_file() and path.name != 'manifest.json'}
    manifest.update({os.path.relpath(root / name, output): digest for name, digest in paths.items()})
    (output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    original = root / 'rgb-store-batch16-1024'
    output = root / 'twolevel-input-batch16-1024'
    output.mkdir(exist_ok=True)
    paths, size = scenario(original / 'summary.loom', output / 'summary.loom')
    (output / 'config.json').write_bytes((original / 'config.json').read_bytes())
    stage = json.loads((original / 'stage.json').read_text())
    stage['sizes']['tables'] = size
    stage['files'] = {os.path.relpath(root / name, output): digest for name, digest in paths.items()}
    stage['files'].update({path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                          for path in output.iterdir() if path.is_file() and path.name != 'stage.json'})
    (output / 'stage.json').write_text(json.dumps(stage, indent=2) + '\n')
    record = {'tables': {key: {name: value for name, value in entry.items() if name != 'words'}
                          for key, entry in table_records.items()},
              'allocated_words_per_table': 2048, 'sources': {name: hashlib.sha256((notes / name).read_bytes()).hexdigest()
                  for name in ('twolevel_fixtures.py', 'twolevel_source.py', 'device_entropy_cursor_twolevel.h')}}
    (notes / 'twolevel-tables-qualified.json').write_text(json.dumps(record, indent=2) + '\n')
    print(len(table_records), 'distinct tables; used words', sorted({entry['used_words'] for entry in table_records.values()}), flush=True)
