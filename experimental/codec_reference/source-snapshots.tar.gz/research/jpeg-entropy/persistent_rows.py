"""Cold evidence: bounded component rows through the real model's filter order.

Captured, qualified IDCT output supplies the producer. This does not execute
entropy decoding or prove a GPU scheduler. Complete native RGB and the retained
native model-resize hash independently check the changed storage lifetime.
Only JSON/hashes are retained; no new full-image artifact is written.
"""

import hashlib
import json
from pathlib import Path

import numpy as np

from sequential import parse
from device_fixture import input_bytes


NOTES = Path(__file__).resolve().parent
ROOT = Path(json.loads((NOTES / "device-active.json").read_text())["directory"])
FIXTURE = ROOT / "mixed-current"
MODEL = ROOT / "native-projector/sources/experimental/loom_serve/models/qwen"
F32 = np.float32


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def cubic(position):
    x = F32(abs(position))
    if x < 1:
        product = F32(1.5) * x
        quadratic = (product - F32(2.5)) * x
        return quadratic * x + F32(1)
    if x < 2:
        product = F32(-0.5) * x
        quadratic = (product + F32(2.5)) * x
        return (quadratic - F32(4)) * x + F32(2)
    return F32(0)


def axis_plan(source, target):
    """Preserve the actual vision_pixels.loom scalar rounding and tap order."""
    scale = F32(F32(source) / F32(target))
    support = F32(scale * F32(2)) if scale >= 1 else F32(2)
    inverse = F32(1.0 / float(scale)) if scale >= 1 else F32(1)
    maximum_taps = int(np.ceil(support)) * 2 + 1
    plan = []
    for output in range(target):
        center = F32(float(scale) * (output + 0.5))
        start = max(int(float(F32(center - support)) + 0.5), 0)
        limit = min(int(float(F32(center + support)) + 0.5), source)
        count = min(max(limit - start, 0), maximum_taps)
        weights = np.array([cubic(F32((index - float(center) + 0.5) * float(inverse)))
                            for index in range(start, start + count)], dtype=np.float32)
        total = F32(0)
        for weight in weights:
            total = F32(total + weight)
        weights /= total
        plan.append((start, weights))
    return plan


class ComponentRows:
    def __init__(self, frame, pixels, origin):
        # Immutable mapped oracle; it stands in for completed IDCT rows.
        self.pixels = pixels
        # Actual encoded geometry and per-component sampling.
        self.frame = frame
        # Maximum source sampling factors defining one interleaved MCU row.
        self.horizontal = max(c.horizontal for c in frame.components)
        self.vertical = max(c.vertical for c in frame.components)
        # Three physical slots retain neighboring MCU rows, never a full frame.
        self.rows = []
        # Original component base and actual sample geometry.
        self.planes = []
        for component in frame.components:
            width = (frame.width * component.horizontal + self.horizontal - 1) // self.horizontal
            height = (frame.height * component.vertical + self.vertical - 1) // self.vertical
            self.planes.append((origin, width, height))
            self.rows.append(np.empty((3, component.vertical * 8, width), dtype=np.uint8))
            origin += component.block_width * component.block_height * 64
        # Sequence identity protects slot wrap and detects missing producer work.
        self.generations = [-1] * 3
        # Next encoded MCU row the simulated IDCT producer may publish.
        self.next_row = 0
        # Exact useful bytes fetched from the captured IDCT oracle.
        self.produced_bytes = 0
        # Live sample rows required by this RGB row, protecting old-slot reuse.
        self.required = set()

    def prepare(self, y):
        needed = set()
        for component, (_, width, height) in zip(self.frame.components, self.planes):
            horizontal = self.horizontal // component.horizontal
            vertical = self.vertical // component.vertical
            row = y // vertical
            needed.add(row // (component.vertical * 8))
            halo = vertical == 2 and (horizontal == 1 or (horizontal == 2 and width > 2))
            if halo:
                neighbor = min(max(row + (1 if y & 1 else -1), 0), height - 1)
                needed.add(neighbor // (component.vertical * 8))
        self.required = needed
        while self.next_row <= max(needed):
            current = self.next_row
            slot = current % 3
            assert self.generations[slot] not in needed
            for component, (origin, width, height), ring in zip(
                    self.frame.components, self.planes, self.rows):
                columns = np.arange(width, dtype=np.int64)
                for local in range(component.vertical * 8):
                    row = current * component.vertical * 8 + local
                    if row >= height:
                        break
                    addresses = origin + ((row // 8) * component.block_width + columns // 8) * 64
                    addresses += (row % 8) * 8 + columns % 8
                    ring[slot, local] = self.pixels[addresses]
                    self.produced_bytes += width
            self.generations[slot] = current
            self.next_row += 1

    def sample(self, component_index, row, columns):
        component = self.frame.components[component_index]
        _, width, height = self.planes[component_index]
        row = min(max(row, 0), height - 1)
        owner = row // (component.vertical * 8)
        assert owner in self.required and self.generations[owner % 3] == owner
        return self.rows[component_index][owner % 3, row % (component.vertical * 8),
                                          np.clip(columns, 0, width - 1)].astype(np.int32)

    def rgb(self, y, color_space):
        self.prepare(y)
        x = np.arange(self.frame.width, dtype=np.int64)
        values = []
        for index, component in enumerate(self.frame.components):
            horizontal = self.horizontal // component.horizontal
            vertical = self.vertical // component.vertical
            width = self.planes[index][1]
            column, row = x // horizontal, y // vertical
            value = self.sample(index, row, column)
            neighbor_x = column + np.where(x & 1, 1, -1)
            neighbor_y = row + (1 if y & 1 else -1)
            if horizontal == 2 and vertical == 2 and width > 2:
                value = (9 * value + 3 * self.sample(index, row, neighbor_x) +
                         3 * self.sample(index, neighbor_y, column) +
                         self.sample(index, neighbor_y, neighbor_x) + np.where(x & 1, 7, 8)) >> 4
            elif horizontal == 2 and vertical == 1 and width > 2:
                value = (3 * value + self.sample(index, row, neighbor_x) + np.where(x & 1, 2, 1)) >> 2
            elif horizontal == 1 and vertical == 2:
                value = (3 * value + self.sample(index, neighbor_y, column) + (2 if y & 1 else 1)) >> 2
            values.append(value)
        if color_space == 1:
            channels = [values[0]] * 3
        elif color_space == 2:
            channels = values
        else:
            assert color_space == 3
            luminance, cb, cr = values
            cb = cb - 128
            cr = cr - 128
            channels = [luminance + ((91881 * cr + 32768) >> 16),
                        luminance + ((-22554 * cb - 46802 * cr + 32768) >> 16),
                        luminance + ((116130 * cb + 32768) >> 16)]
        return np.stack([np.clip(channel, 0, 255) for channel in channels], axis=1).astype(np.uint8)


def evaluate(image, pixels, expected_rgb, resize):
    encoded = input_bytes(image["name"])
    assert hashlib.sha256(encoded).hexdigest() == image["input_sha256"]
    frame = parse(encoded)
    assert len(frame.scans) == len(frame.scans[0].segments) == 1
    header = image["header"]
    source = ComponentRows(frame, pixels, header[3] * 4)
    color_space = image["numerical_reference"][-1]["color_space"]
    row_bytes = frame.width * 3
    expected = expected_rgb[header[14]:header[14] + frame.height * row_bytes]
    expected = expected.reshape(frame.height, frame.width, 3)
    rgb_hash = hashlib.sha256()
    output_hash = hashlib.sha256()
    retained_rows = {}
    maximum_retained = 0
    output_row = 0
    horizontal = axis_plan(frame.width, 1152) if resize else []
    vertical = axis_plan(frame.height, 864) if resize else []
    maximum_horizontal = max((len(weights) for _, weights in horizontal), default=0)
    maximum_vertical = max((len(weights) for _, weights in vertical), default=0)
    # Vectorize across destination columns while preserving per-pixel tap order.
    horizontal_indices = np.zeros((maximum_horizontal, 1152), dtype=np.int64)
    horizontal_weights = np.zeros((maximum_horizontal, 1152), dtype=np.float32)
    for column, (start, weights) in enumerate(horizontal):
        horizontal_indices[:len(weights), column] = np.arange(start, start + len(weights))
        horizontal_weights[:len(weights), column] = weights
    for y in range(frame.height):
        row = source.rgb(y, color_space)
        assert np.array_equal(row, expected[y]), (image["name"], y)
        rgb_hash.update(row.tobytes())
        if not resize:
            continue
        filtered = np.zeros((1152, 3), dtype=np.float32)
        for indices, weights in zip(horizontal_indices, horizontal_weights):
            product = row[indices].astype(np.float32) * weights[:, None]
            filtered += product
        retained_rows[y] = filtered
        maximum_retained = max(maximum_retained, len(retained_rows))
        while output_row < len(vertical):
            start, weights = vertical[output_row]
            if start + len(weights) > y + 1:
                break
            value = np.zeros_like(filtered)
            for index, weight in enumerate(weights):
                value += retained_rows[start + index] * weight
            result = np.clip(np.rint(value), 0, 255).astype(np.uint8)
            output_hash.update(result.tobytes())
            output_row += 1
            first_live = vertical[output_row][0] if output_row < len(vertical) else frame.height
            for retired in [index for index in retained_rows if index < first_live]:
                del retained_rows[retired]
        assert len(retained_rows) <= maximum_vertical
    expected_component_bytes = sum(width * height for _, width, height in source.planes)
    assert source.produced_bytes == expected_component_bytes
    if resize:
        assert output_row == 864 and not retained_rows
        native = json.loads((NOTES / "gorgon4-resize-metrics.json").read_text())
        assert output_hash.hexdigest() == native["output_sha256"]["loom-float32"], output_hash.hexdigest()
    return {"image": image["name"], "width": frame.width, "height": frame.height,
            "input_sha256": image["input_sha256"], "complete_rgb_exact": True,
            "rgb_sha256": rgb_hash.hexdigest(), "component_bytes_produced_once": source.produced_bytes,
            "component_ring_bytes": sum(row.nbytes for row in source.rows),
            "full_component_bytes": header[15] + (2 * header[16] if len(frame.components) == 3 else 0),
            "full_rgb_bytes": frame.height * row_bytes, "rgb_row_bytes": row_bytes,
            "resize": ({"width": 1152, "height": 864, "horizontal_maximum_taps": maximum_horizontal,
                        "vertical_maximum_taps": maximum_vertical, "peak_horizontal_rows": maximum_retained,
                        "horizontal_ring_bytes": maximum_retained * 1152 * 3 * 4,
                        "vertical_accumulator_bytes": 1152 * 3 * 4,
                        "output_row_bytes": 1152 * 3,
                        "output_sha256": output_hash.hexdigest(), "native_output_exact": True} if resize else None)}


def main():
    stage = json.loads((NOTES / "sharkbox-primary-stage.json").read_text())
    for name in ("pixels.npy", "rgb.npy", "headers.npy", "intervals.npy"):
        assert digest(FIXTURE / name) == stage["files"]["primary/" + name]["sha256"]
    pixels = np.load(FIXTURE / "pixels.npy", mmap_mode="r").view(np.uint8)
    rgb = np.load(FIXTURE / "rgb.npy", mmap_mode="r").view(np.uint8)
    result = {"scope": "Cold streaming-storage/numerical witness using captured IDCT output, not GPU scheduling or performance.",
              "retention": "Reuses immutable mmap inputs; writes only this JSON. No full-frame candidate output or executable.",
              "source_sha256": digest(Path(__file__)), "numpy_version": np.__version__,
              "model_source_sha256": {name: digest(MODEL / name) for name in
                                      ("vision_pixels.loom", "kernels/qwen38/vision_resize.loom")},
              "evidence_sha256": {name: digest(NOTES / name) for name in
                                  ("sharkbox-primary-stage.json", "gorgon4-resize-metrics.json")}, "rows": []}
    for index, image in enumerate(stage["fixture"]["images"][:4]):
        row = evaluate(image, pixels, rgb, resize=index == 0)
        result["rows"].append(row)
        print(json.dumps(row), flush=True)
    (NOTES / "persistent-rows.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
