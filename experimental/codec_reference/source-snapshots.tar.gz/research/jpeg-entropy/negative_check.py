"""Qualify malformed entropy without weakening valid-peer output contracts."""
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import tarfile


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def run(root):
    directory = root / "negative-check"
    manifest = json.loads((directory / "manifest.json").read_text())
    assert os.environ["BENCHMARK_LOCK_LEASE_ID"]
    for name, expected in manifest["files"].items():
        assert digest(root / name) == expected, name
    tree = ast.parse((root / "cpu-current/machine-state.py").read_text())
    node = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "state")
    namespace = dict(globals())
    exec(compile(ast.Module(body=[node], type_ignores=[]), "machine-state.py", "exec"), namespace)
    state = namespace["state"]
    record = {"manifest": manifest, "before": state(), "rows": [], "passed": False}
    output = directory / "result.json"
    output.write_text(json.dumps(record, indent=2) + "\n")
    assert not record["before"]["kfd_processes"] and not record["before"]["drm"]
    cases = [{"directory": "mixed-negative-base", "mutation": None}, *manifest["fixture"]["cases"]]
    try:
        for case in cases:
            command = [str(root / "codec_negative_probe"),
                       "--jpeg_fixture=" + str(root / case["directory"]),
                       "--gtest_filter=JpegCommandTest.CompressedToRgb", "--jpeg_access=true",
                       "--amdgpu_asan=true", "--amdgpu_asan_report_policy=fail-device"]
            negative = case["mutation"] is not None
            if negative:
                command.append("--jpeg_regions=verification.txt")
            process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            stdout, stderr = process.communicate()
            rows = [json.loads(line) for line in stdout.splitlines() if line.startswith("{")]
            result = {"directory": case["directory"], "mutation": case["mutation"],
                      "ordinal": case.get("ordinal"), "command": command, "pid": process.pid,
                      "returncode": process.returncode, "rows": rows, "stdout": stdout, "stderr": stderr}
            record["rows"].append(result)
            output.write_text(json.dumps(record, indent=2) + "\n")
            assert process.returncode == 0, stdout + stderr
            phase = "regions" if negative else "exact"
            checks = [row for row in rows if row.get("phase") == phase]
            assert len(checks) == 26 and len({row["binding"] for row in checks}) == 26
            errors = [row for row in rows if row.get("phase") == "body_error"]
            if negative:
                assert len(errors) == 1 and errors[0]["image"] == case["ordinal"]
                assert errors[0]["value"] in (256, 512, 768, 1024, 1280)
            else:
                assert not errors
                assert all(row["bytes"] == row["checked_bytes"] for row in checks)
            print(json.dumps({"case": case["directory"], "checks": len(checks), "errors": errors}), flush=True)
        record["passed"] = True
    finally:
        record["after"] = state()
        record["after_processes"] = {}
        for process_id in record["after"]["kfd_processes"]:
            path = Path("/proc") / process_id / "comm"
            try:
                record["after_processes"][process_id] = path.read_text().strip()
            except FileNotFoundError:
                record["after_processes"][process_id] = None
        record["retired"] = (not record["after"]["drm"] and
            set(record["after"]["kfd_processes"]) <= {str(row["pid"]) for row in record["rows"]} and
            all(value is None for value in record["after_processes"].values()))
        output.write_text(json.dumps(record, indent=2) + "\n")
    assert record["retired"]


def stage():
    notes = Path(__file__).resolve().parent
    root = Path(json.loads((notes / "device-active.json").read_text())["directory"])
    fixture = json.loads((notes / "entropy-validity-cases.json").read_text())
    build = json.loads((notes / "negative-caller-build.json").read_text())
    capture = json.loads(subprocess.check_output(["bureau-bazel", "tag", "inspect", build["tag"], "--json"], text=True))
    assert build["restored"] and build["build_returncode"] == 0 and build["configuration"] == "asan"
    assert capture["capture"] == build["capture"]["capture"]
    assert digest(notes / "command_probe.cc") == build["source_sha256"]
    tag = Path(json.loads(os.environ["BUREAU_TAG_ROOTS"])[build["tag"]])
    binary = tag / "loom/src/loom/tooling/target/amdgpu/serve/codec_command_probe"
    files = {"codec_negative_probe": binary, "negative-check/check.py": Path(__file__).resolve()}
    fixture_directories = [("mixed-negative-base", fixture["baseline"]),
                           *((case["directory"], case["stage"]) for case in fixture["cases"])]
    for relative, fixture_stage in fixture_directories:
        assert json.loads((root / relative / "stage.json").read_text()) == fixture_stage
        for name, expected in fixture_stage["files"].items():
            path = root / relative / name
            assert digest(path) == expected, path
            files[str(Path(relative) / name)] = path
        files[str(Path(relative) / "stage.json")] = root / relative / "stage.json"
    hashes = {name: digest(path) for name, path in files.items()}
    prior = json.loads((notes / "gorgon4-cohort-64-comparison.json").read_text())
    hashes["cpu-current/machine-state.py"] = prior["manifest"]["files"]["cpu-current/machine-state.py"]
    manifest = {"files": hashes, "fixture": fixture, "build": build,
                "scope": "ASAN/access correctness only; full exact baseline followed by 27 entropy-invalid cases."}
    directory = root / "negative-check"
    directory.mkdir(exist_ok=True)
    manifest_path = directory / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
    files["negative-check/manifest.json"] = manifest_path
    assert sum(path.stat().st_size for path in files.values()) < 192 * 1024**2
    process = subprocess.Popen(["ssh", "hrx-gorgon-4", "tar -xf - -C " + shlex.quote(str(root))], stdin=subprocess.PIPE)
    with tarfile.open(fileobj=process.stdin, mode="w|", dereference=True) as archive:
        for name, path in files.items():
            archive.add(path, arcname=name, recursive=False)
    process.stdin.close()
    assert process.wait() == 0
    command = ["/home/benvanik/.dotfiles/bin/benchmark-lock", "--label=codec-jpeg-entropy-validity", "--",
               "timeout", "--signal=INT", "--kill-after=10s", "300s", "env", "LD_LIBRARY_PATH=/opt/rocm/lib",
               "python3", "-B", str(directory / "check.py"), "--remote", str(root)]
    log = notes / "gorgon4-entropy-validity.log"
    with log.open("w") as stream:
        result = subprocess.run(["ssh", "hrx-gorgon-4", shlex.join(command)], stdout=stream, stderr=subprocess.STDOUT)
    status = subprocess.run(["ssh", "hrx-gorgon-4", "~/.dotfiles/bin/benchmark-lock --status"], capture_output=True, text=True)
    saved = subprocess.run(["ssh", "hrx-gorgon-4", "cat " + shlex.quote(str(directory / "result.json"))], capture_output=True)
    if saved.returncode == 0:
        (notes / "gorgon4-entropy-validity.json").write_bytes(saved.stdout)
    receipt = {"command": command, "returncode": result.returncode, "broker_status_after": status.stdout + status.stderr,
               "broker_status_returncode": status.returncode, "result_retrieval_returncode": saved.returncode,
               "manifest_sha256": digest(manifest_path), "log_sha256": digest(log)}
    (notes / "gorgon4-entropy-validity-run.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(log.read_text(), end="")
    print(status.stdout + status.stderr, end="", flush=True)
    assert result.returncode == 0 and status.returncode == 0 and saved.returncode == 0


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "--remote":
        run(Path(sys.argv[2]))
    else:
        stage()
