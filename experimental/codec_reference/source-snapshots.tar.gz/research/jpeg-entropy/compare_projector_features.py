"""Quantify recorded trained-projector output; no GPU or benchmark lease."""
from array import array
import hashlib
import json
import math
from pathlib import Path
import sys

directory = Path(sys.argv[1])
manifest = json.loads((directory / 'manifest.json').read_text())
columns, rows = (value // 32 for value in manifest['target_geometry'])
feature_count = columns * rows * 5120
names = ('jpeg', 'islow', 'loom-float32', 'cosine', 'float', 'ifast')
observations = directory / 'observations'
artifacts = {}
features = {}
norm_squared = {}
for name in names:
    for suffix in ('prepared', 'features'):
        path = observations / (name + '.' + suffix)
        artifacts[path.name] = {'bytes': path.stat().st_size,
                                'sha256': hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()}
    values = array('f')
    with (observations / (name + '.features')).open('rb') as stream:
        values.fromfile(stream, feature_count)
        assert not stream.read(1), name
    assert values.itemsize == 4 and sys.byteorder == 'little'
    assert all(math.isfinite(value) for value in values), name
    features[name] = values
    norm_squared[name] = math.fsum(value * value for value in values)

control = {suffix: artifacts['jpeg.' + suffix] == artifacts['islow.' + suffix]
           for suffix in ('prepared', 'features')}
result = {'shape': [columns * rows, 5120], 'type': 'little-endian float32',
          'artifacts': artifacts, 'jpeg_islow_equal': control,
          'feature_l2_norm': {name: math.sqrt(value) for name, value in norm_squared.items()},
          'comparisons': []}
assert all(control.values()), control
for candidate, reference in [('islow', 'cosine'), ('loom-float32', 'cosine'),
                             ('float', 'cosine'), ('ifast', 'cosine'),
                             ('loom-float32', 'islow')]:
    values, baseline = features[candidate], features[reference]
    squared_error = math.fsum((value - expected) ** 2 for value, expected in zip(values, baseline))
    maximum, index = max((abs(value - expected), index)
                         for index, (value, expected) in enumerate(zip(values, baseline)))
    dot = math.fsum(value * expected for value, expected in zip(values, baseline))
    row = {'candidate': candidate, 'reference': reference, 'count': len(values),
           'different': sum(value != expected for value, expected in zip(values, baseline)),
           'maximum_absolute_error': maximum, 'maximum_index': index,
           'rmse': math.sqrt(squared_error / len(values)),
           'relative_l2_error': math.sqrt(squared_error / norm_squared[reference]),
           'cosine_similarity': dot / math.sqrt(norm_squared[candidate] * norm_squared[reference])}
    result['comparisons'].append(row)
    print(json.dumps(row), flush=True)
(directory / 'projector-metrics.json').write_text(json.dumps(result, indent=2) + '\n')
