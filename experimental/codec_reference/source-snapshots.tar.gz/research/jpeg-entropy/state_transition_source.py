"""Retain only the phase or additive totals each checked entropy caller needs."""
from pathlib import Path

notes = Path(__file__).resolve().parent
source = (notes / 'device_entropy_cursor_short.h').read_text()
begin = source.index('static LOOM_FORCE_INLINE Symbol advance_symbol(')
end = source.index('static LOOM_FORCE_INLINE Cursor advance(', begin)
transition = source[begin:end]
transition = transition.replace('static LOOM_FORCE_INLINE Symbol advance_symbol(',
    'template <bool RetainTotals>\nstatic LOOM_FORCE_INLINE Cursor advance_state(')
transition = transition.replace('return advance_symbol_slow(words, tables, blocks, limit, cursor);', '''Cursor result = advance_symbol_slow(words, tables, blocks, limit, cursor).cursor;
    if constexpr (!RetainTotals) {
      result.blocks = cursor.blocks;
      result.predictors = cursor.predictors;
    }
    return result;''')
begin = transition.index('  unsigned amplitude_mask =')
end = transition.index('  if (cursor.coefficient == 0)', begin)
amplitude = transition[begin:end]
amplitude = amplitude[:amplitude.index('  unsigned output_index =')]
transition = transition[:begin] + transition[end:]
old = '''    unsigned component = descriptor & 255;
    cursor.predictors[component] += amplitude;'''
new = '''    if constexpr (RetainTotals) {
''' + ''.join('    ' + line + '\n' for line in amplitude.splitlines()) + '''      unsigned component = descriptor & 255;
      cursor.predictors[component] += amplitude;
    }'''
assert transition.count(old) == 1
transition = transition.replace(old, new)
for line in ('    output_index = 0;\n', '    output_value = cursor.predictors[component];\n',
             '        output_index = index;\n', '        output_value = amplitude;\n'):
    assert transition.count(line) == 1
    transition = transition.replace(line, '')
transition = transition.replace('      ++cursor.blocks;',
                                '      if constexpr (RetainTotals) ++cursor.blocks;')
transition = transition.replace('return {cursor, output_index, output_value};', 'return cursor;')
(notes / 'device_entropy_cursor_state.h').write_text(
    '#pragma once\n#include "device_entropy_cursor_certified.h"\n\n' + transition)

speculate = (notes / 'device_entropy_partitioned.cxx').read_text()
old = 'cursor = advance(words, tables, blocks, limit, cursor);'
assert speculate.count(old) == 3
speculate = speculate.replace(old,
    'cursor = advance_state<false>(words, tables, blocks, limit, cursor);', 1)
speculate = speculate.replace(old,
    'cursor = advance_state<true>(words, tables, blocks, limit, cursor);')
old = '  unsigned first_bit = cursor.position;'
assert speculate.count(old) == 1
speculate = speculate.replace(old, '''  // Only phase survives lookbehind. Published totals start at this boundary.
  cursor.blocks = 0;
  cursor.predictors = {};
''' + old)
(notes / 'device_entropy_state.cxx').write_text(speculate)
bridge = (notes / 'device_bridge.cxx').read_text()
old = 'cursor = advance(words, tables, blocks, bit_limit, cursor);'
assert bridge.count(old) == 1
bridge = bridge.replace(old, 'cursor = advance_state<true>(words, tables, blocks, bit_limit, cursor);')
(notes / 'device_bridge_state.cxx').write_text(bridge)
pipeline = '#include "device_entropy_cursor_state.h"\n'
pipeline += '''[[loom::config("jpeg.output_partitions"), loom::where(loom::predicate::range(2u, 8u))]]
extern const unsigned output_partitions;
'''
for name in ('device_entropy_state.cxx', 'device_bridge_state.cxx',
             'device_certify_partitioned.cxx', 'device_reconstruct_compact.cxx'):
    pipeline += '\n' + (notes / name).read_text().replace('#include "device_entropy_cursor.h"', '') + '\n'
(notes / 'device_state_pipeline.cxx').write_text(pipeline)
