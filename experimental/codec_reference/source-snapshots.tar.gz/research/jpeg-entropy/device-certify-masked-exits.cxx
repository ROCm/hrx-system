#include "device_entropy_cursor.h"

[[loom::config("jpeg.segments"), loom::where(loom::predicate::range(1u, 1048576u))]]
extern const unsigned certification_segments;

using Sums = unsigned __attribute__((ext_vector_type(4)));
using loom::kernel::scan_direction;
using loom::kernel::scan_mode;

static loom::kernel::configuration configure_segment_groups() {
  return {{certification_segments, 1, 1}, {loom::target::subgroup::size() * 4, 1, 1}};
}

static loom::kernel::configuration configure_segment_roots() {
  unsigned threads = loom::target::subgroup::size();
  return {{(certification_segments + threads - 1) / threads, 1, 1}, {threads, 1, 1}};
}

// Suffix records retain sequence limits and additive block/DC totals. The
// difference between two suffixes describes a contiguous summary range; it
// does not certify that range as part of the actual JPEG trajectory.
[[loom::kernel(configure_segment_groups)]]
void jpeg_index(const unsigned* segments, const unsigned* summaries,
                unsigned* suffixes, unsigned* ranges, unsigned* intervals) {
  unsigned segment = loom::kernel::workgroup::id.x;
  unsigned item = loom::kernel::workitem::id.x;
  unsigned threads = loom::kernel::workgroup::size.x;
  const unsigned* descriptor = segments + segment * 8;
  unsigned first_job = descriptor[2];
  unsigned count = descriptor[3];
  unsigned first_record = descriptor[5];
  unsigned summary_stride = (5 + component_count + 3) & ~3u;
  unsigned suffix_stride = (2 + component_count + 3) & ~3u;
  unsigned interval_stride = (4 + component_count + 3) & ~3u;
  unsigned* suffix = suffixes + first_record * suffix_stride;
  unsigned* range = ranges + first_record * suffix_stride;
  unsigned* output = intervals + (2 * first_job + segment) * interval_stride;
  if (item == 0) {
    [[loom::unroll]]
    for (unsigned field = 0; field < suffix_stride; ++field) {
      suffix[count * suffix_stride + field] = 0;
      range[count * suffix_stride + field] = 0;
    }
    suffix[count * suffix_stride] = count;
    range[count * suffix_stride] = 0xffffffffu;
    [[loom::unroll]]
    for (unsigned field = 0; field < interval_stride; ++field) {
      output[2 * count * interval_stride + field] = 0;
    }
  }
  unsigned end_carry = count;
  unsigned block_carry = 0;
  Sums dc_carry = {};
  for (unsigned tiles = (count + threads - 1) / threads; tiles != 0; --tiles) {
    unsigned index = (tiles - 1) * threads + item;
    unsigned end = count;
    unsigned blocks = 0;
    Sums dc = {};
    if (index < count) {
      const unsigned* summary = summaries + (first_job + index) * summary_stride;
      if (summary[0] != 0xffffffffu) {
        blocks = summary[4];
        [[loom::unroll]]
        for (unsigned component = 0; component < component_count; ++component) {
          dc[component] = summary[5 + component];
        }
      }
      bool connected = false;
      if (index + 1 < count) {
        const unsigned* next = summary + summary_stride;
        connected = summary[0] != 0xffffffffu && next[0] == summary[2] &&
                    next[1] == summary[3];
      }
      if (!connected) end = index + 1;
    }
    unsigned local_end = loom::kernel::workgroup::scan::minui<
        scan_mode::inclusive, scan_direction::reverse>(end);
    unsigned local_blocks = loom::kernel::workgroup::scan::addi<
        scan_mode::inclusive, scan_direction::reverse>(blocks);
    Sums local_dc = loom::kernel::workgroup::scan::addi<
        scan_mode::inclusive, scan_direction::reverse>(dc);
    if (index < count) {
      [[loom::unroll]]
      for (unsigned field = 0; field < suffix_stride; ++field) {
        suffix[index * suffix_stride + field] = 0;
        range[index * suffix_stride + field] = 0;
      }
      suffix[index * suffix_stride] = minimum(end_carry, local_end);
      suffix[index * suffix_stride + 1] = block_carry + local_blocks;
      range[index * suffix_stride] = 0xffffffffu;
      [[loom::unroll]]
      for (unsigned component = 0; component < component_count; ++component) {
        suffix[index * suffix_stride + 2 + component] = dc_carry[component] + local_dc[component];
      }
      [[loom::unroll]]
      for (unsigned field = 0; field < interval_stride; ++field) {
        output[index * interval_stride + field] = 0;
        output[(count + index) * interval_stride + field] = 0;
      }
    }
    end_carry = minimum(end_carry, loom::kernel::workgroup::reduce::minui(end));
    block_carry += loom::kernel::workgroup::reduce::addi(blocks);
    dc_carry += loom::kernel::workgroup::reduce::addi(dc);
  }
}

static LOOM_FORCE_INLINE void write_interval(unsigned* output, unsigned first,
    unsigned last, unsigned blocks, unsigned phase, Sums dc) {
  output[0] = first;
  output[1] = last;
  output[2] = blocks;
  output[3] = phase;
  [[loom::unroll]]
  for (unsigned component = 0; component < component_count; ++component) {
    output[4 + component] = dc[component];
  }
}

// Only this restart-rooted traversal certifies local transitions. It consumes
// indexed sequence ends and additive totals, never compressed entropy bytes.
[[loom::kernel(configure_segment_roots)]]
void jpeg_certify(const unsigned* segments, const unsigned* summaries,
                  const unsigned* bridges, const unsigned* suffixes,
                  unsigned* ranges, unsigned* intervals) {
  unsigned segment = loom::kernel::workgroup::id.x * loom::kernel::workgroup::size.x +
                     loom::kernel::workitem::id.x;
  if (segment >= certification_segments) return;
  const unsigned* descriptor = segments + segment * 8;
  unsigned first_job = descriptor[2];
  unsigned count = descriptor[3];
  unsigned total_blocks = descriptor[4];
  unsigned first_record = descriptor[5];
  unsigned summary_stride = (5 + component_count + 3) & ~3u;
  unsigned stride = (2 + component_count + 3) & ~3u;
  unsigned interval_stride = (4 + component_count + 3) & ~3u;
  const unsigned* suffix = suffixes + first_record * stride;
  unsigned* range = ranges + first_record * stride;
  unsigned* output = intervals + (2 * first_job + segment) * interval_stride;
  unsigned position = 0;
  unsigned blocks = 0;
  unsigned phase = 0;
  Sums dc = {};
  unsigned source = 0;
  while (source < count) {
    const unsigned* bridge = bridges + (first_job + source) * stride;
    unsigned target = bridge[0];
    if (target == 0xffffffffu || bridge[1] >= total_blocks - blocks) break;
    const unsigned* entry = summaries + (first_job + target) * summary_stride;
    write_interval(output + (count + source) * interval_stride,
                   position, entry[0], blocks, phase, dc);
    position = entry[0];
    blocks += bridge[1];
    phase = entry[1];
    [[loom::unroll]]
    for (unsigned component = 0; component < component_count; ++component) {
      dc[component] += bridge[2 + component];
    }
    unsigned sequence_end = suffix[target * stride];
    unsigned limit = sequence_end;
    unsigned base_blocks = suffix[target * stride + 1];
    if (base_blocks - suffix[limit * stride + 1] >= total_blocks - blocks) {
      unsigned lower = target;
      unsigned upper = sequence_end;
      while (lower < upper) {
        unsigned middle = lower + (upper - lower + 1) / 2;
        if (base_blocks - suffix[middle * stride + 1] < total_blocks - blocks) {
          lower = middle;
        } else {
          upper = middle - 1;
        }
      }
      limit = lower;
    }
    if (limit != target) {
      range[target * stride] = limit;
      range[target * stride + 1] = blocks;
      [[loom::unroll]]
      for (unsigned component = 0; component < component_count; ++component) {
        range[target * stride + 2 + component] = dc[component];
        dc[component] += suffix[target * stride + 2 + component] -
                         suffix[limit * stride + 2 + component];
      }
      const unsigned* last = summaries + (first_job + limit - 1) * summary_stride;
      position = last[2];
      phase = last[3];
      blocks += base_blocks - suffix[limit * stride + 1];
    }
    if (limit != sequence_end) break;
    source = sequence_end;
  }
  // The output consumer owns the exact final MCU and padding validation.
  write_interval(output + 2 * count * interval_stride,
                 position, descriptor[1], blocks, phase, dc);
}

[[loom::kernel(configure_segment_groups)]]
void jpeg_intervals(const unsigned* segments, const unsigned* summaries,
                    const unsigned* suffixes, const unsigned* ranges,
                    unsigned* intervals) {
  unsigned segment = loom::kernel::workgroup::id.x;
  unsigned item = loom::kernel::workitem::id.x;
  unsigned threads = loom::kernel::workgroup::size.x;
  const unsigned* descriptor = segments + segment * 8;
  unsigned first_job = descriptor[2];
  unsigned count = descriptor[3];
  unsigned first_record = descriptor[5];
  unsigned summary_stride = (5 + component_count + 3) & ~3u;
  unsigned stride = (2 + component_count + 3) & ~3u;
  unsigned interval_stride = (4 + component_count + 3) & ~3u;
  const unsigned* suffix = suffixes + first_record * stride;
  const unsigned* range = ranges + first_record * stride;
  unsigned* output = intervals + (2 * first_job + segment) * interval_stride;
  unsigned carry = 0;
  for (unsigned begin = 0; begin < count; begin += threads) {
    unsigned index = begin + item;
    unsigned start = 0;
    if (index < count && range[index * stride] != 0xffffffffu) start = index + 1;
    unsigned prefix = loom::kernel::workgroup::scan::maxui(start);
    if (prefix < carry) prefix = carry;
    if (index < count && prefix != 0) {
      unsigned target = prefix - 1;
      if (index < range[target * stride]) {
        const unsigned* summary = summaries + (first_job + index) * summary_stride;
        unsigned blocks = range[target * stride + 1] +
                          suffix[target * stride + 1] - suffix[index * stride + 1];
        Sums dc = {};
        [[loom::unroll]]
        for (unsigned component = 0; component < component_count; ++component) {
          dc[component] = range[target * stride + 2 + component] +
                          suffix[target * stride + 2 + component] -
                          suffix[index * stride + 2 + component];
        }
        write_interval(output + index * interval_stride,
                       summary[0], summary[2], blocks, summary[1], dc);
      }
    }
    unsigned total = loom::kernel::workgroup::reduce::maxui(start);
    if (total > carry) carry = total;
  }
}
