"""Run lossless decoder controls through the unchanged trained Qwen service."""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time
import urllib.error
import urllib.request

arguments = argparse.ArgumentParser()
arguments.add_argument('directory', type=Path)
arguments.add_argument('--cases', default='jpeg,islow,loom-float32,cosine,float,ifast')
arguments = arguments.parse_args()
directory = arguments.directory.resolve()
manifest = json.loads((directory / 'manifest.json').read_text())
for name, expected in manifest['files'].items():
    actual = hashlib.file_digest((directory / name).open('rb'), 'sha256').hexdigest()
    if actual != expected:
        raise RuntimeError(f'input identity differs: {name}')
for name, information in manifest['assets'].items():
    if Path(information['path']).stat().st_size != information['bytes']:
        raise RuntimeError(f'asset extent differs: {name}')

endpoint = 'http://127.0.0.1:18184'
command = [str(directory / 'loom-serve'), '--device=amdgpu', '--workers=16',
           '--pool_backing=elastic', '--listen=127.0.0.1:18184', '--connections=4',
           '--request_body_bytes=67108864', '--heartbeat_ms=0',
           '--model=' + str(directory / 'deployment.json')]
receipt = {'command': command, 'manifest': manifest,
           'lease': os.environ.get('BENCHMARK_LOCK_LEASE_ID'), 'responses': []}
prompt = manifest['prompt']


def request(path, payload=None):
    body = None if payload is None else json.dumps(payload, separators=(',', ':')).encode()
    call = urllib.request.Request(endpoint + path, data=body,
                                  headers={'Content-Type': 'application/json'})
    try:
        with urllib.request.urlopen(call) as response:
            return json.load(response)
    except urllib.error.HTTPError as error:
        raise RuntimeError(f'HTTP {error.code}: {error.read().decode()}') from error


def record():
    (directory / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n')


with (directory / 'server.log').open('w') as log:
    server = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT)
    receipt['server_pid'] = server.pid
    previous_state = None
    try:
        while True:
            if server.poll() is not None:
                raise RuntimeError(f'server exited during preparation: {server.returncode}')
            try:
                status = request('/v1/status')
            except urllib.error.URLError as error:
                if not isinstance(error.reason, ConnectionRefusedError):
                    raise
                time.sleep(0.05)
                continue
            entries = status.get('data', [])
            if len(entries) != 1:
                raise RuntimeError(f'expected one registered model: {status}')
            state = entries[0]['loom']
            current = state.get('registration')
            if current != previous_state:
                print(json.dumps({'registration': current, 'state': state}), flush=True)
                previous_state = current
            if state.get('error') or current == 'failed':
                raise RuntimeError(f'model preparation failed: {state}')
            if current == 'ready':
                receipt['ready'] = status
                break
            time.sleep(0.05)
        for name in arguments.cases.split(','):
            item = manifest['inputs'][name]
            encoded = base64.b64encode((directory / item['file']).read_bytes()).decode('ascii')
            payload = {
                'model': 'codec-jpeg-accuracy', 'temperature': 0, 'max_tokens': 64,
                'enable_thinking': False,
                'messages': [{'role': 'user', 'content': [
                    {'type': 'image_url', 'image_url': {'url': 'data:' + item['mime'] + ';base64,' + encoded}},
                    {'type': 'text', 'text': prompt}]}],
            }
            print(json.dumps({'case': name, 'phase': 'request'}), flush=True)
            response = request('/v1/chat/completions', payload)
            row = {'case': name, 'prompt': prompt, 'response': response}
            receipt['responses'].append(row)
            record()
            print(json.dumps(row), flush=True)
        responses = {row['case']: row['response'] for row in receipt['responses']}
        if 'jpeg' in responses and 'islow' in responses:
            baseline = responses['jpeg']
            lossless = responses['islow']
            equal = baseline['choices'][0]['message'] == lossless['choices'][0]['message']
            equal &= baseline['usage']['prompt_tokens'] == lossless['usage']['prompt_tokens']
            equal &= baseline['usage']['completion_tokens'] == lossless['usage']['completion_tokens']
            receipt['adapter_control_equal'] = equal
            if not equal:
                raise RuntimeError('JPEG versus lossless ISLOW adapter control differs')
        receipt['final_status'] = request('/v1/status')
    except BaseException as error:
        receipt['error'] = repr(error)
        raise
    finally:
        if server.poll() is None:
            server.send_signal(signal.SIGINT)
        receipt['server_exit'] = server.wait()
        record()
if receipt['server_exit'] != 0:
    raise RuntimeError(f'server shutdown failed: {receipt["server_exit"]}')
