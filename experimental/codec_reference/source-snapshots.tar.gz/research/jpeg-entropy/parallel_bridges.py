"""Bounded local transitions are certified only by the restart-rooted path."""
from bisect import bisect_left
from dataclasses import dataclass

from bounded import Cursor, State
from recover_prefix import CountedBits, ReadBudgetExceeded
from sequential import InvalidJPEG, require


def phase(state, block_count):
    return (state.blocks % block_count) * 64 + state.coefficient


@dataclass
class Sequence:
    # First included summary index.
    first: int
    # One-past-last included summary index.
    limit: int
    # Exclusive completed-block prefixes, including zero and the total.
    block_prefix: list
    # Exclusive component DC prefixes, including zero and the total.
    dc_prefix: list


@dataclass
class Bridge:
    # Advertised source state; predictors are relative zero.
    first: State
    # Last locally decoded state, whether joined or rejected.
    last: State
    # Joined later summary index, or None when no connection was established.
    target: object
    # Joined, syntax failure, or cap exhaustion.
    outcome: str
    # Successfully decoded Huffman symbols, including unselected branches.
    symbols: int
    # All attempted Huffman symbols, including the failed transition.
    attempts: int
    # Consumed bits, bounded independently of convergence.
    bits: int


def construct(segment, scan, components, summaries, chunk_bits, bridge_bits, trace=None):
    block_count = len(scan.blocks)
    sequences = []
    membership = [None] * len(summaries)
    for index, summary in enumerate(summaries):
        if summary is None:
            continue
        # One syntax transition is at most 16 Huffman plus 11 amplitude bits.
        assert 0 <= summary.first.position - index * chunk_bits <= 26
        previous = summaries[index - 1] if index else None
        connected = (previous is not None and
                     previous.last.position == summary.first.position and
                     phase(previous.last, block_count) == phase(summary.first, block_count))
        if not connected:
            sequences.append(Sequence(index, index, [0], [(0,) * components]))
        sequence = sequences[-1]
        membership[index] = len(sequences) - 1
        sequence.limit = index + 1
        sequence.block_prefix.append(sequence.block_prefix[-1] + summary.last.blocks - summary.first.blocks)
        sequence.dc_prefix.append(tuple(
            current + end - start for current, start, end in
            zip(sequence.dc_prefix[-1], summary.first.predictors, summary.last.predictors, strict=True)))

    def decode_bridge(first, after):
        first = State(first.position, first.blocks % block_count, first.coefficient, (0,) * components)
        cursor = Cursor(segment, scan, components, first)
        cursor.reader = CountedBits(segment.data, first.position, bridge_bits + 26)
        target = None
        outcome = 'cap'
        try:
            while True:
                state = cursor.state()
                lower = max(after + 1, 0, (state.position - 26 + chunk_bits - 1) // chunk_bits)
                upper = min(len(summaries) - 1, state.position // chunk_bits)
                for index in range(lower, upper + 1):
                    summary = summaries[index]
                    if (summary is not None and summary.first.position == state.position and
                            phase(summary.first, block_count) == phase(state, block_count)):
                        target = index
                        break
                if target is not None:
                    outcome = 'joined'
                    break
                if cursor.reader.position - first.position >= bridge_bits:
                    break
                cursor.advance()
        except InvalidJPEG:
            outcome = 'syntax'
        except ReadBudgetExceeded:
            outcome = 'cap'
        assert cursor.reader.read_bits <= bridge_bits + 26
        return Bridge(first, cursor.state(), target, outcome, cursor.symbols,
                      cursor.reader.huffman_attempts, cursor.reader.read_bits)

    # Every job below is independent of the true root and the other bridge jobs.
    root = State(0, 0, 0, (0,) * components)
    initial = decode_bridge(root, -1)
    bridges = [decode_bridge(summaries[sequence.limit - 1].last, sequence.limit - 1)
               for sequence in sequences]
    all_bridges = [initial, *bridges]
    counts = {
        'sequences': len(sequences), 'candidate_bridges': len(all_bridges),
        'bridge_symbols': sum(bridge.symbols for bridge in all_bridges),
        'bridge_symbol_attempts': sum(bridge.attempts for bridge in all_bridges),
        'bridge_bits': sum(bridge.bits for bridge in all_bridges),
        'bridge_bit_bound': len(all_bridges) * (bridge_bits + 26),
        'maximum_bridge_symbols': max(bridge.symbols for bridge in all_bridges),
        'joined_candidates': sum(bridge.target is not None for bridge in all_bridges),
        'capped_candidates': sum(bridge.outcome == 'cap' for bridge in all_bridges),
        'syntax_rejected_candidates': sum(bridge.outcome == 'syntax' for bridge in all_bridges),
        'selected_bridges': 0, 'root_sequence_visits': 0, 'accepted_summaries': 0,
        'serial_anchor_symbols': 0,
    }
    assert counts['bridge_bits'] <= counts['bridge_bit_bound']

    # Prefix arrays are candidate data. Root traversal only chooses connected
    # ranges and combines their totals; per-summary checkpoint materialization
    # below models the later parallel consumer used to check complete output.
    state = root
    checkpoints = [state]
    bridge = initial
    source = 0
    if trace is not None:
        trace.update({'ranges': {}, 'bridges': {}})
    total_blocks = segment.mcu_count * block_count
    while True:
        assert (bridge.first.position, phase(bridge.first, block_count)) == (
            state.position, phase(state, block_count))
        delta = bridge.last.blocks - bridge.first.blocks
        if bridge.target is None or delta >= total_blocks - state.blocks:
            break
        before = state
        state = State(bridge.last.position, state.blocks + delta, bridge.last.coefficient,
                      tuple(left + right for left, right in zip(state.predictors, bridge.last.predictors, strict=True)))
        if trace is not None:
            trace['bridges'][source] = (before, state)
        counts['selected_bridges'] += 1
        if state.position != checkpoints[-1].position:
            checkpoints.append(state)
        target = bridge.target
        sequence = sequences[membership[target]]
        offset = target - sequence.first
        counts['root_sequence_visits'] += 1
        wanted = sequence.block_prefix[offset] + total_blocks - state.blocks
        limit = min(sequence.limit - sequence.first,
                    bisect_left(sequence.block_prefix, wanted, lo=offset + 1) - 1)
        assert limit >= offset
        base = state
        if trace is not None and limit != offset:
            trace['ranges'][target] = (sequence.first + limit, base)
        for local in range(offset, limit):
            summary = summaries[sequence.first + local]
            actual = State(
                summary.last.position,
                base.blocks + sequence.block_prefix[local + 1] - sequence.block_prefix[offset],
                summary.last.coefficient,
                tuple(value + end - start for value, start, end in zip(
                    base.predictors, sequence.dc_prefix[offset], sequence.dc_prefix[local + 1], strict=True)))
            assert phase(actual, block_count) == phase(summary.last, block_count)
            if actual.position != checkpoints[-1].position:
                checkpoints.append(actual)
        counts['accepted_summaries'] += limit - offset
        if limit != offset:
            last = summaries[sequence.first + limit - 1].last
            state = State(last.position,
                          base.blocks + sequence.block_prefix[limit] - sequence.block_prefix[offset],
                          last.coefficient,
                          tuple(value + end - start for value, start, end in zip(
                              base.predictors, sequence.dc_prefix[offset], sequence.dc_prefix[limit], strict=True)))
        if sequence.first + limit != sequence.limit:
            break
        bridge = bridges[membership[target]]
        source = sequence.limit

    # The residual interval belongs to an ordinary output worker. This CPU
    # model materializes its terminal checkpoint only to exercise the existing
    # full-MCU output checker; the candidate anchor does no entropy decoding.
    cursor = Cursor(segment, scan, components, state)
    if trace is not None:
        trace['tail'] = state
    while cursor.blocks < total_blocks:
        cursor.advance()
    require(cursor.blocks == total_blocks and cursor.coefficient == 0,
            'bridge output did not terminate at the exact final MCU')
    final = cursor.state()
    padding = cursor.reader.limit - final.position
    require(0 <= padding < 8 and cursor.reader.take(padding) == (1 << padding) - 1,
            'bridge output has invalid final padding')
    if final.position != checkpoints[-1].position:
        checkpoints.append(final)
    counts.update({'residual_output_symbols': cursor.symbols,
                   'residual_output_bits': final.position - state.position,
                   'maximum_interval_bits': max((last.position - first.position
                                                for first, last in zip(checkpoints, checkpoints[1:])), default=0),
                   'output_intervals': len(checkpoints) - 1})
    transitions = {0: initial}
    transitions.update({sequence.limit: bridge for sequence, bridge in zip(sequences, bridges, strict=True)
                        if sequence.limit < len(summaries)})
    return checkpoints, counts, transitions
