"""Match eight mixed GPU cohorts against one CPU submission of 128 images."""
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import shlex
import statistics
import subprocess
import sys
import tarfile


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def run(root):
    directory = root / "cpu-pipeline"
    manifest = json.loads((directory / "manifest.json").read_text())
    assert os.environ["BENCHMARK_LOCK_LEASE_ID"]
    assert not any(name.startswith("JSIMD_") for name in os.environ)
    for name, expected in manifest["files"].items():
        assert digest(root / name) == expected, name
    tree = ast.parse((root / "cpu-current/machine-state.py").read_text())
    node = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "state")
    namespace = dict(globals())
    exec(compile(ast.Module(body=[node], type_ignores=[]), "machine-state.py", "exec"), namespace)
    state = namespace["state"]
    before = state()
    assert before["governor"] == "performance" and before["gpu_policy"] == "high"
    assert int(before["personality"], 16) & 0x40000
    assert not before["kfd_processes"] and not before["drm"] and before["gpu_busy"] == 0
    images = [root / "mixed-cpu" / name for name in manifest["image_names"]]
    record = {"manifest": manifest, "before": before, "rows": [], "routes": {},
              "scope": {"images_per_completion": 128, "normalization_images": 16,
                        "cpu_workers": 16, "cpu_affinity": "0-15", "warmups": 2, "samples": 9,
                        "cpu": "128 independent decode jobs queued before one completion; 128 disjoint preallocated RGB outputs; four shared immutable input images.",
                        "gpu": "Eight serial device commands, each decoding sixteen images, before one completion; sixteen preallocated output spans reused; original compressed bytes resident.",
                        "gpu_excludes": "Header parsing, JIT, allocation, upload, and verification download.",
                        "cpu_includes": "Task submission, codec create/header/start/read/finish/destroy, internal codec allocations, and final retirement. Final output allocation and verification are outside timing.",
                        "numerics": "GPU follows independently checked float32 reconstruction; libjpeg policies have different measured pixel errors. No production numerical tolerance selected."}}
    for policy, symbol in (("islow", "jsimd_idct_islow_avx2"), ("float", "jsimd_idct_float_sse2"), ("ifast", "jsimd_idct_ifast_sse2")):
        binary = directory / ("jpeg_pipeline_" + policy)
        command = ["/opt/rocm/bin/rocgdb", "-q", "-batch", "-ex", "set pagination off",
                   "-ex", "set confirm off", "-ex", "break " + symbol,
                   "-ex", "run qualify " + str(images[0]), "-ex", "bt 3", "-ex", "quit", str(binary)]
        result = subprocess.run(command, capture_output=True, text=True)
        assert result.returncode == 0 and "Breakpoint 1," in result.stdout and symbol in result.stdout, result.stdout + result.stderr
        record["routes"][policy] = {"command": command, "output": result.stdout + result.stderr}
    output = directory / "comparison.json"
    output.write_text(json.dumps(record, indent=2) + "\n")
    for ordinal, policy in enumerate(("islow", "gpu", "float", "gpu", "ifast", "gpu", "float", "islow", "ifast")):
        if policy == "gpu":
            command = [str(root / "codec_command_probe"), "--jpeg_fixture=" + str(root / "mixed-current"),
                       "--gtest_filter=JpegCommandTest.CompressedToRgb", "--jpeg_benchmark=true"]
        else:
            command = ["taskset", "-c", "0-15", str(directory / ("jpeg_pipeline_" + policy)),
                       "bench", "128", "16", "9", *(str(image) for image in images)]
        result = subprocess.run(command, capture_output=True, text=True)
        log = directory / (str(ordinal) + "-" + policy + ".log")
        log.write_text(result.stdout + result.stderr)
        assert result.returncode == 0, result.stdout + result.stderr
        rows = [json.loads(line) for line in result.stdout.splitlines() if line.startswith("{")]
        if policy == "gpu":
            measurement, = [row for row in rows if row.get("phase") == "measurement"]
            assert measurement["operations_per_submission"] == 8
            assert len([row for row in rows if row.get("phase") == "exact"]) == 52
            duration = measurement["median_operation_ns"]
        else:
            row, = rows
            assert row["full_rgb_and_guards"] and row["batch"] == 128 and len(row["batch_ns"]) == 9
            assert row["rgb_bytes"] == manifest["cpu_rgb_bytes_per_completion"]
            duration = statistics.median(row["batch_ns"]) / 8
        record["rows"].append({"policy": policy, "command": command,
                               "median_16_image_ns": duration, "result": rows,
                               "children_peak_rss_kib": resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
                               "log_sha256": digest(log)})
        output.write_text(json.dumps(record, indent=2) + "\n")
        print(json.dumps({"policy": policy, "median_16_image_ms": duration / 1e6}), flush=True)
    record["after"] = state()
    assert not record["after"]["kfd_processes"] and not record["after"]["drm"]
    output.write_text(json.dumps(record, indent=2) + "\n")


def stage():
    notes = Path(__file__).resolve().parent
    root = Path(json.loads((notes / "device-active.json").read_text())["directory"])
    tags = {name: Path(value) for name, value in json.loads(os.environ["BUREAU_TAG_ROOTS"]).items()}
    fixture = json.loads((root / "mixed-current/stage.json").read_text())
    assert fixture["cohort"] == "primary" and fixture["invalid_index"] is None
    checked = json.loads((notes / "gorgon4-mixed-primary-access.json").read_text())
    assert checked["returncode"] == 0 and checked["stage"] == fixture
    cpu_build = json.loads((notes / "cpu-pipeline-build.json").read_text())
    assert cpu_build["returncode"] == 0
    capture = json.loads(subprocess.check_output(["bureau-bazel", "tag", "inspect", "codec-jpeg-pipeline-cpu", "--json"], text=True))
    assert capture["capture"] == cpu_build["capture"]["capture"]
    gpu_build = json.loads((notes / "current-probe-opt-build.json").read_text())
    gpu_capture = json.loads(subprocess.check_output(["bureau-bazel", "tag", "inspect", "codec-jpeg-rebased-tools", "--json"], text=True))
    assert gpu_capture["capture"] == gpu_build["capture"]["capture"] and gpu_build["restored"]
    files = {"codec_command_probe": tags["codec-jpeg-rebased-tools"] / "loom/src/loom/tooling/target/amdgpu/serve/codec_command_probe",
             "cpu-pipeline/compare.py": Path(__file__).resolve()}
    native = {}
    for policy in ("islow", "float", "ifast"):
        name = "jpeg_pipeline_" + policy
        binary = tags["codec-jpeg-pipeline-cpu"] / "experimental/codec_reference/research/jpeg-baseline" / name
        files["cpu-pipeline/" + name] = binary
        symbols = subprocess.check_output(["/home/ben/tools/llvm/latest/bin/llvm-nm", "--defined-only", str(binary)], text=True)
        selected = [line.split()[-1] for line in symbols.splitlines() if re.search(
            r"\b(?:jsimd_(?:idct_(?:islow|ifast|float)|ycc_rgb_convert|h2v2_fancy_upsample)_(?:avx2|sse2)|decode_mcu(?:\.llvm\.\d+)?)$", line)]
        assembly = subprocess.check_output(["/home/ben/tools/llvm/latest/bin/llvm-objdump", "-d", "--disassemble-symbols=" + ",".join(selected), str(binary)], text=True)
        (notes / (name + ".native.s")).write_text(assembly)
        native[policy] = {"symbols": selected, "native_sha256": hashlib.sha256(assembly.encode()).hexdigest()}
    cpu = json.loads((notes / "gorgon4-mixed-cpu.json").read_text())["manifest"]
    hashes = {name: digest(path) for name, path in files.items()}
    hashes.update({"mixed-current/" + name: expected for name, expected in fixture["files"].items()})
    for image in cpu["images"]:
        hashes["mixed-cpu/" + image["name"]] = image["sha256"]
    hashes["cpu-current/machine-state.py"] = cpu["files"]["cpu-current/machine-state.py"]
    manifest = {"files": hashes, "fixture": fixture, "cpu_build": cpu_build, "gpu_build": gpu_build,
                "cpu_native": native, "image_names": [image["name"] for image in cpu["images"]],
                "cpu_rgb_bytes_per_completion": cpu["cohort_rgb_bytes"] * 8}
    directory = root / "cpu-pipeline"
    directory.mkdir(exist_ok=True)
    (directory / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    files["cpu-pipeline/manifest.json"] = directory / "manifest.json"
    assert sum(path.stat().st_size for path in files.values()) < 64 * 1024 * 1024
    process = subprocess.Popen(["ssh", "hrx-gorgon-4", "tar -xf - -C " + shlex.quote(str(root))], stdin=subprocess.PIPE)
    with tarfile.open(fileobj=process.stdin, mode="w|", dereference=True) as archive:
        for name, path in files.items(): archive.add(path, arcname=name, recursive=False)
    process.stdin.close()
    assert process.wait() == 0
    command = ["/home/benvanik/.dotfiles/bin/benchmark-lock", "--label=codec-jpeg-mixed-pipeline", "--",
               "timeout", "--signal=INT", "--kill-after=10s", "300s", "env", "LD_LIBRARY_PATH=/opt/rocm/lib",
               "python3", "-B", str(directory / "compare.py"), "--remote", str(root)]
    with (notes / "gorgon4-mixed-comparison.log").open("w") as stream:
        result = subprocess.run(["ssh", "hrx-gorgon-4", shlex.join(command)], stdout=stream, stderr=subprocess.STDOUT)
    status = subprocess.run(["ssh", "hrx-gorgon-4", "~/.dotfiles/bin/benchmark-lock --status"], capture_output=True, text=True)
    receipt = {"command": command, "returncode": result.returncode, "broker_status_after": status.stdout + status.stderr,
               "broker_status_returncode": status.returncode, "manifest": manifest}
    (notes / "gorgon4-mixed-comparison-run.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print((notes / "gorgon4-mixed-comparison.log").read_text(), end="")
    print(status.stdout + status.stderr, end="", flush=True)
    assert result.returncode == 0 and status.returncode == 0
    output = subprocess.check_output(["ssh", "hrx-gorgon-4", "cat " + shlex.quote(str(directory / "comparison.json"))])
    (notes / "gorgon4-mixed-comparison.json").write_bytes(output)


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "--remote": run(Path(sys.argv[2]))
    else:
        assert len(sys.argv) == 1
        stage()
