"""Compile the unchanged control and float32 arithmetic through pinned tools."""
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
tags = json.loads(os.environ['BUREAU_TAG_ROOTS'])
frontend = Path(tags['codec-jpeg-rebased-tools']) / 'loom/src/loom/tools'
compiler = Path(tags['codec-jpeg-unsigned-opt']) / 'loom/src/loom/tools/loom-compile/loom-compile'
records = {}
for name, source_name in (('integer', 'device_stride_pipeline.cxx'), ('float32', 'device_float_pipeline.cxx')):
    source = notes / source_name
    output = root / ('idct-' + name)
    subprocess.run([str(frontend / 'loom-import-cxx/loom-import-cxx'), str(source),
                    '--output=' + str(output) + '.loom'], check=True)
    subprocess.run([str(frontend / 'loom-link/loom-link'), str(output) + '.loom',
                    '--to=bc', '--output=' + str(output) + '.loombc'], check=True)
    command = [str(compiler), str(output) + '.loombc', '--root=jpeg_reconstruct',
               '--target=amdgpu:gfx1151', '--config-file=' + str(root / 'connected-stride/config.json'),
               '--output=' + str(output) + '.hsaco', '--compile-report=details',
               '--compile-report-output=' + str(output) + '.report.json']
    subprocess.run(command, check=True)
    assembly = subprocess.check_output(['/home/ben/tools/llvm/latest/bin/llvm-objdump', '-d',
        '--mcpu=gfx1151', str(output) + '.hsaco'], text=True)
    (root / ('idct-' + name + '.native.s')).write_text(assembly)
    histogram = Counter(re.findall(r'^\s+(\w+)\s+[^\n]*//', assembly, re.M))
    row = json.loads(Path(str(output) + '.report.json').read_text())['entries']['rows'][0]
    record = {'command': command, 'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
              'library_sha256': hashlib.sha256(Path(str(output) + '.loombc').read_bytes()).hexdigest(),
              'native_sha256': hashlib.sha256(Path(str(output) + '.hsaco').read_bytes()).hexdigest(),
              'instruction_histogram': dict(sorted(histogram.items())),
              'resources': {key: row[key] for key in ('instruction_count', 'code_byte_count',
                  'private_memory_bytes', 'local_memory_bytes', 'target_resources')}}
    records[name] = record
    print(name, json.dumps(record['resources']), flush=True)
(notes / 'float-idct-native.json').write_text(json.dumps(records, indent=2) + '\n')
