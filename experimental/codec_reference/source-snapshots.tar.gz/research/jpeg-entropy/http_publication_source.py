"""Produce explicit temporary source overlays for the HTTP ownership witness."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / "device-active.json").read_text())["directory"])
directory = root / "http-publication"
overlays = directory / "overlays"
overlays.mkdir(parents=True, exist_ok=True)
originals = {}
files = {}


def read(name):
    path = Path(name)
    data = path.read_text()
    originals[name] = hashlib.sha256(data.encode()).hexdigest()
    return data


def write(name, data):
    path = overlays / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(data)
    files[name] = hashlib.sha256(data.encode()).hexdigest()


def replace(text, before, after, count=1):
    assert text.count(before) == count, (before, text.count(before), count)
    return text.replace(before, after)


finite = "loom/src/loom/serve/service/finite/"
media = "loom/src/loom/serve/media/"
projector_path = "loom/src/loom/serve/service/text/media_projector.c"

result = read(finite + "result.c")
result = replace(result, "  // Live result prefix containing every checked row.\n", "  // Optional source-declared device input-outcome vector outside the result prefix.\n  iree_host_size_t status_offset;\n  // Live result prefix containing every checked row.\n")
result = replace(result, "  // Independent checked records followed by the downloaded host result bytes.\n", "  // Optional input outcomes after the downloaded result prefix, relative to storage.\n  iree_host_size_t status_offset;\n  // Independent checked records followed by the downloaded host result bytes.\n")
start = result.index("iree_status_t loom_serve_finite_result_create(")
end = result.index("void loom_serve_finite_result_bind(")
create = re.sub(r"\b32\b", "40", result[start:end])
create = replace(create, "  uint64_t first_row = 0;", """  const uint64_t status_offset = iree_unaligned_load_le_u64(bytes.data + 32);
  if (status_offset && (status_offset % 4 || status_offset < length ||
                        status_offset > output_length ||
                        count > (output_length - status_offset) / 4)) {
    return iree_make_status(IREE_STATUS_INVALID_ARGUMENT,
                            "source input outcomes lie outside output storage");
  }
  uint64_t first_row = 0;""")
create = replace(create, "  result->request_count = request_count;", "  result->request_count = request_count;\n  result->status_offset = (iree_host_size_t)status_offset;")
result = result[:start] + create + result[end:]
start = result.index("iree_status_t loom_serve_finite_result_download(")
end = result.index("uint64_t loom_serve_finite_snapshot_input_tokens(")
download = result[start:end]
download = replace(download, "  iree_host_size_t allocation_size = 0;", "  const iree_host_size_t status_length = result->status_offset ? result->request_count * 4 : 0;\n  iree_host_size_t allocation_size = 0;")
download = replace(download, "result->length,\n                                  &allocation_size", "result->length + status_length,\n                                  &allocation_size")
download = replace(download, "  snapshot->records_length = result->records_length;", "  snapshot->records_length = result->records_length;\n  snapshot->status_offset = status_length ? result->records_length + result->length : 0;")
download = replace(download, "      result->buffer, 0, result->length,", "      result->buffer, 0, result->output_length,")
old = """    const iree_hal_transfer_operation_t download = {
        .type = IREE_HAL_TRANSFER_OPERATION_TYPE_DOWNLOAD,
        .download = {.source_buffer = source,
                     .target = snapshot->storage + snapshot->records_length,
                     .length = result->length}};
    uint64_t value = 0;
    status =
        loom_serve_execution_feedback(result->execution, 1, &download, &value);"""
new = """    const iree_hal_transfer_operation_t downloads[2] = {
        {.type = IREE_HAL_TRANSFER_OPERATION_TYPE_DOWNLOAD,
         .download = {.source_buffer = source,
                      .target = snapshot->storage + snapshot->records_length,
                      .length = result->length}},
        {.type = IREE_HAL_TRANSFER_OPERATION_TYPE_DOWNLOAD,
         .download = {.source_buffer = source,
                      .source_offset = result->status_offset,
                      .target = snapshot->storage + snapshot->status_offset,
                      .length = status_length}}};
    uint64_t value = 0;
    status = loom_serve_execution_feedback(result->execution,
                                            status_length ? 2 : 1, downloads,
                                            &value);"""
download = replace(download, old, new)
result = result[:start] + download + result[end:]
result += "\n" + (notes / "http_result_status.c").read_text()
write(finite + "result.c", result)
header = read(finite + "result.h")
header = replace(header, "// header is [physical output bytes, result bytes, request count, row count],", "// header is [physical output bytes, result bytes, request count, row count,\n// input status offset]. A nonzero status offset names count LE u32 outcomes\n// outside the result prefix: zero is valid, nonzero rejects that input.")
header = replace(header, "#ifdef __cplusplus\n}  // extern \"C\"", (notes / "http_result_status.h").read_text() + "\n#ifdef __cplusplus\n}  // extern \"C\"")
write(finite + "result.h", header)
model_header = read(finite + "model.h")
model_header = replace(model_header,
    "// result_bytes, request_count, row_count], request records",
    "// result_bytes, request_count, row_count, input_status_offset], request records")
write(finite + "model.h", model_header)
model = read(finite + "model.c")
model = replace(model, """  return loom_serve_jit_create(
      loom_serve_device_handle(model->owner),
      loom_serve_device_dispatch_queue(model->owner),
      loom_serve_device_host(model->owner), &load->options.sources, NULL,
      &model->compilation, host_allocator, &model->jit);""", """  const loomc_sanitizer_options_t sanitizer = {
      .type = LOOMC_STRUCTURE_TYPE_SANITIZER_OPTIONS,
      .structure_size = sizeof(loomc_sanitizer_options_t),
      .checks = LOOMC_SANITIZER_CHECK_ACCESS};
  return loom_serve_jit_create(
      loom_serve_device_handle(model->owner),
      loom_serve_device_dispatch_queue(model->owner),
      loom_serve_device_host(model->owner), &load->options.sources, &sanitizer,
      &model->compilation, host_allocator, &model->jit);""")
write(finite + "model.c", model)

# Fixed-root readiness is supplied by the durable weight-owner repair.
assert "loom_serve_weight_preparation_backing_ready" in Path(
    "loom/src/loom/serve/runtime/parameter/weights.c").read_text()

projector = read(projector_path)
projector = replace(projector, "#include <string.h>", "#include <string.h>\n#include <stdio.h>")
projector = replace(projector, "  // Exact decoded packet bytes selected into the gathering window.", "  // Cohort retained until device input validity is observed.\n  loom_serve_finite_result_t* result;\n  // Queue-owned host outcome storage, independent of cancelled request jobs.\n  loom_serve_finite_statuses_t* device_statuses;\n  // Exact decoded packet bytes selected into the gathering window.")
start = projector.index("static iree_status_t loom_serve_text_media_projector_submit(")
end = projector.index("bool loom_serve_text_media_projector_is_pending(")
projector = projector[:start] + """static void loom_serve_text_media_projector_publish(
    loom_serve_text_media_projector_t* projector) {
  for (iree_host_size_t i = 0; i < projector->cohort_count; ++i) {
    loom_serve_text_media_job_t* job = projector->cohort[i];
    if (!job->request) continue;
    iree_status_t status = loom_serve_finite_statuses_request(
        projector->device_statuses, i);
    if (projector->device_statuses) {
      fprintf(stderr, "{\\"phase\\":\\"jpeg_http_publish\\",\\"image\\":%zu,\\"status\\":%u}\\n",
              i, (unsigned)iree_status_code(status));
    }
    loom_serve_text_media_image_t* image =
        &job->request->images[job->image_index];
    if (iree_status_is_ok(status)) {
      loom_serve_finite_result_retain(projector->result);
      image->result = projector->result;
      image->result_index = (uint32_t)i;
    } else {
      job->request->status = iree_status_join(job->request->status, status);
    }
    image->selected = false;
    job->request = NULL;
  }
  loom_serve_finite_result_release(projector->result);
  projector->result = NULL;
  loom_serve_finite_statuses_release(projector->device_statuses);
  projector->device_statuses = NULL;
}

static iree_status_t loom_serve_text_media_projector_submit(
    loom_serve_text_media_projector_t* projector) {
  loom_serve_execution_frontier_t ready;
  IREE_RETURN_IF_ERROR(loom_serve_finite_model_submit(
      projector->model, &projector->result, &ready));
  IREE_RETURN_IF_ERROR(loom_serve_finite_result_download_statuses(
      projector->result, &projector->device_statuses, &ready));
  if (projector->device_statuses) {
    fprintf(stderr, "{\\"phase\\":\\"jpeg_http_submit\\",\\"images\\":%zu,\\"status_bytes\\":%zu}\\n",
            projector->cohort_count, projector->cohort_count * 4);
  } else {
    loom_serve_text_media_projector_publish(projector);
  }
  IREE_RETURN_IF_ERROR(
      loom_serve_text_readiness_await(&projector->readiness, &ready));
  projector->phase = MEDIA_RUNNING;
  return iree_ok_status();
}

""" + projector[end:]
projector = replace(projector, "    if (iree_status_is_ok(status)) {\n      loom_serve_finite_model_complete(projector->model);", "    if (iree_status_is_ok(status)) {\n      if (projector->result) loom_serve_text_media_projector_publish(projector);\n      loom_serve_finite_model_complete(projector->model);")
projector = replace(projector, "  loom_serve_text_readiness_deinitialize(&projector->readiness);", "  loom_serve_finite_result_release(projector->result);\n  loom_serve_finite_statuses_release(projector->device_statuses);\n  loom_serve_text_readiness_deinitialize(&projector->readiness);")
write(projector_path, projector)

service = read(finite + "service.c")
service = replace(service, "static void loom_serve_finite_complete_execution(", "static iree_status_t loom_serve_finite_complete_execution(")
start = service.index("static iree_status_t loom_serve_finite_complete_execution(")
end = service.index("static iree_status_t loom_serve_finite_collect(")
complete = service[start:end]
complete = replace(complete, "  iree_host_size_t retained = 0;", "  iree_status_t status = iree_ok_status();\n  iree_host_size_t retained = 0;")
complete = replace(complete, "    // The surviving encoding cohort can have holes", """    job->status = loom_serve_finite_snapshot_status(service->snapshot, i);
    if (!iree_status_is_ok(job->status)) {
      job->outcome = LOOM_SERVE_TELEMETRY_REJECTED;
      status = iree_status_join(status, loom_serve_finite_reject(
          service, job->id, job->connection, service->protocol->invalid_status,
          iree_status_message(job->status)));
      job->connection = NULL;
      loom_serve_finite_job_destroy(service, job, iree_ok_status());
      continue;
    }
    // The surviving encoding cohort can have holes""")
complete = replace(complete, "  if (retained) {", "  if (!iree_status_is_ok(status)) {\n    loom_serve_finite_finish(service, status);\n  } else if (retained) {")
complete = replace(complete, "  IREE_TRACE_ZONE_END(z0);\n}", "  IREE_TRACE_ZONE_END(z0);\n  return status;\n}")
service = service[:start] + complete + service[end:]
service = replace(service, "    loom_serve_finite_complete_execution(service);", "    status = loom_serve_finite_complete_execution(service);")
write(finite + "service.c", service)

packet = read(media + "image_request.c")
packet = replace(packet, "#include <string.h>\n", "#include <string.h>\n\n" + (notes / "http_image_packet.c").read_text())
packet = replace(packet, "  *out_length = 0;", "  *out_length = 0;\n  if (FLAG_codec_jpeg) return jpeg_request_bound(info, metadata_length, out_length);")
packet = replace(packet, "  if (!count) {", "  if (FLAG_codec_jpeg) {\n    for (iree_host_size_t i = 0; i < count; ++i) {\n      out_statuses[i] = jpeg_request_create(&requests[i], host_allocator, &out_packets[i]);\n    }\n    return iree_ok_status();\n  }\n  if (!count) {")
write(media + "image_request.c", packet)
names = ["native_upload.c", "native_upload.h", "device_upload.h", "native_header.c",
         "native_header.h", "native_metadata.c", "native_metadata.h", "native_color.c", "native_color.h"]
for name in names:
    assert not Path(media + name).exists()
    write(media + name, (notes / name).read_text())
build = read(media + "BUILD.bazel")
build = replace(build, '    srcs = ["image_request.c"],', '    srcs = ["image_request.c", ' + ", ".join(json.dumps(name) for name in names) + '],')
before = '    name = "image_request",'
begin = build.index(before)
end = build.index('\n)\n', begin)
target = build[begin:end]
target = replace(target, '        "//runtime/src/iree/base",', '        "//runtime/src/iree/base",\n        "//runtime/src/iree/base/tooling:flags",')
build = build[:begin] + target + build[end:]
write(media + "BUILD.bazel", build)

test = read(finite + "result_test.cc")
test = replace(test, "std::array<uint64_t, 16> words_ = {32, 20, 2, 3,", "std::array<uint64_t, 17> words_ = {32, 20, 2, 3, 0,")
test = replace(test, "const std::array<std::pair<size_t, uint64_t>, 12> invalid", "const std::array<std::pair<size_t, uint64_t>, 16> invalid")
test = replace(test, "       {4, 1},\n       {5, 1},\n       {7, 1},\n       {10, 1},\n       {11, 0},\n       {15, UINT64_MAX}", "       {5, 1},\n       {6, 1},\n       {8, 1},\n       {11, 1},\n       {12, 0},\n       {16, UINT64_MAX},\n       {4, 16},\n       {4, 21},\n       {4, 28},\n       {4, UINT64_MAX}")
test = replace(test, "    IREE_ASSERT_OK(CreatePlan());\n    IREE_ASSERT_OK(CreateResult(allocator_.allocator()));", "    words_[4] = 24;\n    IREE_ASSERT_OK(CreatePlan());\n    IREE_ASSERT_OK(CreateResult(allocator_.allocator()));")
test = replace(test, "    loom_serve_finite_snapshot_release(snapshot_);", "    loom_serve_finite_statuses_release(statuses_);\n    loom_serve_finite_snapshot_release(snapshot_);")
test = replace(test, "  // Whether the test deliberately failed the feedback semaphore.", "  // Status-only caller reference, independently retained by feedback.\n  loom_serve_finite_statuses_t* statuses_ = nullptr;\n  // Whether the test deliberately failed the feedback semaphore.")
start = test.index("TEST_P(SnapshotLifetimeTest, EarlyReleasePreservesAcceptedDownloadStorage)")
end = test.index("INSTANTIATE_TEST_SUITE_P(")
status_test = test[start:end].replace("EarlyReleasePreservesAcceptedDownloadStorage", "EarlyReleasePreservesAcceptedStatusStorage")
status_test = status_test.replace("loom_serve_finite_result_download(result_, &snapshot_, &frontier)", "loom_serve_finite_result_download_statuses(result_, &statuses_, &frontier)")
status_test = status_test.replace("loom_serve_finite_snapshot_release(std::exchange(snapshot_, nullptr))", "loom_serve_finite_statuses_release(std::exchange(statuses_, nullptr))")
test = test[:end] + status_test + test[end:]
write(finite + "result_test.cc", test)

# The real model stays at its pinned source, copied into the active experiment.
baseline = root / "native-projector"
for name in ("sources", "control-sources"):
    shutil.copytree(baseline / name, directory / name, dirs_exist_ok=True)
    path = directory / name / "experimental/loom_serve/models/qwen/vision_control.loom"
    control = path.read_text()
    control = replace(control, "%header_bytes = index.constant 32 : offset", "%header_bytes = index.constant 40 : offset")
    control = control.replace("view<4xi64>", "view<5xi64>")
    store = "  view.store %rows64, %header[3] : i64, view<5xi64>"
    outcome = "%output_bytes" if name == "sources" else "%no_status"
    extra = "" if name == "sources" else "\n  %no_status = scalar.constant 0 : i64"
    control = replace(control, store, store + extra + f"\n  view.store {outcome}, %header[4] : i64, view<5xi64>")
    path.write_text(control)
for name in ("deployment.json", "control-deployment.json"):
    deployment = (baseline / name).read_text().replace(str(baseline), str(directory))
    # Keep the same registered name for the control and candidate endpoint.
    document = json.loads(deployment)
    document["name"] = "codec-jpeg-publication"
    (directory / name).write_text(json.dumps(document, indent=2) + "\n")
shutil.copyfile(baseline / "decoder.loombc", directory / "decoder.loombc")
record = {"compiler_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
          "directory": str(directory), "originals": originals, "overlays": files,
          "generator_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          "sources": {str(path.relative_to(directory)): hashlib.sha256(path.read_bytes()).hexdigest()
                      for folder in ("sources", "control-sources")
                      for path in (directory / folder).rglob("*") if path.is_file()}}
for name in ("deployment.json", "control-deployment.json", "decoder.loombc"):
    record["sources"][name] = hashlib.sha256((directory / name).read_bytes()).hexdigest()
(notes / "http-publication-source.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"directory": str(directory), "tracked_overlays": len(originals), "added_files": len(files) - len(originals)}))
