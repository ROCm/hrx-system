"""Bounded complete-checkpoint timing around an entropy-only control."""
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
assert os.environ['BENCHMARK_LOCK_LEASE_ID']
tools = json.loads((root / 'unsigned-tools.json').read_text())
programs = {row['program']: row['sha256']
            for row in json.loads((root / 'tables-linked.json').read_text())}
forward = [('summary', 'batch16-1024'), ('1k', 'anchor-batch16-1024'),
           ('4k', 'anchor-batch16')]
for window, cases in [('forward', forward), ('reverse', list(reversed(forward)))]:
    for name, fixture in cases:
        command = [sys.executable, str(root / 'device_batch_benchmark.py'),
                   '--fixture=' + fixture, '--result-name=entropy-anchor-' + name + '-' + window,
                   '--runner=iree-benchmark-loom-unsigned',
                   '--runner-sha256=' + tools['files']['iree-benchmark-loom-unsigned']]
        if name == 'summary':
            program = fixture + '/tables-summary.loombc'
            command.extend(['--program=' + program, '--program-sha256=' + programs[program],
                            '--cache-tables=0'])
        subprocess.run(command, check=True)
