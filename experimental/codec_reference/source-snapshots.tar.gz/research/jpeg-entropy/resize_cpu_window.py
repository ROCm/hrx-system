"""One bounded CPU oracle qualification or cohort measurement window."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time

import persistent_window as harness

parser=argparse.ArgumentParser()
parser.add_argument('mode',choices=('qualify','bench'))
args=parser.parse_args()
root=Path(__file__).resolve().parent
manifest=json.loads((root/'cpu-manifest.json').read_text())
assert os.environ['BENCHMARK_LOCK_LEASE_ID']
before=harness.state()
before['governor']=Path('/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor').read_text().strip()
before['loadavg']=Path('/proc/loadavg').read_text().strip()
before['gpu_power']={str(p):p.read_text().strip() for p in Path('/sys/class/drm').glob('card*/device/power_dpm_force_performance_level')}
assert not before['live_kfd'] and not before['native_workers'],before
for name,row in manifest['files'].items():
    p=root/name
    assert p.stat().st_size==row['bytes'] and hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==row['sha256'],name
images=['012mp-bus.jpg.r0.jpg','006mp-cathedral.jpg.r0.jpg','synthetic-1024.jpg.r0.jpg','synthetic-256.jpg.r0.jpg']
topology=subprocess.check_output(['lscpu','-p=CPU,CORE,SOCKET'],text=True)
cores={tuple(row.split(',')[1:]) for row in topology.splitlines() if not row.startswith('#') and int(row.split(',')[0])<16}
assert len(cores)==16
assert before['governor']=='performance',before
record={'mode':args.mode,'before':before,'manifest':manifest,'topology':topology,'rows':[],
 'scope':'Sixteen jobs each decode/resize eight images into one retained output; 128 completed images and one final CPU task-pool completion. Codec setup, internal and row workspace allocation, scanlines, filtering, and cleanup are timed. Weights and final outputs preallocated.'}
path=root/('cpu-'+args.mode+'-result.json')
policies=('islow','ifast') if args.mode=='qualify' else ('islow','ifast','islow','ifast')
for ordinal,policy in enumerate(policies):
    binary=root/('jpeg_resize_'+policy)
    if args.mode=='qualify':
        command=[str(binary),'capture',str(root/'cpu'/images[0]),str(root/'cpu'/('bus-'+policy+'.rgb'))]
    else:
        command=['taskset','-c','0-15',str(binary),'bench','16','16','9']+[str(root/'cpu'/name) for name in images]
    started=time.monotonic(); result=harness.run_group(command,60)
    row={'policy':policy,'result':result,'wall_seconds':time.monotonic()-started}
    record['rows'].append(row);path.write_text(json.dumps(record,indent=2)+'\n')
    assert result['returncode']==0 and not result.get('harness_timeout'),result
    if args.mode=='qualify':
        output=root/'cpu'/('bus-'+policy+'.rgb')
        row['output_bytes']=output.stat().st_size
        row['output_sha256']=hashlib.file_digest(output.open('rb'),'sha256').hexdigest()
        expected={'islow':'c0b103d5cfe5ae41dac990e7f5c81b4c314bd0fde8bc4d853a2ef75a18e1e05e',
                  'ifast':'7dba1d844a05867a65776609243a1c46126cc1de26c1b056e82d88af75c2a5a5'}
        assert row['output_sha256']==expected[policy],row
    else:
        values=[json.loads(line) for line in result['output'].splitlines() if line.startswith('{')]
        value,=values
        assert value['full_rgb_and_guards'] and value['batch']==16 and value['repeats_per_job']==8
        row['measurement']=value;row['median_ms']=statistics.median(value['batch_ns'])/1e6
    path.write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({k:v for k,v in row.items() if k!='result'}),flush=True)
record['after']=harness.state()
path.write_text(json.dumps(record,indent=2)+'\n')
