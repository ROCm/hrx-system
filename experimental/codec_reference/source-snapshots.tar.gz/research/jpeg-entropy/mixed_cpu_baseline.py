"""Measure the existing CPU oracle on one explicitly mixed sixteen-image cohort."""

import ast
import hashlib
import json
import os
from pathlib import Path
import shlex
import statistics
import subprocess
import sys
import tarfile


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def measure(root):
    directory = root / "mixed-cpu"
    manifest = json.loads((directory / "manifest.json").read_text())
    for relative, expected in manifest["files"].items():
        assert digest(root / relative) == expected, relative
    assert os.environ["BENCHMARK_LOCK_LEASE_ID"]
    assert not any(name.startswith("JSIMD_") for name in os.environ)
    tree = ast.parse((root / "cpu-current/machine-state.py").read_text())
    node = next(node for node in tree.body
                if isinstance(node, ast.FunctionDef) and node.name == "state")
    namespace = dict(globals())
    # The retained machine-state helper's only additional module dependency.
    import re
    namespace["re"] = re
    exec(compile(ast.Module(body=[node], type_ignores=[]), "machine-state.py", "exec"), namespace)
    state = namespace["state"]
    before = state()
    assert before["governor"] == "performance"
    assert int(before["personality"], 16) & 0x40000
    assert before["gpu_busy"] == 0 and not before["kfd_processes"] and not before["drm"]
    topology = subprocess.check_output(["lscpu", "-p=CPU,CORE,SOCKET"], text=True)
    physical = {tuple(row.split(",")[1:]) for row in topology.splitlines()
                if not row.startswith("#") and int(row.split(",")[0]) < 16}
    assert len(physical) == 16
    binaries = {"islow": "cpu-current/jpeg_baseline",
                "float": "cpu-idct/cpu_float_baseline",
                "ifast": "cpu-idct/cpu_fast_baseline"}
    record = {"manifest": manifest, "before": before, "topology": topology, "rows": [],
              "scope": {"batch": 16, "workers": 16, "affinity": "0-15",
                        "warmups": 2, "samples": 9,
                        "timed": "One CPU task-pool cohort submission through final retirement; codec header/create/decode/finish/destroy included; final RGB destinations preallocated.",
                        "distribution": "Ordered quartet repeated four times; deliberately uneven size distribution, not a training dataset."}}
    output = directory / "results.json"
    output.write_text(json.dumps(record, indent=2) + "\n")
    for ordinal, policy in enumerate(("islow", "float", "ifast", "islow", "ifast", "float")):
        command = ["taskset", "-c", "0-15", str(root / binaries[policy]),
                   "bench", "16", "16", "9"]
        command.extend(str(directory / image["name"]) for image in manifest["images"])
        result = subprocess.run(command, capture_output=True, text=True)
        log = directory / f"{ordinal}-{policy}.log"
        log.write_text(result.stdout + result.stderr)
        assert result.returncode == 0, result.stdout + result.stderr
        rows = [json.loads(line) for line in result.stdout.splitlines() if line.startswith("{")]
        row, = rows
        assert row["full_rgb_and_guards"] and len(row["batch_ns"]) == 9
        assert row["images"] == [image["name"] for image in manifest["images"]]
        assert row["compressed_bytes"] == manifest["cohort_compressed_bytes"]
        assert row["rgb_bytes"] == manifest["cohort_rgb_bytes"]
        record["rows"].append({"policy": policy, "command": command,
                               "median_batch_ns": statistics.median(row["batch_ns"]),
                               "result": row, "log_sha256": digest(log)})
        output.write_text(json.dumps(record, indent=2) + "\n")
        print(json.dumps({"policy": policy, "median_batch_ms": statistics.median(row["batch_ns"]) / 1e6}), flush=True)
    record["after"] = state()
    assert not record["after"]["kfd_processes"] and not record["after"]["drm"]
    output.write_text(json.dumps(record, indent=2) + "\n")


def stage_and_run():
    notes = Path(__file__).resolve().parent
    root = Path(json.loads((notes / "device-active.json").read_text())["directory"])
    directory = root / "mixed-cpu"
    directory.mkdir(exist_ok=True)
    baseline = notes.parent / "jpeg-baseline"
    structures = {row["name"]: row for row in json.loads((baseline / "input-structure.json").read_text())}
    names = ["012mp-bus.jpg.r0.jpg", "006mp-cathedral.jpg.r0.jpg",
             "synthetic-1024.jpg.r0.jpg", "synthetic-256.jpg.r0.jpg"]
    files = {"mixed-cpu/" + name: baseline / "inputs" / name for name in names}
    files["mixed-cpu/measure.py"] = Path(__file__).resolve()
    cpu = json.loads((notes / "cpu-refresh-stage.json").read_text())
    variants = json.loads((notes / "cpu-idct-stage.json").read_text())
    assert digest(baseline / "jpeg_baseline.cc") == cpu["source_sha256"]
    hashes = {name: digest(path) for name, path in files.items()}
    hashes.update({"cpu-current/jpeg_baseline": cpu["files"]["jpeg_baseline"],
                   "cpu-current/machine-state.py": cpu["files"]["machine-state.py"]})
    for policy in ("float", "fast"):
        relative = "cpu-idct/cpu_" + policy + "_baseline"
        hashes[relative] = variants["files"][relative]
    images = [structures[name] for name in names]
    for image in images:
        assert hashes["mixed-cpu/" + image["name"]] == image["sha256"]
    manifest = {"files": hashes, "images": images,
                "cohort_compressed_bytes": 4 * sum(image["bytes"] for image in images),
                "cohort_rgb_bytes": 4 * sum(image["rgb_bytes"] for image in images),
                "oracle_build_commit": cpu["commit"], "oracle_configuration": cpu["configuration"],
                "oracle_source_sha256": cpu["source_sha256"],
                "oracle_native_sha256": cpu["native_sha256"],
                "retention": "Existing pinned comparator binaries reused in /tmp. CPU output/reference arrays exist only during each process. New input copies total less than 5 MiB. Durable output is JSON, manifests, and short logs."}
    (directory / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    files["mixed-cpu/manifest.json"] = directory / "manifest.json"
    process = subprocess.Popen(["ssh", "hrx-gorgon-4", "tar -xf - -C " + shlex.quote(str(root))], stdin=subprocess.PIPE)
    with tarfile.open(fileobj=process.stdin, mode="w|", dereference=True) as archive:
        for name, path in files.items():
            archive.add(path, arcname=name, recursive=False)
    process.stdin.close()
    assert process.wait() == 0
    command = ["/home/benvanik/.dotfiles/bin/benchmark-lock", "--label=codec-jpeg-mixed-cpu",
               "--", "timeout", "--signal=INT", "--kill-after=10s", "180s",
               "python3", "-B", str(directory / "measure.py"), "--remote", str(root)]
    result = subprocess.run(["ssh", "hrx-gorgon-4", shlex.join(command)], capture_output=True, text=True)
    (notes / "gorgon4-mixed-cpu.log").write_text(result.stdout + result.stderr)
    print(result.stdout + result.stderr, end="", flush=True)
    status = subprocess.run(["ssh", "hrx-gorgon-4", "~/.dotfiles/bin/benchmark-lock --status"], capture_output=True, text=True)
    receipt = {"command": command, "returncode": result.returncode,
               "broker_status_after": status.stdout + status.stderr,
               "broker_status_returncode": status.returncode, "manifest": manifest}
    (notes / "gorgon4-mixed-cpu-run.json").write_text(json.dumps(receipt, indent=2) + "\n")
    assert result.returncode == 0, result.stdout + result.stderr
    output = subprocess.check_output(["ssh", "hrx-gorgon-4", "cat " + shlex.quote(str(directory / "results.json"))])
    (notes / "gorgon4-mixed-cpu.json").write_bytes(output)
    print(status.stdout + status.stderr, end="", flush=True)


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "--remote":
        measure(Path(sys.argv[2]))
    else:
        assert len(sys.argv) == 1
        stage_and_run()
