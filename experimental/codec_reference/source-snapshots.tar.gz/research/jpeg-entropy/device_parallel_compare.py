"""Matched bridge/control and complete certificate batches; no host inner wait."""
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
tools = json.loads((root / 'unsigned-tools.json').read_text())
for window, name in enumerate(('bridge', 'certificate', 'bridge', 'certificate', 'bridge')):
    fixture = ('bridge' if name == 'bridge' else 'parallel') + '-batch16-1024'
    command = [sys.executable, str(root / 'device_batch_benchmark.py'),
               '--fixture=' + fixture, '--result-name=entropy-parallel-' + name + '-' + str(window),
               '--runner=iree-benchmark-loom-unsigned',
               '--runner-sha256=' + tools['files']['iree-benchmark-loom-unsigned']]
    subprocess.run(command, check=True)
