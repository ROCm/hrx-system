"""Capture the actual second-witness resize with one bounded GPU lease."""
import json
from pathlib import Path
import shlex
import subprocess

notes = Path(__file__).resolve().parent
directory = Path(json.loads((notes / 'device-active.json').read_text())['directory']) / 'vision-accuracy'
host = 'hrx-gorgon-3'
prefix = 'gorgon3-cathedral-resize'
expected = json.loads((notes / 'gorgon4-resize-metrics.json').read_text())['tool_sha256']
verify = '''
import hashlib, json
from pathlib import Path
p = Path(%r)
assert hashlib.file_digest((p / 'resize-check').open('rb'), 'sha256').hexdigest() == %r
m = json.loads((p / 'manifest.json').read_text())
assert m['witness'] == 'cathedral'
for name, digest in m['files'].items():
    assert hashlib.file_digest((p / name).open('rb'), 'sha256').hexdigest() == digest, name
''' % (str(directory), expected)
subprocess.run(['ssh', host, 'python3 -B -'], input=verify, text=True, check=True)
base = ['python3', '-B', str(directory / 'observe_model_resize.py'), str(directory)]
subprocess.run(['ssh', host, shlex.join(base + ['prepare'])], check=True)
command = ['ssh', host, shlex.join([
    '/home/benvanik/.dotfiles/bin/benchmark-lock', '--label=codec-jpeg-cathedral-resize', '--',
    'env', 'LD_LIBRARY_PATH=/opt/rocm/lib', *base, 'execute'])]
with (notes / (prefix + '.log')).open('w') as log:
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    for line in process.stdout:
        log.write(line)
        log.flush()
        print(line, end='', flush=True)
    result = process.wait()
status = subprocess.run(['ssh', host, '/home/benvanik/.dotfiles/bin/benchmark-lock --status'],
                        capture_output=True, text=True)
receipt = {'command': command, 'returncode': result, 'tool_sha256': expected,
           'broker_status_after': status.stdout + status.stderr,
           'broker_status_returncode': status.returncode}
(notes / (prefix + '-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
subprocess.run(['scp', host + ':' + str(directory / 'resize-observations/runs.json'),
                str(notes / (prefix + '-runs.json'))], check=True)
if result or status.returncode:
    raise SystemExit(result or status.returncode)
subprocess.run(['ssh', host, shlex.join(base + ['analyze'])], check=True)
for name, output in [('resize-metrics.json', prefix + '-metrics.json'),
                      ('projector-metrics.json', 'gorgon3-cathedral-projector-metrics.json')]:
    subprocess.run(['scp', host + ':' + str(directory / name), str(notes / output)], check=True)
assert json.loads((notes / (prefix + '-metrics.json')).read_text())['tool_sha256'] == expected
print(json.dumps(receipt), flush=True)
