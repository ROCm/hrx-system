"""Separate source compilation from device execution for the shift timeout."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

notes = Path(__file__).resolve().parent
directory = Path(json.loads((notes / 'device-active.json').read_text())['directory']) / 'rebase-1956'
directory.mkdir(exist_ok=True)
tag_name = sys.argv[1] if len(sys.argv) > 1 else 'codec-jpeg-rebased-tools'
tag = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])[tag_name])
compiler = tag / 'loom/src/loom/tools/loom-compile/loom-compile'
source = Path('loom/src/loom/test/corpus/numeric/vector/integer_shifts.loom').read_text()
for width in (8, 16, 32, 64):
    source += f'''
kernel.def @shift_i{width}() {{
  %unit = index.constant 1 : index
  kernel.launch.config workgroups(%unit, %unit, %unit) workgroup_size(%unit, %unit, %unit) : index
}} launch(%input: buffer, %counts: buffer, %output: buffer) {{
  func.call @vector_i{width}_shifts(%input, %counts, %output) : (buffer, buffer, buffer) -> ()
  kernel.return
}}
'''
path = directory / 'shifts.loom'
path.write_text(source)
rows = []
for width in (8, 16, 32, 64):
    command = [str(compiler), str(path), f'--root=shift_i{width}',
               '--target=spirv:vulkan1.3+bda+extended-types',
               '--dump-ir-after-all', f'--dump-ir-output={directory}/shift{width}-ir',
               f'--output={directory}/shift{width}.spv']
    print('Starting', width, flush=True)
    start = time.monotonic()
    with (directory / f'shift{width}.log').open('w') as stream:
        result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT)
    row = {'width': width, 'exit': result.returncode, 'seconds': time.monotonic() - start,
           'command': command}
    rows.append(row)
    print(json.dumps(row), flush=True)
    if result.returncode:
        print((directory / f'shift{width}.log').read_text(), flush=True)
        break
(notes / f'{tag_name}-shift-compilation.json').write_text(json.dumps({
    'compiler_sha256': hashlib.sha256(compiler.read_bytes()).hexdigest(),
    'source_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'rows': rows}, indent=2) + '\n')
