"""Refresh the complete public-libjpeg CPU boundary on the active GPU host."""
from pathlib import Path
import ast
import hashlib
import json
import os
import re
import statistics
import subprocess

root=Path(__file__).resolve().parent
os.chdir(root)
manifest=json.loads((root/'manifest.json').read_text())
for name,digest in manifest['files'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
assert os.environ['BENCHMARK_LOCK_LEASE_ID']
tree=ast.parse((root/'machine-state.py').read_text())
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='state')
exec(compile(ast.Module(body=[node],type_ignores=[]),'machine-state.py','exec'))
before=state()
assert before['governor']=='performance' and int(before['personality'],16)&0x40000
assert not before['kfd_processes'] and not before['drm']
assert not any(name.startswith('JSIMD_') for name in os.environ)
record={'manifest':manifest,'before':before,'rows':[]}
record['host']=subprocess.check_output(['lscpu'],text=True)
command=['taskset','-c','4','/opt/rocm/bin/rocgdb','--batch','-x','routes.gdb','--args','./jpeg_baseline','qualify','012mp-bus.jpg.r0.jpg']
r=subprocess.run(command,check=True,capture_output=True,text=True)
(root/'routes.log').write_text(r.stdout+r.stderr)
record['routes']=re.findall(r'^JPEG_ROUTE (\S+) (\S+)',r.stdout,re.M)
for symbol in ('jsimd_idct_islow_avx2','jsimd_ycc_rgb_convert_avx2','jsimd_h2v2_fancy_upsample_avx2'):
    assert any(name==symbol for name,address in record['routes']),symbol
assert 'exited normally' in r.stdout
for workers in (4,16,4,16,4):
    command=['taskset','-c','4-7' if workers==4 else '0-15','./jpeg_baseline','bench','16',str(workers),'9','012mp-bus.jpg.r0.jpg']
    r=subprocess.run(command,check=True,capture_output=True,text=True)
    rows=[json.loads(line) for line in r.stdout.splitlines() if line.startswith('{')]
    assert len(rows)==1 and rows[0]['full_rgb_and_guards']
    row=rows[0];row['command']=command;row['median_batch_ns']=statistics.median(row['batch_ns'])
    record['rows'].append(row)
    (root/'results.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({'workers':workers,'batch':16,'median_ms':row['median_batch_ns']/1e6}),flush=True)
record['after']=state()
(root/'results.json').write_text(json.dumps(record,indent=2)+'\n')
