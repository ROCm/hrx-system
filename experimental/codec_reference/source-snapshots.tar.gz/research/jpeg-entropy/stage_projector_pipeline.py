"""Stage the next measured boundary within the existing bounded source root."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import tarfile

parser = argparse.ArgumentParser()
parser.add_argument("--configuration", choices=("asan", "opt"), required=True)
options = parser.parse_args()
notes = Path(__file__).resolve().parent
previous = json.loads((notes / "http-publication-stage.json").read_text())
source = json.loads((notes / "http-publication-source.json").read_text())
build = json.loads((notes / f"projector-pipeline-{options.configuration}-build.json").read_text())
assert build['restored'] and build['returncode'] == 0
directory = Path(source['directory'])
tag = 'codec-jpeg-pipeline-' + options.configuration
capture = json.loads(subprocess.check_output(['bureau-bazel', 'tag', 'inspect', tag, '--json'], text=True))
assert capture['capture'] == build['capture']['capture']
binary = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])[tag]) / capture['outputs'][0]
name = 'pipeline-probe-' + options.configuration
files = {name: binary, 'pipeline_run.py': notes / 'projector_pipeline_run.py'}
manifest = {'configuration': options.configuration, 'capture': capture['capture'],
            'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
            'files': {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in files.items()},
            'source_files': {name: digest for name, digest in previous['manifest']['files'].items()
                             if name not in ['loom-serve', 'run.py']},
            'retired_server_sha256': previous['manifest']['files']['loom-serve'],
            'maximum_staged_bytes': 256 * 1024**2,
            'feature_pair_bytes': 2 * 19906560}
manifest_path = directory / f'pipeline-{options.configuration}-manifest.json'
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
files[manifest_path.name] = manifest_path
machine = previous['machine']
# The exact completed experimental server is replaceable cache state; source
# and receipt files remain. This never stops a shared process or removes a tree.
retire = '''import hashlib,pathlib,sys
root=pathlib.Path(sys.argv[1]); path=root/'loom-serve'
assert not list(pathlib.Path('/sys/class/kfd/kfd/proc').iterdir()), 'active GPU client'
if path.exists():
 assert hashlib.file_digest(path.open('rb'),'sha256').hexdigest()==sys.argv[2]
 path.unlink()
 print('Retired the completed HTTP server copy.')
'''
subprocess.run(['ssh', machine, shlex.join(['python3','-B','-c',retire,str(directory),manifest['retired_server_sha256']])], check=True)
process = subprocess.Popen(['ssh', machine, 'tar -xzf - -C ' + shlex.quote(str(directory))], stdin=subprocess.PIPE)
with tarfile.open(fileobj=process.stdin, mode='w|gz', dereference=True) as archive:
    for item, path in files.items():
        archive.add(path, arcname=item, recursive=False)
process.stdin.close()
assert process.wait() == 0
verify = '''import hashlib,json,pathlib,sys
root=pathlib.Path(sys.argv[1]); manifest=json.loads((root/sys.argv[2]).read_text())
for name,digest in dict(manifest['source_files'],**manifest['files']).items():
 with (root/name).open('rb') as stream:
  assert hashlib.file_digest(stream,'sha256').hexdigest()==digest,name
total=sum(path.stat().st_size for path in root.rglob('*') if path.is_file())
assert total+manifest['feature_pair_bytes'] < manifest['maximum_staged_bytes'],total
assert not list(pathlib.Path('/sys/class/kfd/kfd/proc').iterdir())
print(json.dumps({'staged_bytes':total,'reserved_feature_bytes':manifest['feature_pair_bytes'],'verified':True,'lease_held':False}))
'''
result = subprocess.run(['ssh', machine, shlex.join(['python3','-B','-c',verify,str(directory),manifest_path.name])], capture_output=True,text=True)
record = {'machine':machine,'manifest':manifest,'verification_returncode':result.returncode,
          'verification':result.stdout+result.stderr,'lease_held':False}
(notes / f'projector-pipeline-{options.configuration}-stage.json').write_text(json.dumps(record,indent=2)+'\n')
print(record['verification'],flush=True)
assert result.returncode == 0
