"""Header-only plans, poisoned device state, and independent final filter output."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from persistent_rows import axis_plan

parser = argparse.ArgumentParser()
parser.add_argument('--family',choices=('small','primary'),default='small')
parser.add_argument('--rows',type=int,default=3)
parser.add_argument('--workers',type=int,default=128)
parser.add_argument('--repetitions',type=int,default=8)
parser.add_argument('--invalid',nargs='?',const='marker',choices=('marker','padding'))
args=parser.parse_args()
NOTES=Path(__file__).resolve().parent
ROOT=Path(json.loads((NOTES/'device-active.json').read_text())['directory'])
SOURCE=ROOT/('mixed-negative-base' if args.family=='small' else 'mixed-current')
PROGRAM=ROOT/'persistent-resize/source'
case=f'{args.family}-r{args.rows}-w{args.workers}'+('-invalid' if args.invalid=='marker' else '-invalid-padding' if args.invalid else '')
OUTPUT=ROOT/'persistent-resize'/case
OUTPUT.mkdir(parents=True,exist_ok=True)
layout=json.loads((PROGRAM/'directory.json').read_text())
stage=json.loads((SOURCE/'stage.json').read_text())
assert stage['invalid_index'] is None
assert 3<=args.rows<=64 and 1<=args.workers<=1024
arrays={}; expected={}; hashes={}
def load(name):
    path=SOURCE/(name+'.npy')
    digest=hashlib.file_digest(path.open('rb'),'sha256').hexdigest()
    assert digest==stage['files'][path.name]
    hashes[path.name]=digest
    return np.load(path,mmap_mode='r').view(np.uint8 if name=='rgb' else np.uint32)
for name in ('tables','blocks','geometry','quantization','zigzag','compressed'):
    arrays[name]=load(name).copy()
arrays['images']=load('headers').copy()
producer_names=('entropy','segments','intervals','records','prefixes','errors','schedule',
                'jobs','expected','points','bridges','suffixes','ranges')
for name in producer_names: expected[name]=load(name).copy()
original_geometry=arrays['geometry'].copy()
original_pixels=load('pixels'); original_rgb=load('rgb')
ring_chunks=[]; ring_words=0; plans=[]; stream_expected=[]; decoded_expected=[]
color_counts=[]; row_offset=0; resize_plans=[]; resize_row_offset=0
filter_indices=[]; filter_weights=[]; filter_tiles=[]; horizontal_chunks=[]
horizontal_words=0; result_chunks=[]; result_bytes=0; resize_counts=[]; image_records=[]
cache={}
def add_axis(plan):
    start_offset=len(filter_indices); filter_indices.extend(start for start,_ in plan)
    offset_offset=len(filter_indices); offsets=[0]
    for _,weights in plan: offsets.append(offsets[-1]+len(weights))
    filter_indices.extend(offsets)
    weight_offset=len(filter_weights)
    for _,weights in plan: filter_weights.extend(weights)
    return start_offset,offset_offset,weight_offset
def oracle(rgb,horizontal,vertical,width,ring_rows):
    ring=np.full(ring_rows*width*3,17,dtype=np.uint32).view(np.float32).reshape(ring_rows,width,3)
    output=np.empty((len(vertical),width,3),dtype=np.uint8)
    count=max(len(w) for _,w in horizontal)
    indices=np.zeros((count,width),dtype=np.int32)
    weights=np.zeros((count,width),dtype=np.float32)
    for x,(start,ws) in enumerate(horizontal):
        indices[:len(ws),x]=np.arange(start,start+len(ws));weights[:len(ws),x]=ws
    output_row=0
    for y,row in enumerate(rgb):
        filtered=np.zeros((width,3),dtype=np.float32)
        for positions,ws in zip(indices,weights):
            filtered+=row[positions].astype(np.float32)*ws[:,None]
        ring[y%ring_rows]=filtered
        while output_row<len(vertical):
            start,ws=vertical[output_row]
            if start+len(ws)>y+1:break
            value=np.zeros((width,3),dtype=np.float32)
            for index,weight in enumerate(ws):value+=ring[(start+index)%ring_rows]*weight
            output[output_row]=np.clip(np.rint(value),0,255).astype(np.uint8)
            output_row+=1
    assert output_row==len(vertical)
    return ring.reshape(-1).view(np.uint32).copy(),output.reshape(-1)

for ordinal,record in enumerate(stage['images']):
    image=arrays['images'][ordinal*18:ordinal*18+18]
    old_image=image.copy(); width,height=map(int,image[12:14])
    blocks=arrays['blocks'][ordinal*4:ordinal*4+4];count=int(blocks[3])
    segment=expected['segments'][ordinal*8:ordinal*8+8]
    mcu_height=16 if int(image[17]) in (5,6,8) else 8
    rows=(height+mcu_height-1)//mcu_height
    geometry_base=int(image[9]);components={}
    for block in range(count):
        component=int(blocks[block//4]>>((block%4)*8))&3
        shape=original_geometry[geometry_base+block*8:geometry_base+block*8+8]
        components[component]=tuple(map(int,shape[:5]))
    offsets={};sizes={};local=[]
    for component,(old_offset,columns,block_rows,horizontal,vertical) in sorted(components.items()):
        capacity=args.rows*vertical;size=capacity*columns*16
        offsets[component]=sum(len(v) for v in local);sizes[component]=size
        plane=np.full(size,17,dtype=np.uint32)
        for row in range(block_rows):
            begin=int(old_image[3])+old_offset+row*columns*16
            target=(row%capacity)*columns*16
            plane[target:target+columns*16]=original_pixels[begin:begin+columns*16]
        local.append(plane)
    for block in range(count):
        component=int(blocks[block//4]>>((block%4)*8))&3
        arrays['geometry'][geometry_base+block*8]=offsets[component]
    image[3]=ring_words;segment[7]=ring_words
    image[15]=sizes[0]*4;image[16]=sizes.get(1,0)*4
    plans.extend([row_offset,rows,ring_words,0,0,0,0])
    first=int(segment[2])*5+ordinal; interval_count=int(segment[3])*5+1
    intervals=expected['intervals'][first*8:(first+interval_count)*8].reshape(-1,8)
    retained=int(np.count_nonzero(intervals[:-1,0]<intervals[:-1,1]))+1
    stream_expected.extend([row_offset,rows,ring_words,rows,retained,retained,0])
    decoded_expected.extend([int(image[11])]*rows)
    ring_chunks.append(np.concatenate(local+[np.full(8,17,dtype=np.uint32)]))
    ring_words+=len(ring_chunks[-1])
    if args.family=='primary':
        targets={'012mp-bus.jpg.r0.jpg':(1152,864),'006mp-cathedral.jpg.r0.jpg':(576,864),
                 'synthetic-1024.jpg.r0.jpg':(448,336),'synthetic-256.jpg.r0.jpg':(112,112)}
        out_width,out_height=targets[record['name']]
    else: out_width,out_height=max(1,(width*2+2)//3),max(1,(height*2+2)//3)
    hp=axis_plan(width,out_width); vp=axis_plan(height,out_height)
    horizontal_rows=max(len(w) for _,w in vp)+mcu_height
    hs,ho,hw=add_axis(hp);vs,vo,vw=add_axis(vp)
    tile_offset=len(filter_tiles)//4;begin=0
    while begin<out_width:
        first_source=hp[begin][0]//4*4;end=begin
        while end<min(out_width,begin+32) and hp[end][0]+len(hp[end][1])<=first_source+128:end+=1
        assert end>begin
        filter_tiles.extend([begin,end,first_source,128]);begin=end
    tile_count=len(filter_tiles)//4-tile_offset
    for row in range(rows):color_counts.append(tile_count*min(mcu_height,height-row*mcu_height))
    resize_counts.extend([(out_width+31)//32]*out_height)
    key=(record['name'],out_width,out_height,horizontal_rows)
    if key not in cache:
        rgb=original_rgb[int(old_image[14]):int(old_image[14])+width*height*3].reshape(height,width,3)
        cache[key]=oracle(rgb,hp,vp,out_width,horizontal_rows)
        if record['name']=='012mp-bus.jpg.r0.jpg':
            assert hashlib.sha256(cache[key][1].tobytes()).hexdigest()=='1814e73c296f30373fd37e3f5bb0a711697486372e0617110ae774ae0791a642'
    filtered,result=cache[key]
    resize_plans.extend([out_width,out_height,horizontal_words,horizontal_rows,hs,ho,hw,vs,vo,vw,
                         tile_offset,tile_count,resize_row_offset,result_bytes])
    horizontal_chunks.append(np.concatenate([filtered,np.full(8,17,dtype=np.uint32)]))
    result_chunks.append(np.concatenate([result,np.full(32,17,dtype=np.uint8)]))
    image_records.append({'name':record['name'],'rows':rows,'row_offset':row_offset,
        'pixel_word_count':len(ring_chunks[-1]),'interval_count':retained,
        'source':[width,height],'target':[out_width,out_height],
        'output_offset':result_bytes,'output_bytes':len(result),'horizontal_rows':horizontal_rows,
        'horizontal_bytes':filtered.nbytes,'output_sha256':hashlib.sha256(result.tobytes()).hexdigest()})
    row_offset+=rows;resize_row_offset+=out_height
    horizontal_words+=len(horizontal_chunks[-1]);result_bytes+=len(result_chunks[-1])

arrays['plans']=np.array(plans,dtype=np.uint32)
arrays['resize_plans']=np.array(resize_plans,dtype=np.uint32)
arrays['filter_indices']=np.array(filter_indices,dtype=np.uint32)
arrays['filter_weights']=np.array(filter_weights,dtype=np.float32).view(np.uint32)
arrays['filter_tiles']=np.array(filter_tiles,dtype=np.uint32)
expected.update(pixels=np.concatenate(ring_chunks),streams=np.array(stream_expected,dtype=np.uint32),
    heads=np.full(row_offset,0xffffffff,dtype=np.uint32),pending=np.zeros(row_offset,dtype=np.uint32),
    decoded=np.array(decoded_expected,dtype=np.uint32),color_claimed=np.array(color_counts,dtype=np.uint32),
    color_done=np.array(color_counts,dtype=np.uint32),horizontal=np.concatenate(horizontal_chunks),
    provisional=np.concatenate(result_chunks),resized=np.concatenate(result_chunks),
    resize_rows=np.array([r['target'][1] for r in image_records],dtype=np.uint32),
    resize_claimed=np.array(resize_counts,dtype=np.uint32),resize_done=np.array(resize_counts,dtype=np.uint32),
    validity=np.zeros(len(image_records),dtype=np.uint32))
for name,value in expected.items():arrays[name]=np.full_like(value,17)
arrays['links']=np.full(len(expected['intervals'])//8,17,dtype=np.uint32)
arrays['cursors']=np.full(len(expected['intervals']),17,dtype=np.uint32)
if args.invalid:
    image=arrays['images'][:18]
    position=int(image[4])*4+int(image[0])-1
    encoded=arrays['compressed'].view(np.uint8)
    assert encoded[position]==0xd9
    if args.invalid=='marker':
        encoded[position]=0xd8
        rejection=258
    else:
        from sequential import parse,decode
        first=int(image[4])*4
        frame=parse(encoded[first:position+1].tobytes())
        _,traces=decode(frame,record_trace=True)
        assert len(traces)==1 and int(traces[0].positions[-1])%8!=0
        byte=position-2
        if encoded[byte]==0 and encoded[byte-1]==255:byte-=1
        assert encoded[byte]&1
        # An unused padding bit changes, after the complete coefficient stream.
        # Byte stuffing is unaffected for this retained small-image witness.
        assert encoded[byte]!=255
        encoded[byte]&=254
        rejection=4
    # Device byte admission rejects the first image. Its private intermediates
    # are unprescribed; all other final images and every allocation guard remain
    # checked after the same single command completion.
    resized=expected['resized']
    resized[:image_records[0]['output_bytes']]=17
    validity=expected['validity'];validity[0]=rejection
    expected={'resized':resized,'validity':validity}
names=layout['inputs']+layout['outputs'];roots={'input':bytearray(4*len(names)),'output':bytearray()}
ranges={};regions=[];guard_ranges=[]
for name in names:
    owner='input' if name in layout['inputs'] else 'output';value=arrays[name];raw=roots[owner]
    padding=(-len(raw))%16
    if owner=='output' and padding:guard_ranges.append((len(raw),padding))
    raw.extend(bytes([0xa7])*padding);offset=len(raw);raw.extend(value.tobytes())
    if owner=='output':guard_ranges.append((len(raw),32))
    raw.extend(bytes([0xa7])*32)
    ranges[name]={'root':owner,'offset':offset,'bytes':value.nbytes,'elements':len(value),
                  'type':'i8' if value.itemsize==1 else 'i32'}
    roots['input'][names.index(name)*4:names.index(name)*4+4]=offset.to_bytes(4,'little')
assert sum(map(len,roots.values()))<128*1024*1024
for name,value in roots.items():np.save(OUTPUT/(name+'.npy'),np.frombuffer(value,dtype=np.int8))
final=np.frombuffer(roots['output'],dtype=np.uint8).copy()
for name,value in expected.items():
    row=ranges[name];final[row['offset']:row['offset']+row['bytes']]=value.view(np.uint8)
    regions.append(('output',row['offset'],row['bytes']))
regions+=[('output',offset,length) for offset,length in guard_ranges]
regions.insert(0,('input',0,len(roots['input'])))
np.save(OUTPUT/'output-expected.npy',final.view(np.int8))
(OUTPUT/'bindings.txt').write_text(f'input 1 1 {len(roots["input"])} input.npy\noutput 0 1 {len(roots["output"])} output-expected.npy\n')
(OUTPUT/'regions.txt').write_text(''.join(f'{owner} {offset} {length} exact\n' for owner,offset,length in regions))
configuration=json.loads((SOURCE/'config.json').read_text())
configuration['stream']={'rows':args.rows,'workers':args.workers}
configuration['input']['tiles']=max(int(r['header'][7]) for r in stage['images'])
(OUTPUT/'config.json').write_text(json.dumps(configuration,indent=2)+'\n')
command=(PROGRAM/'command.loom').read_text()
body=command[command.index('  %zero ='):command.rindex('  command.return')]
launches=body[body.index('  command.serial {')+len('  command.serial {'):body.rindex('  }')]
command+='\ncommand.program.def public @jpeg_batch() launch(%input: buffer, %output: buffer) {\n  %zero = index.constant 0 : offset\n  command.serial {\n'+launches*args.repetitions+'  }\n  command.return\n}\n'
(OUTPUT/'command.loom').write_text(command)
receipt={'case':case,'scope':'Poisoned compressed-input to bounded native RGB resize; original entropy, IDCT and exact model filter order.',
    'source_fixture':str(SOURCE),'input_hashes':hashes,'images':image_records,'ranges':ranges,
    'root_bytes':{k:len(v) for k,v in roots.items()},'configuration':configuration,
    'repetitions':args.repetitions,'guard_bytes':sum(n for _,n in guard_ranges),
    'source_sha256':hashlib.sha256((PROGRAM/'resize.cxx').read_bytes()).hexdigest()}
(OUTPUT/'fixture.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'case':case,'root_bytes':receipt['root_bytes'],'component_bytes':arrays['pixels'].nbytes,
                  'horizontal_bytes':arrays['horizontal'].nbytes,'final_bytes':result_bytes}),flush=True)
