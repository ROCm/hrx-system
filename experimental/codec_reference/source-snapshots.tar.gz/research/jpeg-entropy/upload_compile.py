"""Compile and account the two-root join using the leased qualified tools."""

import hashlib
import json
import os
from pathlib import Path
import subprocess


notes = Path(__file__).resolve().parent
directory = Path(json.loads((notes / "device-active.json").read_text())["directory"]) / "native-upload"
tag = Path(json.loads(os.environ["BUREAU_TAG_ROOTS"])["codec-jpeg-rebased-tools"])
tools = {name: tag / "loom/src/loom/tools" / name / name
         for name in ("loom-import-cxx", "loom-link", "loom-compile")}
source = json.loads((notes / "upload-source.json").read_text())
for name, expected in source["files"].items():
    assert hashlib.sha256((directory / name).read_bytes()).hexdigest() == expected
record = {"source": source, "tools": {name: hashlib.sha256(path.read_bytes()).hexdigest()
                                     for name, path in tools.items()}, "commands": [], "leaves": {}}


def run(name, command):
    result = subprocess.run(command, capture_output=True, text=True)
    (directory / (name + ".log")).write_text(result.stdout + result.stderr)
    record["commands"].append({"arguments": command, "returncode": result.returncode})
    (notes / "upload-compile.json").write_text(json.dumps(record, indent=2) + "\n")
    assert result.returncode == 0, result.stdout + result.stderr


run("import", [str(tools["loom-import-cxx"]), str(directory / "upload_pipeline.cxx"),
               "--output=" + str(directory / "library.loom")])
run("link", [str(tools["loom-link"]), str(directory / "command.loom"), str(directory / "library.loom"),
             "--to=bc", "--output=" + str(directory / "summary.loombc")])
print("Imported and linked twelve two-root decoder kernels.", flush=True)
for entry in source["entries"]:
    name = entry["name"]
    report = directory / (name + ".report.json")
    binary = directory / (name + ".hsaco")
    run(name, [str(tools["loom-compile"]), str(directory / "summary.loombc"), "--root=" + name,
               "--target=amdgpu:gfx1151", "--config-file=" + str(directory / "config.json"),
               "--output=" + str(binary), "--compile-report=details", "--compile-report-output=" + str(report)])
    row = json.loads(report.read_text())["entries"]["rows"][0]
    assembly = subprocess.check_output(["/home/ben/tools/llvm/latest/bin/llvm-objdump", "-d", "--mcpu=gfx1151", str(binary)], text=True)
    (directory / (name + ".native.s")).write_text(assembly)
    record["leaves"][name] = {
        "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
        "assembly_sha256": hashlib.sha256(assembly.encode()).hexdigest(),
        "resources": {key: row[key] for key in ("instruction_count", "code_byte_count", "private_memory_bytes", "local_memory_bytes", "target_resources")},
    }
    (notes / "upload-compile.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps({"kernel": name, "instructions": row["instruction_count"], "private": row["private_memory_bytes"],
                      "vgpr": row["target_resources"]["vector"]["final"]["register_count"]}), flush=True)
record["bytecode_sha256"] = hashlib.sha256((directory / "summary.loombc").read_bytes()).hexdigest()
(notes / "upload-compile.json").write_text(json.dumps(record, indent=2) + "\n")
