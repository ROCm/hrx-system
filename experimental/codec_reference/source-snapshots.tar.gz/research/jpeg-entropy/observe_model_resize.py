"""Observe the pinned model filter on real VM-produced packets."""
import ast
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
import sys

directory = Path(sys.argv[1])
phase = sys.argv[2]
assert phase in ('prepare', 'execute', 'analyze')
metrics = json.loads((directory / 'projector-metrics.json').read_text())
observations = directory / 'observations'
destination = directory / 'resize-observations'
destination.mkdir(exist_ok=True)
names = ('jpeg', 'islow', 'loom-float32', 'cosine', 'float', 'ifast')
source = directory / 'sources/experimental/loom_serve/models/qwen/kernels/qwen38/vision_resize.loom'
manifest = json.loads((directory / 'manifest.json').read_text())
assert hashlib.file_digest(source.open('rb'), 'sha256').hexdigest() == manifest['files'][str(source.relative_to(directory))]
runner = directory / 'resize-check'
records = []
source_width, source_height = manifest['image_geometry']
target_width, target_height = manifest['target_geometry']
output_bytes = target_width * target_height * 3
for name in names if phase == 'prepare' else ():
    prepared = observations / (name + '.prepared')
    packet = bytearray(prepared.read_bytes())
    expected = metrics['artifacts'][prepared.name]
    assert len(packet) == expected['bytes']
    assert hashlib.sha256(packet).hexdigest() == expected['sha256']
    # The actual prepare_batch source writes this one-image cohort directory.
    assert packet[:64] == bytes(64)
    struct.pack_into('<QQ', packet, 0, 64, len(packet) - 64)
    fields = struct.unpack_from('<16I', packet, 64)
    assert fields[:4] == (source_height, source_width, target_height, target_width), fields
    output_bytes = fields[7]
    assert output_bytes == target_width * target_height * 3
    header = repr({'descr': '|i1', 'fortran_order': False, 'shape': (len(packet),)}).encode()
    header += b' ' * ((64 - (10 + len(header) + 1) % 64) % 64) + b'\n'
    packet_path = destination / (name + '.npy')
    packet_path.write_bytes(b'\x93NUMPY\x01\x00' + struct.pack('<H', len(header)) + header + packet)
    case = f'''kernel.decl @qwen38_vision_resize(%groups_x: index, %groups_y: index) launch(%image: index, %input: buffer, %output: buffer) where [range(%image, 0, 3)]
check.case @observe_resize {{
  %groups_x = check.literal value({target_width // 32}) : index
  %groups_y = check.literal value({target_height // 16}) : index
  %image = check.literal value(0) : index
  %input = check.file.read.npy path("{name}.npy") : tensor<{len(packet)}xi8>
  %output = check.generate.fill value(17) : tensor<{output_bytes + 32}xi8>
  %expected_guard = check.generate.fill value(17) : tensor<32xi8>
  kernel.launch @qwen38_vision_resize[%groups_x, %groups_y](%image, %input, %output) : [index, index](index, tensor<{len(packet)}xi8>, tensor<{output_bytes + 32}xi8>)
  %guard = check.tensor.view %output offset({output_bytes}) : tensor<{output_bytes + 32}xi8> -> tensor<32xi8>
  check.expect.bitwise actual(%guard) expected(%expected_guard) : tensor<32xi8>
  check.file.write.npy value(%output) path("{name}.resized.npy") mode(always) : tensor<{output_bytes + 32}xi8>
  check.return
}}
'''
    (destination / (name + '.loom')).write_text(case)
    records.append({'case': name, 'packet_sha256': hashlib.sha256(packet).hexdigest(),
                    'fixture_sha256': hashlib.sha256(case.encode()).hexdigest()})

assert sum(path.stat().st_size for path in directory.rglob('*') if path.is_file()) + 6 * 3000000 < 1024**3
if phase == 'prepare':
    (destination / 'prepared.json').write_text(json.dumps(records, indent=2) + '\n')
    raise SystemExit(0)
records = json.loads((destination / 'prepared.json').read_text())
if phase == 'execute':
    assert os.environ['BENCHMARK_LOCK_LEASE_ID']
for row in records if phase == 'execute' else ():
    name = row['case']
    command = [str(runner),
               str(destination / (name + '.loom')), '--library=' + str(source),
               '--device=amdgpu', '--target=amdgpu:gfx1151', '--sanitizer=access',
               '--file-output-root=' + str(destination)]
    result = subprocess.run(command, capture_output=True, text=True)
    row.update(command=command, returncode=result.returncode,
               stdout=result.stdout, stderr=result.stderr)
    (destination / 'runs.json').write_text(json.dumps(records, indent=2) + '\n')
    if result.returncode:
        print(result.stdout + result.stderr, flush=True)
        raise SystemExit(result.returncode)
    report = json.loads(result.stdout)
    assert report['sample_count'] == 1 and report['failed_sample_count'] == 0, report
    print(json.dumps({'case': name, 'passed': True}), flush=True)
if phase == 'execute':
    raise SystemExit(0)
assert all(row['returncode'] == 0 for row in json.loads((destination / 'runs.json').read_text()))

pixels = {}
for name in names:
    path = destination / (name + '.resized.npy')
    data = path.read_bytes()
    assert data[:8] == b'\x93NUMPY\x01\x00'
    length = struct.unpack_from('<H', data, 8)[0]
    header = ast.literal_eval(data[10:10 + length].decode())
    assert header['shape'] == (output_bytes + 32,) and not header['fortran_order'], header
    raw = data[10 + length:]
    assert len(raw) == output_bytes + 32 and raw[-32:] == bytes([17]) * 32
    pixels[name] = raw[:-32]
assert pixels['jpeg'] == pixels['islow']
comparisons = []
for name in ('islow', 'loom-float32', 'float', 'ifast'):
    differences = [abs(x - y) for x, y in zip(pixels[name], pixels['cosine'])]
    row = {'candidate': name, 'reference': 'cosine', 'samples': output_bytes,
           'different': sum(value != 0 for value in differences),
           'maximum': max(differences), 'absolute_sum': sum(differences),
           'square_sum': sum(value * value for value in differences)}
    comparisons.append(row)
    print(json.dumps(row), flush=True)
record = {'model_commit': manifest['model_commit'],
          'source_sha256': hashlib.file_digest(source.open('rb'), 'sha256').hexdigest(),
          'tool_sha256': hashlib.file_digest(runner.open('rb'), 'sha256').hexdigest(),
          'jpeg_islow_equal': True, 'comparisons': comparisons,
          'output_sha256': {name: hashlib.sha256(data).hexdigest() for name, data in pixels.items()},
          'scope': 'Actual model resize output; reference image passed through the same filter. Guards and access checked, not an independent resize oracle.'}
(directory / 'resize-metrics.json').write_text(json.dumps(record, indent=2) + '\n')
