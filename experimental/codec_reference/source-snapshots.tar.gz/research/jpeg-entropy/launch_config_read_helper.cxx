#include <loomcxx/kernel.h>
#include <loomcxx/predicate.h>

static LOOM_FORCE_INLINE unsigned count_from(const unsigned* workload) {
  return workload[0];
}

static loom::kernel::configuration configure(const unsigned* workload) {
  unsigned count = count_from(workload);
  loom::assume(count <= 1048576u);
  return {{count, 1, 1}, {32, 1, 1}};
}

[[loom::kernel(configure)]] void consume(unsigned* output) {
  output[loom::kernel::workgroup::id.x] = 1;
}
