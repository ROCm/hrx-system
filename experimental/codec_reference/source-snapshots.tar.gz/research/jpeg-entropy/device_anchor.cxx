#include "device_entropy_cursor.h"

[[loom::config("jpeg.segments"), loom::where(loom::predicate::range(1u, 1048576u))]]
extern const unsigned segment_count;

static loom::kernel::configuration configure_segments() {
  unsigned threads = loom::target::subgroup::size();
  return {{(segment_count + threads - 1) / threads, 1, 1}, {threads, 1, 1}};
}

static LOOM_FORCE_INLINE void save_checkpoint(unsigned* output, Cursor cursor) {
  unsigned stride = (3 + component_count + 3) & ~3u;
  [[loom::unroll]]
  for (unsigned index = 0; index < stride; ++index) output[index] = 0;
  output[0] = cursor.position;
  output[1] = cursor.blocks;
  output[2] = cursor.block_index * 64 + cursor.coefficient;
  [[loom::unroll]]
  for (unsigned component = 0; component < component_count; ++component) {
    output[3 + component] = cursor.predictors[component];
  }
}

// This bounded experiment measures the remaining serial ownership boundary:
// one restart segment per lane, exact summaries produced by the preceding
// device dispatch, and no host-provided entropy checkpoints.
[[loom::kernel(configure_segments)]]
void jpeg_anchor(const unsigned* entropy, const unsigned* segments,
                 const unsigned* tables, const unsigned* blocks,
                 const unsigned* summaries, unsigned* checkpoints,
                 unsigned* status) {
  unsigned segment = loom::kernel::workgroup::id.x * loom::kernel::workgroup::size.x +
                     loom::kernel::workitem::id.x;
  if (segment >= segment_count) return;
  const unsigned* descriptor = segments + segment * 8;
  unsigned entropy_offset = descriptor[0];
  unsigned bit_limit = descriptor[1];
  unsigned first_job = descriptor[2];
  unsigned intervals = descriptor[3];
  unsigned total_blocks = descriptor[4];
  unsigned first_checkpoint = descriptor[5];
  unsigned summary_stride = (5 + component_count + 3) & ~3u;
  unsigned checkpoint_stride = (3 + component_count + 3) & ~3u;
  const unsigned* words = entropy + entropy_offset;
  unsigned* output = checkpoints + first_checkpoint * checkpoint_stride;
  Cursor cursor = {};
  cursor.budget = bit_limit;
  cursor.cached_word = 0xffffffffu;
  save_checkpoint(output, cursor);
  for (unsigned interval = 0; interval < intervals && cursor.error == 0; ++interval) {
    if (cursor.blocks < total_blocks) {
      const unsigned* summary = summaries + (first_job + interval) * summary_stride;
      bool same_entry = summary[0] == cursor.position &&
                        summary[1] == cursor.block_index * 64 + cursor.coefficient;
      // The exact MCU count owns the final interval and excludes padding.
      if (same_entry && summary[4] < total_blocks - cursor.blocks) {
        cursor.position = summary[2];
        cursor.blocks += summary[4];
        cursor.block_index = summary[3] >> 6;
        cursor.coefficient = summary[3] & 63;
        [[loom::unroll]]
        for (unsigned component = 0; component < component_count; ++component) {
          cursor.predictors[component] += static_cast<int>(summary[5 + component]);
        }
      } else {
        unsigned boundary = (interval + 1) * chunk_bytes * 8;
        while (cursor.blocks < total_blocks && cursor.position < boundary &&
               cursor.error == 0) {
          cursor = advance(words, tables, blocks, bit_limit, cursor);
        }
      }
    }
    save_checkpoint(output + (interval + 1) * checkpoint_stride, cursor);
  }
  if (cursor.error == 0 &&
      (cursor.blocks != total_blocks || cursor.coefficient != 0)) {
    cursor.error = 3;
  }
  if (cursor.error == 0) {
    unsigned padding = bit_limit - cursor.position;
    if (padding >= 8) {
      cursor.error = 4;
    } else if (padding != 0) {
      Read input = peek(words, cursor);
      if ((input.value >> (32 - padding)) != (1u << padding) - 1) cursor.error = 4;
    }
  }
  status[segment] = cursor.error;
}
