"""Compare identical block outputs using native 128-bit stores."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
tags = json.loads(os.environ['BUREAU_TAG_ROOTS'])
base = Path(tags['codec-jpeg-rebased-tools'])
native = Path(tags['codec-jpeg-unsigned-opt'])
source = (notes / 'device_reconstruct_register_checksum.cxx').read_text()
source = source.replace('using WideValues =', 'using PackedOutput = unsigned __attribute__((ext_vector_type(4)));\n\nusing WideValues =')
source = source.replace('for (unsigned index = 0; index < 16; ++index) pixels[offset + index] = checksum;',
    'for (unsigned index = 0; index < 4; ++index) {\n              reinterpret_cast<PackedOutput*>(pixels + offset)[index] = {checksum, checksum, checksum, checksum};\n            }')
assert 'pixels[offset + index]' not in source
name = 'wide-store-checksum'
(notes / 'device_reconstruct_wide_store_checksum.cxx').write_text(source)
pipeline = (notes / 'device_output_pipeline.cxx').read_text().replace(
    'device_reconstruct.cxx', 'device_reconstruct_wide_store_checksum.cxx')
(notes / 'device_wide_store_checksum_pipeline.cxx').write_text(pipeline)
library = root / ('entropy-' + name + '.loombc')
commands = [
    [str(base / 'loom/src/loom/tools/loom-import-cxx/loom-import-cxx'),
     str(notes / 'device_wide_store_checksum_pipeline.cxx'), '--output=' + str(root / ('entropy-' + name + '.loom'))],
    [str(base / 'loom/src/loom/tools/loom-link/loom-link'), str(root / ('entropy-' + name + '.loom')),
     '--to=bc', '--output=' + str(library)],
    [str(native / 'loom/src/loom/tools/loom-compile/loom-compile'), str(library),
     '--root=jpeg_reconstruct', '--target=amdgpu:gfx1151',
     '--config-file=' + str(root / 'output-config.json'),
     '--output=' + str(root / ('jpeg_reconstruct-' + name + '.hsaco')),
     '--compile-report=details', '--compile-report-output=' + str(root / (name + '-report.json'))]]
for command in commands:
    subprocess.run(command, check=True)
metrics = json.loads((root / (name + '-report.json')).read_text())['entries']['rows'][0]
metrics = {key: metrics[key] for key in ('instruction_count', 'code_byte_count',
           'private_memory_bytes', 'local_memory_bytes', 'target_resources')}
print(json.dumps(metrics), flush=True)
original = root / 'register-checksum-batch16-1024'
fixture = root / (name + '-batch16-1024')
fixture.mkdir(exist_ok=True)
text = (original / 'summary.loom').read_text()
paths = {}
def relocate(match):
    path = (original / match[1]).resolve()
    relative = os.path.relpath(path, fixture)
    paths[relative] = path
    return 'check.file.read.npy path("' + relative + '")'
text = re.sub(r'check.file.read.npy path\("([^"]+)"\)', relocate, text)
(fixture / 'summary.loom').write_text(text)
(fixture / 'config.json').write_bytes((original / 'config.json').read_bytes())
command = [str(base / 'loom/src/loom/tools/loom-link/loom-link'), str(fixture / 'summary.loom'),
           str(library), '--to=bc', '--output=' + str(fixture / 'summary.loombc')]
subprocess.run(command, check=True)
commands.append(command)
stage = json.loads((original / 'stage.json').read_text())
stage['files'] = {relative: hashlib.sha256(path.read_bytes()).hexdigest() for relative, path in paths.items()}
stage['files'].update({path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                      for path in fixture.iterdir() if path.is_file() and path.name != 'stage.json'})
stage['library'] = {'path': library.name, 'sha256': hashlib.sha256(library.read_bytes()).hexdigest()}
stage['scope'] = 'Diagnostic only: exact register-checksum control, with four 128-bit stores instead of sixteen 32-bit stores per block. Same checksum bytes and block schedule; not JPEG samples.'
stage['link_command'] = command
(fixture / 'stage.json').write_text(json.dumps(stage, indent=2) + '\n')
record = {'commands': commands, 'stage': stage, 'metrics': metrics,
          'native_sha256': hashlib.sha256((root / ('jpeg_reconstruct-' + name + '.hsaco')).read_bytes()).hexdigest(),
          'sources': {filename: hashlib.sha256((notes / filename).read_bytes()).hexdigest() for filename in
                      ('device_output_wide_stores.py', 'device_reconstruct_wide_store_checksum.cxx',
                       'device_wide_store_checksum_pipeline.cxx', 'device_entropy_cursor.h')}}
(notes / ('device-output-' + name + '.json')).write_text(json.dumps(record, indent=2) + '\n')
print('Wide-store checksum diagnostic ready', flush=True)
