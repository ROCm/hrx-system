#include <loomcxx/atomic.h>

[[loom::config("stream.rows"), loom::where(loom::predicate::range(3u, 64u))]]
extern const unsigned stream_rows;
[[loom::config("stream.workers"), loom::where(loom::predicate::range(1u, 1024u))]]
extern const unsigned stream_workers;

struct Stream {
  // First logical row in the disjoint queue/completion arrays.
  unsigned row_offset;
  // Number of encoded MCU rows, including partial bottom-edge MCUs.
  unsigned row_count;
  // First word of the bounded component payload allocation.
  unsigned pixel_offset;
  // Current color row; completing its readers retires the preceding row.
  unsigned color_row;
  // Number of interval owners, including the mandatory terminal validator.
  unsigned interval_count;
  // Fully retired interval owners, including zero-output intervals.
  unsigned interval_done;
  // First observed decode failure; provisional output remains private.
  unsigned error;
};

static constexpr unsigned absent = 0xffffffffu;

// JPEG dimensions and the admitted 256-image cohort bound logical row indices.
static LOOM_FORCE_INLINE unsigned* row_address(unsigned* rows, unsigned index) {
  loom::assume(index < 2097152u);
  return rows + index;
}

static LOOM_FORCE_INLINE unsigned observe(const unsigned* address) {
  return loom::view::atomic::load<loom::atomic::ordering::acquire,
      loom::atomic::scope::device>(address);
}

static LOOM_FORCE_INLINE void publish(unsigned* address, unsigned value) {
  loom::view::atomic::store<loom::atomic::ordering::release,
      loom::atomic::scope::device>(value, address);
}

static LOOM_FORCE_INLINE unsigned add(unsigned* address, unsigned value) {
  return loom::view::atomic::rmw<loom::atomic::kind::addi,
      loom::atomic::ordering::acq_rel, loom::atomic::scope::device>(value, address);
}

static LOOM_FORCE_INLINE unsigned compare(unsigned* address, unsigned expected,
                                         unsigned replacement) {
  return loom::view::atomic::cmpxchg<loom::atomic::ordering::acq_rel,
      loom::atomic::ordering::acquire, loom::atomic::scope::device>(
          expected, replacement, address);
}

// A task enters any logical row at most once. Reusing its link in a later row
// cannot make the same head value reappear in the old row's compare/exchange.
static LOOM_FORCE_INLINE void enqueue(unsigned* head, unsigned* links,
                                     unsigned task) {
  // The admitted 4 MiB/image, 1 KiB/chunk, and five records/chunk fit this pool.
  loom::assume(task < 8388608u);
  unsigned previous = observe(head);
  bool done = false;
  while (!done) {
    publish(links + task, previous);
    unsigned actual = compare(head, previous, task);
    done = actual == previous;
    previous = actual;
  }
}

static loom::kernel::configuration configure_stream_init() {
  return {{certification_segments, 1, 1}, {256, 1, 1}};
}

[[loom::kernel(configure_stream_init)]]
void jpeg_stream_init(const unsigned* segments, const unsigned* intervals,
    const Image* images, const unsigned* blocks, const Stream* plans, Stream* streams,
    unsigned* heads, unsigned* pending, unsigned* decoded, unsigned* color_claimed,
    unsigned* color_done, unsigned* links, unsigned* cursors) {
  unsigned image_index = loom::kernel::workgroup::id.x;
  unsigned lane = loom::kernel::workitem::id.x;
  Stream* stream = streams + image_index;
  unsigned row_offset = plans[image_index].row_offset;
  unsigned row_count = plans[image_index].row_count;
  if (lane == 0) {
    stream->row_offset = row_offset;
    stream->row_count = row_count;
    stream->pixel_offset = plans[image_index].pixel_offset;
    stream->color_row = 0;
    stream->interval_done = 0;
    stream->error = 0;
  }
  for (unsigned row = lane; row < row_count; row += 256) {
    heads[row_offset + row] = absent;
    pending[row_offset + row] = 0;
    decoded[row_offset + row] = 0;
    color_claimed[row_offset + row] = 0;
    color_done[row_offset + row] = 0;
  }
  loom::kernel::barrier<loom::memory_space::global,
      loom::atomic::scope::workgroup, loom::atomic::ordering::acq_rel>();
  const unsigned* segment = segments + image_index * 8;
  unsigned first = segment[2] * (output_partitions + 1) + image_index;
  unsigned count = segment[3] * (output_partitions + 1) + 1;
  unsigned blocks_per_mcu = reinterpret_cast<const BlockLayout*>(blocks)[image_index].count;
  unsigned columns = images[image_index].mcu_columns;
  unsigned retained = 0;
  for (unsigned index = lane; index < count; index += 256) {
    unsigned task = first + index;
    const unsigned* entry = intervals + task * 8;
    if (entry[0] < entry[1] || index + 1 == count) {
      [[loom::unroll]]
      for (unsigned word = 0; word < 8; ++word) cursors[task * 8 + word] = entry[word];
      unsigned mcu = entry[2] / blocks_per_mcu + (entry[3] != 0);
      unsigned row = mcu / columns;
      row = row < row_count ? row : row_count - 1;
      add(row_address(pending, row_offset + row), 1);
      enqueue(row_address(heads, row_offset + row), links, task);
      ++retained;
    }
  }
  unsigned total = loom::kernel::workgroup::reduce::addi(retained);
  if (lane == 0) stream->interval_count = total;
}

// Try one finite batch claim. Contention returns to the ready-work selector;
// it never holds a decoded row hostage to an unscheduled workgroup.
static LOOM_FORCE_INLINE bool claim_decode(unsigned* head, const unsigned* links,
                                          unsigned* selected) {
  unsigned first = observe(head);
  unsigned next = first;
  for (unsigned index = 0; index < 32; ++index) {
    selected[index] = next;
    if (next != absent) {
      loom::assume(next < 8388608u);
      next = observe(links + next);
    }
  }
  return first != absent && compare(head, first, next) == first;
}

static loom::kernel::configuration configure_stream_workers() {
  return {{stream_workers, 1, 1}, {32, 1, 1}};
}

[[loom::kernel(configure_stream_workers)]]
void jpeg_stream(const unsigned* entropy, const unsigned* segments,
    const unsigned* tables, const unsigned* blocks, const unsigned* intervals,
    const unsigned* geometry, const unsigned* quantization, const unsigned* zigzag,
    unsigned* pixels, unsigned char* rgb, const Image* images, Stream* streams,
    unsigned* heads, unsigned* pending, unsigned* decoded, unsigned* color_claimed,
    unsigned* color_done, unsigned* links, unsigned* cursors) {
  unsigned lane = loom::kernel::workitem::id.x;
  unsigned search = loom::kernel::workgroup::id.x % certification_segments;
  // The color halo and task claims reuse the exact coefficient allocation.
  auto* storage = loom::buffer::alloca<unsigned, loom::memory_space::workgroup, 16>(1024);
  while (true) {
    unsigned role = 0;
    unsigned selected_image = 0;
    unsigned selected_row = 0;
    unsigned selected_tile = 0;
    unsigned done_count = 0;
    if (lane == 0) {
      for (unsigned attempt = 0; attempt < certification_segments && role == 0; ++attempt) {
        unsigned image_index = (search + attempt) % certification_segments;
        Stream* stream = streams + image_index;
        Image image = images[image_index];
        unsigned row = observe(&stream->color_row);
        unsigned rows = stream->row_count;
        if (observe(&stream->error) != 0 ||
            (row == rows && observe(&stream->interval_done) == stream->interval_count)) {
          ++done_count;
        } else {
          unsigned height = image.color_kind == 5 || image.color_kind == 6 || image.color_kind == 8 ? 16 : 8;
          unsigned columns = (image.width + 63) / 64;
          unsigned tiles = columns * (height / 8);
          unsigned row_offset = stream->row_offset;
          unsigned previous = row ? row - 1 : 0;
          unsigned next = row + 1 < rows ? row + 1 : rows - 1;
          if (row < rows && observe(row_address(pending, row_offset + previous)) == 0 &&
              observe(row_address(pending, row_offset + row)) == 0 &&
              observe(row_address(pending, row_offset + next)) == 0 &&
              observe(row_address(decoded, row_offset + previous)) == image.mcu_columns &&
              observe(row_address(decoded, row_offset + row)) == image.mcu_columns &&
              observe(row_address(decoded, row_offset + next)) == image.mcu_columns) {
            unsigned tile = observe(row_address(color_claimed, row_offset + row));
            if (tile < tiles && compare(row_address(color_claimed, row_offset + row), tile, tile + 1) == tile) {
              role = 2;
              selected_image = image_index;
              selected_row = row;
              selected_tile = tile;
            }
          }
          unsigned first_row = row ? row - 1 : 0;
          for (unsigned relative = 0; relative < stream_rows && role == 0; ++relative) {
            unsigned candidate = first_row + relative;
            if (candidate < rows && claim_decode(row_address(heads, row_offset + candidate), links, storage)) {
              role = 1;
              selected_image = image_index;
              selected_row = candidate;
            }
          }
        }
      }
    }
    role = loom::kernel::subgroup::broadcast(role, 0);
    selected_image = loom::kernel::subgroup::broadcast(selected_image, 0);
    // Every selected image is an in-range scheduler candidate, including idle 0.
    unsigned available_images = certification_segments;
    loom::assume(selected_image < available_images);
    selected_row = loom::kernel::subgroup::broadcast(selected_row, 0);
    selected_tile = loom::kernel::subgroup::broadcast(selected_tile, 0);
    done_count = loom::kernel::subgroup::broadcast(done_count, 0);
    if (done_count == certification_segments) break;
    // Transfer the leader's acquired global payload and selected LDS task IDs
    // to all consumers. This is subgroup synchronization, never a grid barrier.
    loom::kernel::barrier<loom::memory_space::global,
        loom::atomic::scope::subgroup, loom::atomic::ordering::acq_rel>();
    loom::kernel::barrier<loom::memory_space::workgroup,
        loom::atomic::scope::subgroup, loom::atomic::ordering::acq_rel>();
    Stream* stream = streams + selected_image;
    Image image = images[selected_image];
    if (role == 1) {
      unsigned task = storage[lane];
      loom::kernel::barrier<loom::memory_space::workgroup,
          loom::atomic::scope::subgroup, loom::atomic::ordering::acq_rel>();
      unsigned produced = stream_decode(entropy, segments, tables, blocks, intervals,
          geometry, quantization, zigzag, pixels, images, selected_image,
          selected_row, task, reinterpret_cast<short*>(storage), cursors,
          streams, heads, pending, links);
      unsigned total = loom::kernel::subgroup::reduce::addi(produced);
      unsigned retired = loom::kernel::subgroup::reduce::addi(static_cast<unsigned>(task != absent));
      loom::kernel::barrier<loom::memory_space::global,
          loom::atomic::scope::subgroup, loom::atomic::ordering::acq_rel>();
      if (lane == 0) {
        if (total != 0) add(row_address(decoded, stream->row_offset + selected_row), total);
        add(row_address(pending, stream->row_offset + selected_row), 0u - retired);
      }
    }
    if (role == 2) {
      unsigned height = image.color_kind == 5 || image.color_kind == 6 || image.color_kind == 8 ? 16 : 8;
      unsigned columns = (image.width + 63) / 64;
      unsigned first_x = selected_tile % columns * 64;
      unsigned first_y = selected_row * height + selected_tile / columns * 8;
      stream_color(reinterpret_cast<const unsigned char*>(pixels), rgb, image,
                   first_x, first_y, storage);
      loom::kernel::barrier<loom::memory_space::global,
          loom::atomic::scope::subgroup, loom::atomic::ordering::acq_rel>();
      if (lane == 0) {
        unsigned done = add(row_address(color_done, stream->row_offset + selected_row), 1);
        if (done + 1 == columns * (height / 8)) publish(&stream->color_row, selected_row + 1);
      }
    }
    search = (search + 1) % certification_segments;
  }
}
