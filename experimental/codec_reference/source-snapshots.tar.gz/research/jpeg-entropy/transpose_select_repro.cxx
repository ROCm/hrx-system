#include <loomcxx/kernel.h>

using Values = int __attribute__((ext_vector_type(8)));
static loom::kernel::configuration configure() {
  return {{1, 1, 1}, {32, 1, 1}};
}
[[loom::kernel(configure)]]
void indexed_select(const Values* left, const Values* right, Values* output) {
  unsigned lane = loom::kernel::workitem::id.x;
  Values a = left[lane];
  Values b = right[lane];
  Values result = {};
  [[loom::unroll]]
  for (unsigned index = 0; index < 8; ++index) {
    result[index] = ((lane ^ index) & 1) ? b[index ^ 1] : a[index];
  }
  output[lane] = result;
}
[[loom::kernel(configure)]]
void masked_select(const Values* left, const Values* right, Values* output) {
  unsigned lane = loom::kernel::workitem::id.x;
  Values a = left[lane];
  Values b = right[lane];
  Values result = {};
  [[loom::unroll]]
  for (unsigned index = 0; index < 8; ++index) {
    int mask = -static_cast<int>(((lane ^ index) & 1) != 0);
    result[index] = a[index] ^ ((a[index] ^ b[index ^ 1]) & mask);
  }
  output[lane] = result;
}
