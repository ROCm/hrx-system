"""Pin and stage one fresh Fabric-built CPU comparator, preserving old evidence."""
from pathlib import Path
import hashlib
import json
import os
import re
import shlex
import subprocess
import tarfile

notes=Path(__file__).resolve().parent
root=Path(json.loads((notes/'device-active.json').read_text())['directory'])
fixture=root/'cpu-current'
fixture.mkdir(exist_ok=True)
base=notes.parent/'jpeg-baseline'
tag=Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['codec-jpeg-cpu-current'])
binary=tag/'experimental/codec_reference/research/jpeg-baseline/jpeg_baseline'
llvm=Path('/home/ben/tools/llvm/latest/bin')
symbols=subprocess.check_output([str(llvm/'llvm-nm'),'-n',str(binary)],text=True)
selected=[]
for line in symbols.splitlines():
    pieces=line.split()
    if len(pieces)!=3 or pieces[1].lower()!='t':continue
    address,_,name=pieces
    if name=='main':main=int(address,16)
    if re.fullmatch(r'jsimd_(idct_islow|ycc_rgb_convert|h2v2_fancy_upsample)_(avx2|sse2)|decode_mcu(?:\.llvm\.\d+)?',name):selected.append((name,int(address,16)))
commands=['set pagination off','set confirm off','set startup-with-shell off','set disable-randomization on','starti',f'set $bias = (long)&main - {main}']
for index,(name,address) in enumerate(selected,1):
    commands += [f'break *($bias + {address})','commands','silent',f'printf "JPEG_ROUTE {name} %p\\n", $pc',f'disable {index}','continue','end']
commands+=['continue']
(fixture/'routes.gdb').write_text('\n'.join(commands)+'\n')
assembly=subprocess.check_output([str(llvm/'llvm-objdump'),'-d','--no-show-raw-insn',str(binary)],text=True)
prefixes={name for name,address in selected}
functions=re.finditer(r'^([0-9a-f]+) <([^>]+)>:\n(.*?)(?=^[0-9a-f]+ <|\Z)',assembly,re.M|re.S)
(notes/'cpu-refresh-native.s').write_text(''.join(match[0] for match in functions if any(match[2]==name or match[2].startswith(name+'.') for name in prefixes)))
files={'jpeg_baseline':binary,'cpu_refresh_run.py':notes/'cpu_refresh_run.py','routes.gdb':fixture/'routes.gdb',
       '012mp-bus.jpg.r0.jpg':base/'inputs/012mp-bus.jpg.r0.jpg','machine-state.py':notes.parent/'scan/ordered-oracle/run.py'}
manifest={'commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'configuration':'--config=opt',
          'source_sha256':hashlib.sha256((base/'jpeg_baseline.cc').read_bytes()).hexdigest(),
          'files':{name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in files.items()},
          'selected_symbols':selected,'native_sha256':hashlib.sha256((notes/'cpu-refresh-native.s').read_bytes()).hexdigest(),
          'retention':'One optimized CPU comparator in /tmp; pinned source and native text in .notes; no extra output arrays retained.'}
(fixture/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
files['manifest.json']=fixture/'manifest.json'
p=subprocess.Popen(['ssh','hrx-gorgon-4','mkdir -p '+shlex.quote(str(fixture))+' && tar -xf - -C '+shlex.quote(str(fixture))],stdin=subprocess.PIPE)
with tarfile.open(fileobj=p.stdin,mode='w|',dereference=True) as archive:
    for name,path in files.items():archive.add(path,arcname=name,recursive=False)
p.stdin.close();assert p.wait()==0
(notes/'cpu-refresh-stage.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'staged':str(fixture),'binary_sha256':manifest['files']['jpeg_baseline'],'symbols':len(selected)}),flush=True)
