"""Return finite scheduler snapshots without weakening the completion checks.

The debug worker stops after 4096 selection visits. A complete-output failure
remains a failure; the output snapshot identifies unfinished ownership state.
This bounded diagnostic kernel is never a performance or completion candidate.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory']) / 'persistent'
source = (root / 'persistent.cxx').read_text()
assert source.count('while (true) {') == 1
source = source.replace('while (true) {', 'for (unsigned debug_visit = 0; debug_visit < 4096; ++debug_visit) {')
(root / 'debug.cxx').write_text(source)
case = root / 'rows3-workers1-debug'
case.mkdir(exist_ok=True)
for path in (root / 'rows3-workers1').iterdir():
    if path.is_file() and path.suffix in ('.npy', '.json', '.loom'):
        shutil.copyfile(path, case / path.name)
tools = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['codec-jpeg-rebased-tools']) / 'loom/src/loom/tools'
commands = [
    ['loom-import-cxx', str(root / 'debug.cxx'), '--output=' + str(root / 'debug.loom')],
    ['loom-link', str(case / 'check.loom'), str(root / 'debug.loom'), '--to=bc', '--output=' + str(case / 'check.loombc')],
    ['loom-compile', str(root / 'debug.loom'), '--root=jpeg_stream', '--target=amdgpu:gfx1100',
     '--config-file=' + str(case / 'config.json'), '--sanitizer=access', '--output=' + str(case / 'kernel.hsaco')],
]
receipt = {'scope': __doc__.strip(), 'source_sha256': hashlib.sha256(source.encode()).hexdigest(), 'commands': []}
for command in commands:
    command[0] = str(tools / command[0] / command[0])
    result = subprocess.run(command, capture_output=True, text=True)
    receipt['commands'].append({'command': command, 'returncode': result.returncode,
                                'output': result.stdout + result.stderr})
    (notes / 'persistent-debug.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(command[0].split('/')[-1], result.returncode, result.stdout + result.stderr, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
