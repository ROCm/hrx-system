"""Refresh the complete GPU oracle around the admitted entropy-only candidate."""
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import statistics
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
oracle = Path('/tmp/codec-jpeg-oracle.vkmuS8O0')
tree = ast.parse((oracle / 'machine-state.py').read_text())
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'state')
exec(compile(ast.Module(body=[node], type_ignores=[]), 'machine-state.py', 'exec'))
build = json.loads((oracle / 'benchmark-build.json').read_text())
for name, entry in build['files'].items():
    assert hashlib.sha256((oracle / name).read_bytes()).hexdigest() == entry['sha256']
assert build['files']['hip_benchmark']['sha256'] == '4a673fc4ec3c4d3a96db8e5be2cf104f1d2879b60aca36fec28249f705d7c047'
image = oracle / 'inputs/012mp-bus.jpg.r0.jpg'
assert hashlib.sha256(image.read_bytes()).hexdigest() == '18a96a46ffbc049bb3d90ed336ba86791cc1fa55c04e8021331f3603c431e558'
tools = json.loads((root / 'unsigned-tools.json').read_text())
programs = {r['program']: r['sha256'] for r in json.loads((root / 'tables-linked.json').read_text())}
observations = {'build': build, 'states': [], 'rows': []}
completed_processes = set()
for index, kind in enumerate(('oracle', 'loom', 'oracle', 'loom', 'oracle')):
    before = state()
    # KFD's sysfs entry can outlive waitpid while kernel teardown retires it.
    # Only entries belonging to our reaped children may wait here.
    while before['kfd_processes']:
        assert set(before['kfd_processes']) <= completed_processes, before
        assert all(not Path('/proc', pid).exists() for pid in before['kfd_processes'])
        observations['states'].append(before)
        time.sleep(0.01)
        before = state()
    assert not before['kfd_processes'] and not before['drm'], before
    assert before['governor'] == 'performance' and before['gpu_policy'] == 'high'
    assert int(before['personality'], 16) & 0x40000
    observations['states'].append(before)
    if kind == 'oracle':
        command = [str(oracle / 'hip_benchmark'), str(image), str(oracle / 'gpu-planes'),
                   '16', '16', '8', '9', 'resident']
    else:
        program = 'batch16-1024/tables-summary.loombc'
        command = [sys.executable, str(root / 'device_batch_benchmark.py'),
                   '--fixture=batch16-1024', '--result-name=entropy-headroom-' + str(index),
                   '--runner=iree-benchmark-loom-unsigned',
                   '--runner-sha256=' + tools['files']['iree-benchmark-loom-unsigned'],
                   '--program=' + program, '--program-sha256=' + programs[program],
                   '--cache-tables=0']
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    stdout, stderr = process.communicate()
    completed_processes.add(str(process.pid))
    (root / ('headroom-' + str(index) + '.log')).write_text(stdout + stderr)
    if process.returncode or stderr:
        print(stdout + stderr, flush=True)
        raise SystemExit(process.returncode or 1)
    rows = [json.loads(line) for line in stdout.splitlines() if line.startswith('{')]
    if kind == 'oracle':
        row, = rows
        assert row['full_output_and_guards_equal']
        median = statistics.median(row['batch_device_ms'])
    else:
        row, = [r for r in rows if r.get('row') == 'benchmark']
        assert row['correctness']['failed_sample_count'] == 0
        median = row['measurement']['operation_timing_ns']['p50'] / 1e6
    observations['rows'].append({'kind': kind, 'index': index, 'command': command,
                                 'median_ms': median, 'result': row})
    (root / 'headroom.json').write_text(json.dumps(observations, indent=2) + '\n')
    print(json.dumps({'kind': kind, 'index': index, 'median_ms': median}), flush=True)
observations['states'].append(state())
(root / 'headroom.json').write_text(json.dumps(observations, indent=2) + '\n')
