"""Materialize one reusable full-image reference set and linked float command."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess

from device_fixture import input_bytes

arguments = argparse.ArgumentParser()
arguments.add_argument('--small', action='store_true')
arguments = arguments.parse_args()
notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
original = root / ('connected-small' if arguments.small else 'connected-stride')
directory = root / ('connected-float-small' if arguments.small else 'connected-float')
references = root / ('float-reference-small' if arguments.small else 'float-reference-batch16')
directory.mkdir(exist_ok=True)
references.mkdir(exist_ok=True)
tags = json.loads(os.environ['BUREAU_TAG_ROOTS'])
oracle = Path(tags['codec-jpeg-float-reference']) / 'experimental/codec_reference/research/jpeg-entropy/float_reference'
frontend = Path(tags['codec-jpeg-rebased-tools']) / 'loom/src/loom/tools'
name = 'existing_exif_fixture' if arguments.small else '012mp-bus.jpg.r0.jpg'
encoded = input_bytes(name)
(references / 'input.jpg').write_bytes(encoded)
bindings = [line.split() for line in (original / 'bindings.txt').read_text().splitlines()]
paths = {row[0]: (original / row[4]).resolve() for row in bindings}
configuration = json.loads((original / 'config.json').read_text())
configuration['input'].setdefault('entropy_padding_words', 2)
command = [str(oracle), str(references / 'input.jpg'), str(references),
           str(paths['pixels']), str(paths['rgb'])]
result = subprocess.run(command, capture_output=True, text=True)
log = notes / ('float-reference-small.log' if arguments.small else 'float-reference-batch16.log')
log.write_text(result.stdout + result.stderr)
assert result.returncode == 0, result.stdout + result.stderr
print(result.stdout, flush=True)
batch = configuration['jpeg']['segments']
for row in bindings:
    name, _, width, count, _ = row
    if name in ('pixels', 'rgb'):
        raw = (references / (name + '.raw')).read_bytes()
        length = len(raw) * batch
        total = int(width) * int(count)
        assert 0 <= total - length <= 32, (name, total, length)
        with paths[name].open('rb') as reader:
            header = reader.read(10)
            assert header[:8] == b'\x93NUMPY\x01\x00'
            header += reader.read(struct.unpack_from('<H', header, 8)[0])
            reader.seek(len(header) + length)
            tail = reader.read()
            assert len(tail) == total - length
        paths[name] = references / (name + '.npy')
        with paths[name].open('wb') as stream:
            stream.write(header)
            for _ in range(batch): stream.write(raw)
            stream.write(tail)
    row[4] = os.path.relpath(paths[name], directory)
(directory / 'bindings.txt').write_text('\n'.join(' '.join(row) for row in bindings) + '\n')
(directory / 'config.json').write_text(json.dumps(configuration, indent=2) + '\n')
text = (original / 'summary.loom').read_text()
original_paths = {str((original / row[4]).resolve()): row[0] for row in
                  [line.split() for line in (original / 'bindings.txt').read_text().splitlines()]}
text = re.sub(r'check.file.read.npy path\("([^"]+)"\)', lambda match:
              'check.file.read.npy path("' + os.path.relpath(paths[original_paths[str((original / match[1]).resolve())]], directory) + '")', text)
(directory / 'summary.loom').write_text(text)
subprocess.run([str(frontend / 'loom-import-cxx/loom-import-cxx'), str(notes / 'device_float_pipeline.cxx'),
                '--output=' + str(directory / 'library.loom')], check=True)
subprocess.run([str(frontend / 'loom-link/loom-link'), str(directory / 'summary.loom'), str(directory / 'library.loom'),
                '--to=bc', '--output=' + str(directory / 'summary.loombc')], check=True)
files = {os.path.relpath(path, directory): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths.values()}
files.update({path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in directory.iterdir() if path.name != 'stage.json'})
stage = {'files': files, 'source_sha256': hashlib.sha256((notes / 'device_float_pipeline.cxx').read_bytes()).hexdigest(),
         'reference_source_sha256': hashlib.sha256((notes / 'float_reference.cc').read_bytes()).hexdigest(),
         'reference_binary_sha256': hashlib.sha256(oracle.read_bytes()).hexdigest(),
         'scope': 'Float32 IDCT experiment. Full output is checked against explicit CPU IEEE float32 evaluation; independent long-double cosine and integer-reference errors are recorded separately. No numerical production default selected.'}
(directory / 'stage.json').write_text(json.dumps(stage, indent=2) + '\n')
(notes / ('float-fixture-small.json' if arguments.small else 'float-fixture-batch16.json')).write_text(json.dumps(stage, indent=2) + '\n')
