#include <loomcxx/kernel.h>
#include <loomcxx/predicate.h>

static loom::kernel::configuration configure_writer() {
  return {{1, 1, 1}, {32, 1, 1}};
}

[[loom::kernel(configure_writer)]]
void write_grid(const unsigned* input, unsigned* schedule) {
  if (loom::kernel::workitem::id.x == 0) {
    schedule[0] = input[0];
    schedule[1] = input[1];
    schedule[2] = input[2];
  }
}

static loom::kernel::configuration configure_reader(const unsigned* schedule) {
  unsigned x = schedule[0];
  unsigned y = schedule[1];
  unsigned z = schedule[2];
  loom::assume(x <= 512u);
  loom::assume(y <= 16u);
  loom::assume(z == 1u);
  return {{x, y, z}, {32, 1, 1}};
}

[[loom::kernel(configure_reader)]]
void read_grid(unsigned* output) {
  if (loom::kernel::workitem::id.x == 0) {
    unsigned index = (loom::kernel::workgroup::id.y * 512 +
                      loom::kernel::workgroup::id.x) * 5;
    output[index + 0] = loom::kernel::workgroup::count.x;
    output[index + 1] = loom::kernel::workgroup::count.y;
    output[index + 2] = loom::kernel::workgroup::count.z;
    output[index + 3] = loom::kernel::workgroup::size.x;
    output[index + 4] = loom::kernel::subgroup::size();
  }
}
