#include <loomcxx/buffer.h>
#include <loomcxx/kernel.h>

[[loom::kernel, loom::workgroup_size(32, 1, 1),
  loom::workgroup_count(1, 1, 1)]]
void unsigned_table_bounds(const unsigned* indices, unsigned* output) {
  unsigned lane = loom::kernel::workitem::id.x;
  auto* table = loom::buffer::alloca<unsigned, loom::memory_space::workgroup, 16>(6);
  if (lane < 6u) table[lane] = lane + 10u;
  loom::kernel::workgroup::barrier();
  unsigned index = indices[lane];
  unsigned limit = 6u;
  loom::assume(index < limit);
  output[lane] = table[index];
}

[[loom::kernel, loom::workgroup_size(32, 1, 1),
  loom::workgroup_count(1, 1, 1)]]
void unsigned_table_mask_control(const unsigned* indices, unsigned* output) {
  unsigned lane = loom::kernel::workitem::id.x;
  auto* table = loom::buffer::alloca<unsigned, loom::memory_space::workgroup, 16>(6);
  if (lane < 6u) table[lane] = lane + 10u;
  loom::kernel::workgroup::barrier();
  unsigned index = indices[lane] & 7u;
  unsigned limit = 6u;
  loom::assume(index < limit);
  output[lane] = table[index];
}
