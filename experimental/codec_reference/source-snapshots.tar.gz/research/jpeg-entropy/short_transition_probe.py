"""Construct capped, truncated, and invalid-state differential transition checks."""
import hashlib
import json
import os
from pathlib import Path
import random
import re
import subprocess

from device_fixture import read_words, write_words

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
directory = root / 'short-probe'
directory.mkdir(exist_ok=True)
source = root / 'output-large'
key = '012mp-bus.jpg.r0.jpg-scan0-chunk1024'
text = (source / (key + '.loom')).read_text()
pattern = re.compile(r'%([a-z_]+) = check.file.read.npy path\("([^"]+)"\) : tensor<(\d+)xi32>')
paths = {m[1]:(source/m[2]).resolve() for m in pattern.finditer(text)}
sizes = {m[1]:int(m[3]) for m in pattern.finditer(text)}
limit = read_words(paths['segments'])[1]
randomizer = random.Random(0x5A1761)
states = []
count = 32768
for index in range(count):
    position = randomizer.randrange(limit-1024)
    extent = index % 32 if index % 3 else 1024
    remaining = index // 32 % 32 if index % 5 else 1024
    reads = randomizer.randrange(256)
    completed = randomizer.randrange(4096)
    phase = index % 64
    predictors = [randomizer.randrange(-1024,1024) for _ in range(4)]
    states.extend([position, position+extent, reads, reads+remaining, completed,
                   index//64%6, phase, *predictors, 1+index%8])
write_words(directory / 'states.npy', states)
write_words(directory / 'expected.npy', [0]*count)
sizes['states'] = len(states)
paths['states'] = directory / 'states.npy'
names = ('entropy','tables','blocks','states')
lines = ['kernel.decl @transition_probe() launch('+', '.join('%'+name+': buffer' for name in (*names,'output'))+')',
         '', 'check.case @transitions {']
for name in names:
    lines.append(f'  %{name} = check.file.read.npy path("{os.path.relpath(paths[name],directory)}") : tensor<{sizes[name]}xi32>')
lines += [f'  %expected = check.file.read.npy path("expected.npy") : tensor<{count}xi32>',
          f'  %output = check.generate.fill value(17) : tensor<{count}xi32>',
          '  kernel.launch @transition_probe('+', '.join('%'+name for name in (*names,'output'))+') : ('+
          ', '.join(f'tensor<{sizes[name]}xi32>' for name in names)+f', tensor<{count}xi32>)',
          f'  check.expect.bitwise actual(%output) expected(%expected) : tensor<{count}xi32>',
          '  check.return','}']
(directory / 'check.loom').write_text('\n'.join(lines)+'\n')
config = json.loads((source / (key+'.json')).read_text())
config['jpeg']['probes'] = count
(directory / 'config.json').write_text(json.dumps(config,indent=2)+'\n')
tag = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['codec-jpeg-rebased-tools'])
commands = [[str(tag/'loom/src/loom/tools/loom-import-cxx/loom-import-cxx'), str(notes/'short_transition_probe.cxx'), '--output='+str(directory/'library.loom')],
            [str(tag/'loom/src/loom/tools/loom-link/loom-link'), str(directory/'library.loom'), str(directory/'check.loom'), '--to=bc', '--output='+str(directory/'check.loombc')]]
for command in commands:
    subprocess.run(command,check=True)
files = {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in directory.iterdir() if p.is_file()}
files.update({str(paths[name].relative_to(root)):hashlib.sha256(paths[name].read_bytes()).hexdigest() for name in names})
record = {'count':count,'commands':commands,'files':files,
          'scope':'Differential all Cursor fields and emitted index/value against the previously qualified transition; arbitrary real entropy offsets, all coefficient/block phases, truncated extents/read caps, and 1–8 transitions. Not complete malformed-image API qualification.',
          'sources':{name:hashlib.sha256((notes/name).read_bytes()).hexdigest() for name in
                     ('short_transition_probe.py','short_transition_probe.cxx','device_entropy_cursor_short.h')}}
(notes/'short-probe-stage.json').write_text(json.dumps(record,indent=2)+'\n')
print(count,'differential probes',flush=True)
