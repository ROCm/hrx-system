"""Consume the completed-block certificate at reconstruction's block boundary."""
from pathlib import Path

notes = Path(__file__).resolve().parent
source = (notes / 'device_reconstruct_block_ac.cxx').read_text()
old = '''  unsigned certified_end = intervals[
      (first_interval + (output_partitions + 1) * count) * stride];'''
new = old + '''
  unsigned certified_blocks = intervals[
      (first_interval + (output_partitions + 1) * count) * stride + 2];'''
assert source.count(old) == 1
source = source.replace(old, new)
begin = source.index('          // Interval alignment and the completed preceding block establish')
end = source.index('          const unsigned* shape = geometry + block * 8;', begin)
source = source[:begin] + '''          if (cursor.blocks < certified_blocks) {
            // The root certificate covers this whole block. Syntax is proven;
            // the absolute DC predictor remains a consumer-owned constraint.
            unsigned first_coefficient = cursor.coefficient;
            loom::assume(first_coefficient == 0);
            cursor.coefficient = first_coefficient;
            Symbol dc = advance_symbol_certified(words, tables, blocks, cursor);
            cursor = dc.cursor;
            if (dc.value < -1024 || dc.value > 1023) cursor.error = 5;
            if (cursor.error == 0) {
              coefficients[lane] = static_cast<short>(dc.value);
              do {
                Symbol symbol = advance_ac_certified(words, ac_table, cursor);
                cursor = symbol.cursor;
                if (symbol.index != 0xffffffffu) {
                  unsigned natural = zigzag[symbol.index];
                  loom::assume(natural < 64u);
                  coefficients[natural * coefficient_stride + lane] = static_cast<short>(symbol.value);
                  any_ac = true;
                }
              } while (cursor.coefficient != 0);
            }
          } else {
            do {
              Symbol symbol = advance_symbol(words, tables, blocks, bit_limit, cursor);
              cursor = symbol.cursor;
              if (symbol.index == 0 && (symbol.value < -1024 || symbol.value > 1023)) {
                cursor.error = 5;
              }
              if (symbol.index != 0xffffffffu && cursor.error == 0) {
                unsigned natural = zigzag[symbol.index];
                loom::assume(natural < 64u);
                coefficients[natural * coefficient_stride + lane] = static_cast<short>(symbol.value);
                if (symbol.index != 0) any_ac = true;
              }
            } while (cursor.coefficient != 0 && cursor.error == 0);
          }
''' + source[end:]
(notes / 'device_reconstruct_block_certificate.cxx').write_text(source)
pipeline = '#include "device_entropy_cursor_certified.h"\n'
pipeline += '''[[loom::config("jpeg.output_partitions"), loom::where(loom::predicate::range(2u, 8u))]]
extern const unsigned output_partitions;
'''
for name in ('device_entropy_partitioned.cxx', 'device_bridge.cxx',
             'device_certify_partitioned.cxx', 'device_reconstruct_block_certificate.cxx'):
    pipeline += '\n' + (notes / name).read_text().replace('#include "device_entropy_cursor.h"', '') + '\n'
(notes / 'device_block_certificate_pipeline.cxx').write_text(pipeline)
