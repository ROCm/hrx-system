"""Qualify one tiny ownership transfer before expanding GPU execution."""
import hashlib
import json
from pathlib import Path
import shlex
import subprocess

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
library = root / 'entropy-overlap.loombc'
digest = hashlib.sha256(library.read_bytes()).hexdigest()
subprocess.run(['scp', str(library), 'hrx-gorgon-4:' + str(library)], check=True)
command = ['/home/benvanik/.dotfiles/bin/benchmark-lock', '--label=codec-jpeg-overlap-witness',
           '--', 'env', 'LD_LIBRARY_PATH=/opt/rocm/lib', 'python3', '-B',
           str(root / 'device_tables_qualify.py'), '--stage=twolevel-small-stage.json',
           '--fixtures=twolevel-small/fixtures.json', '--runner=iree-test-loom-unsigned',
           '--runner-sha256=5e267978d7e937b1009f64a2e005913a4cc36c002b1f24eef44776cc4683a632',
           '--library=entropy-overlap.loombc', '--library-sha256=' + digest,
           '--output-directory=overlap-witness-actual', 'existing_exif_fixture-scan0-chunk1024']
log = notes / 'gorgon4-overlap-witness.log'
with log.open('w') as stream:
    result = subprocess.run(['ssh', 'hrx-gorgon-4', shlex.join(command)], stdout=stream, stderr=subprocess.STDOUT)
status = subprocess.run(['ssh', 'hrx-gorgon-4', '/home/benvanik/.dotfiles/bin/benchmark-lock --status'], capture_output=True, text=True)
record = {'host': 'hrx-gorgon-4', 'command': command, 'returncode': result.returncode,
          'broker_status_after': status.stdout + status.stderr}
(notes / 'gorgon4-overlap-witness-lease.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
print(log.read_text()[-6000:], flush=True)
if result.returncode:
    raise SystemExit(result.returncode)
output = notes / 'gorgon4-overlap-witness.json'
subprocess.run(['scp', 'hrx-gorgon-4:' + str(root / 'overlap-witness-actual/qualified.json'), str(output)], check=True)
assert len(json.loads(output.read_text())['rows']) == 1
