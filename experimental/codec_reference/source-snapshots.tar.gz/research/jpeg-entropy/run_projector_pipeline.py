"""Execute one bounded foreground comparison and preserve its exact receipts."""
import argparse
import hashlib
import json
from pathlib import Path
import shlex
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--configuration', choices=('asan', 'opt'), required=True)
parser.add_argument('--name', required=True)
parser.add_argument('--samples', type=int, default=0)
parser.add_argument('--iterations', type=int, default=2)
parser.add_argument('--order', default='cpu,gpu')
args = parser.parse_args()
assert args.name.replace('-', '').isalnum()
notes = Path(__file__).resolve().parent
source = json.loads((notes / 'http-publication-source.json').read_text())
stage = json.loads((notes / f'projector-pipeline-{args.configuration}-stage.json').read_text())
assert stage['verification_returncode'] == 0
directory = Path(source['directory'])
machine = stage['machine']
prefix = f'gorgon3-projector-pipeline-{args.name}'
receipt_path = notes / (prefix + '-receipt.json')
assert not receipt_path.exists(), 'Preserve the preceding experiment receipt.'
runner_source = (notes / 'projector_pipeline_run.py').read_text()
command = ['/home/benvanik/.dotfiles/bin/benchmark-lock',
           '--label=codec-jpeg-pipeline-' + args.name, '--',
           'timeout', '--signal=INT', '--kill-after=15s', '240s',
           'env', 'LD_LIBRARY_PATH=/opt/rocm/lib', 'python3', '-B',
           '-c', runner_source, str(directory),
           '--configuration=' + args.configuration, '--samples=' + str(args.samples),
           '--iterations=' + str(args.iterations), '--order=' + args.order]
record = {'machine': machine, 'stage_manifest_sha256': hashlib.sha256(
          json.dumps(stage['manifest'], sort_keys=True).encode()).hexdigest(),
          'runner_source_sha256':hashlib.sha256(runner_source.encode()).hexdigest(),
          'command': command, 'copies': []}
with (notes / (prefix + '-run.log')).open('w') as log:
    process = subprocess.Popen(['ssh', machine, shlex.join(command)],
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    for line in process.stdout:
        log.write(line)
        log.flush()
        print(line, end='', flush=True)
    record['returncode'] = process.wait()
status = subprocess.run(['ssh', machine, '/home/benvanik/.dotfiles/bin/benchmark-lock --status'],
                        capture_output=True, text=True)
record['broker_status_returncode'] = status.returncode
record['broker_status_after'] = status.stdout + status.stderr
names = [f'pipeline-{args.configuration}-results.json']
names.extend(f'pipeline-{args.configuration}-{ordinal}-{mode}.log'
             for ordinal, mode in enumerate(args.order.split(',')))
for name in names:
    result = subprocess.run(['ssh', machine, 'cat ' + shlex.quote(str(directory / name))],
                            capture_output=True)
    entry = {'name': name, 'returncode': result.returncode}
    record['copies'].append(entry)
    if result.returncode == 0:
        suffix = '-result.json' if name.endswith('results.json') else '-' + name
        path = notes / (prefix + suffix)
        path.write_bytes(result.stdout)
        entry['path'] = str(path)
        entry['sha256'] = hashlib.sha256(result.stdout).hexdigest()
    else:
        entry['error'] = result.stderr.decode()
receipt_path.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key:value for key,value in record.items() if key!='command'}), flush=True)
raise SystemExit(record['returncode'] or status.returncode or
                 any(item['returncode'] for item in record['copies']))
