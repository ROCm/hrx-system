"""Prepare pinned model sources and bit-preserving decoder controls in /tmp."""
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
directory = root / 'vision-accuracy'
directory.mkdir(exist_ok=True)
inputs = directory / 'inputs'
inputs.mkdir(exist_ok=True)
tag = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['codec-jpeg-vision-asan'])
reference = tag / 'experimental/codec_reference/research/jpeg-entropy/float_reference'
server = tag / 'loom/src/loom/tools/loom-serve/loom-serve'
references = root / 'float-reference-batch16'
original = root / 'connected-stride'
bindings = {row[0]: (original / row[4]).resolve() for row in
            [line.split() for line in (original / 'bindings.txt').read_text().splitlines()]}
command = [str(reference), str(references / 'input.jpg'), str(references),
           str(bindings['pixels']), str(bindings['rgb'])]
result = subprocess.run(command, text=True, capture_output=True)
(notes / 'float-reference-model-inputs.log').write_text(result.stdout + result.stderr)
if result.returncode:
    raise RuntimeError(result.stdout + result.stderr)
rows = [json.loads(line) for line in result.stdout.splitlines()]
control = next(row for row in rows if row.get('comparison') == 'libjpeg_islow_vs_integer_rgb')
assert control['different'] == 0, control
old = json.loads((notes / 'float-reference-cpu-policies.json').read_text())
for name, expected in old['candidate_raw_sha256'].items():
    assert hashlib.file_digest((references / name).open('rb'), 'sha256').hexdigest() == expected, name
geometry = rows[-1]
width, height = geometry['width'], geometry['height']
header = f'P7\nWIDTH {width}\nHEIGHT {height}\nDEPTH 3\nMAXVAL 255\nTUPLTYPE RGB\nENDHDR\n'.encode()
input_information = {}
for name, filename in [('loom-float32', 'rgb.raw'), ('islow', 'islow.rgb'),
                       ('cosine', 'cosine.rgb'), ('float', 'float.rgb'), ('ifast', 'ifast.rgb')]:
    pixels = (references / filename).read_bytes()
    assert len(pixels) == width * height * 3
    path = inputs / (name + '.pam')
    path.write_bytes(header + pixels)
    input_information[name] = {'file': str(path.relative_to(directory)),
                               'mime': 'image/x-portable-arbitrarymap',
                               'rgb_sha256': hashlib.sha256(pixels).hexdigest()}
shutil.copyfile(references / 'input.jpg', inputs / 'original.jpg')
input_information['jpeg'] = {'file': 'inputs/original.jpg', 'mime': 'image/jpeg'}

model_commit = '964dca5ed218eb11399c4c62774131abcdd0dc3e'
archive = subprocess.check_output(['git', 'archive', model_commit,
                                   'experimental/loom_serve/models/qwen',
                                   'experimental/loom_serve/motifs'])
sources = directory / 'sources'
sources.mkdir(exist_ok=True)
with tarfile.open(fileobj=io.BytesIO(archive)) as stream:
    stream.extractall(sources, filter='data')
model = sources / 'experimental/loom_serve/models/qwen'
assets = {
    'text': {'path': '/home/benvanik/models/unsloth/Qwen3.8-27B-GGUF/408fcc1807ab264d8cd644a7c4c0f58fbd32eebc/Qwen3.8-27B-UD-Q5_K_XL.gguf', 'bytes': 20218178624},
    'tokenizer': {'path': '/home/benvanik/models/Qwen/Qwen3.8-27B/1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0/tokenizer.json', 'bytes': 12809320},
    'projector': {'path': '/home/benvanik/models/unsloth/Qwen3.8-27B-GGUF/be8e54148befbe990c6daeed4aecf9ac4540b840/mmproj-F16.gguf', 'bytes': 927607488},
}
declaration = json.loads((model / 'model.json').read_text())
declaration['name'] = 'codec-jpeg-accuracy'
declaration['base_directory'] = str(model)
definition = declaration['definition']
definition.update(weights=assets['text']['path'], tokenizer=assets['tokenizer']['path'],
                  rows=1, context_capacity=2048, pool_capacity=4096,
                  prefill_capacity=128, draft_depth=0, continuation_epochs=1)
definition['image']['assets'] = str(Path(assets['projector']['path']).parent)
(directory / 'deployment.json').write_text(json.dumps(declaration, indent=2) + '\n')
shutil.copyfile(notes / 'model_accuracy.py', directory / 'model_accuracy.py')
files = {str(path.relative_to(directory)): hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()
         for top in (inputs, sources) for path in top.rglob('*') if path.is_file()}
for name in ('deployment.json', 'model_accuracy.py'):
    files[name] = hashlib.file_digest((directory / name).open('rb'), 'sha256').hexdigest()
files['loom-serve'] = hashlib.file_digest(server.open('rb'), 'sha256').hexdigest()
manifest = {'codec_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
            'model_commit': model_commit, 'build_config': 'asan', 'files': files,
            'inputs': input_information, 'assets': assets, 'reference_rows': rows,
            'reference_source_sha256': hashlib.sha256((notes / 'float_reference.cc').read_bytes()).hexdigest(),
            'reference_binary_sha256': hashlib.file_digest(reference.open('rb'), 'sha256').hexdigest(),
            'scope': 'Lossless GPU-verified RGB through actual trained model. Numerical evidence only; device decoder not integrated.'}
(directory / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(notes / 'model-accuracy-stage.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'prepared': str(directory), 'files': len(files), 'geometry': [width, height]}), flush=True)
subprocess.run(['ssh', 'hrx-gorgon-3', 'mkdir', '-p', str(directory)], check=True)
subprocess.run(['scp', str(server), 'hrx-gorgon-3:' + str(directory / 'loom-serve')], check=True)
print('Server staged; transferring pinned sources and lossless input controls.', flush=True)
producer = subprocess.Popen(['tar', '-C', str(directory), '-cf', '-', 'sources', 'inputs',
                             'deployment.json', 'manifest.json', 'model_accuracy.py'], stdout=subprocess.PIPE)
consumer = subprocess.run(['ssh', 'hrx-gorgon-3', 'tar', '-C', str(directory), '-xf', '-'], stdin=producer.stdout)
producer.stdout.close()
producer_status = producer.wait()
if producer_status or consumer.returncode:
    raise RuntimeError(f'stage transfer failed: {producer_status}, {consumer.returncode}')
print('Stage complete; no GPU lease held.', flush=True)
