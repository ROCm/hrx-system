"""Pin every emitted leaf of the mixed-image experiment before execution."""
from collections import Counter
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

notes = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--fixture', default='mixed-current')
parser.add_argument('--receipt', default='mixed-native.json')
parser.add_argument('--target', choices=('gfx1100', 'gfx1151'), default='gfx1151')
parser.add_argument('--output-directory', type=Path)
arguments = parser.parse_args()
directory = Path(json.loads((notes / "device-active.json").read_text())["directory"]) / arguments.fixture
tag = Path(json.loads(os.environ["BUREAU_TAG_ROOTS"])["codec-jpeg-rebased-tools"])
compiler = tag / "loom/src/loom/tools/loom-compile/loom-compile"
source = json.loads((notes / "mixed-source.json").read_text())
for name, expected in source["files"].items():
    assert hashlib.sha256((directory / name).read_bytes()).hexdigest() == expected
record = {"compiler_sha256": hashlib.sha256(compiler.read_bytes()).hexdigest(),
          "source": source, "target": arguments.target,
          "configuration": json.loads((directory / "config.json").read_text()), "leaves": {}}
output_directory = arguments.output_directory or directory
output_directory.mkdir(exist_ok=True)
roots = re.findall(r"void (jpeg_\w+)\(", (directory / "mixed_pipeline.cxx").read_text())
for name in roots:
    binary = output_directory / (name + ".hsaco")
    report = output_directory / (name + ".report.json")
    command = [str(compiler), str(directory / "summary.loombc"), "--root=" + name,
               "--target=amdgpu:" + arguments.target, "--config-file=" + str(directory / "config.json"),
               "--output=" + str(binary), "--compile-report=details", "--compile-report-output=" + str(report)]
    result = subprocess.run(command, capture_output=True, text=True)
    (output_directory / (name + ".compile.log")).write_text(result.stdout + result.stderr)
    assert result.returncode == 0, name + "\n" + result.stdout + result.stderr
    assembly = subprocess.check_output(["/home/ben/tools/llvm/latest/bin/llvm-objdump", "-d", "--mcpu=" + arguments.target, str(binary)], text=True)
    (output_directory / (name + ".native.s")).write_text(assembly)
    row = json.loads(report.read_text())["entries"]["rows"][0]
    record["leaves"][name] = {"command": command, "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
                              "native_sha256": hashlib.sha256(assembly.encode()).hexdigest(),
                              "instruction_histogram": dict(sorted(Counter(re.findall(r"^\s+(\w+)\s+[^\n]*//", assembly, re.M)).items())),
                              "resources": {key: row[key] for key in ("instruction_count", "code_byte_count", "private_memory_bytes", "local_memory_bytes", "target_resources")}}
    (notes / arguments.receipt).write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps({"root": name, "instructions": row["instruction_count"],
                      "lds": row["local_memory_bytes"], "private": row["private_memory_bytes"],
                      "vgpr": row["target_resources"]["vector"]["final"]["register_count"]}), flush=True)
