"""Reduce helper-composition failures independently of the JPEG program."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / "device-active.json").read_text())["directory"]) / "native-projector"
tool = Path(json.loads(os.environ["BUREAU_TAG_ROOTS"])["codec-jpeg-rebased-tools"]) / "loom/src/loom/tools/loom-import-cxx/loom-import-cxx"
cases = {
    "pure": ("unsigned element_count", "unsigned value", "return (value + 31u) / 32u;", "helper(element_count)", "(element_count + 31u) / 32u", "", "32"),
    "read": ("const unsigned* workload", "const unsigned* value", "return value[0];", "helper(workload)", "workload[0]", "loom::assume(count <= 1048576u);", "32"),
    "target": ("", "", "return loom::target::subgroup::size();", "1u", "1u", "", "helper()"),
}
records = []
for name, (workload, argument, body, call, direct, assumptions, threads) in cases.items():
    for variant in ("helper", "direct"):
        expression = call if variant == "helper" else direct
        size = threads if variant == "helper" else threads.replace("helper()", "loom::target::subgroup::size()")
        helper = f"static LOOM_FORCE_INLINE unsigned helper({argument}) {{ {body} }}\n" if variant == "helper" else ""
        source = f'''#include <loomcxx/kernel.h>
#include <loomcxx/predicate.h>
#include <loomcxx/target.h>
{helper}static loom::kernel::configuration configure({workload}) {{
  unsigned count = {expression};
  {assumptions}
  return {{{{count, 1, 1}}, {{{size}, 1, 1}}}};
}}
[[loom::kernel(configure)]] void consume(unsigned* output) {{
  output[loom::kernel::workgroup::id.x] = 1;
}}
'''
        filename = root / f"launch_{name}_{variant}.cxx"
        filename.write_text(source)
        result = subprocess.run([str(tool), str(filename), "--output=" + str(filename.with_suffix(".loom"))], capture_output=True, text=True)
        records.append({"case": name, "variant": variant, "source": source,
                        "source_sha256": hashlib.sha256(source.encode()).hexdigest(),
                        "returncode": result.returncode, "output": result.stdout + result.stderr})
        print(json.dumps({"case": name, "variant": variant, "returncode": result.returncode}), flush=True)
(notes / "launch-config-helpers.json").write_text(json.dumps({"compiler_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(), "records": records}, indent=2) + "\n")
assert all(record["returncode"] == 0 for record in records if record["variant"] == "direct" or record["case"] == "pure")
assert next(record for record in records if record["case"] == "read" and record["variant"] == "helper")["returncode"] != 0
assert next(record for record in records if record["case"] == "target" and record["variant"] == "helper")["returncode"] != 0
