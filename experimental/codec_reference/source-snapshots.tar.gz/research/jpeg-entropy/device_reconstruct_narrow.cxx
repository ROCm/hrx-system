#include "device_entropy_cursor.h"

[[loom::config("jpeg.mcu_width"), loom::where(loom::predicate::range(1u, 65536u))]]
extern const unsigned scan_mcu_width;

using WideValues = long long __attribute__((ext_vector_type(8)));

static loom::kernel::configuration configure_output() {
  unsigned threads = loom::target::subgroup::size();
  unsigned interval_capacity = chunks * 2 + certification_segments;
  unsigned stripe = threads * certification_segments;
  return {{(interval_capacity + stripe - 1) / stripe, certification_segments, 1},
          {threads, 1, 1}};
}

static LOOM_FORCE_INLINE WideValues transform_block_axis(WideValues input) {
  long long sum = (input[0] + input[4]) * 8192;
  long long difference = (input[0] - input[4]) * 8192;
  long long rotation = (input[2] + input[6]) * 4433;
  long long two = rotation - input[6] * 15137;
  long long six = rotation + input[2] * 6270;
  long long even0 = sum + six;
  long long even1 = difference + two;
  long long even2 = difference - two;
  long long even3 = sum - six;
  long long odd_rotation = (input[1] + input[3] + input[5] + input[7]) * 9633;
  long long seven_three = odd_rotation - (input[7] + input[3]) * 16069;
  long long five_one = odd_rotation - (input[5] + input[1]) * 3196;
  long long seven_one = (input[7] + input[1]) * -7373;
  long long five_three = (input[5] + input[3]) * -20995;
  long long odd0 = input[1] * 12299 + seven_one + five_one;
  long long odd1 = input[3] * 25172 + five_three + seven_three;
  long long odd2 = input[5] * 16819 + five_three + five_one;
  long long odd3 = input[7] * 2446 + seven_one + seven_three;
  return {even0 + odd0, even1 + odd1, even2 + odd2, even3 + odd3,
          even3 - odd3, even2 - odd2, even1 - odd1, even0 - odd0};
}

static LOOM_FORCE_INLINE unsigned sample_byte(int value) {
  return value < 0 ? 0u : value > 255 ? 255u : static_cast<unsigned>(value);
}

static LOOM_FORCE_INLINE Symbol output_symbol(const unsigned* words,
    const unsigned* tables, const unsigned* blocks, unsigned limit, Cursor cursor) {
  Symbol symbol = advance_symbol(words, tables, blocks, limit, cursor);
  if (symbol.index == 0 && (symbol.value < -1024 || symbol.value > 1023)) {
    symbol.cursor.error = 5;
  }
  return symbol;
}

using Values = int __attribute__((ext_vector_type(8)));

static LOOM_FORCE_INLINE Values transform_block_axis_narrow(Values input) {
  int sum = (input[0] + input[4]) * 8192;
  int difference = (input[0] - input[4]) * 8192;
  int rotation = (input[2] + input[6]) * 4433;
  int two = rotation - input[6] * 15137;
  int six = rotation + input[2] * 6270;
  int even0 = sum + six;
  int even1 = difference + two;
  int even2 = difference - two;
  int even3 = sum - six;
  int odd_rotation = (input[1] + input[3] + input[5] + input[7]) * 9633;
  int seven_three = odd_rotation - (input[7] + input[3]) * 16069;
  int five_one = odd_rotation - (input[5] + input[1]) * 3196;
  int seven_one = (input[7] + input[1]) * -7373;
  int five_three = (input[5] + input[3]) * -20995;
  int odd0 = input[1] * 12299 + seven_one + five_one;
  int odd1 = input[3] * 25172 + five_three + seven_three;
  int odd2 = input[5] * 16819 + five_three + five_one;
  int odd3 = input[7] * 2446 + seven_one + seven_three;
  return {even0 + odd0, even1 + odd1, even2 + odd2, even3 + odd3,
          even3 - odd3, even2 - odd2, even1 - odd1, even0 - odd0};
}


// Exchange the low three bits of the register index with the lane index.
// Every shuffle is confined to a fully participating eight-lane block.
static LOOM_FORCE_INLINE Values transpose_block(Values values, unsigned axis) {
  [[loom::unroll]]
  for (unsigned stage = 0; stage < 3; ++stage) {
    unsigned mask = 1u << stage;
    Values exchanged = loom::kernel::subgroup::shuffle_xor(values, mask, 8).value;
    Values next = {};
    [[loom::unroll]]
    for (unsigned index = 0; index < 8; ++index) {
      int exchange_mask = -static_cast<int>(((axis ^ index) & mask) != 0);
      next[index] = values[index] ^ ((values[index] ^ exchanged[index ^ mask]) & exchange_mask);
    }
    values = next;
  }
  return values;
}

// All lanes enter; each group of eight consumes one producer's block.
static LOOM_FORCE_INLINE void reconstruct_cooperative(const short* coefficients,
    unsigned coefficient_stride, unsigned threads, unsigned lane,
    unsigned owner, bool valid, bool any_ac, unsigned offset,
    const unsigned* quantization, unsigned* pixels) {
  bool owner_valid = loom::kernel::subgroup::shuffle_index(
      static_cast<unsigned>(valid), owner, threads).value != 0;
  bool owner_ac = loom::kernel::subgroup::shuffle_index(
      static_cast<unsigned>(any_ac), owner, threads).value != 0;
  unsigned owner_offset = loom::kernel::subgroup::shuffle_index(offset, owner, threads).value;
  unsigned axis = lane & 7;
  if (owner_valid) {
    unsigned long long packed = 0;
    if (!owner_ac) {
      int dc = static_cast<int>(coefficients[owner]) * static_cast<int>(quantization[0]);
      unsigned value = sample_byte(((dc + 4) >> 3) + 128);
      packed = static_cast<unsigned long long>(value) * 0x0101010101010101ull;
    } else {
      Values input = {};
      int ac = 0;
      unsigned maximum = 0;
      [[loom::unroll]]
      for (unsigned row = 0; row < 8; ++row) {
        unsigned natural = row * 8 + axis;
        unsigned step = quantization[natural];
        loom::assume(step <= 65535u);
        int value = static_cast<int>(coefficients[natural * coefficient_stride + owner]) *
                    static_cast<int>(step);
        input[row] = value;
        if (row != 0) ac |= value;
        unsigned magnitude = static_cast<unsigned>(value < 0 ? -value : value);
        maximum = magnitude > maximum ? magnitude : maximum;
      }
      unsigned block_maximum = loom::kernel::subgroup::reduce::maxui<8>(maximum);
      bool narrow = block_maximum <= 1024;
      Values columns = {};
      if (ac == 0) {
        [[loom::unroll]]
        for (unsigned row = 0; row < 8; ++row) columns[row] = input[0] * 4;
      } else if (narrow) {
        Values result = transform_block_axis_narrow(input);
        [[loom::unroll]]
        for (unsigned row = 0; row < 8; ++row) columns[row] = (result[row] + 1024) >> 11;
      } else {
        WideValues wide_input = {};
        [[loom::unroll]]
        for (unsigned row = 0; row < 8; ++row) wide_input[row] = input[row];
        WideValues result = transform_block_axis(wide_input);
        [[loom::unroll]]
        for (unsigned row = 0; row < 8; ++row) {
          columns[row] = static_cast<int>((result[row] + 1024) >> 11);
        }
      }
      Values row = transpose_block(columns, axis);
      if (narrow) {
        Values result = transform_block_axis_narrow(row);
        [[loom::unroll]]
        for (unsigned column = 0; column < 8; ++column) {
          int value = ((result[column] + 131072) >> 18) + 128;
          packed |= static_cast<unsigned long long>(sample_byte(value)) << (column * 8);
        }
      } else {
        WideValues wide_input = {};
        [[loom::unroll]]
        for (unsigned column = 0; column < 8; ++column) wide_input[column] = row[column];
        WideValues result = transform_block_axis(wide_input);
        [[loom::unroll]]
        for (unsigned column = 0; column < 8; ++column) {
          int value = static_cast<int>((result[column] + 131072) >> 18) + 128;
          packed |= static_cast<unsigned long long>(sample_byte(value)) << (column * 8);
        }
      }
    }
    reinterpret_cast<unsigned long long*>(pixels + owner_offset)[axis] = packed;
  }
}

// A single subgroup owns the workgroup so its active vote controls every
// barrier uniformly. Producer lanes retain bounded interval cursors; consumers
// exchange matrix ownership only while a complete coefficient block is live.
[[loom::kernel(configure_output)]]
void jpeg_reconstruct(const unsigned* entropy, const unsigned* segments,
    const unsigned* tables, const unsigned* blocks, const unsigned* intervals,
    const unsigned* geometry, const unsigned* quantization, const unsigned* zigzag,
    unsigned* pixels, unsigned* status) {
  unsigned segment = loom::kernel::workgroup::id.y;
  unsigned lane = loom::kernel::workitem::id.x;
  unsigned threads = loom::kernel::workgroup::size.x;
  unsigned interval_capacity = chunks * 2 + certification_segments;
  unsigned stripe = threads * certification_segments;
  unsigned group_count = (interval_capacity + stripe - 1) / stripe;
  const unsigned* descriptor = segments + segment * 8;
  unsigned count = descriptor[3];
  unsigned total_blocks = descriptor[4];
  unsigned first_interval = descriptor[2] * 2 + segment;
  unsigned stride = (4 + component_count + 3) & ~3u;
  const unsigned* words = entropy + descriptor[0];
  unsigned bit_limit = descriptor[1];
  // A two-halfword skew gives distinct bank words to the eight consumers.
  unsigned coefficient_stride = threads + 2;
  auto* coefficients = loom::buffer::alloca<short, loom::memory_space::workgroup, 16>(coefficient_stride * 64);
  for (unsigned first = loom::kernel::workgroup::id.x * threads;
       first < count * 2 + 1; first += group_count * threads) {
    unsigned interval = first + lane;
    bool present = interval < count * 2 + 1;
    Cursor cursor = {};
    cursor.budget = bit_limit;
    cursor.cached_word = 0xffffffffu;
    unsigned end = 0;
    if (present) {
      const unsigned* entry = intervals + (first_interval + interval) * stride;
      cursor.position = entry[0];
      end = entry[1];
      cursor.blocks = entry[2];
      cursor.block_index = entry[3] >> 6;
      cursor.coefficient = entry[3] & 63;
      [[loom::unroll]]
      for (unsigned component = 0; component < component_count; ++component) {
        cursor.predictors[component] = static_cast<int>(entry[4 + component]);
      }
      if (cursor.position < end) {
        while ((cursor.block_index != 0 || cursor.coefficient != 0) && cursor.error == 0) {
          cursor = output_symbol(words, tables, blocks, bit_limit, cursor).cursor;
        }
      }
    }
    bool active = present && cursor.blocks < total_blocks && cursor.position < end && cursor.error == 0;
    while (loom::kernel::subgroup::vote::any(active)) {
      unsigned mcu = descriptor[6] + cursor.blocks / blocks_per_mcu;
      unsigned mcu_row = mcu / scan_mcu_width;
      unsigned mcu_column = mcu % scan_mcu_width;
      for (unsigned block = 0; block < blocks_per_mcu; ++block) {
        bool any_ac = false;
        bool output_valid = false;
        unsigned offset = 0;
        if (active && cursor.error == 0) {
          [[loom::unroll]]
          for (unsigned index = 0; index < 64; ++index) coefficients[index * coefficient_stride + lane] = 0;
          do {
            Symbol symbol = output_symbol(words, tables, blocks, bit_limit, cursor);
            cursor = symbol.cursor;
            if (symbol.index != 0xffffffffu && cursor.error == 0) {
              unsigned natural = zigzag[symbol.index];
              loom::assume(natural < 64u);
              coefficients[natural * coefficient_stride + lane] = static_cast<short>(symbol.value);
              if (symbol.index != 0) any_ac = true;
            }
          } while (cursor.coefficient != 0 && cursor.error == 0);
          const unsigned* shape = geometry + block * 8;
          unsigned column = mcu_column * shape[3] + shape[5];
          unsigned row = mcu_row * shape[4] + shape[6];
          output_valid = cursor.error == 0 && column < shape[1] && row < shape[2];
          offset = descriptor[7] + shape[0] + (row * shape[1] + column) * 16;
        }
        loom::kernel::barrier<loom::memory_space::workgroup,
            loom::atomic::scope::subgroup, loom::atomic::ordering::acq_rel>();
        unsigned component = blocks[block] & 255;
        unsigned components = component_count;
        loom::assume(component < components);
        for (unsigned round = 0; round < 8; ++round) {
          unsigned owner = round * (threads / 8) + lane / 8;
          reconstruct_cooperative(coefficients, coefficient_stride, threads, lane,
              owner, output_valid, any_ac, offset, quantization + component * 64, pixels);
        }
        loom::kernel::barrier<loom::memory_space::workgroup,
            loom::atomic::scope::subgroup, loom::atomic::ordering::acq_rel>();
      }
      active = present && cursor.blocks < total_blocks && cursor.position < end && cursor.error == 0;
    }
    if (present) {
      if (interval == count * 2 && cursor.error == 0) {
        if (cursor.blocks != total_blocks || cursor.coefficient != 0) {
          cursor.error = 3;
        } else {
          unsigned padding = bit_limit - cursor.position;
          if (padding >= 8) {
            cursor.error = 4;
          } else if (padding != 0) {
            Read input = peek(words, cursor);
            if ((input.value >> (32 - padding)) != (1u << padding) - 1) cursor.error = 4;
          }
        }
      }
      status[first_interval + interval] = cursor.error;
    }
  }
}
