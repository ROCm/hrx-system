"""Bounded, interleaved certificate/control and component-output measurements."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
assert os.environ['BENCHMARK_LOCK_LEASE_ID']
parser = argparse.ArgumentParser()
parser.add_argument('--checksum', action='store_true')
parser.add_argument('--storage', action='store_true')
parser.add_argument('--stores', action='store_true')
parser.add_argument('--continuous', action='store_true')
parser.add_argument('--pair', nargs=2)
parser.add_argument('--prefix')
parser.add_argument('--fixtures', nargs=2)
parser.add_argument('--check-candidate', action='store_true')
arguments = parser.parse_args()
sequence = (('wide-store-checksum', 'continuous-checksum', 'wide-store-checksum', 'continuous-checksum', 'wide-store-checksum') if arguments.continuous else
            ('register-checksum', 'wide-store-checksum', 'register-checksum', 'wide-store-checksum', 'register-checksum') if arguments.stores else
            ('checksum', 'register-checksum', 'checksum', 'register-checksum', 'checksum') if arguments.storage else
            ('output', 'checksum', 'output', 'checksum', 'output') if arguments.checksum
            else ('parallel', 'output', 'parallel', 'output', 'parallel'))
prefix = ('gorgon4-continuous' if arguments.continuous else 'gorgon4-stores' if arguments.stores else 'gorgon4-storage' if arguments.storage
          else 'gorgon4-checksum' if arguments.checksum else 'gorgon4-components')
if arguments.pair:
    assert arguments.prefix
    control, candidate = arguments.pair
    sequence = (control, candidate, control, candidate, control)
    prefix = arguments.prefix
fixtures = dict(zip(arguments.pair, arguments.fixtures)) if arguments.fixtures else {}
if arguments.check_candidate:
    assert arguments.pair and arguments.fixtures
    directory = root / arguments.fixtures[1]
    subprocess.run([str(root / 'iree-test-loom-unsigned'), str(directory / 'summary.loombc'),
                    '--config-file=' + str(directory / 'config.json'), '--device=amdgpu',
                    '--target=amdgpu:gfx1151', '--sanitizer=access'], check=True)
for index, variant in enumerate(sequence):
    name = f'{prefix}-{index}-{variant}'
    command = [sys.executable, '-B', str(root / 'device_batch_benchmark.py'),
               '--fixture=' + fixtures.get(variant, variant + '-batch16-1024'), '--result-name=' + name,
               '--runner=iree-benchmark-loom-unsigned',
               '--runner-sha256=3ba3a3e1b3a85a876459320d21d1f32630fb625fd0d39347c45cb875d16c1dad']
    subprocess.run(command, check=True)
    print(json.dumps({'complete': name}), flush=True)
