"""Compile the bounded bridge leaf with the pinned optimized tool closure."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
tags = json.loads(os.environ['BUREAU_TAG_ROOTS'])
base = Path(tags['codec-jpeg-rebased-tools'])
candidate = Path(tags['codec-jpeg-unsigned-opt'])
importer = base / 'loom/src/loom/tools/loom-import-cxx/loom-import-cxx'
linker = base / 'loom/src/loom/tools/loom-link/loom-link'
compiler = candidate / 'loom/src/loom/tools/loom-compile/loom-compile'
commands = [
    [str(importer), str(notes / 'device_entropy_pipeline.cxx'), '--output=' + str(root / 'entropy-bridges.loom')],
    [str(linker), str(root / 'entropy-bridges.loom'), '--to=bc', '--output=' + str(root / 'entropy-bridges.loombc')]]
for command in commands:
    subprocess.run(command, check=True)
output = root / 'jpeg-bridge.hsaco'
report = root / 'jpeg-bridge-report.json'
command = [str(compiler), str(root / 'entropy-bridges.loombc'), '--root=jpeg_bridge',
           '--target=amdgpu:gfx1151', '--config-file=' + str(root / 'anchor-batch16-1024/config.json'),
           '--output=' + str(output), '--compile-report=details',
           '--compile-report-output=' + str(report)]
subprocess.run(command, check=True)
commands.append(command)
metrics = json.loads(report.read_text())['entries']['rows'][0]
record = {
    'commands': commands, 'artifact_sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
    'bytecode_sha256': hashlib.sha256((root / 'entropy-bridges.loombc').read_bytes()).hexdigest(),
    'compiler_sha256': hashlib.sha256(compiler.read_bytes()).hexdigest(),
    'sources': {path: hashlib.sha256((notes / path).read_bytes()).hexdigest() for path in
                ('device_entropy_cursor.h', 'device_entropy_tables.cxx', 'device_anchor.cxx',
                 'device_bridge.cxx', 'device_entropy_pipeline.cxx')},
    'metrics': {key: metrics[key] for key in ('instruction_count', 'code_byte_count',
                                            'private_memory_bytes', 'local_memory_bytes', 'target_resources')}}
(notes / 'device-bridge-code.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record['metrics']), flush=True)
