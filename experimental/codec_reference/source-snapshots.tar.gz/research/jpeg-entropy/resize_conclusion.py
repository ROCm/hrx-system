"""Summarize completed controlled runs without mixing machines or boundaries."""
import hashlib
import json
from pathlib import Path
import statistics

notes=Path(__file__).resolve().parent
comparison=json.loads((notes/'resize-gorgon4-comparison.json').read_text())
assert len(comparison['rows'])==10 and not comparison['after']['live_kfd']
policies={}
for policy in ('baseline','polling','islow','ifast'):
    rows=[row for row in comparison['rows'] if row['policy']==policy]
    samples=[value/1e6 for row in rows for value in row['measurement']['batch_ns']]
    assert all(row['result']['returncode']==0 for row in rows)
    policies[policy]={'pooled_median_ms':statistics.median(samples),'samples_ms':samples,
                      'round_medians_ms':[row['median_ms'] for row in rows]}
profile,=[row for row in comparison['rows'] if row['policy']=='profile']
times={row['function']:row['total_ns']/1e6 for row in profile['profile']}
cpu=min(policies[p]['pooled_median_ms'] for p in ('islow','ifast'))
baseline=policies['baseline']['pooled_median_ms'];polling=policies['polling']['pooled_median_ms']
summary={'state':'Complete bounded experiment; reject this per-tile role-selecting schedule for serving.',
 'machine':'hrx-gorgon-4; gfx1151; 16 physical Zen5 CPU cores; native-worker hold and benchmark broker lease',
 'scope':comparison['scope'],'cohort_images':128,'retained_outputs':16,'fixture_unique_images':4,
 'policies':policies,'profile_ms':times,'profile_total_ms':profile['device_total_ms'],
 'synchronization_time_reduction_fraction':1-polling/baseline,
 'gpu_over_best_cpu_ratio':polling/cpu,
 'consumer_share_fraction':times['jpeg_resize_stream']/profile['device_total_ms'],
 'memory':json.loads((notes/'resize-memory.json').read_text()),
 'logical_work':json.loads((notes/'resize-logical-work.json').read_text())['cohort'],
 'native_resources':{},'source_pins':json.loads((notes/'resize-polling-source.json').read_text()),
 'numerical_contract':'Unchanged float32 GPU IDCT and exact model bicubic operation order. CPU ISLOW/IFAST preserve their separately checked outputs; no new cross-policy bit-equality or accuracy claim.',
 'limits':['Four unique images repeated into sixteen distinct outputs, then eight queued repetitions; not a training-dataset generalization.',
           'Resident GPU compressed input; header preparation, GPU upload/allocation and JIT outside timing. CPU codec lifecycle and row workspace allocation included.',
           'CPU uses actual SIMD libjpeg plus the identical bounded row filter, not a claim to the fastest available CPU resizing library.',
           'Device allocation peak counters are unavailable; live image-buffer backing excludes runtime/code and host mirrors.',
           'The synchronization variant jointly changes empty-queue work and acquire placement; their individual contributions are not separated.',
           'Static task/byte counts and native ISA do not dynamically apportion remaining scheduler, reconstruction, filter, or memory-stall time.'],
 'receipts':{}}
for policy,case in [('baseline','primary-r3-w128'),('polling','primary-r3-w128-polling')]:
    receipt=json.loads((notes/('resize-'+case+'-compile.json')).read_text())
    summary['native_resources'][policy]=receipt['resources']['jpeg_resize_stream']
names=['resize-gorgon4-comparison.json','resize-gorgon4-comparison-window.json','resize-output-audit.json',
 'resize-gorgon4-cpu-checks.json','resize-gorgon4-cpu-routes.json','resize-gorgon4-primary-window.json',
 'resize-gorgon4-padding-window.json','resize-baseline-worker.native.s','resize-polling-worker.native.s',
 'resize-cpu-islow.native.s','resize-cpu-ifast.native.s','resize-cpu-stage.json',
 'resize-hrx-gorgon-3-small-r3-w1-check.json','resize-hrx-gorgon-3-primary-r3-w128-check.json',
 'resize-hrx-gorgon-3-small-r3-w128-invalid-check.json','resize-hrx-gorgon-3-small-r3-w128-invalid-padding-check.json',
 'resize-hrx-gorgon-4-primary-r3-w128-polling-check.json','resize-hrx-gorgon-4-small-r3-w128-invalid-padding-polling-check.json']
for name in names:
    p=notes/name
    summary['receipts'][name]=hashlib.sha256(p.read_bytes()).hexdigest()
(notes/'resize-conclusion.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({key:value for key,value in summary.items() if key not in ('receipts','native_resources','source_pins','policies','memory')},indent=2))
for policy,value in policies.items():print(policy,value['pooled_median_ms'],value['round_medians_ms'])
