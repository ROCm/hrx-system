"""Pin and stage the bounded HTTP witness before acquiring GPU exclusivity."""
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import tarfile


notes = Path(__file__).resolve().parent
source_path = notes / "http-publication-source.json"
source = json.loads(source_path.read_text())
directory = Path(source["directory"])
root = directory.parent
build = json.loads((notes / "http-publication-build.json").read_text())
compiled = json.loads((notes / "http-publication-compile.json").read_text())
source_digest = hashlib.sha256(source_path.read_bytes()).hexdigest()
assert build["source_manifest_sha256"] == compiled["source_sha256"] == source_digest
assert build["restored"] and all(item["returncode"] == 0 for item in build["commands"] + compiled["commands"])
tag = "codec-jpeg-http"
capture = json.loads(subprocess.check_output(["bureau-bazel", "tag", "inspect", tag, "--json"], text=True))
assert capture["capture"] == build["capture"]["capture"]
binary = Path(json.loads(os.environ["BUREAU_TAG_ROOTS"])[tag]) / build["capture"]["outputs"][0]
files = {"loom-serve": binary, "run.py": notes / "http_publication_run.py"}
for name, expected in source["sources"].items():
    path = directory / name
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, name
    files[name] = path
controls = json.loads((notes / "model-accuracy-stage.json").read_text())
for name in ("original.jpg", "loom-float32.pam"):
    path = root / "vision-accuracy/inputs" / name
    assert hashlib.sha256(path.read_bytes()).hexdigest() == controls["files"]["inputs/" + name]
    files[name] = path

# Remove only the entropy body. Locate SOS from bounded segment lengths, not
# an entropy parse; the GPU must discover the missing coefficient data.
encoded = files["original.jpg"].read_bytes()
assert encoded[:2] == b"\xff\xd8"
position = 2
while True:
    assert encoded[position] == 255
    while encoded[position] == 255:
        position += 1
    marker = encoded[position]
    position += 1
    length = int.from_bytes(encoded[position:position + 2], "big")
    assert length >= 2 and position + length <= len(encoded)
    position += length
    if marker == 218:
        break
invalid = directory / "empty-entropy.jpg"
invalid.write_bytes(encoded[:position] + b"\xff\xd9")
files[invalid.name] = invalid
assert position == 442
staged_bytes = sum(path.stat().st_size for path in files.values())
assert staged_bytes < 256 * 1024**2
manifest = {"source_sha256": source_digest, "capture": capture["capture"],
            "entropy_start": position, "staged_bytes": staged_bytes,
            "files": {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in files.items()}}
manifest_path = directory / "stage-manifest.json"
manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
files[manifest_path.name] = manifest_path
machine = "hrx-gorgon-3"
subprocess.run(["ssh", machine, "mkdir -p " + shlex.quote(str(directory))], check=True)
print(json.dumps({"staged_bytes": staged_bytes, "lease_held": False}), flush=True)
process = subprocess.Popen(["ssh", "-o", "ConnectTimeout=15", machine,
                            "tar -xzf - -C " + shlex.quote(str(directory))], stdin=subprocess.PIPE)
with tarfile.open(fileobj=process.stdin, mode="w|gz", dereference=True) as archive:
    for name, path in files.items():
        archive.add(path, arcname=name, recursive=False)
process.stdin.close()
assert process.wait() == 0
verify = '''import hashlib,json,pathlib,socket,sys
root=pathlib.Path(sys.argv[1]); manifest=json.loads((root/'stage-manifest.json').read_text())
for name,digest in manifest['files'].items():
 with (root/name).open('rb') as stream:
  assert hashlib.file_digest(stream,'sha256').hexdigest()==digest,name
for row in sys.argv[2].splitlines():
 digest,name=row.split(None,1)
 with pathlib.Path(name).open('rb') as stream:
  assert hashlib.file_digest(stream,'sha256').hexdigest()==digest,name
assert not list(pathlib.Path('/sys/class/kfd/kfd/proc').iterdir())
with socket.socket() as listener:
 listener.bind(('127.0.0.1',18185))
print('All staged inputs and trained assets verified; no GPU client; port free.',flush=True)
'''
result = subprocess.run(["ssh", machine, shlex.join(["python3", "-B", "-c", verify, str(directory),
                       (notes / "model-accuracy-assets.sha256").read_text()])], capture_output=True, text=True)
record = {"machine": machine, "manifest": manifest, "build_capture": capture,
          "verification_returncode": result.returncode, "verification": result.stdout + result.stderr,
          "lease_held": False}
(notes / "http-publication-stage.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({key: value for key, value in record.items() if key not in ("manifest", "build_capture")}), flush=True)
assert result.returncode == 0
