"""Compose the qualified decoder with a pinned trained projector in /tmp."""

import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile


notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / "device-active.json").read_text())["directory"])
directory = root / "native-projector"
directory.mkdir(exist_ok=True)
sources = directory / "sources"
sources.mkdir(exist_ok=True)
control_sources = directory / "control-sources"
control_sources.mkdir(exist_ok=True)
commit = "964dca5ed218eb11399c4c62774131abcdd0dc3e"
archive = subprocess.check_output(["git", "archive", commit,
    "experimental/loom_serve/models/qwen", "experimental/loom_serve/motifs"])
with tarfile.open(fileobj=io.BytesIO(archive)) as stream:
    stream.extractall(sources, filter="data")
with tarfile.open(fileobj=io.BytesIO(archive)) as stream:
    stream.extractall(control_sources, filter="data")
model = sources / "experimental/loom_serve/models/qwen"
baseline = root / "native-upload"
baseline_record = json.loads((notes / "upload-source.json").read_text())
for name, expected in baseline_record["files"].items():
    assert hashlib.sha256((baseline / name).read_bytes()).hexdigest() == expected
    if name.endswith(".h"):
        (directory / name).write_bytes((baseline / name).read_bytes())
originals = {}


def read(name):
    data = (model / name).read_text()
    originals[name] = hashlib.sha256(data.encode()).hexdigest()
    return data


def replace(text, old, new, count=1):
    assert text.count(old) == count, (old, text.count(old), count)
    return text.replace(old, new)


source = (baseline / "upload_pipeline.cxx").read_text()
source = replace(source,
    "  loom::assume(loom::predicate::multiple_of(offset, 16u));\n  return offset / 4;",
    "  // Image statuses are packed words; all other spans retain 16-byte alignment.\n"
    "  unsigned alignment = buffer == JPEG_VALIDITY ? 4u : 16u;\n"
    "  loom::assume(loom::predicate::multiple_of(offset, alignment));\n  return offset / 4;")
helper = '''
static LOOM_FORCE_INLINE const unsigned* jpeg_model_input(unsigned image, const unsigned* root) {
  loom::assume(image < 4u);
  unsigned packet_offset = root[image * 4];
  loom::assume(packet_offset <= 268435456u);
  loom::assume(loom::predicate::multiple_of(packet_offset, 16u));
  const unsigned* packet = root + packet_offset / 4;
  unsigned jpeg_offset = packet[8];
  loom::assume(loom::predicate::multiple_of(jpeg_offset, 16u));
  return packet + jpeg_offset / 4;
}
'''
source = source.replace('#include <loomcxx/predicate.h>\n', '#include <loomcxx/predicate.h>\n' + helper, 1)
for entry in baseline_record["entries"]:
    kind = entry["config_arguments"]
    if kind:
        configure = entry["configure"]
        suffix = ", const unsigned* output" if kind == "schedule" else ""
        source = replace(source,
            f"static loom::kernel::configuration {configure}(const unsigned* input{suffix}) {{",
            f"static loom::kernel::configuration {configure}(unsigned image, const unsigned* root{suffix}) {{\n"
            "  loom::assume(image < 4u);\n"
            "  unsigned packet_offset = root[image * 4];\n"
            "  loom::assume(packet_offset <= 268435456u);\n"
            "  loom::assume(loom::predicate::multiple_of(packet_offset, 16u));\n"
            "  const unsigned* packet = root + packet_offset / 4;\n"
            "  unsigned jpeg_offset = packet[8];\n"
            "  loom::assume(loom::predicate::multiple_of(jpeg_offset, 16u));\n"
            "  const unsigned* input = packet + jpeg_offset / 4;")
    source = replace(source,
        f'void {entry["name"]}(const unsigned* input, unsigned* output) {{',
        f'void {entry["name"]}(unsigned image, const unsigned* root, unsigned* output) {{\n'
        '  const unsigned* input = jpeg_model_input(image, root);')
(directory / "projector_decoder.cxx").write_text(source)

entries = {entry["name"]: entry for entry in baseline_record["entries"]}
order = re.findall(r"    kernel.launch @(jpeg_\w+)", (baseline / "command.loom").read_text())
declarations, launches = [], []
for name in order:
    kind = entries[name]["config_arguments"]
    declaration = "%selected: i32, %launch_input: buffer, %input_offset: offset"
    arguments, types = "%ordinal, %input, %zero", "i32, buffer, offset"
    if kind == "schedule":
        declaration += ", %launch_output: buffer, %output_offset: offset"
        arguments += ", %output, %zero"
        types += ", buffer, offset"
    if not kind:
        declaration = ""
    declarations.append(f"kernel.decl @{name}({declaration}) launch(%image: i32, %input: buffer, %output: buffer)")
    config = f"[{arguments}]" if kind else ""
    signature = f"[{types}]" if kind else ""
    launches.append(f"    kernel.launch @{name}{config}(%ordinal, %input, %output) : {signature}(i32, buffer, buffer)")
command = "\n".join(declarations) + '''

template.decl @jpeg_projector_decode(%image: index, %input: buffer, %output: buffer)

template.def<@jpeg_projector_decode> @jpeg_projector_decode_impl(%image: index, %input: buffer, %output: buffer) {
  %zero = index.constant 0 : offset
  %ordinal = index.cast %image : index to i32
  command.serial {
''' + "\n".join(launches) + '''
  }
  template.return
}
'''
(directory / "decoder_command.loom").write_text(command)

pixels = read("vision_pixels.loom")
pixels = replace(pixels, '''// The native image packet supplies checked display geometry, orientation, and
// decoded RGB/RGBA storage. Its source-owned metadata is the two I32 dimensions
// selected while rendering the chat. This packet preserves the decoded plane
// and appends the filter plans; it never materializes resized pixels on the host.
//
// The first 64 bytes reserve a four-image cohort directory. Batch preparation
// fills the first packet's directory in the native packed upload. All offsets in
// the following 64-byte resize header are relative to that header, not the cohort.''', '''// The native compressed packet supplies checked geometry, orientation, target
// dimensions, JPEG tables, and original encoded bytes. Preparation retains the
// trained filter plans and appends that upload without materializing pixels.
// The first 64 bytes reserve the cohort directory. The following 80-byte header
// addresses filter tables and JPEG input relative to itself; batch preparation
// relocates decoder output ranges into reusable device scratch.''')
signature = "func.def public @qwen38_vision_pixel_packet(%request: buffer) -> (buffer) {"
pixels = replace(pixels, signature, '''func.decl import("input") @require(%condition: i32, %diagnostic: buffer)

global.rodata.def @jpeg_packet_diagnostic = bytes("''' + b"Projector requires the native compressed JPEG packet".hex() + '''")

''' + signature)
header = "  %header = buffer.view %request[%origin] : buffer -> view<16xi32>"
pixels = replace(pixels, header, header + '''
  %representation = view.load %header[0] : view<16xi32> -> i32
  %jpeg_representation = scalar.constant 1195724874 : i32
  %representation_valid = scalar.cmpi eq, %representation, %jpeg_representation : i32
  %representation_valid32 = scalar.extui %representation_valid : i1 to i32
  %representation_diagnostic = global.load @jpeg_packet_diagnostic : buffer
  func.call @require(%representation_valid32, %representation_diagnostic) : (i32, buffer)
  %encoded_bytes = view.load %header[11] : view<16xi32> -> i32
  %decoder_bytes = view.load %header[13] : view<16xi32> -> i32''')
pixels = replace(pixels, "%source_bytes = view.load %header[11]", "%source_bytes = view.load %header[14]")
pixels = replace(pixels, "%horizontal_starts = scalar.constant 64 : i32", "%horizontal_starts = scalar.constant 80 : i32")
pixels = replace(pixels, "%pixel_end = scalar.addi %pixels, %source_bytes : i32", "%pixel_end = scalar.addi %pixels, %encoded_bytes : i32")
pixels = replace(pixels, "%pixel_bytes = index.cast %source_bytes : i32 to offset", "%pixel_bytes = index.cast %encoded_bytes : i32 to offset")
pixels = "\n".join(line.replace("view<16xi32>", "view<20xi32>") if "%resize_header" in line else line
                   for line in pixels.splitlines()) + "\n"
layout = "  view.store %layout, %resize_header[15] : i32, view<20xi32>"
pixels = replace(pixels, layout, layout + '''
  view.store %decoder_bytes, %resize_header[16] : i32, view<20xi32>
  view.store %encoded_bytes, %resize_header[17] : i32, view<20xi32>
  view.store %zero, %resize_header[18] : i32, view<20xi32>
  view.store %zero, %resize_header[19] : i32, view<20xi32>''')
(model / "vision_pixels.loom").write_text(pixels)

control = read("vision_control.loom")
control = replace(control, "// directory in place; the original decoded planes need no further cohort copy.",
                  "// directory in place; compressed payloads need no further cohort copy.")
control = replace(control, "  view.store %output_bytes, %header[0] : i64, view<4xi64>\n", "")
loop = "  scf.for %i = [%c0 to %count step %c1] {"
control = replace(control, loop, '''  %zero64 = scalar.constant 0 : i64
  %status_bytes = scalar.constant 16 : i64
  %decoder_base = scalar.addi %output_bytes, %status_bytes : i64
  %decoder_base32 = scalar.trunci %decoder_base : i64 to i32
  %scratch_capacity = scf.for %i = [%c0 to %count step %c1](%largest = %zero64 : i64) -> (i64) {''')
tail = "    view.store %image_rows, %requests[%i, 2] : i64, view<[%count]x3xi64>"
relocations = []
for index in [0, 3, 4, 5, 6, 7, 8, 9, 13, 14, 15, 16, 18, 19, 20, 22]:
    relocations.append(f'''    %old_{index} = view.load %jpeg_directory[{index}] : view<26xi32> -> i32
    %new_{index} = scalar.addi %old_{index}, %decoder_base32 : i32
    view.store %new_{index}, %jpeg_directory[{index}] : i32, view<26xi32>''')
control = replace(control, tail, tail + '''
    %header_bounded = scalar.assume %header_offset [range(%header_offset, 0, 268435456)] : i64
    %resize_position = index.cast %header_bounded : i64 to offset
    %resize = buffer.view %packed[%resize_position] : buffer -> view<20xi32>
    %jpeg_relative32 = view.load %resize[8] : view<20xi32> -> i32
    %jpeg_relative = scalar.extui %jpeg_relative32 : i32 to i64
    %jpeg_position64 = scalar.addi %header_bounded, %jpeg_relative : i64
    %jpeg_position = index.cast %jpeg_position64 : i64 to offset
    %jpeg_directory = buffer.view %packed[%jpeg_position] : buffer -> view<26xi32>
''' + "\n".join(relocations) + '''
    %four = scalar.constant 4 : i64
    %status_relative = scalar.muli %i64, %four : i64
    %status_position64 = scalar.addi %output_bytes, %status_relative : i64
    %status_position = scalar.trunci %status_position64 : i64 to i32
    view.store %status_position, %jpeg_directory[25] : i32, view<26xi32>
    %decoder_bytes32 = view.load %resize[16] : view<20xi32> -> i32
    %decoder_bytes = scalar.extui %decoder_bytes32 : i32 to i64
    %maximum = scalar.maxui %largest, %decoder_bytes : i64
    scf.yield %maximum : i64''')
control = replace(control, "  %records = buffer.view %plan[%row_offset]", '''  %physical_output = scalar.addi %decoder_base, %scratch_capacity : i64
  view.store %physical_output, %header[0] : i64, view<4xi64>
  %records = buffer.view %plan[%row_offset]''')
(model / "vision_control.loom").write_text(control)

resize = read("kernels/qwen38/vision_resize.loom")
resize = replace(resize, "launch(%image: index, %input: buffer, %output: buffer)",
                 "launch(%image: index, %input: buffer, %decoded: buffer, %output: buffer)")
resize = replace(resize, "%input_noalias, %output_noalias = buffer.assume.noalias %input, %output : buffer, buffer",
    "%input_noalias, %decoded_noalias, %output_noalias = buffer.assume.noalias %input, %decoded, %output : buffer, buffer, buffer")
resize = replace(resize, "  %source_offset = index.add %packet_offset, %source_relative : offset", '''  %jpeg_offset = index.add %packet_offset, %source_relative : offset
  %jpeg_directory = buffer.view %input_noalias[%jpeg_offset] : buffer -> view<26xi32>
  %rgb_offset_word = view.load %jpeg_directory[16] : view<26xi32> -> i32
  %source_offset = index.cast %rgb_offset_word : i32 to offset
  %validity_offset_word = view.load %jpeg_directory[25] : view<26xi32> -> i32
  %validity_offset = index.cast %validity_offset_word : i32 to offset
  %validity = buffer.view %decoded_noalias[%validity_offset] : buffer -> view<1xi32>
  %error = view.load %validity[0] : view<1xi32> -> i32
  %jpeg_valid = scalar.cmpi eq, %error, %c0_i32 : i32''')
resize = replace(resize, "%source = buffer.view %input_noalias[%source_offset]", "%source = buffer.view %decoded_noalias[%source_offset]")
loads = '''        %red_byte = view.load %source[%red_index] : view<[%source_count]xi8> -> i8
        %green_byte = view.load %source[%green_index] : view<[%source_count]xi8> -> i8
        %blue_byte = view.load %source[%blue_index] : view<[%source_count]xi8> -> i8'''
resize = replace(resize, loads, '''        %red_byte, %green_byte, %blue_byte = scf.if %jpeg_valid -> (i8, i8, i8) {
          %r = view.load %source[%red_index] : view<[%source_count]xi8> -> i8
          %g = view.load %source[%green_index] : view<[%source_count]xi8> -> i8
          %b = view.load %source[%blue_index] : view<[%source_count]xi8> -> i8
          scf.yield %r, %g, %b : i8, i8, i8
        } else {
          %black = scalar.constant 0 : i8
          scf.yield %black, %black, %black : i8, i8, i8
        }''')
(model / "kernels/qwen38/vision_resize.loom").write_text(resize)

projector = read("programs/qwen38/vision_projector.loom")
projector = replace(projector, "launch(%image: index, %input: buffer, %output: buffer)",
    "launch(%image: index, %input: buffer, %decoded: buffer, %output: buffer)")
launch = "    kernel.launch @qwen38_vision_resize[%resize_x, %resize_y](%image, %input, %activation) : [index, index](index, buffer, buffer)"
projector = replace(projector, launch, '''    template.apply<@jpeg_projector_decode>(%image, %input, %output) : (index, buffer, buffer)
    kernel.launch @qwen38_vision_resize[%resize_x, %resize_y](%image, %input, %output, %activation) : [index, index](index, buffer, buffer, buffer)''')
projector = "template.decl @jpeg_projector_decode(%image: index, %input: buffer, %output: buffer)\n\n" + projector
(model / "programs/qwen38/vision_projector.loom").write_text(projector)

configuration = {"jpeg.chunk_bytes": 1024, "jpeg.output_partitions": 4,
                 "jpeg.segments": 1, "input.tiles": 1024, "input.entropy_padding_words": 32}
stages = read("vision_stages.loom")
constants, settings = [], []
for index, (name, value) in enumerate(configuration.items()):
    constants.append(f'global.rodata.def @jpeg_config_{index} = bytes("{name.encode().hex()}")')
    settings.append(f'''  %jpeg_key_{index} = global.load @jpeg_config_{index} : buffer
  %jpeg_value_{index} = scalar.constant {value} : i64
  func.call @config_i64(%stage, %jpeg_key_{index}, %jpeg_value_{index}) : (i32, buffer, i64)''')
stages = "\n".join(constants) + "\n\n" + stages
stages = replace(stages, "  func.return %stage : i32", "\n".join(settings) + "\n  func.return %stage : i32")
(model / "vision_stages.loom").write_text(stages)

deployment = json.loads((root / "vision-accuracy/deployment.json").read_text())
control_deployment = json.loads(json.dumps(deployment))
control_deployment["base_directory"] = str(control_sources / "experimental/loom_serve/models/qwen")
(directory / "control-deployment.json").write_text(json.dumps(control_deployment, indent=2) + "\n")
deployment["name"] = "codec-jpeg-native-projector"
deployment["base_directory"] = str(model)
deployment["definition"]["sources"].append(str(directory / "decoder.loombc"))
(directory / "deployment.json").write_text(json.dumps(deployment, indent=2) + "\n")
record = {"model_commit": commit, "decoder_baseline": baseline_record,
          "originals": originals, "configuration": configuration,
          "generator_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          "files": {str(path.relative_to(directory)): hashlib.sha256(path.read_bytes()).hexdigest()
                    for path in [*sources.rglob("*"), *control_sources.rglob("*"),
                                 directory / "projector_decoder.cxx", directory / "decoder_command.loom",
                                 directory / "mixed_cursor.h", directory / "mixed_image.h", directory / "device_upload.h",
                                 directory / "deployment.json", directory / "control-deployment.json"]
                    if path.is_file() and path.suffix in (".loom", ".cxx", ".h", ".json")},
          "scope": "Bounded copied model source: native compressed packet, source-owned filter plans, twelve queued JPEG stages per image, actual trained projection, decoder scratch reused between images. No shipping API or model branch change."}
(notes / "projector-upload-source.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"directory": str(directory), "modified_model_sources": list(originals), "kernels": len(order)}))
