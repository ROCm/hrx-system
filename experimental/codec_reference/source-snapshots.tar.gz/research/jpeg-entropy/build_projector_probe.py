"""Capture a temporary native observer; restore the target package exactly."""
import hashlib
import json
from pathlib import Path
import subprocess

notes = Path(__file__).resolve().parent
build = Path('loom/src/loom/tooling/target/amdgpu/serve/BUILD.bazel')
source = build.parent / 'codec_projector_probe.cc'
assert not source.exists()
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True)
original = build.read_bytes()
probe = (notes / 'projector_probe.cc').read_bytes()
target = b'''
loom_cc_binary(
    name = "codec_projector_probe",
    testonly = True,
    srcs = ["codec_projector_probe.cc"],
    deps = [
        ":test_compiler", ":test_device",
        "//loom/src/loom/serve/media:image",
        "//loom/src/loom/serve/media:image_request",
        "//loom/src/loom/serve/runtime/device",
        "//loom/src/loom/serve/runtime/host",
        "//loom/src/loom/serve/runtime/host:wake",
        "//loom/src/loom/serve/runtime/parameter:residency",
        "//loom/src/loom/serve/service/finite:model",
        "//loom/src/loom/serve/service/finite:result",
        "//loom/src/loom/serve/testing:compiler",
        "//loom/src/loom/serve/testing:device",
        "//loom/src/loom/serve/testing:model",
        "//runtime/src/iree/base",
        "//runtime/src/iree/base/internal:base64",
        "//runtime/src/iree/base/tooling:flags",
        "//runtime/src/iree/hal",
        "//runtime/src/iree/testing:gtest",
        "//runtime/src/iree/testing:gtest_main",
        "//runtime/src/iree/vm",
    ],
)
'''
overlay = original + target
record = {'source_sha256': hashlib.sha256(probe).hexdigest(), 'restored': False}
build.write_bytes(overlay)
source.write_bytes(probe)
try:
    result = subprocess.run(['bureau-bazel', 'build', '--tag=codec-jpeg-vision-asan', '--config=asan',
                             '//loom/src/loom/tools/loom-serve',
                             '//experimental/codec_reference/research/jpeg-entropy:float_reference',
                             '//loom/src/loom/tooling/target/amdgpu/serve:codec_projector_probe'])
    record['returncode'] = result.returncode
finally:
    assert build.read_bytes() == overlay, 'concurrent BUILD change; preserve for reconciliation'
    assert source.read_bytes() == probe, 'concurrent probe change; preserve for reconciliation'
    build.write_bytes(original)
    source.unlink()
    record['restored'] = True
    (notes / 'projector-probe-build.json').write_text(json.dumps(record, indent=2) + '\n')
raise SystemExit(result.returncode)
