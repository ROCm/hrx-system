"""Derive a bounded metadata experiment from the pinned, qualified decoder."""

import hashlib
import json
from pathlib import Path
import re

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / "device-active.json").read_text())["directory"])
directory = root / "mixed-current"
directory.mkdir(exist_ok=True)
original = (notes / "device_float_pipeline.cxx").read_text()
identity = json.loads((notes / "connected-requalified-stage.json").read_text())
assert hashlib.sha256(original.encode()).hexdigest() == identity["source_sha256"]

cursor = (notes / "device_entropy_cursor_twolevel.h").read_text()
first = cursor.index("using Predictors")
cursor = '''#pragma once
#include <loomcxx/buffer.h>
#include <loomcxx/kernel.h>
#include <loomcxx/predicate.h>
#include <loomcxx/target.h>
#include "mixed_image.h"
[[loom::config("jpeg.chunk_bytes"), loom::where(loom::predicate::range(1u, 65536u))]]
extern const unsigned chunk_bytes;
static constexpr unsigned component_count = 3;
static constexpr unsigned table_count = 8;
static constexpr bool cache_tables = false;

static LOOM_FORCE_INLINE unsigned block_descriptor(BlockLayout layout, unsigned block) {
  unsigned word = block < 4 ? layout.first : (block < 8 ? layout.second : layout.third);
  return (word >> ((block & 3u) * 8u)) & 255u;
}

''' + cursor[first:]
cursor = cursor.replace("const unsigned* blocks", "BlockLayout layout")
cursor = cursor.replace(", blocks,", ", layout,")
cursor = cursor.replace("blocks_per_mcu", "layout.count")
cursor = cursor.replace("block_descriptor(block_index)", "block_descriptor(layout, block_index)")
(directory / "mixed_cursor.h").write_text(cursor)
(directory / "mixed_image.h").write_bytes((notes / "mixed_image.h").read_bytes())

source = original.replace('"device_entropy_cursor_twolevel.h"', '"mixed_cursor.h"')
source = re.sub(r'\b(advance|advance_symbol|advance_symbol_certified|output_symbol)\(words, tables, blocks,',
                lambda match: match[1] + '(words, tables, layout,', source)
source = source.replace("blocks_per_mcu", "layout.count")
source = source.replace("block_descriptor(block)", "block_descriptor(layout, block)")
source = source.replace("const unsigned* tables, const unsigned* blocks, unsigned limit,",
                        "const unsigned* tables, BlockLayout layout, unsigned limit,")
source = source.replace("const unsigned* table, Cursor cursor) {",
                        "const unsigned* table, Cursor cursor, BlockLayout layout) {")
source = source.replace("advance_ac_certified(words, ac_table, cursor)",
                        "advance_ac_certified(words, ac_table, cursor, layout)")
source = source.replace("  unsigned interval_capacity = chunks * (output_partitions + 1) + certification_segments;\n", "")
source = re.sub(r'\[\[loom::config\("jpeg.mcu_width"\).*?\nextern const unsigned scan_mcu_width;\n', '', source)


def change_function(text, name, transform):
    begin = text.index("void " + name + "(")
    opening = text.index("{", begin)
    depth = 1
    end = opening + 1
    while depth:
        if text[end] == "{": depth += 1
        if text[end] == "}": depth -= 1
        end += 1
    return text[:begin] + transform(text[begin:end]) + text[end:]


def entropy_kernel(text):
    text = text.replace("const unsigned* schedule)",
                        "const unsigned* schedule, const Image* headers)")
    text = text.replace("job * 3", "job * 4")
    marker = "  if (job >= schedule[0]) return;"
    assert text.count(marker) == 1
    return text.replace(marker, marker + '''
  unsigned image = jobs[job * 4 + 3];
  BlockLayout layout = reinterpret_cast<const BlockLayout*>(blocks)[image];
  tables += headers[image].table_word_offset;
''')


for name in ("jpeg_speculate", "jpeg_bridge"):
    source = change_function(source, name, entropy_kernel)


def reconstruct(text):
    text = text.replace("unsigned* pixels, unsigned* status)",
                        "unsigned* pixels, unsigned* status, const Image* headers)")
    marker = "  const unsigned* descriptor = segments + segment * 8;"
    assert text.count(marker) == 1
    text = text.replace(marker, marker + '''
  Image image = headers[segment];
  BlockLayout layout = reinterpret_cast<const BlockLayout*>(blocks)[segment];
  tables += image.table_word_offset;
  geometry += image.geometry_word_offset;
  quantization += image.quantization_word_offset;
''')
    return text.replace("scan_mcu_width", "image.mcu_columns")


source = change_function(source, "jpeg_reconstruct", reconstruct)
color_begin = source.index('[[loom::config("image.width")')
color_end = source.index('[[loom::config("input.tiles")')
color = source[color_begin:color_end]
color = color[color.index("using ColorSamples"):]
configure_begin = color.index("static loom::kernel::configuration configure_color()")
body_begin = color.index("void jpeg_color(")
color = color[:configure_begin] + color[body_begin:]
color = color.replace("static LOOM_FORCE_INLINE", "LOOM_FORCE_INLINE")
color = color.replace("void jpeg_color(const unsigned char* components, unsigned char* rgb)",
                      "void run(const unsigned char* components, unsigned char* rgb, Image image, const unsigned* tile, unsigned* cache)")
color = color.replace("  unsigned stride = image_color_space == 1 ? bytes0 : bytes0 + bytes1 + bytes2;\n", "")
color = color.replace("components + loom::kernel::workgroup::id.z * stride",
                      "components + image.component_word_offset * 4")
color = color.replace("unsigned bytes0 = color_plane_bytes(horizontal0, vertical0)",
                      "unsigned bytes0 = image.first_plane_bytes")
color = color.replace("unsigned bytes1 = color_plane_bytes(horizontal1, vertical1)",
                      "unsigned bytes1 = image.second_plane_bytes")
color = color.replace("  unsigned bytes2 = color_plane_bytes(horizontal2, vertical2);\n", "")
color = color.replace("loom::kernel::workgroup::id.x * 64", "tile[1]")
color = color.replace("loom::kernel::workgroup::id.y * 16", "tile[2]")
color = color.replace("((loom::kernel::workgroup::id.z * image_height + y) * image_width + x) * 3",
                      "image.rgb_byte_offset + (y * image_width + x) * 3")
color = re.sub(r'  auto\* cache([012]) = loom::buffer::alloca<[^;]+;',
               lambda match: '  unsigned* cache' + match[1] + ' = cache' + (' + 640;' if match[1] == '2' else ';'), color)
tail = color.index("\n\n#include", color.index("void run("))
color = color[:tail]
functions = re.findall(r'LOOM_FORCE_INLINE \w+ (color_\w+)\(', color)
for name in functions:
    color = color.replace(name + "(", name + "(dimensions, ")
    color = re.sub(r'(LOOM_FORCE_INLINE \w+ ' + name + r')\(dimensions, ',
                   r'\1(ColorGeometry dimensions, ', color)
color = color.replace("image_width", "dimensions.width").replace("image_height", "dimensions.height")
color = color.replace("void run(", '''template<unsigned image_color_space, unsigned horizontal0, unsigned vertical0,
         unsigned horizontal1, unsigned vertical1, unsigned horizontal2, unsigned vertical2>
static LOOM_FORCE_INLINE void color_run(''')
color = color.replace("Image image, const unsigned* tile, unsigned* cache) {", "Image image, const unsigned* tile, unsigned* cache) {\n  ColorGeometry dimensions{image.width, image.height};")
color = '''struct ColorGeometry {
  // Per-image encoded width, independent of the sampling specialization.
  unsigned width;
  // Per-image encoded height, independent of the sampling specialization.
  unsigned height;
};
''' + color
color += '''
static loom::kernel::configuration configure_color(const unsigned* color_schedule) {
  unsigned count = color_schedule[0];
  loom::assume(count <= 1048576u);
  return {{count, 1, 1}, {256, 1, 1}};
}

[[loom::kernel(configure_color)]]
void jpeg_color(const unsigned char* components, unsigned char* rgb,
                const Image* headers, const unsigned* color_tiles, const unsigned* validity) {
  const unsigned* tile = color_tiles + loom::kernel::workgroup::id.x * 3;
  unsigned ordinal = tile[0];
  if (validity[ordinal] != 0) return;
  Image image = headers[ordinal];
  // At most two reduced planes are live. The largest supported halo is
  // 64 columns by ten rows; mutually exclusive sampling cases reuse it.
  auto* cache = loom::buffer::alloca<unsigned, loom::memory_space::workgroup, 16>(1280);
'''
for kind, parameters in enumerate(((1, 1, 1, 1, 1, 1, 1), (2, 1, 1, 1, 1, 1, 1),
                                   (3, 1, 1, 1, 1, 1, 1), (3, 1, 1, 2, 1, 2, 1),
                                   (3, 1, 1, 2, 2, 2, 2), (3, 1, 1, 1, 2, 1, 2),
                                   (3, 1, 1, 4, 1, 4, 1), (3, 1, 1, 4, 2, 4, 2)), 1):
    color += f'''  if (image.color_kind == {kind}) {{
    color_run<{', '.join(str(value) for value in parameters)}>(components, rgb, image, tile, cache);
  }}
'''
color += "}\n\n"
source = source[:color_begin] + color + source[color_end:]

source = source.replace("const unsigned* headers", "const Image* headers")
source = source.replace("image * (tile_count * 1024 + 4)", "headers[image].compressed_word_offset")
source = source.replace("image * (tile_count * 1024 + entropy_padding_words)", "headers[image].entropy_word_offset")
for index, field in enumerate(("compressed_bytes", "entropy_start", "block_count", "component_word_offset")):
    source = source.replace("headers[image * 4" + (" + " + str(index) if index else "") + "]",
                            "headers[image]." + field)
source = source.replace("image * tile_count + tile", "headers[image].tile_offset + tile")
source = source.replace("tile < tile_count", "tile < headers[image].tile_count")


def tile_kernel(text):
    marker = "  unsigned tile = loom::kernel::workgroup::id.x;"
    assert text.count(marker) == 1
    return text.replace(marker, marker + "\n  if (tile >= headers[image].tile_count) return;")


for name in ("jpeg_classify_bytes", "jpeg_compact_bytes"):
    source = change_function(source, name, tile_kernel)
source = source.replace("jobs + (segment[2] + job) * 3", "jobs + (segment[2] + job) * 4")
source = source.replace("    output[2] = job;", "    output[2] = job;\n    output[3] = image;")
source += '''
// One status belongs to one stable input ordinal; input failures do not become
// device failures and no later image consumer reads a failed image's pixels.
[[loom::kernel(configure_images)]]
void jpeg_validate(const unsigned* segments, const unsigned* errors,
                   const unsigned* status, unsigned* validity) {
  unsigned image = loom::kernel::workgroup::id.x;
  const unsigned* segment = segments + image * 8;
  unsigned first = segment[2] * (output_partitions + 1) + image;
  unsigned count = segment[3] * (output_partitions + 1) + 1;
  unsigned error = 0;
  for (unsigned index = loom::kernel::workitem::id.x; index < count; index += 256) {
    unsigned value = status[first + index];
    if (value > error) error = value;
  }
  error = loom::kernel::workgroup::reduce::maxui(error);
  if (loom::kernel::workitem::id.x == 0) validity[image] = errors[image * 4] | (error << 8);
}
'''
(directory / "mixed_pipeline.cxx").write_text(source)
manifest = {"baseline_sha256": identity["source_sha256"],
            "files": {name: hashlib.sha256((directory / name).read_bytes()).hexdigest()
                      for name in ("mixed_pipeline.cxx", "mixed_image.h", "mixed_cursor.h")}}
(notes / "mixed-source.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({"directory": str(directory), "source_bytes": len(source)}))
