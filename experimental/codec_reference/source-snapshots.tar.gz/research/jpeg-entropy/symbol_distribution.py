"""Count exact JPEG symbol/window lengths without treating model work as timing."""
from collections import Counter
import hashlib
import json
from pathlib import Path

from device_fixture import input_bytes
from sequential import Huffman, decode, parse

notes = Path(__file__).resolve().parent
name = '012mp-bus.jpg.r0.jpg'
data = input_bytes(name)
frame = parse(data)
kinds = {}
for scan in frame.scans:
    for block in scan.blocks:
        kinds[id(block.dc)] = 'dc'
        kinds[id(block.ac)] = 'ac'
counts = Counter()
original = Huffman.decode


def counted(table, reader):
    before = reader.position
    symbol = original(table, reader)
    kind = kinds[id(table)]
    category = symbol if kind == 'dc' else symbol & 15
    counts[kind, reader.position - before, category] += 1
    return symbol


Huffman.decode = counted
planes, traces = decode(frame)
symbols = sum(counts.values())
assert symbols == 4637859
result = {'input_sha256': hashlib.sha256(data).hexdigest(),
          'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'scope': 'Exact sequential symbol distribution for the primary image; speculative-prefix distribution and GPU cost are not inferred.',
          'symbols': symbols, 'complete_window_fraction': {}, 'huffman_window_fraction': {},
          'rows': [{'kind': kind, 'huffman_bits': length, 'amplitude_bits': category, 'count': count}
                   for (kind, length, category), count in sorted(counts.items())]}
for width in (8, 9, 10, 11, 12, 16):
    result['complete_window_fraction'][width] = sum(count for (kind, length, category), count in counts.items()
                                                   if length + category <= width) / symbols
    result['huffman_window_fraction'][width] = sum(count for (kind, length, category), count in counts.items()
                                                 if length <= width) / symbols
(notes / 'symbol-distribution.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'rows'}), flush=True)
