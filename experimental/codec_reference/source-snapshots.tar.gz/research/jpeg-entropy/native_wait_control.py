"""Construct an exact native wait counterfactual; never used by production."""
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
tag = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['codec-jpeg-unsigned-opt'])
compiler = tag / 'loom/src/loom/tools/loom-compile/loom-compile'
objdump = '/home/ben/tools/llvm/latest/bin/llvm-objdump'
library = root / 'entropy-noalias.loombc'
fixture = root / 'noalias-batch16-1024'
entries = []
commands = []
for entry, argument_text in re.findall(r'kernel.launch @(\w+)\(([^)]+)\)', (fixture / 'summary.loom').read_text()):
    path = root / (entry + '-wait-control.hsaco')
    report_path = root / (entry + '-wait-control-report.json')
    command = [str(compiler), str(library), '--root=' + entry, '--target=amdgpu:gfx1151',
               '--config-file=' + str(fixture / 'config.json'), '--output=' + str(path),
               '--compile-report=details', '--compile-report-output=' + str(report_path)]
    subprocess.run(command, check=True)
    commands.append(command)
    report = json.loads(report_path.read_text())
    entries.append({'entry': entry, 'artifact': path.name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                    'arguments': re.findall(r'%(\w+)', argument_text), 'workload': report['workload'],
                    'local_bytes': report['memory']['local_bytes']})
    if entry != 'jpeg_reconstruct':
        continue
    assert entries[-1]['sha256'] == json.loads((notes / 'device-output-noalias.json').read_text())['native_sha256']
    waits = [row for row in report['wait_action_rows']['rows'] if row['counter'] == 'vmem_store']
    assert len(waits) == 21
    assert sum(row['reason'] == 'amdgpu.program_exit' for row in waits) == 1
    assert sum(row['reason'] == 'amdgpu.memory_effect' for row in waits) == 20
    assembly = subprocess.check_output([objdump, '-d', '--mcpu=gfx1151', str(path)], text=True)
    instructions = [(int(address, 16), operation.strip(), words.split()) for operation, address, words in
                    re.findall(r'^\s+(.+?)\s*//\s*([0-9A-Fa-f]+):\s*([0-9A-Fa-f ]+)', assembly, re.M)]
    exits = [index for index, row in enumerate(instructions) if row[1] == 's_endpgm']
    assert len(exits) == 1
    wait_indices = [index for index, row in enumerate(instructions) if row[1] == 's_waitcnt_vscnt null, 0x0']
    assert len(wait_indices) == 21
    exit_wait = max(index for index in wait_indices if index < exits[0])
    assert all(row[1].startswith(('s_waitcnt', 's_nop', 's_endpgm'))
               for row in instructions[exit_wait:exits[0] + 1])
    before = path.read_bytes()
    data = bytearray(before)
    section_offset = struct.unpack_from('<Q', data, 40)[0]
    section_size, section_count, strings_index = struct.unpack_from('<HHH', data, 58)
    sections = [struct.unpack_from('<IIQQQQIIQQ', data, section_offset + index * section_size)
                for index in range(section_count)]
    strings = sections[strings_index]
    names = data[strings[4]:strings[4] + strings[5]]
    text = next(section for section in sections if names[section[0]:].split(b'\0', 1)[0] == b'.text')
    changes = []
    for index in wait_indices:
        if index == exit_wait:
            continue
        address, operation, words = instructions[index]
        assert words == ['BC7C0000']
        offset = text[4] + address - text[3]
        assert data[offset:offset + 4] == bytes.fromhex('00007cbc')
        data[offset:offset + 4] = bytes.fromhex('000080bf')
        changes.append({'address': address, 'file_offset': offset, 'before': 'BC7C0000', 'after': 'BF800000'})
    assert len(changes) == 20 and sum(a != b for a, b in zip(before, data)) == 40
    candidate = root / 'jpeg_reconstruct-wait-nop.hsaco'
    candidate.write_bytes(data)
    after_assembly = subprocess.check_output([objdump, '-d', '--mcpu=gfx1151', str(candidate)], text=True)
    assert after_assembly.count('s_waitcnt_vscnt') == 1
    patch = {'original_sha256': hashlib.sha256(before).hexdigest(), 'candidate_sha256': hashlib.sha256(data).hexdigest(),
             'candidate': candidate.name, 'changes': changes, 'preserved_exit_wait': instructions[exit_wait][0],
             'wait_report_rows': waits,
             'proof_scope': 'This invocation uses distinct immutable input allocations and distinct write-only pixel/status allocations. No pixel/status load, atomic, cross-workitem publication, or other global reader depends on these stores inside the kernel. LDS waits and final VMEM-store completion are retained. This is a workload-specific counterfactual, not a generic compiler repair.'}
record = {'commands': commands, 'entries': entries, 'patch': patch,
          'fixture': str(fixture.relative_to(root)), 'compiler_sha256': hashlib.sha256(compiler.read_bytes()).hexdigest(),
          'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(root / 'native-wait-control.json').write_text(json.dumps(record, indent=2) + '\n')
(notes / 'native-wait-control.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'entries': len(entries), 'changed_instruction_words': len(patch['changes']),
                  'preserved_exit_wait': patch['preserved_exit_wait']}), flush=True)
