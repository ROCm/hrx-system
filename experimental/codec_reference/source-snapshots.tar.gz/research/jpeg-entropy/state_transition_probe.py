"""Qualify retained and discarded totals over the existing arbitrary-state corpus."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
source = (notes / 'short_transition_probe.cxx').read_text()
source = source.replace('device_entropy_cursor_short.h', 'device_entropy_cursor_state.h')
source = source.replace('  Cursor right = left;', '''  Cursor right = left;
  Cursor phase = left;
  Cursor initial = left;''')
source = source.replace('    Symbol candidate = advance_symbol(entropy, tables, blocks, limit, right);',
    '''    Cursor candidate = advance_state<true>(entropy, tables, blocks, limit, right);
    phase = advance_state<false>(entropy, tables, blocks, limit, phase);''')
source = source.replace('    right = candidate.cursor;', '    right = candidate;')
old = '''    result |= static_cast<unsigned>(original.index != candidate.index) << 13;
    result |= static_cast<unsigned>(original.value != candidate.value) << 14;'''
new = '''    Cursor expected_phase = left;
    expected_phase.blocks = initial.blocks;
    expected_phase.predictors = initial.predictors;
    result |= difference(expected_phase, phase) << 16;'''
assert source.count(old) == 1
source = source.replace(old, new)
(notes / 'state_transition_probe.cxx').write_text(source)
original = root / 'short-probe'
directory = root / 'state-probe'
directory.mkdir(exist_ok=True)
paths = {}
def relocate(match):
    path = (original / match[1]).resolve()
    relative = os.path.relpath(path, directory)
    paths[str(path.relative_to(root))] = hashlib.sha256(path.read_bytes()).hexdigest()
    return 'check.file.read.npy path("' + relative + '")'
scenario = re.sub(r'check.file.read.npy path\("([^"]+)"\)', relocate, (original / 'check.loom').read_text())
(directory / 'check.loom').write_text(scenario)
(directory / 'config.json').write_bytes((original / 'config.json').read_bytes())
tag = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['codec-jpeg-rebased-tools'])
commands = [[str(tag / 'loom/src/loom/tools/loom-import-cxx/loom-import-cxx'),
             str(notes / 'state_transition_probe.cxx'), '--output=' + str(directory / 'library.loom')],
            [str(tag / 'loom/src/loom/tools/loom-link/loom-link'), str(directory / 'library.loom'),
             str(directory / 'check.loom'), '--to=bc', '--output=' + str(directory / 'check.loombc')]]
for command in commands:
    subprocess.run(command, check=True)
paths.update({str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
              for path in directory.iterdir() if path.is_file()})
record = {'count': 32768, 'commands': commands, 'files': paths,
          'scope': 'Every state field matches the qualified slow transition. Phase-only calls preserve incoming block/DC totals. Existing arbitrary-offset, phase, extent/read-cap and 1-8 transition corpus; no new large input.',
          'sources': {name: hashlib.sha256((notes / name).read_bytes()).hexdigest() for name in
                      ('state_transition_probe.py', 'state_transition_probe.cxx', 'device_entropy_cursor_state.h')}}
(notes / 'state-probe-stage.json').write_text(json.dumps(record, indent=2) + '\n')
print('32768 state probes ready', flush=True)
