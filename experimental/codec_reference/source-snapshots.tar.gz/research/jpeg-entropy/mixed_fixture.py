"""Compose independent per-image oracles into a mixed original-byte cohort."""

import argparse
import array
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess

from byte_compaction_model import model, reference
from connected_fixture import header_geometry
from device_fixture import input_bytes, read_words


parser = argparse.ArgumentParser()
parser.add_argument("--cohort", choices=("small", "primary"), default="small")
parser.add_argument("--invalid-index", type=int)
parser.add_argument("--directory", default="mixed-current")
parser.add_argument("--receipt")
arguments = parser.parse_args()
notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / "device-active.json").read_text())["directory"])
directory = root / arguments.directory
tags = json.loads(os.environ["BUREAU_TAG_ROOTS"])
oracle = Path(tags["codec-jpeg-float-reference"]) / "experimental/codec_reference/research/jpeg-entropy/float_reference"
linker = Path(tags["codec-jpeg-rebased-tools"]) / "loom/src/loom/tools/loom-link/loom-link"
if arguments.cohort == "primary":
    names = ["012mp-bus.jpg.r0.jpg", "006mp-cathedral.jpg.r0.jpg",
             "synthetic-1024.jpg.r0.jpg", "synthetic-256.jpg.r0.jpg"] * 4
else:
    names = ["existing_exif_fixture", "ycbcr_444", "ycbcr_422", "ycbcr_420",
             "ycbcr_440", "ycbcr_411", "ycbcr_410", "ycbcr_444_extended_quantization",
             "rgb_sequential", "grayscale", "dense-periodic", "mcu-phase",
             "grayscale", "rgb_sequential", "ycbcr_420", "existing_exif_fixture"]
if arguments.invalid_index is not None:
    assert 0 <= arguments.invalid_index < len(names)
cases = {}
for group in ("small", "large"):
    base = root / ("twolevel-" + group)
    for case in json.loads((base / "fixtures.json").read_text())["cases"]:
        if case["scan"] == 0 and case["chunk_bytes"] == 1024:
            cases[case["name"]] = (base, case)
order = [line.split()[0] for line in (root / "connected-main-requalified/bindings.txt").read_text().splitlines()]
order.extend(["color_tiles", "color_schedule", "validity"])
values = {name: array.array("I") for name in order if name != "rgb"}
values["rgb"] = bytearray()
assert array.array("I").itemsize == 4 and struct.pack("=I", 1) == struct.pack("<I", 1)
inputs = {"compressed", "headers", "tables", "blocks", "geometry", "quantization", "zigzag", "color_tiles", "color_schedule"}
capacity = 0
first_job = 0
tile_base = 0
images = []
cached = {}


def numpy_write(filename, data, element_bytes):
    header = repr({"descr": "|i1" if element_bytes == 1 else "<i4",
                   "fortran_order": False, "shape": (len(data),)}).encode()
    header += b" " * ((64 - (10 + len(header) + 1) % 64) % 64) + b"\n"
    with filename.open("wb") as stream:
        stream.write(b"\x93NUMPY\x01\x00" + struct.pack("<H", len(header)) + header)
        if isinstance(data, array.array): data.tofile(stream)
        else: stream.write(data)


def append_words(name, words):
    offset = len(values[name])
    values[name].extend(words)
    return offset


for ordinal, name in enumerate(names):
    base, case = cases[name]
    assert case["segments"] == 1
    encoded = input_bytes(name)
    assert hashlib.sha256(encoded).hexdigest() == case["input_sha256"]
    start, geometry = header_geometry(encoded)
    configuration = json.loads((base / (case["key"] + ".json")).read_text())["jpeg"]
    components = configuration["components"]
    assert components in (1, 3) and configuration["output_partitions"] == 4
    paths = {key: (base / relative).resolve() for key, relative in re.findall(
        r'%([a-z_]+) = check.file.read.npy path\("([^"]+)"\)', (base / (case["key"] + ".loom")).read_text())}
    if name not in cached:
        references = directory / ("reference-" + str(len(cached)))
        references.mkdir(exist_ok=True)
        input_file = references / "input.jpg"
        input_file.write_bytes(encoded)
        result = subprocess.run([str(oracle), str(input_file), str(references)], capture_output=True, text=True)
        assert result.returncode == 0, result.stdout + result.stderr
        numerical = [json.loads(line) for line in result.stdout.splitlines() if line.startswith("{")]
        cached[name] = (references, numerical)
    references, numerical = cached[name]
    color_space = numerical[-1]["color_space"]
    assert (numerical[-1]["width"], numerical[-1]["height"]) == (geometry["width"], geometry["height"])
    malformed = ordinal == arguments.invalid_index
    if malformed:
        assert encoded[-2:] == b"\xff\xd9"
        encoded = encoded[:-1] + b"\xd8"
    valid, raw, records, prefixes = model(encoded, start)
    assert (valid, raw) == reference(encoded, start)
    assert valid != malformed
    count = (len(raw) + 1023) // 1024
    assert count == (0 if malformed else case["jobs"])
    tiles = (len(encoded) + 4095) // 4096
    assert 1 <= tiles <= 1024
    capacity += tiles * 4
    compressed_words = array.array("I")
    compressed_words.frombytes(encoded + bytes(tiles * 4096 + 16 - len(encoded)))
    compressed_base = append_words("compressed", compressed_words)
    raw_padded = raw + bytes((-len(raw)) % 4 + 8)
    entropy_base = append_words("entropy", struct.unpack(">" + "I" * (len(raw_padded) // 4), raw_padded))
    values["entropy"].extend([17] * (tiles * 1024 + 32 + 8 - len(raw_padded) // 4))
    table_base = append_words("tables", read_words(paths["tables"]))
    geometry_base = append_words("geometry", read_words(paths["geometry"]))
    quantization_base = append_words("quantization", read_words(paths["quantization"]))
    append_words("blocks", [configuration["layout0"], configuration["layout1"],
                            configuration["layout2"], configuration["blocks"]])
    zigzag = read_words(paths["zigzag"])
    if values["zigzag"]: assert tuple(values["zigzag"]) == zigzag
    else: append_words("zigzag", zigzag)
    pixel_base = len(values["pixels"])
    if malformed:
        values["pixels"].extend([17] * geometry["pixel_words"])
    else:
        values["pixels"].frombytes((references / "pixels.raw").read_bytes())
    assert len(values["pixels"]) - pixel_base == geometry["pixel_words"]
    values["pixels"].extend([17] * 8)
    rgb_base = len(values["rgb"])
    rgb_count = geometry["width"] * geometry["height"] * 3
    values["rgb"].extend(bytes([17]) * rgb_count if malformed else (references / "rgb.raw").read_bytes())
    assert len(values["rgb"]) - rgb_base == rgb_count
    # Keep the following image's packed stores naturally aligned even for odd widths.
    values["rgb"].extend(bytes([17]) * (32 + (-rgb_count) % 4))
    horizontal = max(h for h, v in geometry["sampling"])
    vertical = max(v for h, v in geometry["sampling"])
    factors = [(horizontal // h, vertical // v) for h, v in geometry["sampling"]]
    assert all(horizontal % h == 0 and vertical % v == 0 for h, v in geometry["sampling"])
    assert factors[0] == (1, 1)
    if color_space == 1: kind = 1
    elif color_space == 2:
        assert factors == [(1, 1)] * 3
        kind = 2
    else:
        assert color_space == 3 and factors[1] == factors[2]
        kind = {(1, 1): 3, (2, 1): 4, (2, 2): 5, (1, 2): 6, (4, 1): 7, (4, 2): 8}[factors[1]]
    plane_bytes = [((geometry["width"] + h * 8 - 1) // (h * 8)) *
                   ((geometry["height"] + v * 8 - 1) // (v * 8)) * 64 for h, v in factors]
    header = [len(encoded), start, geometry["blocks"], pixel_base, compressed_base,
              entropy_base, tile_base, tiles, table_base, geometry_base, quantization_base,
              configuration["mcu_width"], geometry["width"], geometry["height"], rgb_base,
              plane_bytes[0], plane_bytes[1] if components == 3 else 0, kind]
    append_words("headers", header)
    append_words("segments", [entropy_base, len(raw) * 8, first_job, count,
                              geometry["blocks"], first_job + ordinal, 0, pixel_base])
    append_words("jobs", (value for job in range(count)
                          for value in (entropy_base, len(raw) * 8, job, ordinal)))
    append_words("records", (value for row in records for value in row))
    append_words("prefixes", [0] * tiles if malformed else prefixes)
    append_words("errors", [2 if malformed else 0, min(row[1] for row in records),
                            min(row[2] for row in records), len(raw)])
    if malformed:
        append_words("suffixes", [0] * 8)
        append_words("ranges", [0xffffffff] + [0] * 7)
        append_words("intervals", [0] * 8)
        append_words("status", [3])
    else:
        for key in ("expected", "bridges", "suffixes", "ranges", "points", "intervals", "status"):
            words = read_words(paths[key])
            stride = 4 if components == 1 and key in ("bridges", "suffixes", "ranges", "points") else 8
            if stride == 4:
                words = [value for begin in range(0, len(words), stride)
                         for value in (*words[begin:begin + stride], 0, 0, 0, 0)]
            append_words(key, words)
    append_words("validity", [770 if malformed else 0])
    for y in range(0, geometry["height"], 16):
        for x in range(0, geometry["width"], 64):
            append_words("color_tiles", [ordinal, x, y])
    images.append({"ordinal": ordinal, "name": name, "input_sha256": hashlib.sha256(encoded).hexdigest(),
                   "malformed_terminal_marker": malformed, "header": header, "jobs": count,
                   "numerical_reference": numerical, "source_case": case["key"]})
    first_job += count
    tile_base += tiles

intervals = first_job * 5 + len(names)
append_words("schedule", [first_job, (first_job + 127) // 128, 1, 1,
                          (intervals + 32 * len(names) - 1) // (32 * len(names)), len(names), 1, intervals])
append_words("color_schedule", [len(values["color_tiles"]) // 3])
padded = {"jobs": capacity * 4, "expected": capacity * 8, "bridges": capacity * 8,
          "suffixes": (capacity + len(names)) * 8, "ranges": (capacity + len(names)) * 8,
          "points": capacity * 3 * 8, "intervals": (capacity * 5 + len(names)) * 8,
          "status": capacity * 5 + len(names)}
for key, size in padded.items():
    assert len(values[key]) <= size, (key, len(values[key]), size)
    values[key].extend([17] * (size - len(values[key])))
for key in values:
    if key not in ("pixels", "rgb", "entropy"):
        values[key].extend([17] * 8)
bindings = []
for key in order:
    width = 1 if key == "rgb" else 4
    numpy_write(directory / (key + ".npy"), values[key], width)
    bindings.append(f"{key} {int(key in inputs)} {width} {len(values[key])} {key}.npy")
(directory / "bindings.txt").write_text("\n".join(bindings) + "\n")
configuration = {"jpeg": {"chunk_bytes": 1024, "output_partitions": 4, "segments": len(names)},
                 "input": {"tiles": 1024, "entropy_padding_words": 32}}
(directory / "config.json").write_text(json.dumps(configuration, indent=2) + "\n")
program = (root / "connected-main-requalified/summary.loom").read_text().split("check.scenario")[0]
program = "\n".join(
    line.replace("%schedule: buffer)", "%schedule: buffer, %color_tiles: buffer, %color_schedule: buffer, %validity: buffer)")
    if line.startswith(("func.def @fixture_values(", "command.program.def public @jpeg_decode(", "command.program.def public @jpeg_batch("))
    else line for line in program.splitlines()) + "\n"
program = program.replace("%headers, %schedule)", "%headers, %schedule, %color_tiles, %color_schedule, %validity)")
batch_types = " : (" + ", ".join(["buffer"] * (len(order) - 3)) + ")"
program = program.replace(batch_types, " : (" + ", ".join(["buffer"] * len(order)) + ")")
for name in ("jpeg_speculate", "jpeg_bridge", "jpeg_reconstruct"):
    program = re.sub(r'(kernel.decl @' + name + r'[^\n]*launch\([^\n]*)\)', r'\1, %headers: buffer)', program)
    pattern = r'(kernel.launch @' + name + r'[^\n]*?)(\) : \[buffer, offset\]\()([^\n]*)(\))'
    program = re.sub(pattern, lambda match: match[1] + ", %headers" + match[2] + match[3] + ", buffer" + match[4], program)
program = re.sub(r'kernel.decl @jpeg_color[^\n]*', '''kernel.decl @jpeg_validate() launch(%segments: buffer, %errors: buffer, %status: buffer, %validity: buffer)
kernel.decl @jpeg_color(%launch_schedule: buffer, %launch_offset: offset) launch(%pixels: buffer, %rgb: buffer, %headers: buffer, %color_tiles: buffer, %validity: buffer)''', program)
program = re.sub(r'    kernel.launch @jpeg_color[^\n]*', '''    kernel.launch @jpeg_validate(%segments, %errors, %status, %validity) : (buffer, buffer, buffer, buffer)
    kernel.launch @jpeg_color[%color_schedule, %schedule_offset](%pixels, %rgb, %headers, %color_tiles, %validity) : [buffer, offset](buffer, buffer, buffer, buffer, buffer)''', program)
(directory / "summary.loom").write_text(program)
subprocess.run([str(linker), str(directory / "summary.loom"), str(directory / "library.loom"),
                "--to=bc", "--output=" + str(directory / "summary.loombc")], check=True)
files = {name + ".npy": hashlib.file_digest((directory / (name + ".npy")).open("rb"), "sha256").hexdigest() for name in order}
for name in ("bindings.txt", "config.json", "summary.loom", "library.loom", "summary.loombc", "mixed_pipeline.cxx", "mixed_image.h", "mixed_cursor.h"):
    files[name] = hashlib.file_digest((directory / name).open("rb"), "sha256").hexdigest()
stage = {"cohort": arguments.cohort, "invalid_index": arguments.invalid_index, "images": images,
         "files": files, "source": json.loads((notes / "mixed-source.json").read_text()),
         "bytes": {key: len(values[key]) * (1 if key == "rgb" else 4) for key in order},
         "reference_binary_sha256": hashlib.file_digest(oracle.open("rb"), "sha256").hexdigest(),
         "scope": "Original JPEG bytes, header-derived metadata, and header-only color tiles are inputs. All body counts and outputs are oracle expectations only. Single-scan restart-free experiment; no production numerical policy selected."}
(directory / "stage.json").write_text(json.dumps(stage, indent=2) + "\n")
receipt = arguments.receipt or "mixed-" + arguments.cohort + ("-invalid" if arguments.invalid_index is not None else "") + "-stage.json"
(notes / receipt).write_text(json.dumps(stage, indent=2) + "\n")
# The complete expected planes are now in the bounded reusable fixture. These
# uniquely owned oracle outputs are reproducible from the pinned input/tool.
for references, numerical in cached.values():
    for name in ("input.jpg", "pixels.raw", "rgb.raw", "cosine.rgb", "islow.rgb", "float.rgb", "ifast.rgb"):
        (references / name).unlink()
print(json.dumps({"cohort": arguments.cohort, "images": len(images), "jobs": first_job,
                  "bindings": len(order), "fixture_bytes": sum(stage["bytes"].values())}), flush=True)
