"""Build the bounded finite caller with GPU access checks, restoring all overlays."""
import hashlib
import json
from pathlib import Path
import subprocess

notes = Path(__file__).resolve().parent
assert not subprocess.check_output(["git", "status", "--porcelain"], text=True)
build = Path("loom/src/loom/tooling/target/amdgpu/serve/BUILD.bazel")
finite = Path("loom/src/loom/serve/service/finite/model.c")
original = build.read_bytes()
original_finite = finite.read_text()
names = ["native_upload.c", "native_upload.h", "device_upload.h",
         "native_header.c", "native_header.h", "native_metadata.c", "native_metadata.h",
         "native_color.c", "native_color.h", "projector_upload_probe.cc"]
files = {name: (notes / name).read_bytes() for name in names}
for name in names:
    assert not (build.parent / name).exists(), name
target = '''
loom_cc_binary(
    name = "codec_projector_upload_probe",
    testonly = True,
    srcs = [''' + ", ".join(json.dumps(name) for name in names) + '''],
    deps = [
        ":test_compiler", ":test_device",
        "//loom/src/loom/serve/media:image",
        "//loom/src/loom/serve/media:image_request",
        "//loom/src/loom/serve/runtime/device",
        "//loom/src/loom/serve/runtime/execution",
        "//loom/src/loom/serve/runtime/host",
        "//loom/src/loom/serve/runtime/host:wake",
        "//loom/src/loom/serve/runtime/parameter:residency",
        "//loom/src/loom/serve/service/finite:model",
        "//loom/src/loom/serve/service/finite:result",
        "//loom/src/loom/serve/testing:compiler",
        "//loom/src/loom/serve/testing:device",
        "//loom/src/loom/serve/testing:model",
        "//runtime/src/iree/base",
        "//runtime/src/iree/base/internal:base64",
        "//runtime/src/iree/base/tooling:flags",
        "//runtime/src/iree/hal",
        "//runtime/src/iree/testing:gtest",
        "//runtime/src/iree/testing:gtest_main",
        "//runtime/src/iree/vm",
    ],
)
'''
before = '''  return loom_serve_jit_create(
      loom_serve_device_handle(model->owner),
      loom_serve_device_dispatch_queue(model->owner),
      loom_serve_device_host(model->owner), &load->options.sources, NULL,
      &model->compilation, host_allocator, &model->jit);'''
after = '''  const loomc_sanitizer_options_t sanitizer = {
      .type = LOOMC_STRUCTURE_TYPE_SANITIZER_OPTIONS,
      .structure_size = sizeof(loomc_sanitizer_options_t),
      .checks = LOOMC_SANITIZER_CHECK_ACCESS};
  return loom_serve_jit_create(
      loom_serve_device_handle(model->owner),
      loom_serve_device_dispatch_queue(model->owner),
      loom_serve_device_host(model->owner), &load->options.sources, &sanitizer,
      &model->compilation, host_allocator, &model->jit);'''
assert original_finite.count(before) == 1
finite_overlay = original_finite.replace(before, after)
overlay = original + target.encode()
tag = "codec-jpeg-projector-upload"
command = ["bureau-bazel", "build", "--tag=" + tag, "--config=asan",
           "//loom/src/loom/tooling/target/amdgpu/serve:codec_projector_upload_probe"]
receipt = notes / "projector-upload-probe-build.json"
record = {"commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
          "tag": tag, "configuration": "asan", "gpu_checks": "access", "command": command,
          "restored": False, "sources": {name: hashlib.sha256(data).hexdigest() for name, data in files.items()},
          "build_original_sha256": hashlib.sha256(original).hexdigest(),
          "build_overlay_sha256": hashlib.sha256(overlay).hexdigest(),
          "finite_original_sha256": hashlib.sha256(original_finite.encode()).hexdigest(),
          "finite_overlay_sha256": hashlib.sha256(finite_overlay.encode()).hexdigest()}
receipt.write_text(json.dumps(record, indent=2) + "\n")
build.write_bytes(overlay)
finite.write_text(finite_overlay)
for name, data in files.items():
    (build.parent / name).write_bytes(data)
try:
    result = subprocess.run(command)
    record["build_returncode"] = result.returncode
finally:
    assert build.read_bytes() == overlay and finite.read_text() == finite_overlay
    for name, data in files.items():
        assert (build.parent / name).read_bytes() == data
    build.write_bytes(original)
    finite.write_text(original_finite)
    for name in files:
        (build.parent / name).unlink()
    record["restored"] = True
    receipt.write_text(json.dumps(record, indent=2) + "\n")
assert result.returncode == 0
assert not subprocess.check_output(["git", "status", "--porcelain"], text=True)
record["capture"] = json.loads(subprocess.check_output(["bureau-bazel", "tag", "inspect", tag, "--json"], text=True))
receipt.write_text(json.dumps(record, indent=2) + "\n")
