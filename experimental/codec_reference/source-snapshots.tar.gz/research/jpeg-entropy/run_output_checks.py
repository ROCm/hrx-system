"""Qualify a scratch decoder against both existing exact component corpora."""
import argparse
import hashlib
import json
from pathlib import Path
import shlex
import subprocess

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
parser = argparse.ArgumentParser()
parser.add_argument('variant')
parser.add_argument('--fixture-prefix', default='output')
parser.add_argument('--families', nargs='+', choices=('small','large'), default=['small','large'])
arguments = parser.parse_args()
variant = arguments.variant
library = root / ('entropy-' + variant + '.loombc')
digest = hashlib.sha256(library.read_bytes()).hexdigest()
subprocess.run(['scp', str(library), 'hrx-gorgon-4:' + str(library)], check=True)
script = '''import subprocess,sys
root,digest,variant,prefix,*families=sys.argv[1:]
for family in families:
 subprocess.run(['python3','-B',root+'/device_tables_qualify.py','--stage='+prefix+'-'+family+'-stage.json','--fixtures='+prefix+'-'+family+'/fixtures.json','--runner=iree-test-loom-unsigned','--runner-sha256=5e267978d7e937b1009f64a2e005913a4cc36c002b1f24eef44776cc4683a632','--library=entropy-'+variant+'.loombc','--library-sha256='+digest,'--output-directory='+variant+'-'+family+'-actual'],check=True)
'''
command = ['/home/benvanik/.dotfiles/bin/benchmark-lock', '--label=codec-jpeg-'+variant+'-check',
           '--', 'env', 'LD_LIBRARY_PATH=/opt/rocm/lib', 'python3', '-B', '-c', script,
           str(root), digest, variant, arguments.fixture_prefix, *arguments.families]
log = notes / ('gorgon4-' + variant + '-check-run.log')
with log.open('w') as stream:
    result = subprocess.run(['ssh', 'hrx-gorgon-4', shlex.join(command)], stdout=stream, stderr=subprocess.STDOUT)
status = subprocess.run(['ssh', 'hrx-gorgon-4', '/home/benvanik/.dotfiles/bin/benchmark-lock --status'], capture_output=True, text=True)
record = {'host': 'hrx-gorgon-4', 'command': command, 'returncode': result.returncode,
          'broker_status_returncode': status.returncode, 'broker_status_after': status.stdout + status.stderr}
(notes / ('gorgon4-' + variant + '-check-lease.json')).write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record), flush=True)
if result.returncode:
    print(log.read_text()[-6000:])
    raise SystemExit(result.returncode)
for family in arguments.families:
    output = notes / ('gorgon4-' + variant + '-' + family + '-qualified.json')
    subprocess.run(['scp', 'hrx-gorgon-4:' + str(root / (variant+'-'+family+'-actual') / 'qualified.json'), str(output)], check=True)
    print(family, len(json.loads(output.read_text())['rows']), 'exact cases', flush=True)
