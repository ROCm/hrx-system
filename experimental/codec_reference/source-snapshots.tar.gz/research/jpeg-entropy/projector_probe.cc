// Bounded numerical observation through production media and finite-model APIs.
#include <array>
#include <atomic>
#include <condition_variable>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <mutex>
#include <string>
#include <vector>

#include "iree/base/internal/base64.h"
#include "iree/base/tooling/flags.h"
#include "iree/testing/gtest.h"
#include "iree/testing/status_matchers.h"
#include "iree/vm/buffer.h"
#include "loom/serve/media/image_request.h"
#include "loom/serve/runtime/device/device.h"
#include "loom/serve/runtime/host/wake.h"
#include "loom/serve/runtime/parameter/residency.h"
#include "loom/serve/service/finite/model.h"
#include "loom/serve/service/finite/result.h"
#include "loom/serve/testing/compiler.h"
#include "loom/serve/testing/device.h"
#include "loom/serve/testing/model.h"

IREE_FLAG(string, jpeg_fixture, "", "Pinned model deployment and lossless decoder controls.");
IREE_FLAG(int32_t, image_width, 0, "Expected source display width.");
IREE_FLAG(int32_t, image_height, 0, "Expected source display height.");
IREE_FLAG(int32_t, target_width, 0, "Width selected by the pinned chat geometry policy.");
IREE_FLAG(int32_t, target_height, 0, "Height selected by the pinned chat geometry policy.");

namespace {
class ProjectorProbe : public ::testing::Test {
 protected:
  void SetUp() override {
    directory_ = FLAG_jpeg_fixture;
    std::filesystem::create_directory(directory_ / "observations");
    IREE_ASSERT_OK(document_.Load((directory_ / "deployment.json").string()));
    IREE_ASSERT_OK(loom_serve_test_host_create(16, allocator_, &host_));
    iree_hal_driver_t* driver = nullptr;
    IREE_ASSERT_OK(loom_serve_test_driver_create(host_, allocator_, &driver));
    const loom_serve_device_options_t device_options = {
        .driver = driver, .uri = IREE_SV("amdgpu"),
        .backing = LOOM_SERVE_DEVICE_BACKING_FIXED};
    auto status = loom_serve_device_group_allocate(host_, 1, &device_options, allocator_, &group_);
    iree_hal_driver_release(driver);
    IREE_ASSERT_OK(status);
    device_ = loom_serve_device_group_at(group_, 0);
    auto sources = document_.value().sources;
    const auto& image = document_.value().text.image;
    sources.prepare = image.prepare;
    sources.control = image.control;
    const loom_serve_finite_model_options_t options = {
        .sources = sources, .asset_directory = image.assets,
        .options = image.options, .specialization_cache = image.specialization_cache};
    IREE_ASSERT_OK(loom_serve_finite_model_allocate(device_, &options, allocator_, &model_));
    loom_serve_finite_model_set_observer(model_, {Wake, this});
  }

  void TearDown() override {
    if (batch_pending_) {
      IREE_EXPECT_OK(Resolve(true));
      loom_serve_finite_model_release_batch(model_);
    }
    IREE_EXPECT_OK(loom_serve_finite_model_free(model_));
    loom_serve_finite_snapshot_release(snapshot_);
    loom_serve_finite_result_release(result_);
    iree_vm_buffer_release(prepared_.bytes);
    iree_vm_buffer_release(packet_);
    loom_serve_media_image_input_deinitialize(&image_);
    if (device_) IREE_EXPECT_OK(loom_serve_test_device_trim_and_drain(device_, 0));
    IREE_EXPECT_OK(loom_serve_device_group_free(group_));
    loom_serve_host_release(host_);
  }

  static void Wake(void* self) {
    auto* test = static_cast<ProjectorProbe*>(self);
    std::lock_guard<std::mutex> lock(test->mutex_);
    ++test->wakes_;
    test->condition_.notify_all();
  }

  iree_status_t Resolve(bool cancel = false) {
    bool complete = false;
    while (!complete) {
      const auto previous = wakes_.load();
      IREE_RETURN_IF_ERROR(loom_serve_finite_model_advance_batch(model_, cancel, &complete));
      if (!complete) {
        std::unique_lock<std::mutex> lock(mutex_);
        condition_.wait(lock, [&] { return wakes_.load() != previous; });
      }
    }
    return iree_ok_status();
  }

  void Observe(const char* name, const char* filename, const char* mime) {
    SCOPED_TRACE(name);
    std::ifstream stream(directory_ / "inputs" / filename, std::ios::binary);
    ASSERT_TRUE(stream.good());
    const std::vector<uint8_t> encoded(std::istreambuf_iterator<char>(stream), {});
    std::string url = std::string("data:") + mime + ";base64,";
    const size_t prefix = url.size();
    const size_t length = iree_base64_encoded_size(encoded.size());
    url.resize(prefix + length);
    size_t written = 0;
    IREE_ASSERT_OK(iree_base64_encode(iree_make_const_byte_span(encoded.data(), encoded.size()),
        {url.data() + prefix, length}, &written));
    ASSERT_EQ(written, length);
    const loom_serve_media_image_limits_t limits = {67108864, 4096, 4096, 16777216};
    IREE_ASSERT_OK(loom_serve_media_image_input_initialize(
        iree_make_string_view(url.data(), url.size()), &limits, allocator_, &image_));
    ASSERT_GT(FLAG_image_width, 0);
    ASSERT_GT(FLAG_image_height, 0);
    ASSERT_EQ(image_.info.display_width, uint32_t(FLAG_image_width));
    ASSERT_EQ(image_.info.display_height, uint32_t(FLAG_image_height));
    ASSERT_GT(FLAG_target_width, 0);
    ASSERT_GT(FLAG_target_height, 0);
    ASSERT_LE(FLAG_target_width, 4096);
    ASSERT_LE(FLAG_target_height, 4096);
    ASSERT_EQ(FLAG_target_width % 32, 0);
    ASSERT_EQ(FLAG_target_height % 32, 0);
    const std::array<uint32_t, 2> geometry = {
        uint32_t(FLAG_target_width), uint32_t(FLAG_target_height)};
    const uint32_t output_rows = (geometry[0] / 32) * (geometry[1] / 32);
    const iree_host_size_t rows = output_rows;
    const loom_serve_media_image_request_t request = {
        .image = &image_,
        .metadata = iree_make_const_byte_span(geometry.data(), sizeof(geometry)),
        .output_rows = output_rows};
    iree_status_t image_status = iree_ok_status();
    auto status = loom_serve_media_image_request_create_batch(1, &request, allocator_, &packet_, &image_status);
    IREE_EXPECT_OK(image_status);
    IREE_ASSERT_OK(status);
    ASSERT_NE(packet_, nullptr);
    IREE_ASSERT_OK(loom_serve_finite_model_prepare_request(model_, packet_, &prepared_));
    iree_const_byte_span_t prepared_bytes;
    IREE_ASSERT_OK(iree_vm_buffer_map_read(prepared_.bytes, 0,
        iree_vm_buffer_length(prepared_.bytes), &prepared_bytes));
    {
      std::ofstream output(directory_ / "observations" / (std::string(name) + ".prepared"), std::ios::binary);
      output.write(reinterpret_cast<const char*>(prepared_bytes.data), prepared_bytes.data_length);
      ASSERT_TRUE(output.good());
    }
    IREE_ASSERT_OK(loom_serve_finite_model_prepare_batch(model_, 1, &prepared_, &rows));
    batch_pending_ = true;
    IREE_ASSERT_OK(Resolve());
    loom_serve_residency_admission_t admission;
    IREE_ASSERT_OK(loom_serve_residency_try_admit(loom_serve_finite_model_residency(model_), &admission));
    ASSERT_EQ(admission, LOOM_SERVE_RESIDENCY_ADMISSION_ACQUIRED);
    loom_serve_execution_frontier_t ready;
    batch_pending_ = false;
    IREE_ASSERT_OK(loom_serve_finite_model_submit(model_, &result_, &ready));
    IREE_ASSERT_OK(loom_serve_finite_result_download(result_, &snapshot_, &ready));
    for (size_t index = 0; index < IREE_ARRAYSIZE(ready.semaphores); ++index) {
      IREE_ASSERT_OK(iree_hal_semaphore_wait(ready.semaphores[index], ready.values[index],
          iree_infinite_timeout(), IREE_ASYNC_WAIT_FLAG_NONE));
    }
    ASSERT_EQ(loom_serve_finite_result_length(result_), rows * 5120 * sizeof(float));
    {
      std::ofstream output(directory_ / "observations" / (std::string(name) + ".features"), std::ios::binary);
      for (size_t row = 0; row < rows; ++row) {
        auto values = loom_serve_finite_snapshot_row(snapshot_, 0, row);
        ASSERT_EQ(values.data_length, 5120 * sizeof(float));
        output.write(reinterpret_cast<const char*>(values.data), values.data_length);
      }
      ASSERT_TRUE(output.good());
    }
    std::printf("{\"case\":\"%s\",\"prepared_bytes\":%zu,\"feature_bytes\":%zu}\n",
                name, prepared_bytes.data_length, rows * 5120 * sizeof(float));
    std::fflush(stdout);
    loom_serve_finite_model_complete(model_);
    loom_serve_finite_snapshot_release(snapshot_); snapshot_ = nullptr;
    loom_serve_finite_result_release(result_); result_ = nullptr;
    iree_vm_buffer_release(prepared_.bytes); prepared_ = {};
    iree_vm_buffer_release(packet_); packet_ = nullptr;
    loom_serve_media_image_input_deinitialize(&image_);
  }

  // Allocator retained through all native owners.
  iree_allocator_t allocator_ = iree_allocator_system();
  // Pinned source/input directory; observation files are temporary evidence.
  std::filesystem::path directory_;
  // Parsed production deployment retaining every source and asset locator.
  loom_serve::testing::ModelDocument document_;
  // Shared host workers retained through model destruction.
  loom_serve_host_t* host_ = nullptr;
  // Device group owns queues and allocation pools.
  loom_serve_device_group_t* group_ = nullptr;
  // Borrowed sole device of group_.
  loom_serve_device_t* device_ = nullptr;
  // Real vision component, independent of text weights.
  loom_serve_finite_model_t* model_ = nullptr;
  // Inspected transport input retained through decode and request completion.
  loom_serve_media_image_input_t image_ = {};
  // Decoded native packet retained through batch completion.
  iree_vm_buffer_t* packet_ = nullptr;
  // Source-owned resize plan and decoded input retained through completion.
  loom_serve_finite_prepared_t prepared_ = {};
  // Device output ownership, independent of model lifetime.
  loom_serve_finite_result_t* result_ = nullptr;
  // Explicit host observer, downloaded through the production feedback branch.
  loom_serve_finite_snapshot_t* snapshot_ = nullptr;
  // A prepared but unsubmitted cohort needs cancellation before destruction.
  bool batch_pending_ = false;
  // Synchronizes publication with the outer observer thread.
  std::mutex mutex_;
  // Notification for request compilation completion.
  std::condition_variable condition_;
  // Monotonic wake generation prevents a lost notification around advance.
  std::atomic<uint64_t> wakes_ = 0;
};

TEST_F(ProjectorProbe, DecoderControls) {
  ASSERT_NO_FATAL_FAILURE(Observe("jpeg", "original.jpg", "image/jpeg"));
  for (const char* name : {"islow", "loom-float32", "cosine", "float", "ifast"}) {
    ASSERT_NO_FATAL_FAILURE(Observe(name, (std::string(name) + ".pam").c_str(),
                                   "image/x-portable-arbitrarymap"));
  }
}
}  // namespace
