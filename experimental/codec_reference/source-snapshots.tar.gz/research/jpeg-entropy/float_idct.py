"""Independent cosine reference, explicit float32 model, and Loom authoring."""
import ctypes
import hashlib
import json
import math
from pathlib import Path
import random
import struct
from integer_idct import reconstruct as integer_reconstruct

notes = Path(__file__).resolve().parent
library = ctypes.CDLL('libm.so.6')
library.fmaf.argtypes = [ctypes.c_float, ctypes.c_float, ctypes.c_float]
library.fmaf.restype = ctypes.c_float


def f32(value):
    return struct.unpack('<f', struct.pack('<f', value))[0]


def constants(rounding):
    a, b, c, d, e, f = [math.sqrt(2) * math.cos(math.pi * i / 16)
                        for i in (1, 2, 3, 5, 6, 7)]
    return [rounding(value) for value in
            (e, -(b + e), b - e, c, -(c + d), -(c - d),
             f - c, -a - c, a + c - d - f, a + c + d - f,
             a + c - d + f, c + d - a - f)]


def transform(values, floating=True):
    rounding = f32 if floating else float
    fused = library.fmaf if floating else lambda a, b, c: a * b + c
    k = constants(rounding)
    add = lambda a, b: rounding(a + b)
    sub = lambda a, b: rounding(a - b)
    mul = lambda a, b: rounding(a * b)
    x = [rounding(value) for value in values]
    total, difference = add(x[0], x[4]), sub(x[0], x[4])
    rotation = mul(add(x[2], x[6]), k[0])
    two, six = fused(x[6], k[1], rotation), fused(x[2], k[2], rotation)
    even = [add(total, six), add(difference, two), sub(difference, two), sub(total, six)]
    rotation = mul(add(add(add(x[1], x[3]), x[5]), x[7]), k[3])
    seven_three = fused(add(x[7], x[3]), k[4], rotation)
    five_one = fused(add(x[5], x[1]), k[5], rotation)
    seven_one, five_three = mul(add(x[7], x[1]), k[6]), mul(add(x[5], x[3]), k[7])
    odd = [add(fused(x[1], k[8], seven_one), five_one),
           add(fused(x[3], k[9], five_three), seven_three),
           add(fused(x[5], k[10], five_three), five_one),
           add(fused(x[7], k[11], seven_one), seven_three)]
    return [add(a, b) for a, b in zip(even, odd)] + [
        sub(a, b) for a, b in reversed(tuple(zip(even, odd)))]


basis = [[1.0 if frequency == 0 else
          math.sqrt(2) * math.cos((2 * position + 1) * frequency * math.pi / 16)
          for frequency in range(8)] for position in range(8)]


def reference(values):
    # Direct matrix products use neither the factorization nor its constants.
    columns = [[math.fsum(values[row * 8 + column] * basis[y][row]
                         for row in range(8)) for column in range(8)] for y in range(8)]
    return [math.fsum(columns[y][column] * basis[x][column]
                      for column in range(8)) / 8 for y in range(8) for x in range(8)]


def reconstructed(values):
    columns = [transform(values[column::8]) for column in range(8)]
    return [value / 8 for row in range(8)
            for value in transform([columns[column][row] for column in range(8)])]


def samples(values):
    return [min(255, max(0, math.floor(value + 128.5))) for value in values]


def qualify():
    maximum_basis_error = 0.0
    for frequency in range(8):
        result = transform([int(index == frequency) for index in range(8)], False)
        maximum_basis_error = max(maximum_basis_error, max(
            abs(result[position] - basis[position][frequency]) for position in range(8)))
    assert maximum_basis_error < 5e-15, maximum_basis_error
    randomizer = random.Random(0x4A504547)
    records = []
    for quantization in (1, 255, 256, 65535):
        cases = []
        # DC half-integers exercise rounding after the level shift.
        for value in range(-1024, 1024):
            cases.append([value] + [0] * 63)
        for position in range(64):
            for amplitude in (-1023, -1, 1, 1023):
                coefficients = [0] * 64
                coefficients[position] = amplitude
                cases.append(coefficients)
        for _ in range(768):
            coefficients = [randomizer.randint(-1023, 1023) for _ in range(64)]
            if len(cases) % 2:
                coefficients = [value if randomizer.randrange(8) == 0 else 0 for value in coefficients]
            cases.append(coefficients)
        # Keep a chosen output inside the byte range despite large intermediate
        # cancellation. Random dense blocks otherwise mostly clip to 0 or 255.
        cancellation_count = 0
        for attempt in range(100000):
            coefficients = [0] * 64
            y, x = randomizer.randrange(8), randomizer.randrange(8)
            for position in randomizer.sample(range(1, 64), 8):
                coefficients[position] = randomizer.randint(-1023, 1023)
            ac = math.fsum(coefficients[index] * basis[y][index // 8] * basis[x][index % 8]
                           for index in range(1, 64))
            coefficients[0] = -round(ac)
            if abs(coefficients[0]) > 1023 or abs((coefficients[0] + ac) * quantization / 8) > 120:
                continue
            cases.append(coefficients)
            cancellation_count += 1
            if cancellation_count == 256:
                break
        assert cancellation_count == 256
        maximum_absolute = 0.0
        maximum_sample = 0
        integer_maximum_sample = 0
        integer_differing = 0
        differing = 0
        worst = None
        for coefficients in cases:
            values = [value * quantization for value in coefficients]
            expected, actual = reference(values), reconstructed(values)
            errors = [abs(left - right) for left, right in zip(expected, actual)]
            actual_samples = [min(255, max(0, math.floor(library.fmaf(value * 8, 0.125, 128.5))))
                              for value in actual]
            expected_samples = samples(expected)
            pixel_errors = [abs(left - right) for left, right in zip(expected_samples, actual_samples)]
            integer_samples = integer_reconstruct(coefficients, [quantization] * 64)
            integer_errors = [abs(left - right) for left, right in zip(expected_samples, integer_samples)]
            integer_maximum_sample = max(integer_maximum_sample, max(integer_errors))
            integer_differing += sum(error != 0 for error in integer_errors)
            maximum_absolute = max(maximum_absolute, max(errors))
            differing += sum(error != 0 for error in pixel_errors)
            if max(pixel_errors) > maximum_sample:
                maximum_sample = max(pixel_errors)
                worst = {'coefficients': coefficients, 'position': pixel_errors.index(maximum_sample),
                         'reference': expected[pixel_errors.index(maximum_sample)],
                         'float32': actual[pixel_errors.index(maximum_sample)]}
        row = {'quantization': quantization, 'blocks': len(cases),
               'maximum_unclipped_error': maximum_absolute, 'maximum_sample_error': maximum_sample,
               'differing_samples': differing, 'integer_maximum_sample_error': integer_maximum_sample,
               'integer_differing_samples': integer_differing, 'worst': worst}
        records.append(row)
        root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
        (root / ('float-idct-cases-' + str(quantization) + '.json')).write_text(json.dumps(cases))
        print(json.dumps({key: value for key, value in row.items() if key != 'worst'}), flush=True)
    record = {'basis_error': maximum_basis_error, 'cases': records,
              'reference': 'Independent double cosine matrix with compensated sums; half ties require separate analysis.',
              'model': 'Explicit IEEE float32 rounding and system libm fmaf; no first-pass integer rounding.',
              'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (notes / 'float-idct-numerical.json').write_text(json.dumps(record, indent=2) + '\n')


def author():
    source = (notes / 'device_stride_pipeline.cxx').read_text()
    source = '#include <loomcxx/scalar.h>\n' + source
    source = source.replace('using WideValues = long long ', 'using WideValues = float ')
    start = source.index('static LOOM_FORCE_INLINE WideValues transform_block_axis(')
    end = source.index('\nstatic LOOM_FORCE_INLINE unsigned sample_byte', start)
    k = [value.hex() + 'f' for value in constants(f32)]
    transform_source = '''static LOOM_FORCE_INLINE WideValues transform_block_axis(WideValues input) {
  float sum = input[0] + input[4];
  float difference = input[0] - input[4];
  float rotation = (input[2] + input[6]) * K0;
  float two = loom::scalar::fmaf(input[6], K1, rotation);
  float six = loom::scalar::fmaf(input[2], K2, rotation);
  float even0 = sum + six;
  float even1 = difference + two;
  float even2 = difference - two;
  float even3 = sum - six;
  float odd_rotation = (input[1] + input[3] + input[5] + input[7]) * K3;
  float seven_three = loom::scalar::fmaf(input[7] + input[3], K4, odd_rotation);
  float five_one = loom::scalar::fmaf(input[5] + input[1], K5, odd_rotation);
  float seven_one = (input[7] + input[1]) * K6;
  float five_three = (input[5] + input[3]) * K7;
  float odd0 = loom::scalar::fmaf(input[1], K8, seven_one) + five_one;
  float odd1 = loom::scalar::fmaf(input[3], K9, five_three) + seven_three;
  float odd2 = loom::scalar::fmaf(input[5], K10, five_three) + five_one;
  float odd3 = loom::scalar::fmaf(input[7], K11, seven_one) + seven_three;
  return {even0 + odd0, even1 + odd1, even2 + odd2, even3 + odd3,
          even3 - odd3, even2 - odd2, even1 - odd1, even0 - odd0};
}
'''
    for index in reversed(range(len(k))):
        transform_source = transform_source.replace('K' + str(index), k[index])
    (notes / 'float_factor.h').write_text(
        '#pragma once\n#include <array>\n#include <cmath>\n#pragma clang fp contract(off)\n'
        'using WideValues = std::array<float, 8>;\n' +
        transform_source.replace('static LOOM_FORCE_INLINE ', 'static inline ').replace('loom::scalar::fmaf', 'std::fma'))
    source = source[:start] + transform_source + source[end:]
    start = source.index('      Values columns = {};')
    end = source.index('\n      [[loom::unroll]]\n      for (unsigned column = 0; column < 8; ++column) {', start)
    source = source[:start] + '''      WideValues columns = {};
      if (ac == 0) {
        [[loom::unroll]]
        for (unsigned row = 0; row < 8; ++row) columns[row] = input[0];
      } else {
        columns = transform_block_axis(input);
      }
      WideValues row = __builtin_bit_cast(WideValues,
          transpose_block(__builtin_bit_cast(Values, columns), axis));
      WideValues result = transform_block_axis(row);''' + source[end:]
    old = 'static_cast<int>((result[column] + 131072) >> 18) + 128'
    assert source.count(old) == 1
    source = source.replace(old, 'static_cast<int>(loom::scalar::floorf(\n            loom::scalar::fmaf(result[column], 0.125f, 128.5f)))')
    (notes / 'device_float_pipeline.cxx').write_text(source)


if __name__ == '__main__':
    qualify()
    author()
