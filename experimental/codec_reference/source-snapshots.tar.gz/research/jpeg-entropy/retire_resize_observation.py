"""Retire only hash-qualified outputs of the completed bus resize experiment."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
parser = argparse.ArgumentParser()
parser.add_argument('--witness', choices=['bus', 'cathedral'], required=True)
witness = parser.parse_args().witness
projector = json.loads((notes / ('gorgon3-cathedral-projector-metrics.json' if witness == 'cathedral' else 'gorgon3-projector-metrics.json')).read_text())
resize = json.loads((notes / ('gorgon3-cathedral-resize-metrics.json' if witness == 'cathedral' else 'gorgon4-resize-metrics.json')).read_text())
hosts = [('hrx-gorgon-3', 'vision-accuracy', True, True)] if witness == 'cathedral' else [
    ('hrx-gorgon-3', 'vision-accuracy', False, True), ('hrx-gorgon-4', 'vision-resize', True, False)]
for host, suffix, outputs, keep_tool in hosts:
    code = '''
import ast, hashlib, json, struct
from pathlib import Path
directory = Path(DIRECTORY)
projector = PROJECTOR
resize = RESIZE
records = []
def qualified(path, digest, payload=None):
    raw = path.read_bytes()
    assert hashlib.sha256(raw if payload is None else payload).hexdigest() == digest, path
    records.append({'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
def numpy_data(path):
    data = path.read_bytes()
    assert data[:8] == b'\\x93NUMPY\\x01\\x00'
    extent = struct.unpack_from('<H', data, 8)[0]
    header = ast.literal_eval(data[10:10 + extent].decode())
    raw = data[10 + extent:]
    assert header['shape'] == (len(raw),) and not header['fortran_order']
    return raw
for name in resize['output_sha256']:
    path = directory / 'observations' / (name + '.prepared')
    qualified(path, projector['artifacts'][path.name]['sha256'])
    if FEATURES:
        feature_path = directory / 'observations' / (name + '.features')
        qualified(feature_path, projector['artifacts'][feature_path.name]['sha256'])
    packet = bytearray(path.read_bytes())
    assert packet[:64] == bytes(64)
    struct.pack_into('<QQ', packet, 0, 64, len(packet) - 64)
    path = directory / 'resize-observations' / (name + '.npy')
    qualified(path, hashlib.sha256(packet).hexdigest(), numpy_data(path))
    if OUTPUTS:
        path = directory / 'resize-observations' / (name + '.resized.npy')
        raw = numpy_data(path)
        assert raw[-32:] == bytes([17]) * 32
        qualified(path, resize['output_sha256'][name], raw[:-32])
if not KEEP_TOOL:
    qualified(directory / 'resize-check', resize['tool_sha256'])
receipt = {'verified': records, 'retired': [], 'keep_tool': KEEP_TOOL}
receipt_path = directory / (WITNESS + '-resize-retirement.json')
receipt_path.write_text(json.dumps(receipt, indent=2) + '\\n')
for row in records:
    path = Path(row['path'])
    assert hashlib.file_digest(path.open('rb'), 'sha256').hexdigest() == row['sha256'], path
    path.unlink()
    receipt['retired'].append(row['path'])
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\\n')
receipt['retired_bytes'] = sum(row['bytes'] for row in records)
receipt['remaining_bytes'] = sum(path.stat().st_size for path in directory.rglob('*') if path.is_file())
receipt_path.write_text(json.dumps(receipt, indent=2) + '\\n')
print(json.dumps(receipt))
'''
    for key, value in {'DIRECTORY': str(root / suffix), 'PROJECTOR': projector,
                       'RESIZE': resize, 'OUTPUTS': outputs, 'KEEP_TOOL': keep_tool,
                       'FEATURES': witness == 'cathedral', 'WITNESS': witness}.items():
        code = code.replace(key, repr(value))
    result = subprocess.run(['ssh', host, 'python3 -B -'], input=code,
                            capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError(result.stdout + result.stderr)
    receipt = json.loads(result.stdout)
    (notes / (host + '-' + witness + '-resize-retirement.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'host': host, 'retired_bytes': receipt['retired_bytes'],
                      'remaining_bytes': receipt['remaining_bytes']}), flush=True)
