"""Pack small row-ownership fixtures with independent pixel expectations.

The default reconstruction control consumes captured interval certificates.
Connected mode derives those certificates from compressed bytes on the GPU.
Both modes check the bounded row consumer; neither qualifies serving or speed.
"""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

parser = argparse.ArgumentParser()
parser.add_argument('--rows', type=int, default=3)
parser.add_argument('--workers', type=int, default=1)
parser.add_argument('--init-only', action='store_true')
parser.add_argument('--connected', action='store_true')
arguments = parser.parse_args()
assert 3 <= arguments.rows <= 64 and 1 <= arguments.workers <= 1024
notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
source = root / 'mixed-negative-base'
case_name = f'rows{arguments.rows}-workers{arguments.workers}' + ('-init' if arguments.init_only else '')
if arguments.connected:
    case_name = 'connected-' + case_name
directory = root / 'persistent' / case_name
directory.mkdir(exist_ok=True)
stage = json.loads((source / 'stage.json').read_text())
assert stage['invalid_index'] is None and len(stage['images']) == 16
program_directory = root / 'persistent'
if arguments.connected:
    program_directory /= 'connected'
layout = json.loads((program_directory / 'directory.json').read_text())
names = layout['inputs'] + layout['outputs']
arrays = {}
hashes = {}


def load(name):
    path = source / (name + '.npy')
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    assert digest == stage['files'][path.name], path
    hashes[path.name] = digest
    return np.load(path).view(np.uint8 if name == 'rgb' else np.uint32).copy()


for name in layout['inputs']:
    if name != 'plans':
        arrays[name] = load('headers' if name == 'images' else name)
producer_names = ['entropy', 'segments', 'intervals', 'records', 'prefixes',
                  'errors', 'schedule', 'jobs', 'expected', 'points',
                  'bridges', 'suffixes', 'ranges']
if arguments.connected:
    for name in producer_names:
        arrays[name] = load(name)
original_pixels = load('pixels')
original_rgb = load('rgb')
original_geometry = arrays['geometry'].copy()
original_images = arrays['images'].copy()
row_offset = 0
ring_chunks = []
ring_words = 0
plans = []
stream_expected = []
decoded_expected = []
tiles_expected = []
initial_pending = []
image_records = []
for ordinal, record in enumerate(stage['images']):
    image = arrays['images'][ordinal * 18:ordinal * 18 + 18]
    old_image = original_images[ordinal * 18:ordinal * 18 + 18]
    blocks = arrays['blocks'][ordinal * 4:ordinal * 4 + 4]
    count = int(blocks[3])
    segment = arrays['segments'][ordinal * 8:ordinal * 8 + 8]
    # The allocation plan consumes only dimensions and sampling from the header.
    # Captured body metadata below is an expectation, never a device input.
    mcu_height = 16 if int(image[17]) in (5, 6, 8) else 8
    rows = (int(image[13]) + mcu_height - 1) // mcu_height
    assert int(image[2]) == rows * int(image[11]) * count == int(segment[4])
    base = int(image[9])
    components = {}
    for block in range(count):
        component = int(blocks[block // 4] >> ((block % 4) * 8)) & 3
        shape = original_geometry[base + block * 8:base + block * 8 + 8]
        info = tuple(map(int, shape[:5]))
        if component in components:
            assert components[component] == info
        components[component] = info
    assert sorted(components) == list(range(len(components)))
    plane_offsets = {}
    plane_sizes = {}
    local = []
    for component, (old_offset, width, height, horizontal, vertical) in sorted(components.items()):
        capacity_rows = arguments.rows * vertical
        size = capacity_rows * width * 16
        plane_offsets[component] = sum(len(part) for part in local)
        plane_sizes[component] = size
        plane = np.full(size, 17, dtype=np.uint32)
        for row in range(height):
            begin = int(old_image[3]) + old_offset + row * width * 16
            target = (row % capacity_rows) * width * 16
            plane[target:target + width * 16] = original_pixels[begin:begin + width * 16]
        local.append(plane)
    for block in range(count):
        component = int(blocks[block // 4] >> ((block % 4) * 8)) & 3
        arrays['geometry'][base + block * 8] = plane_offsets[component]
    image[3] = ring_words
    if arguments.connected:
        segment[7] = ring_words
    image[15] = plane_sizes[0] * 4
    image[16] = plane_sizes.get(1, 0) * 4
    plans.extend([row_offset, rows, ring_words, 0, 0, 0, 0])
    first = int(segment[2]) * 5 + ordinal
    interval_count = int(segment[3]) * 5 + 1
    intervals = arrays['intervals'][first * 8:(first + interval_count) * 8].reshape(-1, 8)
    retained = int(np.count_nonzero(intervals[:-1, 0] < intervals[:-1, 1])) + 1
    pending = [0] * rows
    for index, interval in enumerate(intervals):
        if interval[0] < interval[1] or index + 1 == interval_count:
            mcu = int(interval[2]) // count + int(interval[3] != 0)
            pending[min(mcu // int(image[11]), rows - 1)] += 1
    initial_pending.extend(pending)
    stream_expected.extend([row_offset, rows, ring_words, rows, retained, retained, 0])
    decoded_expected.extend([int(image[11])] * rows)
    mcu_height = 16 if int(image[17]) in (5, 6, 8) else 8
    tiles_expected.extend([(int(image[12]) + 63) // 64 * (mcu_height // 8)] * rows)
    payload = np.concatenate(local + [np.full(8, 17, dtype=np.uint32)])
    ring_chunks.append(payload)
    image_records.append({'name': record['name'], 'rows': rows,
                          'row_offset': row_offset, 'pixel_word_offset': ring_words,
                          'pixel_word_count': len(payload), 'interval_count': retained})
    ring_words += len(payload)
    row_offset += rows

arrays['plans'] = np.array(plans, dtype=np.uint32)
expected = {
    'pixels': np.concatenate(ring_chunks),
    'rgb': original_rgb,
    'streams': np.array(stream_expected, dtype=np.uint32),
    'heads': np.full(row_offset, 0xffffffff, dtype=np.uint32),
    'pending': np.zeros(row_offset, dtype=np.uint32),
    'decoded': np.array(decoded_expected, dtype=np.uint32),
    'color_claimed': np.array(tiles_expected, dtype=np.uint32),
    'color_done': np.array(tiles_expected, dtype=np.uint32),
}
if arguments.connected:
    expected.update({name: arrays[name].copy() for name in producer_names})
interval_capacity = len(arrays['intervals'])
for name, value in expected.items():
    arrays[name] = np.full_like(value, 17)
arrays['links'] = np.full(interval_capacity // 8, 17, dtype=np.uint32)
arrays['cursors'] = np.full(interval_capacity, 17, dtype=np.uint32)
if arguments.init_only:
    for name in ('pixels', 'rgb'):
        expected[name][:] = 17
    expected['streams'].reshape(-1, 7)[:, [3, 5]] = 0
    expected['pending'] = np.array(initial_pending, dtype=np.uint32)
    for name in ('decoded', 'color_claimed', 'color_done'):
        expected[name][:] = 0
    # Concurrent pushes deliberately have no prescribed order. The captured
    # lists are checked independently against the complete retained task set.
    del expected['heads']

roots = {'input': bytearray(4 * len(names)), 'output': bytearray()}
ranges = {}
for name in names:
    owner = 'input' if name in layout['inputs'] else 'output'
    value = arrays[name]
    root_bytes = roots[owner]
    root_bytes.extend(bytes([0xa7]) * ((-len(root_bytes)) % 16))
    offset = len(root_bytes)
    root_bytes.extend(value.tobytes())
    root_bytes.extend(bytes([0xa7]) * 32)
    ranges[name] = {'root': owner, 'offset': offset, 'bytes': value.nbytes,
                    'elements': len(value), 'type': 'i8' if value.itemsize == 1 else 'i32'}
    roots['input'][names.index(name) * 4:names.index(name) * 4 + 4] = offset.to_bytes(4, 'little')
assert max(map(len, roots.values())) < 1 << 30
assert sum(map(len, roots.values())) < 4 * 1024 * 1024
for name, value in roots.items():
    np.save(directory / (name + '.npy'), np.frombuffer(value, dtype=np.int8))
for name, value in expected.items():
    np.save(directory / (name + '-expected.npy'), value.view(np.int8 if value.itemsize == 1 else np.int32))

configuration = json.loads((source / 'config.json').read_text())
configuration['stream'] = {'rows': arguments.rows, 'workers': arguments.workers}
if arguments.connected:
    configuration['input']['tiles'] = max(int(record['header'][7]) for record in stage['images'])
(directory / 'config.json').write_text(json.dumps(configuration, indent=2) + '\n')
input_type = f'tensor<{len(roots["input"])}xi8>'
output_type = f'tensor<{len(roots["output"])}xi8>'
program = '''kernel.decl @jpeg_stream_init() launch(%input: buffer, %output: buffer)
kernel.decl @jpeg_stream() launch(%input: buffer, %output: buffer)
check.case @persistent_rows {
'''
if arguments.connected:
    program = (program_directory / 'command.loom').read_text()
    if arguments.init_only:
        program = program.replace('    kernel.launch @jpeg_stream(%input, %output) : (buffer, buffer)\n', '')
    program += '''
func.def @fixture_values(%input: buffer, %output: buffer) {
  func.return
}
check.scenario @persistent_rows {
  check.trial[1](%trial: index, %trial_entropy: check.entropy) {
'''
program += f'  %input = check.file.read.npy path("input.npy") : {input_type}\n'
program += f'  %output = check.file.read.npy path("output.npy") : {output_type}\n'
if not arguments.connected:
    for kernel in (('jpeg_stream_init',) if arguments.init_only else ('jpeg_stream_init', 'jpeg_stream')):
        program += f'  kernel.launch @{kernel}(%input, %output) : ({input_type}, {output_type})\n'
    program += f'  check.file.write.npy value(%output) path("actual.npy") mode(always) : {output_type}\n'
expectations = []
for name in expected:
    row = ranges[name]
    value_type = f'tensor<{row["elements"]}x{row["type"]}>'
    program += f'  %{name} = check.tensor.view %output offset({row["offset"]}) : {output_type} -> {value_type}\n'
    program += f'  %{name}_expected = check.file.read.npy path("{name}-expected.npy") : {value_type}\n'
    expectations.append(f'  check.expect.bitwise actual(%{name}) expected(%{name}_expected) : {value_type}\n')
guard_ranges = []
if arguments.connected:
    # Recipe values preserve aliases when target and oracle inputs are cloned.
    # The comparison body contains only observations; it cannot perform IO.
    end = 0
    for row in (row for row in ranges.values() if row['root'] == 'output'):
        if row['offset'] > end:
            guard_ranges.append((end, row['offset'] - end))
        end = row['offset'] + row['bytes']
    guard_ranges.append((end, len(roots['output']) - end))
    for ordinal, (offset, length) in enumerate(guard_ranges):
        value_type = f'tensor<{length}xi8>'
        program += f'  %guard{ordinal} = check.tensor.view %output offset({offset}) : {output_type} -> {value_type}\n'
        program += f'  %guard{ordinal}_expected = check.generate.fill value(-89) : {value_type}\n'
        expectations.append(f'  check.expect.bitwise actual(%guard{ordinal}) expected(%guard{ordinal}_expected) : {value_type}\n')
    expectations.append(f'  check.expect.bitwise actual(%input) expected(%input) : {input_type}\n')
    program += f'  check.compare<@jpeg_stream_decode, @fixture_values>(%input, %output) : ({input_type}, {output_type}) -> () {{\n'
program += ''.join(expectations)
if arguments.connected:
    program += '  }\n  }\n'
program += '  check.return\n}\n'
(directory / 'check.loom').write_text(program)
receipt = {'scope': __doc__.strip(), 'input_fixture_hashes': hashes,
           'configuration': configuration, 'ranges': ranges, 'images': image_records,
           'root_bytes': {key: len(value) for key, value in roots.items()},
           'checked_guard_bytes': sum(length for _, length in guard_ranges)}
if arguments.connected:
    receipt['scope'] = ('Original compressed bytes and header-derived facts through nine GPU entropy stages, '
                        'queue initialization, and the persistent three-row consumer in one serial command. '
                        'All body-derived buffers start poisoned. Valid restart-free images only; '
                        'full RGB remains provisional and resize/final publication are not qualified.')
    receipt['producer_outputs'] = producer_names
receipt['files'] = {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                    for path in directory.iterdir() if path.is_file() and path.name != 'fixture.json'}
(directory / 'fixture.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'directory': str(directory), 'roots': receipt['root_bytes'],
                  'rows': row_offset, 'ring_bytes': ring_words * 4}), flush=True)
