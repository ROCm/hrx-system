"""Hold only a foreground trained-model run, then collect ownership receipts."""
import argparse
import json
from pathlib import Path
import subprocess

notes = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--prefix', default='gorgon3-model-accuracy')
prefix = parser.parse_args().prefix
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
directory = root / 'vision-accuracy'
command = ['ssh', 'hrx-gorgon-3', '/home/benvanik/.dotfiles/bin/benchmark-lock',
           '--label=codec-jpeg-model-accuracy', '--', 'env', 'LD_LIBRARY_PATH=/opt/rocm/lib',
           'python3', '-B', str(directory / 'model_accuracy.py'), str(directory)]
with (notes / (prefix + '.log')).open('w') as log:
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    for line in process.stdout:
        log.write(line)
        log.flush()
        print(line, end='', flush=True)
    result = process.wait()
status = subprocess.run(['ssh', 'hrx-gorgon-3',
                         '/home/benvanik/.dotfiles/bin/benchmark-lock', '--status'],
                        capture_output=True, text=True)
receipt = {'command': command, 'returncode': result, 'broker_status_returncode': status.returncode,
           'broker_status_after': status.stdout + status.stderr}
for source, destination in [('result.json', prefix + '-result.json'),
                             ('server.log', prefix + '-server.log')]:
    copied = subprocess.run(['scp', 'hrx-gorgon-3:' + str(directory / source), str(notes / destination)])
    receipt[source + '_copy_returncode'] = copied.returncode
(notes / (prefix + '-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
raise SystemExit(result or status.returncode or any(receipt[key] for key in receipt if key.endswith('_copy_returncode')))
