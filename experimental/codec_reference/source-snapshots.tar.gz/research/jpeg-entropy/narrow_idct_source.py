"""Build the bounded guarded-i32 cooperative transform experiment."""
from pathlib import Path
notes = Path(__file__).resolve().parent
source = (notes / 'device_reconstruct_cooperative_mask.cxx').read_text()
first = source.index('static LOOM_FORCE_INLINE WideValues transform_block_axis(')
last = source.index('static LOOM_FORCE_INLINE unsigned sample_byte', first)
narrow = source[first:last].replace('WideValues', 'Values').replace('long long', 'int').replace('transform_block_axis', 'transform_block_axis_narrow')
marker = 'using Values = int __attribute__((ext_vector_type(8)));\n'
source = source.replace(marker, marker + '\n' + narrow)
first = source.index('      WideValues input = {};', source.index('void reconstruct_cooperative'))
last = source.index('\n    }\n    reinterpret_cast', first)
source = source[:first] + '''      Values input = {};
      int ac = 0;
      unsigned maximum = 0;
      [[loom::unroll]]
      for (unsigned row = 0; row < 8; ++row) {
        unsigned natural = row * 8 + axis;
        unsigned step = quantization[natural];
        loom::assume(step <= 65535u);
        int value = static_cast<int>(coefficients[natural * coefficient_stride + owner]) *
                    static_cast<int>(step);
        input[row] = value;
        if (row != 0) ac |= value;
        unsigned magnitude = static_cast<unsigned>(value < 0 ? -value : value);
        maximum = magnitude > maximum ? magnitude : maximum;
      }
      unsigned block_maximum = loom::kernel::subgroup::reduce::maxui<8>(maximum);
      bool narrow = block_maximum <= 1024;
      Values columns = {};
      if (ac == 0) {
        [[loom::unroll]]
        for (unsigned row = 0; row < 8; ++row) columns[row] = input[0] * 4;
      } else if (narrow) {
        Values result = transform_block_axis_narrow(input);
        [[loom::unroll]]
        for (unsigned row = 0; row < 8; ++row) columns[row] = (result[row] + 1024) >> 11;
      } else {
        WideValues wide_input = {};
        [[loom::unroll]]
        for (unsigned row = 0; row < 8; ++row) wide_input[row] = input[row];
        WideValues result = transform_block_axis(wide_input);
        [[loom::unroll]]
        for (unsigned row = 0; row < 8; ++row) {
          columns[row] = static_cast<int>((result[row] + 1024) >> 11);
        }
      }
      Values row = transpose_block(columns, axis);
      if (narrow) {
        Values result = transform_block_axis_narrow(row);
        [[loom::unroll]]
        for (unsigned column = 0; column < 8; ++column) {
          int value = ((result[column] + 131072) >> 18) + 128;
          packed |= static_cast<unsigned long long>(sample_byte(value)) << (column * 8);
        }
      } else {
        WideValues wide_input = {};
        [[loom::unroll]]
        for (unsigned column = 0; column < 8; ++column) wide_input[column] = row[column];
        WideValues result = transform_block_axis(wide_input);
        [[loom::unroll]]
        for (unsigned column = 0; column < 8; ++column) {
          int value = static_cast<int>((result[column] + 131072) >> 18) + 128;
          packed |= static_cast<unsigned long long>(sample_byte(value)) << (column * 8);
        }
      }''' + source[last:]
(notes / 'device_reconstruct_narrow.cxx').write_text(source)
pipeline = '#include "device_entropy_cursor_fused.h"\n'
for name in ('device_entropy_tables.cxx', 'device_bridge.cxx', 'device_certify.cxx', 'device_reconstruct_narrow.cxx'):
    pipeline += '\n' + (notes / name).read_text().replace('#include "device_entropy_cursor.h"', '') + '\n'
(notes / 'device_narrow_pipeline.cxx').write_text(pipeline)
