"""Falsify the topology-query hypothesis using the producer's exact count."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
source = (notes / 'device_connected_pipeline.cxx').read_text()
old = 'unsigned* pixels, unsigned* status) {'
assert source.count(old) == 1
source = source.replace(old, 'unsigned* pixels, unsigned* status, const unsigned* schedule) {')
old = 'unsigned group_count = loom::kernel::workgroup::count.x;'
assert source.count(old) == 1
source = source.replace(old, 'unsigned group_count = schedule[4];')
(notes / 'device_stored_grid_pipeline.cxx').write_text(source)
tags = json.loads(os.environ['BUREAU_TAG_ROOTS'])
base = Path(tags['codec-jpeg-rebased-tools']) / 'loom/src/loom/tools'
native = Path(tags['codec-jpeg-unsigned-opt']) / 'loom/src/loom/tools'
library = root / 'entropy-stored-grid.loombc'
subprocess.run([str(base / 'loom-import-cxx/loom-import-cxx'), str(notes / 'device_stored_grid_pipeline.cxx'),
               '--output=' + str(root / 'stored-grid.loom')], check=True)
subprocess.run([str(base / 'loom-link/loom-link'), str(root / 'stored-grid.loom'), '--to=bc', '--output=' + str(library)], check=True)
directory = root / 'connected-stored-grid'
directory.mkdir(exist_ok=True)
original = root / 'connected-batch16'
text = (original / 'summary.loom').read_text()
text = re.sub(r'(kernel.decl @jpeg_reconstruct[^\n]+%status: buffer)\)', r'\1, %schedule: buffer)', text)
text = re.sub(r'(kernel.launch @jpeg_reconstruct[^\n]+%status)\)([^\n]+)\)', r'\1, %schedule)\2, buffer)', text)
text = re.sub(r'check.file.read.npy path\("([^"]+)"\)', lambda match: 'check.file.read.npy path("' + os.path.relpath((original / match[1]).resolve(), directory) + '")', text)
(directory / 'summary.loom').write_text(text)
(directory / 'config.json').write_bytes((original / 'config.json').read_bytes())
bindings = [line.split() for line in (original / 'bindings.txt').read_text().splitlines()]
files = {}
for row in bindings:
    path = (original / row[4]).resolve()
    row[4] = os.path.relpath(path, directory)
    files[row[4]] = hashlib.sha256(path.read_bytes()).hexdigest()
(directory / 'bindings.txt').write_text('\n'.join(' '.join(row) for row in bindings) + '\n')
subprocess.run([str(base / 'loom-link/loom-link'), str(directory / 'summary.loom'), str(library),
               '--to=bc', '--output=' + str(directory / 'summary.loombc')], check=True)
subprocess.run([str(native / 'loom-compile/loom-compile'), str(library), '--root=jpeg_reconstruct',
               '--target=amdgpu:gfx1151', '--config-file=' + str(directory / 'config.json'),
               '--output=' + str(root / 'jpeg_reconstruct-stored-grid.hsaco'),
               '--compile-report=details', '--compile-report-output=' + str(root / 'stored-grid-report.json')], check=True)
files.update({path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in directory.iterdir() if path.name != 'stage.json'})
stage = {'files': files, 'scope': 'Same full connected command, reconstruction grid-stride comes from the GPU producer schedule instead of workgroup.count.x. Tests the count-query path; no root-cause claim.'}
(directory / 'stage.json').write_text(json.dumps(stage, indent=2) + '\n')
print(directory, flush=True)
