"""Attribute the shared coefficient storage cost using the same exact checksum."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
tags = json.loads(os.environ['BUREAU_TAG_ROOTS'])
base = Path(tags['codec-jpeg-rebased-tools'])
native = Path(tags['codec-jpeg-unsigned-opt'])
source = (notes / 'device_reconstruct_checksum.cxx').read_text()
start = source.index('// One logically private coefficient block')
end = source.index('static LOOM_FORCE_INLINE Symbol output_symbol')
source = source[:start] + source[end:]
source = source.replace('  auto* coefficients = loom::buffer::alloca<int, loom::memory_space::workgroup, 16>(threads * 64);\n', '')
source = source.replace('          [[loom::unroll]]\n          for (unsigned index = 0; index < 64; ++index) coefficients[index * threads + lane] = 0;\n          bool any_ac = false;', '          unsigned checksum = 0;')
source = source.replace('              coefficients[natural * threads + lane] = symbol.value * static_cast<int>(step);\n              if (symbol.index != 0) any_ac = true;',
    '              checksum ^= static_cast<unsigned>(symbol.value * static_cast<int>(step));')
source = source.replace('            reconstruct_block(coefficients, threads, lane, any_ac, pixels + offset);',
    '            [[loom::unroll]]\n            for (unsigned index = 0; index < 16; ++index) pixels[offset + index] = checksum;')
assert 'coefficients[' not in source
(notes / 'device_reconstruct_register_checksum.cxx').write_text(source)
pipeline = (notes / 'device_output_pipeline.cxx').read_text().replace(
    'device_reconstruct.cxx', 'device_reconstruct_register_checksum.cxx')
(notes / 'device_register_checksum_pipeline.cxx').write_text(pipeline)
library = root / 'entropy-register-checksum.loombc'
commands = [
    [str(base / 'loom/src/loom/tools/loom-import-cxx/loom-import-cxx'),
     str(notes / 'device_register_checksum_pipeline.cxx'), '--output=' + str(root / 'entropy-register-checksum.loom')],
    [str(base / 'loom/src/loom/tools/loom-link/loom-link'), str(root / 'entropy-register-checksum.loom'),
     '--to=bc', '--output=' + str(library)],
    [str(native / 'loom/src/loom/tools/loom-compile/loom-compile'), str(library),
     '--root=jpeg_reconstruct', '--target=amdgpu:gfx1151',
     '--config-file=' + str(root / 'output-config.json'),
     '--output=' + str(root / 'jpeg_reconstruct-register-checksum.hsaco'),
     '--compile-report=details', '--compile-report-output=' + str(root / 'register-checksum-report.json')]]
for command in commands:
    subprocess.run(command, check=True)
metrics = json.loads((root / 'register-checksum-report.json').read_text())['entries']['rows'][0]
metrics = {key: metrics[key] for key in ('instruction_count', 'code_byte_count',
           'private_memory_bytes', 'local_memory_bytes', 'target_resources')}
print(json.dumps(metrics), flush=True)
original = root / 'checksum-batch16-1024'
fixture = root / 'register-checksum-batch16-1024'
fixture.mkdir(exist_ok=True)
text = (original / 'summary.loom').read_text()
paths = {}
def relocate(match):
    path = (original / match[1]).resolve()
    name = os.path.relpath(path, fixture)
    paths[name] = path
    return 'check.file.read.npy path("' + name + '")'
text = re.sub(r'check.file.read.npy path\("([^"]+)"\)', relocate, text)
(fixture / 'summary.loom').write_text(text)
(fixture / 'config.json').write_bytes((original / 'config.json').read_bytes())
command = [str(base / 'loom/src/loom/tools/loom-link/loom-link'), str(fixture / 'summary.loom'),
           str(library), '--to=bc', '--output=' + str(fixture / 'summary.loombc')]
subprocess.run(command, check=True)
commands.append(command)
stage = json.loads((original / 'stage.json').read_text())
stage['files'] = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in paths.items()}
stage['files'].update({path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                      for path in fixture.iterdir() if path.is_file() and path.name != 'stage.json'})
stage['library'] = {'path': library.name, 'sha256': hashlib.sha256(library.read_bytes()).hexdigest()}
stage['scope'] = 'Diagnostic only: same entropy/block schedule and exact block checksums as checksum control, but coefficient XOR accumulated during parsing, without shared coefficient storage. Same 64-byte output/block; not JPEG samples.'
stage['retention'] = 'Reuses checksum expectation; no additional large array.'
stage['link_command'] = command
(fixture / 'stage.json').write_text(json.dumps(stage, indent=2) + '\n')
record = {'commands': commands, 'stage': stage, 'metrics': metrics,
          'native_sha256': hashlib.sha256((root / 'jpeg_reconstruct-register-checksum.hsaco').read_bytes()).hexdigest(),
          'sources': {name: hashlib.sha256((notes / name).read_bytes()).hexdigest() for name in
                      ('device_output_storage.py', 'device_reconstruct_register_checksum.cxx',
                       'device_register_checksum_pipeline.cxx', 'device_entropy_cursor.h')}}
(notes / 'device-output-storage.json').write_text(json.dumps(record, indent=2) + '\n')
print('Register checksum diagnostic ready', flush=True)
