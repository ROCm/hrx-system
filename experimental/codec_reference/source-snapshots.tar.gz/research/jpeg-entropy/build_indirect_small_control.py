"""Capture the reduced regression with only its two acquire corrections undone."""
import hashlib
import json
from pathlib import Path
import subprocess

notes = Path(__file__).resolve().parent
paths = [Path('runtime/src/iree/hal/drivers/amdgpu') / name for name in
         ('aql_block_processor.c', 'aql_block_processor_profile.c')]
candidate = {path: path.read_bytes() for path in paths}
old = b'processor, dispatch_packet_index, IREE_HSA_FENCE_SCOPE_AGENT,'
new = b'processor, dispatch_packet_index, IREE_HSA_FENCE_SCOPE_NONE,'
for data in candidate.values():
    assert data.count(old) == 1
baseline = {path: data.replace(old, new) for path, data in candidate.items()}
command = ['bureau-bazel', 'build', '--tag=codec-indirect-baseline', '--config=asan',
           '--repo_env=IREE_ROCM_PATH=/home/ben/tools/rocm/10.1.0a20260822',
           '--repo_env=IREE_ROCM_DEPENDENCY_MODE=pinned',
           '--repo_env=IREE_HAL_AMDGPU_DEVICE_TOOLCHAIN=rocm',
           '--//runtime/src/iree/hal/drivers/amdgpu:targets=gfx1100,gfx1151',
           '//runtime/src/iree/hal/drivers/amdgpu:indirect_dispatch_test']
record = {'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
          'grid': [32, 2, 3], 'command': command, 'restored': False,
          'candidate_capture': json.loads(subprocess.check_output(
              ['bureau-bazel', 'tag', 'inspect', 'codec-indirect-candidate', '--json'], text=True)),
          'sources': {str(path): {'candidate': hashlib.sha256(candidate[path]).hexdigest(),
                                  'baseline': hashlib.sha256(baseline[path]).hexdigest()}
                      for path in paths},
          'test_sources': {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in
              [paths[0].parent / 'indirect_dispatch_test.cc',
               paths[0].parent / 'cts/testdata/indirect_dispatch_geometry_test.c']}}
try:
    for path, data in baseline.items():
        path.write_bytes(data)
    with (notes / 'indirect-small-baseline-build.log').open('w') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    record['returncode'] = result.returncode
    if not result.returncode:
        record['baseline_capture'] = json.loads(subprocess.check_output(
            ['bureau-bazel', 'tag', 'inspect', 'codec-indirect-baseline', '--json'], text=True))
finally:
    for path in paths:
        assert path.read_bytes() == baseline[path], 'Concurrent change: ' + str(path)
    for path, data in candidate.items():
        path.write_bytes(data)
    record['restored'] = True
    (notes / 'indirect-small-build.json').write_text(json.dumps(record, indent=2) + '\n')
print((notes / 'indirect-small-baseline-build.log').read_text())
assert result.returncode == 0
