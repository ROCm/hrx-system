"""Independent entropy failures with exact valid peers and publication guards."""
import array
import copy
import hashlib
import json
from pathlib import Path
import shutil
import struct

from byte_compaction_model import model, reference
from device_fixture import input_bytes
from sequential import decode, InvalidJPEG, parse
from wide_fixture import digest, payload, write_array

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
baseline = root / 'mixed-negative-base'
base_stage = json.loads((baseline / 'stage.json').read_text())
for name, expected in base_stage['files'].items():
    assert digest(baseline / name) == expected, name
bindings = [line.split() for line in (baseline / 'bindings.txt').read_text().splitlines()]
base_values = {}
for name, _, width, _, relative in bindings:
    data = payload(baseline / relative)
    value = bytearray(data) if width == '1' else array.array('I')
    if width == '4': value.frombytes(data)
    base_values[name] = value
source_ordinal = 3
original = input_bytes('ycbcr_420')
assert hashlib.sha256(original).hexdigest() == base_stage['images'][source_ordinal]['input_sha256']
frame = parse(original)
assert len(frame.scans) == len(frame.scans[0].segments) == 1
scan = frame.scans[0]
segment = scan.segments[0]
start = segment.source_start
raw = segment.data
_, traces = decode(frame, True)
assert traces[-1].positions[-1] % 8


def code(table, symbol):
    key, = [key for key, value in table.symbols.items() if value == symbol]
    length = key.bit_length() - 1
    return format(key - (1 << length), f'0{length}b')


def bits(value):
    value += '1' * ((-len(value)) % 8)
    return bytes(int(value[index:index + 8], 2) for index in range(0, len(value), 8))


first = scan.blocks[0]
mutations = [
    ('empty', b'', 'truncated entropy/amplitude'),
    ('truncated-middle', raw[:len(raw) // 2], 'truncated entropy/amplitude'),
    ('undefined-code', b'\xff\xff', 'undefined Huffman code'),
    ('zrl-overflow', bits(code(first.dc, 0) + code(first.ac, 0xf0) * 4), 'ZRL exceeds block'),
    ('ac-run-overflow', bits(code(first.dc, 0) + (code(first.ac, 0xf1) + '1') * 4), 'AC run exceeds block'),
    ('positive-dc-overflow', bits(code(first.dc, 11) + '1' * 11), 'DC outside 8-bit DCT range'),
    ('negative-dc-overflow', bits(code(first.dc, 11) + '0' * 11), 'DC outside 8-bit DCT range'),
    ('residual-byte', raw + b'\x00', 'entropy remains after last MCU'),
    ('non-ones-padding', raw[:-1] + bytes([raw[-1] & 254]), 'non-ones entropy padding'),
]
cases = []
output = root / 'mixed-negative-cases'
output.mkdir(exist_ok=True)
input_names = {name for name, is_input, *_ in bindings if is_input == '1'}
private_names = {'expected', 'bridges', 'suffixes', 'ranges', 'intervals', 'points'}
image_count = len(base_stage['images'])
assert image_count == 16
for mutation, body, rejection in mutations:
    encoded = original[:start] + body.replace(b'\xff', b'\xff\x00') + b'\xff\xd9'
    parsed = parse(encoded)
    assert encoded[:start] == original[:start] and parsed.scans[0].segments[0].data == body
    try:
        decode(parsed)
    except InvalidJPEG as error:
        assert str(error) == rejection, (mutation, str(error), rejection)
    else:
        raise AssertionError('independent decoder accepted ' + mutation)
    valid, unstuffed, records, prefixes = model(encoded, start)
    assert valid and unstuffed == body and reference(encoded, start) == (True, body)
    for invalid_ordinal in (0, 7, 15):
        name = mutation + '-' + str(invalid_ordinal)
        directory = output / name
        directory.mkdir(exist_ok=True)
        assert not list(directory.glob('*.npy')), 'Reconcile previous case before replacing it.'
        values = {key: value[:] for key, value in base_values.items()}
        order = list(range(image_count))
        order[source_ordinal], order[invalid_ordinal] = order[invalid_ordinal], order[source_ordinal]
        inverse = {old: new for new, old in enumerate(order)}
        images = [copy.deepcopy(base_stage['images'][old]) for old in order]
        for ordinal, image in enumerate(images): image['ordinal'] = ordinal
        headers = [image['header'][:] for image in images]
        header = headers[invalid_ordinal]
        assert (len(encoded) + 4095) // 4096 == header[7]
        header[0] = len(encoded)
        compressed_offset = header[4] * 4
        compressed_length = header[7] * 4096 + 16
        compressed = bytearray(values['compressed'].tobytes())
        compressed[compressed_offset:compressed_offset + compressed_length] = encoded + bytes(compressed_length - len(encoded))
        values['compressed'] = array.array('I')
        values['compressed'].frombytes(compressed)
        values['headers'] = array.array('I', [word for h in headers for word in h] + [17] * 8)
        values['blocks'] = array.array('I', [word for old in order for word in base_values['blocks'][old * 4:(old + 1) * 4]] + [17] * 8)
        for offset in range(0, len(values['color_tiles']) - 8, 3):
            values['color_tiles'][offset] = inverse[values['color_tiles'][offset]]
        entropy_base = header[5]
        entropy_span = header[7] * 1024 + 32 + 8
        values['entropy'][entropy_base:entropy_base + entropy_span] = array.array('I', [17] * entropy_span)
        padded = body + bytes((-len(body)) % 4 + 8)
        entropy = array.array('I', struct.unpack('>' + 'I' * (len(padded) // 4), padded))
        values['entropy'][entropy_base:entropy_base + len(entropy)] = entropy
        values['records'][header[6] * 4:(header[6] + header[7]) * 4] = array.array('I', [word for row in records for word in row])
        values['prefixes'][header[6]:header[6] + header[7]] = array.array('I', prefixes)
        values['errors'] = array.array('I', [word for old in order for word in base_values['errors'][old * 4:(old + 1) * 4]] + [17] * 8)
        values['errors'][invalid_ordinal * 4:invalid_ordinal * 4 + 4] = array.array('I', [0, min(row[1] for row in records), min(row[2] for row in records), len(body)])
        pixel_lengths = {}
        original_headers = [image['header'] for image in base_stage['images']]
        for old, old_header in enumerate(original_headers):
            next_base = original_headers[old + 1][3] if old + 1 < image_count else len(values['pixels'])
            pixel_lengths[old] = next_base - old_header[3]
        first_job = 0
        jobs = []
        segments = []
        regions = {}
        for key in private_names | {'status'}:
            values[key] = array.array('I', [17] * len(values[key]))
        regions['pixels'] = []
        regions['status'] = []
        for ordinal, (old, h) in enumerate(zip(order, headers)):
            length = values['errors'][ordinal * 4 + 3]
            count = (length + 1023) // 1024
            segments.extend([h[5], length * 8, first_job, count, h[2], first_job + ordinal, 0, h[3]])
            for job in range(count): jobs.extend([h[5], length * 8, job, ordinal])
            first_status = first_job * 5 + ordinal
            if ordinal != invalid_ordinal:
                values['status'][first_status:first_status + count * 5 + 1] = array.array('I', [0] * (count * 5 + 1))
                regions['status'].append((first_status * 4, (count * 5 + 1) * 4, 'exact'))
                regions['pixels'].append((h[3] * 4, pixel_lengths[old] * 4, 'exact'))
            else:
                regions['pixels'].append(((h[3] + pixel_lengths[old] - 8) * 4, 32, 'exact'))
            first_job += count
        values['jobs'] = array.array('I', jobs + [17] * (len(values['jobs']) - len(jobs)))
        values['segments'] = array.array('I', segments + [17] * 8)
        intervals = first_job * 5 + image_count
        values['schedule'] = array.array('I', [first_job, (first_job + 127) // 128, 1, 1,
            (intervals + 32 * image_count - 1) // (32 * image_count), image_count, 1, intervals] + [17] * 8)
        regions['status'].append((intervals * 4, (len(values['status']) - intervals) * 4, 'exact'))
        rgb_begin = header[14]
        rgb_length = header[12] * header[13] * 3
        values['rgb'][rgb_begin:rgb_begin + rgb_length] = bytes([17]) * rgb_length
        values['validity'] = array.array('I', [0] * image_count + [17] * 8)
        regions['validity'] = [(ordinal * 4, 4, 'body_error' if ordinal == invalid_ordinal else 'exact') for ordinal in range(image_count)]
        regions['validity'].append((image_count * 4, 32, 'exact'))
        active = {'expected': first_job * 8, 'bridges': first_job * 8,
                  'suffixes': (first_job + image_count) * 8, 'ranges': (first_job + image_count) * 8,
                  'intervals': intervals * 8, 'points': first_job * 3 * 8}
        for key in private_names:
            regions[key] = [(active[key] * 4, (len(values[key]) - active[key]) * 4, 'exact')]
        verification = []
        for key, _, width_text, _, relative in bindings:
            width = int(width_text)
            data = values[key]
            write_array(directory / relative, width, len(data), [data.tobytes() if isinstance(data, array.array) else data])
            selected = regions.get(key, [(0, len(data) * width, 'exact')])
            for offset, length, mode in sorted(selected):
                assert length > 0 and offset + length <= len(data) * width
                verification.append(f'{key} {offset} {length} {mode}')
        (directory / 'verification.txt').write_text('\n'.join(verification) + '\n')
        for relative in ['bindings.txt', 'config.json', 'summary.loombc']:
            shutil.copyfile(baseline / relative, directory / relative)
        files = {path.name: digest(path) for path in directory.iterdir() if path.is_file() and path.name != 'stage.json'}
        for image, h in zip(images, headers): image['header'] = h
        images[invalid_ordinal]['input_sha256'] = hashlib.sha256(encoded).hexdigest()
        record = {'cohort': 'negative-small', 'mutation': mutation, 'invalid_ordinal': invalid_ordinal,
                  'rejection': rejection, 'input_sha256': hashlib.sha256(encoded).hexdigest(),
                  'entropy_hex': body.hex(), 'images': images, 'files': files,
                  'baseline_stage_sha256': digest(baseline / 'stage.json'), 'source': base_stage['source'],
                  'generator_sha256': digest(Path(__file__)), 'sequential_sha256': digest(notes / 'sequential.py'),
                  'scope': 'Header and EOI valid. CPU oracle rejects body; GPU must preserve valid peers and reject without publishing RGB. Only unpublished partial intermediates lack exact value contracts.'}
        (directory / 'stage.json').write_text(json.dumps(record, indent=2) + '\n')
        cases.append({'directory': str(directory.relative_to(root)), 'mutation': mutation,
                      'ordinal': invalid_ordinal, 'input_sha256': record['input_sha256'],
                      'rejection': rejection, 'stage': record})
        print(json.dumps({'case': name, 'rejection': rejection, 'jobs': first_job}), flush=True)
total_bytes = sum(path.stat().st_size for path in output.rglob('*') if path.is_file())
assert total_bytes < 64 * 1024**2
receipt = {'baseline': base_stage, 'cases': cases, 'fixture_bytes': total_bytes,
           'scope': 'Nine independent entropy failures at three stable ordinals; no benchmark timings.'}
(notes / 'entropy-validity-cases.json').write_text(json.dumps(receipt, indent=2) + '\n')
