"""Rebuild the unchanged JPEG command and compare all emitted leaf programs."""
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
previous = root / 'connected-float'
candidate = root / 'connected-main-requalified'
candidate.mkdir(exist_ok=True)
native = root / 'requalified-native'
native.mkdir(exist_ok=True)
tags = json.loads(os.environ['BUREAU_TAG_ROOTS'])
tools = Path(tags['codec-jpeg-rebased-tools']) / 'loom/src/loom/tools'
old_compiler = Path(tags['codec-jpeg-unsigned-opt']) / 'loom/src/loom/tools/loom-compile/loom-compile'
compiler = tools / 'loom-compile/loom-compile'
objdump = '/home/ben/tools/llvm/latest/bin/llvm-objdump'
objcopy = '/home/ben/tools/llvm/latest/bin/llvm-objcopy'


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


previous_stage = json.loads((previous / 'stage.json').read_text())
for name, expected in previous_stage['files'].items():
    assert digest(previous / name) == expected, name
source = notes / 'device_float_pipeline.cxx'
assert digest(source) == previous_stage['source_sha256']
old_identity = next(row for row in json.loads((notes / 'unsigned-assumption-size.json').read_text())
                    if row['tag'] == 'codec-jpeg-unsigned-opt')
assert digest(old_compiler) == old_identity['sha256']
sources = {}


def retain_sources(path):
    if path.name in sources:
        return
    sources[path.name] = digest(path)
    for name in re.findall(r'^#include "([^"]+)"', path.read_text(), re.M):
        retain_sources(path.parent / name)


retain_sources(source)
for name in ('summary.loom', 'bindings.txt', 'config.json'):
    shutil.copyfile(previous / name, candidate / name)
commands = [
    [str(tools / 'loom-import-cxx/loom-import-cxx'), str(source),
     '--output=' + str(candidate / 'library.loom')],
    [str(tools / 'loom-link/loom-link'), str(candidate / 'summary.loom'),
     str(candidate / 'library.loom'), '--to=bc',
     '--output=' + str(candidate / 'summary.loombc')],
]
for command in commands:
    subprocess.run(command, check=True)
stage = dict(previous_stage)
stage['files'] = dict(previous_stage['files'])
for name in ('summary.loom', 'bindings.txt', 'config.json', 'library.loom', 'summary.loombc'):
    stage['files'][name] = digest(candidate / name)
stage['sources'] = sources
stage['build'] = json.loads((notes / 'current-probe-opt-build.json').read_text())
(candidate / 'stage.json').write_text(json.dumps(stage, indent=2) + '\n')
(notes / 'connected-requalified-stage.json').write_text(json.dumps(stage, indent=2) + '\n')
roots = list(dict.fromkeys(re.findall(r'kernel.launch @(\w+)', (candidate / 'summary.loom').read_text())))
records = {'source_hashes': sources, 'stage': stage, 'commands': commands,
           'compiler_hashes': {'baseline': digest(old_compiler), 'candidate': digest(compiler)},
           'leaves': {}}
receipt = notes / 'connected-requalified-native.json'
for name in roots:
    rows = {}
    for role, tool, fixture in (('baseline', old_compiler, previous),
                               ('candidate', compiler, candidate)):
        output = native / (name + '-' + role)
        report = output.with_suffix('.report.json')
        binary = output.with_suffix('.hsaco')
        text_section = output.with_suffix('.text')
        command = [str(tool), str(fixture / 'summary.loombc'), '--root=' + name,
                   '--target=amdgpu:gfx1151', '--config-file=' + str(fixture / 'config.json'),
                   '--output=' + str(binary), '--compile-report=details',
                   '--compile-report-output=' + str(report)]
        records['commands'].append(command)
        subprocess.run(command, check=True)
        assembly = subprocess.check_output([objdump, '-d', '--mcpu=gfx1151', str(binary)], text=True)
        output.with_suffix('.native.s').write_text(assembly)
        subprocess.run([objcopy, '--dump-section=.text=' + str(text_section), str(binary)], check=True)
        row = json.loads(report.read_text())['entries']['rows'][0]
        rows[role] = {'binary_sha256': digest(binary), 'text_sha256': digest(text_section),
                      'instruction_histogram': dict(sorted(Counter(re.findall(
                          r'^\s+(\w+)\s+[^\n]*//', assembly, re.M)).items())),
                      'resources': {key: row[key] for key in
                                    ('instruction_count', 'code_byte_count', 'private_memory_bytes',
                                     'local_memory_bytes', 'target_resources')}}
    rows['identical_text'] = rows['baseline']['text_sha256'] == rows['candidate']['text_sha256']
    records['leaves'][name] = rows
    receipt.write_text(json.dumps(records, indent=2) + '\n')
    print(name, json.dumps({key: value if key == 'identical_text' else value['resources']
                           for key, value in rows.items()}), flush=True)
