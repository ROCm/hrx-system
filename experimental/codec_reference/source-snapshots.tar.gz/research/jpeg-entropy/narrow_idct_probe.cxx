#include "device_narrow_pipeline.cxx"

[[loom::config("jpeg.probe_blocks")]] extern const unsigned probe_blocks;
static loom::kernel::configuration configure_probe() {
  unsigned threads = loom::target::subgroup::size();
  return {{probe_blocks / threads, 1, 1}, {threads, 1, 1}};
}
[[loom::kernel(configure_probe)]]
void idct_probe(const short* input, const unsigned* quantization, unsigned* pixels) {
  unsigned threads = loom::kernel::workgroup::size.x;
  unsigned lane = loom::kernel::workitem::id.x;
  unsigned first = loom::kernel::workgroup::id.x * threads;
  unsigned coefficient_stride = threads + 2;
  auto* coefficients = loom::buffer::alloca<short, loom::memory_space::workgroup, 16>(coefficient_stride * 64);
  bool any_ac = false;
  [[loom::unroll]]
  for (unsigned index = 0; index < 64; ++index) {
    short value = input[(first + lane) * 64 + index];
    coefficients[index * coefficient_stride + lane] = value;
    if (index != 0 && value != 0) any_ac = true;
  }
  loom::kernel::barrier<loom::memory_space::workgroup,
      loom::atomic::scope::subgroup, loom::atomic::ordering::acq_rel>();
  for (unsigned round = 0; round < 8; ++round) {
    unsigned owner = round * (threads / 8) + lane / 8;
    reconstruct_cooperative(coefficients, coefficient_stride, threads, lane,
        owner, true, any_ac, (first + lane) * 16,
        quantization + (first + owner) * 64, pixels);
  }
}
