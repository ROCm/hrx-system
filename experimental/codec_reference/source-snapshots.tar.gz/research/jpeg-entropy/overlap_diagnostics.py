"""Bound the measured fixed-role loss without changing the decoder control."""
import json
import os
from pathlib import Path
import re

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
baseline = (notes / 'device_reconstruct_twolevel.cxx').read_text()
padded = baseline.replace('16>(coefficient_stride * 64);',
                          '16>(coefficient_stride * 128 + threads * 8 + 8);')
assert padded != baseline
(notes / 'device_reconstruct_padded.cxx').write_text(padded)
pipeline = (notes / 'device_twolevel_pipeline.cxx').read_text()
original = baseline.replace('#include "device_entropy_cursor.h"', '')
assert pipeline.count(original) == 1
(notes / 'device_padded_pipeline.cxx').write_text(pipeline.replace(
    original, padded.replace('#include "device_entropy_cursor.h"', '')))

overlap = (notes / 'device_reconstruct_overlap.cxx').read_text()
counted = overlap.replace('static LOOM_FORCE_INLINE unsigned wait_slot(',
'''struct SlotObservation {
  // Publication state observed by the whole subgroup.
  unsigned state;
  // Atomic observations, including the successful one.
  unsigned polls;
};
static LOOM_FORCE_INLINE SlotObservation wait_slot(''')
counted = counted.replace('  unsigned state = 0;\n  do {',
                          '  unsigned state = 0;\n  unsigned polls = 0;\n  do {\n    ++polls;')
counted = counted.replace('  return state;\n}', '  return {state, polls};\n}')
counted = counted.replace('unsigned* pixels, unsigned* status) {',
                          'unsigned* pixels, unsigned* status, unsigned* statistics) {')
counted = counted.replace('  unsigned sequence = 0;', '  unsigned sequence = 0;\n  unsigned polls = 0;')
counted = counted.replace('wait_slot(control + slot * 2, lane, threads, true);',
                          'polls += wait_slot(control + slot * 2, lane, threads, true).polls;')
counted = counted.replace('wait_slot(control + final_slot * 2, lane, threads, true);',
                          'polls += wait_slot(control + final_slot * 2, lane, threads, true).polls;')
counted = counted.replace('unsigned token = wait_slot(control + slot * 2, lane, threads, false);',
'''SlotObservation observation = wait_slot(control + slot * 2, lane, threads, false);
      polls += observation.polls;
      unsigned token = observation.state;''')
assert counted.endswith('  }\n}\n')
counted = counted[:-2] + '''  if (lane == 0) {
    unsigned group = segment * group_count + loom::kernel::workgroup::id.x;
    unsigned role = loom::kernel::subgroup::id();
    statistics[group * 4 + role * 2] = polls;
    statistics[group * 4 + role * 2 + 1] = sequence;
  }
}
'''
(notes / 'device_reconstruct_counted.cxx').write_text(counted)
pipeline = (notes / 'device_overlap_pipeline.cxx').read_text()
original = overlap.replace('#include "device_entropy_cursor.h"', '')
assert pipeline.count(original) == 1
(notes / 'device_counted_pipeline.cxx').write_text(pipeline.replace(
    original, counted.replace('#include "device_entropy_cursor.h"', '')))

# One bounded full-batch output captures polling, not a new production ABI.
base = root / 'twolevel-batch16-1024'
fixture = root / 'counted-input-batch16-1024'
fixture.mkdir(exist_ok=True)
text = (base / 'summary.loom').read_text()
text = re.sub(r'check.file.read.npy path\("([^"]+)"\)',
              lambda m: 'check.file.read.npy path("' + os.path.relpath((base / m[1]).resolve(), fixture) + '")', text)
text = text.replace('%pixels: buffer, %status: buffer)',
                    '%pixels: buffer, %status: buffer, %statistics: buffer)')
configuration = json.loads((base / 'config.json').read_text())
count = configuration['jpeg']['chunks']
segments = configuration['jpeg']['segments']
partitions = configuration['jpeg']['output_partitions']
groups = (count * (partitions + 1) + segments + 32 * segments - 1) // (32 * segments)
statistics_count = groups * segments * 4
text = text.replace('  kernel.launch @jpeg_speculate(',
                    f'  %statistics = check.generate.fill value(-1) : tensor<{statistics_count}xi32>\n  kernel.launch @jpeg_speculate(')
text = text.replace('%pixels_output, %status_output)', '%pixels_output, %status_output, %statistics)')
lines = text.splitlines()
for index, line in enumerate(lines):
    if line.startswith('  kernel.launch @jpeg_reconstruct('):
        assert line.endswith(')')
        lines[index] = line[:-1] + f', tensor<{statistics_count}xi32>)'
text = '\n'.join(lines) + '\n'
text = text.replace('  check.return',
                    f'  check.file.write.npy value(%statistics) path("overlap-statistics.npy") mode(always) : tensor<{statistics_count}xi32>\n  check.return')
(fixture / 'summary.loom').write_text(text)
(fixture / 'config.json').write_bytes((base / 'config.json').read_bytes())
(fixture / 'stage.json').write_bytes((base / 'stage.json').read_bytes())
print(json.dumps({'groups': groups, 'segments': segments, 'statistics_bytes': statistics_count * 4}))
