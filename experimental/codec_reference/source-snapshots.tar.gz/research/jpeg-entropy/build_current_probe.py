"""Capture current compiler/caller artifacts without changing the runtime."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

notes = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--config', choices=('asan', 'opt'), required=True)
parser.add_argument('--tag')
parser.add_argument('--receipt', type=Path)
parser.add_argument('--caller-only', action='store_true')
parser.add_argument('--source', type=Path)
arguments = parser.parse_args()
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True)
build = Path('loom/src/loom/tooling/target/amdgpu/serve/BUILD.bazel')
source = build.parent / 'codec_command_probe.cc'
assert not source.exists()
original = build.read_bytes()
probe = (arguments.source or notes / 'command_probe.cc').read_bytes()
target = b'''
loom_cc_binary(
    name = "codec_command_probe",
    testonly = True,
    srcs = ["codec_command_probe.cc"],
    deps = [
        ":test_compiler",
        ":test_device",
        "//loom/binding/c:loomc",
        "//loom/src/loom/serve/runtime/device",
        "//loom/src/loom/serve/runtime/execution",
        "//loom/src/loom/serve/runtime/host",
        "//loom/src/loom/serve/runtime/program:jit",
        "//loom/src/loom/serve/testing:compiler",
        "//loom/src/loom/serve/testing:device",
        "//runtime/src/iree/base",
        "//runtime/src/iree/base/tooling:flags",
        "//runtime/src/iree/hal",
        "//runtime/src/iree/hal/utils:statistics_sink",
        "//runtime/src/iree/testing:gtest",
        "//runtime/src/iree/testing:gtest_main",
    ],
)
'''
overlay = original + target
tag = arguments.tag or ('codec-jpeg-rebased-tools' if arguments.config == 'opt'
                       else 'codec-jpeg-rebased-checks')
labels = ['//loom/src/loom/tooling/target/amdgpu/serve:codec_command_probe',
          '//loom/src/loom/tools/iree-test-loom']
if arguments.config == 'opt':
    labels += ['//loom/src/loom/tools/' + name for name in
               ('loom-import-cxx', 'loom-link', 'loom-compile', 'iree-benchmark-loom')]
if arguments.caller_only:
    labels = labels[:1]
command = ['bureau-bazel', 'build', '--tag=' + tag,
           '--config=' + arguments.config] + labels
record = {
    'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'tag': tag, 'configuration': arguments.config, 'command': command,
    'source_sha256': hashlib.sha256(probe).hexdigest(),
    'build_original_sha256': hashlib.sha256(original).hexdigest(),
    'build_overlay_sha256': hashlib.sha256(overlay).hexdigest(),
    'runtime_modified': False, 'restored': False,
}
receipt = arguments.receipt or notes / ('current-probe-' + arguments.config + '-build.json')
receipt.write_text(json.dumps(record, indent=2) + '\n')
build.write_bytes(overlay)
source.write_bytes(probe)
try:
    result = subprocess.run(command)
    record['build_returncode'] = result.returncode
finally:
    assert build.read_bytes() == overlay
    assert source.read_bytes() == probe
    build.write_bytes(original)
    source.unlink()
    record['restored'] = True
    receipt.write_text(json.dumps(record, indent=2) + '\n')
assert result.returncode == 0
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True)
record['capture'] = json.loads(subprocess.check_output(
    ['bureau-bazel', 'tag', 'inspect', tag, '--json'], text=True))
receipt.write_text(json.dumps(record, indent=2) + '\n')
