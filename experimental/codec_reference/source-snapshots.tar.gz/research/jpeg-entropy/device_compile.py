"""Compile the bounded CXX experiment using one leased tool set."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

notes = Path(__file__).resolve().parent
directory = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
root = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['codec-jpeg-device-tools'])
tools = {name: root / 'loom/src/loom/tools' / name / name
         for name in ('loom-import-cxx', 'loom-link', 'loom-compile')}
commands = [
    [str(tools['loom-import-cxx']), str(notes / 'device_entropy.cxx'),
     '--output=' + str(directory / 'entropy.loom')],
    [str(tools['loom-link']), str(directory / 'entropy.loom'), '--to=bc',
     '--output=' + str(directory / 'entropy.loombc')],
    [str(tools['loom-compile']), str(directory / 'entropy.loombc'),
     '--root=jpeg_speculate', '--target=amdgpu:gfx1151',
     '--config-file=' + str(directory / 'ycbcr_420-scan0-chunk32.json'),
     '--output=' + str(directory / 'speculate.hsaco'), '--compile-report=details',
     '--compile-report-output=' + str(notes / 'device-first-report.json')],
]
for command in commands:
    subprocess.run(command, check=True)
receipt = {'commands': commands, 'files': {
    str(path): {'bytes': path.stat().st_size,
                'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    for path in [notes / 'device_entropy.cxx', directory / 'entropy.loombc',
                 directory / 'speculate.hsaco', *tools.values()]}}
(notes / 'device-compile.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'state': 'compiled, not executed', 'artifact_bytes':
                  (directory / 'speculate.hsaco').stat().st_size}), flush=True)
