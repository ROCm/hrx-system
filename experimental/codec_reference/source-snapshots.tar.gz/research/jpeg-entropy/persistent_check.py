"""Stage only the leased checker, pinned ROCr closure, and one small fixture."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import tarfile

parser = argparse.ArgumentParser()
parser.add_argument('--case', default='rows3-workers1')
parser.add_argument('--stage-only', action='store_true')
parser.add_argument('--tag', default='codec-jpeg-rebased-checks')
parser.add_argument('--host', choices=('noxa-sharkbox', 'hrx-gorgon-3'), default='noxa-sharkbox')
parser.add_argument('--command', action='store_true')
arguments = parser.parse_args()
notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory']) / 'persistent'
host = arguments.host
gorgon = host == 'hrx-gorgon-3'
remote = Path('/tmp/codec-jpeg-persistent-20261019' if gorgon else '/tmp/codec-gfx1100-oc5uvhRq/persistent')
receipt_prefix = 'persistent-' + (host + '-' if gorgon else '') + arguments.case
if arguments.command:
    receipt_prefix += '-command'
tags = json.loads(os.environ['BUREAU_TAG_ROOTS'])
runner_name = 'codec_command_probe' if arguments.command else 'iree-test-loom'
runner_relative = ('loom/src/loom/tooling/target/amdgpu/serve/codec_command_probe'
                   if arguments.command else 'loom/src/loom/tools/iree-test-loom/iree-test-loom')
runner = Path(tags[arguments.tag]) / runner_relative
files = {runner_name: runner,
         'persistent_window.py': notes / 'persistent_window.py',
         'sharkbox_window.py': notes / 'sharkbox_window.py'}
closure = json.loads((notes / 'noxa-sharkbox-stage.json').read_text())['closure']['files']
for name, metadata in closure.items():
    path = Path('/tmp/codec-gfx1100-y90vg6rv/lib') / name
    assert hashlib.sha256(path.read_bytes()).hexdigest() == metadata['sha256']
    files['lib/' + name] = path
for path in (root / arguments.case).iterdir():
    if path.is_file():
        files[arguments.case + '/' + path.name] = path
manifest = {'case': arguments.case, 'host': host, 'directory': str(remote),
            'runner_tag': arguments.tag,
            'scope': json.loads((root / arguments.case / 'fixture.json').read_text())['scope'],
            'files': {name: {'bytes': path.stat().st_size,
                             'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
                      for name, path in files.items()}}
assert sum(row['bytes'] for row in manifest['files'].values()) < 256 * 1024 * 1024
manifest_path = root / 'check-manifest.json'
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
files['manifest.json'] = manifest_path
subprocess.run(['ssh', host, shlex.join(['mkdir', '-p', str(remote)])], check=True)
inventory = '''import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]);expected=json.load(sys.stdin);changed=[]
for name,row in expected.items():
 path=root/name
 if not path.is_file() or path.stat().st_size!=row['bytes']:
  changed.append(name)
 else:
  with path.open('rb') as f: digest=hashlib.file_digest(f,'sha256').hexdigest()
  if digest!=row['sha256']: changed.append(name)
print(json.dumps(changed))
'''
observed = subprocess.run(['ssh', host, shlex.join(['python3', '-B', '-c', inventory, str(remote)])],
                          input=json.dumps(manifest['files']), capture_output=True, text=True, check=True)
changed = set(json.loads(observed.stdout)) | {'manifest.json'}
print(json.dumps({'phase': 'transfer', 'host': host,
                  'uncompressed_bytes': sum(files[name].stat().st_size for name in changed)}), flush=True)
process = subprocess.Popen(['ssh', host, shlex.join(['tar', '-xzf', '-', '-C', str(remote)])], stdin=subprocess.PIPE)
with tarfile.open(fileobj=process.stdin, mode='w|gz', compresslevel=1) as archive:
    for relative, path in files.items():
        if relative in changed:
            archive.add(path.resolve(), arcname=relative, recursive=False)
process.stdin.close()
assert process.wait() == 0
(notes / (receipt_prefix + '-manifest.json')).write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'staged_bytes': sum(row['bytes'] for row in manifest['files'].values()), 'case': arguments.case}), flush=True)
if arguments.stage_only:
    raise SystemExit(0)
remote_command = ['python3', '-B', str(remote / 'persistent_window.py'), '--window', arguments.case]
if gorgon:
    remote_command.append('--gorgon')
if arguments.command:
    remote_command.append('--command')
command = ['ssh', host, shlex.join(remote_command)]
log = notes / (receipt_prefix + '-window.log')
with log.open('w') as output:
    result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
print(log.read_text()[-14000:], flush=True)
for name in ('window.json', 'result.json'):
    fetched = subprocess.run(['scp', host + ':' + str(remote / arguments.case / name),
                             str(notes / (receipt_prefix + '-' + name))])
    if fetched.returncode:
        print('Receipt unavailable:', name, flush=True)
if arguments.command or 'check.file.write.npy' in (root / arguments.case / 'check.loom').read_text():
    fetched = subprocess.run(['scp', '-r', host + ':' + str(remote / arguments.case / 'actual'),
                              str(root / arguments.case)])
    if fetched.returncode:
        print('Native output capture unavailable; see the execution receipt.', flush=True)
        if result.returncode == 0:
            raise SystemExit(fetched.returncode)
raise SystemExit(result.returncode)
