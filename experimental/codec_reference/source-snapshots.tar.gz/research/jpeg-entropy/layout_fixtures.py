"""Expose the already parsed MCU layout as configuration, reusing all arrays."""
import hashlib
import json
import os
from pathlib import Path
import re

from device_fixture import read_words

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
pattern = re.compile(r'check.file.read.npy path\("([^"]+)"\)')


def configuration(config_path, scenario_path):
    text = scenario_path.read_text()
    match = re.search(r'%blocks = check.file.read.npy path\("([^"]+)"\)', text)
    blocks = read_words((scenario_path.parent / match[1]).resolve())
    config = json.loads(config_path.read_text())
    assert len(blocks) == config['jpeg']['blocks'] and 1 <= len(blocks) <= 10
    words = [0, 0, 0]
    for index, descriptor in enumerate(blocks):
        component, dc, ac = descriptor & 255, (descriptor >> 8) & 255, descriptor >> 16
        assert component < config['jpeg']['components'] <= 4
        assert dc < config['jpeg']['table_count'] <= 8 and ac < config['jpeg']['table_count']
        packed = component | (dc << 2) | (ac << 5)
        words[index // 4] |= packed << ((index % 4) * 8)
    for index, word in enumerate(words):
        config['jpeg']['layout' + str(index)] = word
    return config


def scenario(source, destination):
    paths = {}
    def relocate(match):
        path = (source.parent / match[1]).resolve()
        paths[str(path.relative_to(root))] = hashlib.sha256(path.read_bytes()).hexdigest()
        return 'check.file.read.npy path("' + os.path.relpath(path, destination.parent) + '")'
    destination.write_text(pattern.sub(relocate, source.read_text()))
    return paths


for family in ('small', 'large'):
    original = root / ('partitions4-' + family)
    output = root / ('layout-' + family)
    output.mkdir(exist_ok=True)
    metadata = json.loads((original / 'fixtures.json').read_text())
    paths = {}
    for case in metadata['cases']:
        key = case['key']
        config = configuration(original / (key + '.json'), original / (key + '.loom'))
        (output / (key + '.json')).write_text(json.dumps(config, indent=2) + '\n')
        paths.update(scenario(original / (key + '.loom'), output / (key + '.loom')))
    (output / 'fixtures.json').write_text(json.dumps(metadata, indent=2) + '\n')
    paths.update({str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
                  for path in output.iterdir() if path.is_file()})
    (root / (output.name + '-stage.json')).write_text(json.dumps({'files': paths}, indent=2) + '\n')
    print(family, len(metadata['cases']), flush=True)

original = root / 'compact-batch16-1024'
output = root / 'layout-input-batch16-1024'
output.mkdir(exist_ok=True)
paths = scenario(original / 'summary.loom', output / 'summary.loom')
config = configuration(original / 'config.json', original / 'summary.loom')
batch_config = config
(output / 'config.json').write_text(json.dumps(config, indent=2) + '\n')
stage = json.loads((original / 'stage.json').read_text())
stage['files'] = {os.path.relpath(root / name, output): digest for name, digest in paths.items()}
stage['files'].update({path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                      for path in output.iterdir() if path.is_file() and path.name != 'stage.json'})
(output / 'stage.json').write_text(json.dumps(stage, indent=2) + '\n')

original = root / 'certified-malformed'
output = root / 'layout-malformed-config'
output.mkdir(exist_ok=True)
for case in json.loads((original / 'stage.json').read_text())['cases']:
    key = case['key']
    config = configuration(original / (key + '.json'), original / (key + '.loom'))
    (output / (key + '.json')).write_text(json.dumps(config, indent=2) + '\n')
manifest = {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
            for path in output.iterdir() if path.is_file() and path.name != 'manifest.json'}
(output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(notes / 'layout-fixtures.json').write_text(json.dumps({
    'scope': 'Header-only MCU layout configuration; all original expected arrays reused.',
    'batch_config': batch_config,
    'sources': {name: hashlib.sha256((notes / name).read_bytes()).hexdigest()
                for name in ('layout_fixtures.py', 'layout_source.py', 'device_entropy_cursor_layout.h')}}, indent=2) + '\n')
