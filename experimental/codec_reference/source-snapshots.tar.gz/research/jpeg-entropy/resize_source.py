"""Bounded experimental row consumer; preserve the pinned entropy implementation."""
import hashlib
import json
from pathlib import Path
import re

NOTES = Path(__file__).resolve().parent
ROOT = Path(json.loads((NOTES / 'device-active.json').read_text())['directory'])
OUTPUT = ROOT / 'persistent-resize/source'
OUTPUT.mkdir(parents=True, exist_ok=True)
base = ROOT / 'persistent/connected'
source = (base / 'persistent.cxx').read_text()
assert hashlib.sha256(source.encode()).hexdigest() == json.loads(
    (NOTES / 'persistent-connected-checkpoint.json').read_text())['source_sha256']
# Keep the exact old frontend, reconstruction helper, and queue contract.
source = source[:source.index('static loom::kernel::configuration configure_stream_workers()')]
helpers = source[source.index('LOOM_FORCE_INLINE unsigned stream_color_divide_up'):
                 source.index('template<', source.index('struct StreamColorGeometry'))]
helpers = helpers.replace('stream_color_', 'filter_color_')
helpers = helpers.replace('dimensions, 64, horizontal', 'dimensions, 128, horizontal')
helpers = helpers.replace('dimensions, 8, vertical', 'dimensions, 1, vertical')
native = (NOTES / 'resize_native.cxx').read_text()
cases = ((1,1,1,1,1,1,1),(2,1,1,1,1,1,1),(3,1,1,1,1,1,1),
         (3,1,1,2,1,2,1),(3,1,1,2,2,2,2),(3,1,1,1,2,1,2),
         (3,1,1,4,1,4,1),(3,1,1,4,2,4,2))
native = native.replace('RESIZE_COLOR_SPECIALIZATIONS', '\n  '.join(
    f'if (image.color_kind == {kind}) resize_horizontal<{", ".join(map(str, values))}>(components, image, plan, indices, weights, tile, y, horizontal, storage);'
    for kind, values in enumerate(cases, 1)))
inputs = ['tables','blocks','geometry','quantization','zigzag','images','plans','compressed',
          'resize_plans','filter_indices','filter_weights','filter_tiles']
outputs = ['entropy','segments','intervals','pixels','streams','heads','pending','decoded',
           'color_claimed','color_done','links','cursors','records','prefixes','errors',
           'schedule','jobs','expected','points','bridges','suffixes','ranges',
           'horizontal','provisional','resize_rows','resize_claimed','resize_done','resized','validity']
directory = inputs + outputs
front = ['jpeg_classify_bytes','jpeg_prefix_bytes','jpeg_plan_jobs','jpeg_compact_bytes',
         'jpeg_speculate','jpeg_bridge','jpeg_index','jpeg_certify','jpeg_intervals']
entries = []
def wrap(match):
    configure, name, signature = match.groups()
    entries.append((configure, name, signature))
    return f'static LOOM_FORCE_INLINE void {name}_body({signature}) {{'
native = re.sub(r'\[\[loom::kernel\((\w+)\)\]\]\s*void (jpeg_\w+)\(([^)]*)\)\s*\{',wrap,native)
assert len(entries) == 3
for name in front:
    match = re.search(r'static LOOM_FORCE_INLINE void '+name+r'_body\(([^)]*)\)',source)
    assert match, name
    original = (ROOT / 'mixed-current/mixed_pipeline.cxx').read_text()
    configure = re.search(r'\[\[loom::kernel\((\w+)\)\]\]\s*void '+name+r'\(',original)[1]
    entries.append((configure,name,match[1]))
old_layout = json.loads((base / 'directory.json').read_text())
old_schedule = (old_layout['inputs'] + old_layout['outputs']).index('schedule')
source = source.replace(f'output + input[{old_schedule}] / 4', f'output + input[{directory.index("schedule")}] / 4')
source += '\n' + helpers + '\n' + native + '''
static LOOM_FORCE_INLINE unsigned resize_offset(const unsigned* input, unsigned index) {
  unsigned offset = loom::kernel::subgroup::broadcast_first(input[index]);
  loom::assume(offset < 1073741824u);
  loom::assume(loom::predicate::multiple_of(offset, 16u));
  return offset / 4;
}
'''
for configure,name,signature in entries:
    args=[]
    for parameter in signature.split(','):
        spelling, variable = parameter.strip().rsplit('*',1)
        variable = {'headers':'images','summaries':'expected'}.get(variable.strip(),variable.strip())
        owner='input' if variable in inputs else 'output'
        args.append(f'reinterpret_cast<{spelling.strip()}*>({owner}+resize_offset(input,{directory.index(variable)}))')
    source += f'\n[[loom::kernel({configure})]]\nvoid {name}(const unsigned* input, unsigned* output) {{\n  {name}_body({", ".join(args)});\n}}\n'
configurations = {name:configure for configure,name,_ in entries}
declarations=[]; launches=[]
for name in front + ['jpeg_resize_init','jpeg_resize_stream','jpeg_resize_publish']:
    dynamic=configurations[name] in ('configure_chunks','configure_bridges')
    configuration='%launch_input: buffer, %input_offset: offset, %launch_output: buffer, %output_offset: offset' if dynamic else ''
    declarations.append(f'kernel.decl @{name}({configuration}) launch(%input: buffer, %output: buffer)')
    values='[%input, %zero, %output, %zero]' if dynamic else ''
    types='[buffer, offset, buffer, offset]' if dynamic else ''
    launches.append(f'    kernel.launch @{name}{values}(%input, %output) : {types}(buffer, buffer)')
program='\n'.join(declarations)+'''\n
command.program.def public @jpeg_decode() launch(%input: buffer, %output: buffer) {
  %zero = index.constant 0 : offset
  command.serial {
'''+ '\n'.join(launches)+'''\n  }
  command.return
}
'''
(OUTPUT/'resize.cxx').write_text(source)
(OUTPUT/'command.loom').write_text(program)
(OUTPUT/'directory.json').write_text(json.dumps({'inputs':inputs,'outputs':outputs},indent=2)+'\n')
for name in ('mixed_cursor.h','mixed_image.h'):
    (OUTPUT/name).write_bytes((base/name).read_bytes())
print(json.dumps({'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'directory':str(OUTPUT)}))
