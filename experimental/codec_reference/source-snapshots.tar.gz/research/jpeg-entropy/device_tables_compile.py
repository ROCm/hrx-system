"""Compile paired global/LDS table specializations of one experimental source."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
tags = json.loads(os.environ['BUREAU_TAG_ROOTS'])
importer = Path(tags['codec-jpeg-rebased-tools']) / 'loom/src/loom/tools/loom-import-cxx/loom-import-cxx'
linker = Path(tags['codec-jpeg-rebased-tools']) / 'loom/src/loom/tools/loom-link/loom-link'
compiler = Path(tags['codec-jpeg-unsigned-opt']) / 'loom/src/loom/tools/loom-compile/loom-compile'
commands = [
    [str(importer), str(notes / 'device_entropy_tables.cxx'), '--output=' + str(root / 'entropy-tables.loom')],
    [str(linker), str(root / 'entropy-tables.loom'), '--to=bc', '--output=' + str(root / 'entropy-tables.loombc')],
]
for command in commands:
    subprocess.run(command, check=True)
rows = []
for cache in (0, 1):
    prefix = 'entropy-tables-' + str(cache)
    command = [str(compiler), str(root / 'entropy-tables.loombc'), '--root=jpeg_speculate',
               '--target=amdgpu:gfx1151', '--config-file=' + str(root / 'batch16/config.json'),
               '--config=jpeg.table_count=4', '--config=jpeg.cache_tables=' + str(cache),
               '--output=' + str(root / (prefix + '.hsaco')), '--compile-report=details',
               '--compile-report-output=' + str(root / (prefix + '-report.json'))]
    subprocess.run(command, check=True)
    commands.append(command)
    entry = json.loads((root / (prefix + '-report.json')).read_text())['entries']['rows'][0]
    rows.append({'cache_tables': cache,
                 'artifact_sha256': hashlib.sha256((root / (prefix + '.hsaco')).read_bytes()).hexdigest(),
                 'metrics': {k: entry[k] for k in ('instruction_count', 'code_byte_count',
                                                'private_memory_bytes', 'local_memory_bytes',
                                                'target_resources', 'move_causes')}})
    print(json.dumps(rows[-1]), flush=True)
result = {'commands': commands,
          'source_sha256': hashlib.sha256((notes / 'device_entropy_tables.cxx').read_bytes()).hexdigest(),
          'compiler_sha256': hashlib.sha256(compiler.read_bytes()).hexdigest(),
          'bytecode_sha256': hashlib.sha256((root / 'entropy-tables.loombc').read_bytes()).hexdigest(),
          'rows': rows}
(notes / 'device-tables-code.json').write_text(json.dumps(result, indent=2) + '\n')
