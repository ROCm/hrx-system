"""Retain the current immutable block descriptor across entropy transitions."""
from pathlib import Path

notes=Path(__file__).resolve().parent
header=(notes/'device_entropy_cursor_short.h').read_text()
certified=(notes/'device_entropy_cursor_certified.h').read_text()
header+='\n'+certified[certified.index('// The restart-rooted certificate'):]
old='''  // Next coefficient in zigzag order; zero starts a DC codeword.
  unsigned coefficient;'''
new='''  // Immutable layout/table descriptor for block_index, retained until completion.
  unsigned block_descriptor;
  // Next coefficient in zigzag order; zero starts a DC codeword.
  unsigned coefficient;'''
assert header.count(old)==1
header=header.replace(old,new)
old='  unsigned descriptor = blocks[block_index];'
assert header.count(old)==3
header=header.replace(old,'  unsigned descriptor = cursor.block_descriptor;')
old='        if (cursor.block_index == blocks_per_mcu) cursor.block_index = 0;'
assert header.count(old)==1
header=header.replace(old,old+'\n        cursor.block_descriptor = blocks[cursor.block_index];')
old='      cursor.block_index &= wrap_mask;'
assert header.count(old)==2
header=header.replace(old,old+'\n      cursor.block_descriptor = blocks[cursor.block_index];')
(notes/'device_entropy_cursor_block_state.h').write_text(header)
speculate=(notes/'device_entropy_partitioned.cxx').read_text()
old='  Cursor cursor = {};'
assert speculate.count(old)==1
speculate=speculate.replace(old,old+'\n  cursor.block_descriptor = blocks[0];')
old='      cursor.block_index = 0;'
assert speculate.count(old)==1
speculate=speculate.replace(old,old+'\n      cursor.block_descriptor = blocks[0];')
bridge=(notes/'device_bridge.cxx').read_text()
old='  cursor.block_index = start_phase >> 6;'
assert bridge.count(old)==1
bridge=bridge.replace(old,old+'\n  cursor.block_descriptor = blocks[cursor.block_index];')
reconstruct=(notes/'device_reconstruct_certified.cxx').read_text()
old='      cursor.block_index = entry[3] >> 6;'
assert reconstruct.count(old)==1
reconstruct=reconstruct.replace(old,old+'\n      cursor.block_descriptor = blocks[cursor.block_index];')
pipeline='#include "device_entropy_cursor_block_state.h"\n'
pipeline+='''[[loom::config("jpeg.output_partitions"), loom::where(loom::predicate::range(2u, 8u))]]
extern const unsigned output_partitions;
'''
for source in (speculate,bridge,(notes/'device_certify_partitioned.cxx').read_text(),reconstruct):
    pipeline+='\n'+source.replace('#include "device_entropy_cursor.h"','')+'\n'
(notes/'device_block_state_pipeline.cxx').write_text(pipeline)
