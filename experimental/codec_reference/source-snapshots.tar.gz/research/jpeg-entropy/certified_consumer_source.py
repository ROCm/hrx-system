"""Consume the existing certificate frontier instead of revalidating its prefix."""
from pathlib import Path

notes = Path(__file__).resolve().parent
source = (notes / 'device_reconstruct_partitioned.cxx').read_text()
old = '''    const unsigned* tables, const unsigned* blocks, unsigned limit, Cursor cursor) {
  Symbol symbol = advance_symbol(words, tables, blocks, limit, cursor);'''
new = '''    const unsigned* tables, const unsigned* blocks, unsigned limit,
    unsigned certified_end, Cursor cursor) {
  Symbol symbol = {};
  if (cursor.position < certified_end) {
    symbol = advance_symbol_certified(words, tables, blocks, cursor);
  } else {
    symbol = advance_symbol(words, tables, blocks, limit, cursor);
  }'''
assert source.count(old) == 1
source = source.replace(old,new)
old = '  const unsigned* words = entropy + descriptor[0];'
new = '''  unsigned certified_end = intervals[
      (first_interval + (output_partitions + 1) * count) * stride];
  const unsigned* words = entropy + descriptor[0];'''
assert source.count(old) == 1
source = source.replace(old,new)
old = 'output_symbol(words, tables, blocks, bit_limit, cursor)'
assert source.count(old) == 2
source = source.replace(old,'output_symbol(words, tables, blocks, bit_limit, certified_end, cursor)')
(notes / 'device_reconstruct_certified.cxx').write_text(source)
pipeline = '#include "device_entropy_cursor_certified.h"\n'
pipeline += '''[[loom::config("jpeg.output_partitions"), loom::where(loom::predicate::range(2u, 8u))]]
extern const unsigned output_partitions;
'''
for name in ('device_entropy_partitioned.cxx','device_bridge.cxx','device_certify_partitioned.cxx','device_reconstruct_certified.cxx'):
    pipeline += '\n'+(notes/name).read_text().replace('#include "device_entropy_cursor.h"','')+'\n'
(notes / 'device_certified_pipeline.cxx').write_text(pipeline)
