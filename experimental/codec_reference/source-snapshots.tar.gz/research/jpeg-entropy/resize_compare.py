"""Interleaved complete-cohort GPU/CPU comparison under one bounded lease."""
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import time

import persistent_window as harness

root=Path(__file__).resolve().parent
manifest=json.loads((root/'run-manifest.json').read_text())
assert manifest['mode']=='bench'
assert os.environ['BENCHMARK_LOCK_LEASE_ID']
before=harness.state()
assert not before['live_kfd'] and not before['native_workers'],before
before['governor']=Path('/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor').read_text().strip()
before['loadavg']=Path('/proc/loadavg').read_text().strip()
before['gpu_power']={str(p):p.read_text().strip() for p in Path('/sys/class/drm').glob('card*/device/power_dpm_force_performance_level')}
assert before['governor']=='performance'
for name,row in manifest['files'].items():
    p=root/name
    assert p.stat().st_size==row['bytes'] and hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==row['sha256'],name
cpu=json.loads((root/'cpu-manifest.json').read_text())
for name,row in cpu['files'].items():
    p=root/name
    assert p.stat().st_size==row['bytes'] and hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==row['sha256'],name
case=root/manifest['case']
images=['012mp-bus.jpg.r0.jpg','006mp-cathedral.jpg.r0.jpg','synthetic-1024.jpg.r0.jpg','synthetic-256.jpg.r0.jpg']
record={'before':before,'manifest':manifest,'cpu':cpu,'rows':[],
        'scope':'Both sides complete 128 decode/resize operations before one completion, retain 16 final outputs, and use identical filter weight bytes. GPU has compressed input resident, CPU includes codec and temporary-workspace allocation. Final output/guards checked before and after timing. Distinct IDCT policies retain independent native model-filter hashes.'}
path=root/'comparison.json'
for ordinal,policy in enumerate(('gpu','islow','ifast','gpu','islow','ifast','gpu','profile')):
    if policy in ('gpu','profile'):
        command=[str(root/'codec_command_probe'),'--jpeg_fixture='+str(case),'--jpeg_initial=.',
          '--jpeg_regions=regions.txt','--gtest_filter=JpegCommandTest.CompressedToRgb','--jpeg_repetitions=8',
          '--jpeg_'+('benchmark' if policy=='gpu' else 'profile')+'=true']
    else:
        command=['taskset','-c','0-15',str(root/('jpeg_resize_'+policy)),'bench','16','16','9']+[str(root/'cpu'/name) for name in images]
    started=time.monotonic();result=harness.run_group(command,60)
    row={'policy':policy,'result':result,'wall_seconds':time.monotonic()-started}
    record['rows'].append(row);path.write_text(json.dumps(record,indent=2)+'\n')
    assert result['returncode']==0 and not result.get('harness_timeout'),result
    values=[json.loads(line) for line in result['output'].splitlines() if line.startswith('{')]
    if policy=='profile':
        row['profile']=[v for v in values if v.get('phase')=='profile']
        assert row['profile']
        row['device_total_ms']=sum(v['total_ns'] for v in row['profile'])/1e6
    else:
        value,=[v for v in values if v.get('phase')=='measurement' or v.get('kind')=='timing']
        row['median_ms']=statistics.median(value['batch_ns'])/1e6
        row['measurement']=value
        if policy=='gpu':row['memory']=[v for v in values if v.get('phase')=='memory']
        else:assert value['batch']==16 and value['repeats_per_job']==8 and value['full_rgb_and_guards']
    path.write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({k:v for k,v in row.items() if k not in ('result','profile')}),flush=True)
record['after']=harness.state();assert not record['after']['live_kfd']
path.write_text(json.dumps(record,indent=2)+'\n')
