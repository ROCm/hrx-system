#include <loomcxx/kernel.h>
#include <loomcxx/predicate.h>
#include <loomcxx/target.h>

[[loom::config("jpeg.chunks"), loom::where(loom::predicate::range(1u, 1048576u))]]
extern const unsigned chunks;
[[loom::config("jpeg.chunk_bytes"), loom::where(loom::predicate::range(1u, 65536u))]]
extern const unsigned chunk_bytes;
[[loom::config("jpeg.blocks"), loom::where(loom::predicate::range(1u, 10u))]]
extern const unsigned blocks_per_mcu;
[[loom::config("jpeg.components"), loom::where(loom::predicate::range(1u, 4u))]]
extern const unsigned component_count;

using Predictors = int __attribute__((ext_vector_type(4)));

struct Cursor {
  // Next bit in the unstuffed restart segment.
  unsigned position;
  // Every consumed bit, including invalid-prefix revisits.
  unsigned reads;
  // Maximum permitted reads for this trajectory.
  unsigned budget;
  // Completed blocks since the most recent prefix reset.
  unsigned blocks;
  // Block index within the scan MCU, independent of component identity.
  unsigned block_index;
  // Next coefficient in zigzag order; zero starts a DC codeword.
  unsigned coefficient;
  // Component-relative DC sums since the most recent prefix reset.
  Predictors predictors;
  // Word index of the cached 64-bit lookahead.
  unsigned cached_word;
  // Two adjacent big-endian words, retained across syntax transitions.
  unsigned long long cached_bits;
  // Zero is valid; one is invalid syntax/extent; two exhausts the read cap.
  unsigned error;
};

struct Read {
  // Updated entropy trajectory and cached input words.
  Cursor cursor;
  // Codeword or amplitude bits, interpreted by the transition's syntax.
  unsigned value;
};

static LOOM_FORCE_INLINE unsigned minimum(unsigned left, unsigned right) {
  return left < right ? left : right;
}

static LOOM_FORCE_INLINE Read peek(const unsigned* words, Cursor cursor) {
  unsigned word = cursor.position >> 5;
  if (word != cursor.cached_word) {
    cursor.cached_bits = (static_cast<unsigned long long>(words[word]) << 32) |
                         words[word + 1];
    cursor.cached_word = word;
  }
  return {cursor, static_cast<unsigned>(cursor.cached_bits >> (32 - (cursor.position & 31)))};
}

static LOOM_FORCE_INLINE Read codeword(const unsigned* words,
                                         const unsigned* table, unsigned limit,
                                         Cursor cursor) {
  Read input = peek(words, cursor);
  cursor = input.cursor;
  unsigned bits = input.value;
  unsigned packed = table[bits >> 23];
  unsigned length = packed >> 8;
  unsigned symbol = packed & 255;
  if (length == 0) {
    unsigned prefix = bits >> 16;
    for (unsigned candidate = 10; candidate <= 16 && length == 0; ++candidate) {
      unsigned value = prefix >> (16 - candidate);
      unsigned first = table[512 + candidate * 3];
      unsigned count = table[513 + candidate * 3];
      if (value >= first && value - first < count) {
        unsigned base = table[514 + candidate * 3];
        symbol = table[563 + base + value - first];
        length = candidate;
      }
    }
  }
  unsigned consumed = length ? length : 16;
  unsigned available = limit - cursor.position;
  unsigned remaining = cursor.budget - cursor.reads;
  if (consumed > available || consumed > remaining) {
    unsigned taken = minimum(consumed, minimum(available, remaining));
    cursor.position += taken;
    cursor.reads += taken;
    cursor.error = remaining <= available ? 2 : 1;
  } else {
    cursor.position += consumed;
    cursor.reads += consumed;
    if (length == 0) cursor.error = 1;
  }
  return {cursor, symbol};
}

static LOOM_FORCE_INLINE Read amplitude(const unsigned* words, unsigned count,
                                      unsigned limit, Cursor cursor) {
  int result = 0;
  if (count != 0 && cursor.error == 0) {
    if (count > cursor.budget - cursor.reads) {
      cursor.error = 2;
    } else if (count > limit - cursor.position) {
      cursor.error = 1;
    } else {
      Read input = peek(words, cursor);
      cursor = input.cursor;
      unsigned value = input.value >> (32 - count);
      result = static_cast<int>(value);
      if (value < (1u << (count - 1))) result -= (1u << count) - 1;
      cursor.position += count;
      cursor.reads += count;
    }
  }
  return {cursor, static_cast<unsigned>(result)};
}

static LOOM_FORCE_INLINE Cursor advance(const unsigned* words,
                                     const unsigned* tables,
                                     const unsigned* blocks, unsigned limit,
                                     Cursor cursor) {
  unsigned descriptor = blocks[cursor.block_index];
  unsigned table_index = cursor.coefficient == 0 ? (descriptor >> 8) & 255
                                               : descriptor >> 16;
  Read decoded = codeword(words, tables + table_index * 832, limit, cursor);
  cursor = decoded.cursor;
  unsigned symbol = decoded.value;
  if (cursor.error == 0) {
    if (cursor.coefficient == 0) {
      Read value = amplitude(words, symbol, limit, cursor);
      cursor = value.cursor;
      if (cursor.error == 0) {
        unsigned component = descriptor & 255;
        cursor.predictors[component] += static_cast<int>(value.value);
        cursor.coefficient = 1;
      }
    } else {
      unsigned category = symbol & 15;
      unsigned run = symbol >> 4;
      if (category == 0) {
        if (run == 0) {
          cursor.coefficient = 0;
        } else {
          unsigned next = cursor.coefficient + 16;
          if (next > 64) cursor.error = 1;
          cursor.coefficient = next & 63;
        }
      } else {
        unsigned index = cursor.coefficient + run;
        if (index >= 64) {
          cursor.error = 1;
        } else {
          Read value = amplitude(words, category, limit, cursor);
          cursor = value.cursor;
          cursor.coefficient = (index + 1) & 63;
        }
      }
      if (cursor.error == 0 && cursor.coefficient == 0) {
        ++cursor.blocks;
        ++cursor.block_index;
        if (cursor.block_index == blocks_per_mcu) cursor.block_index = 0;
      }
    }
  }
  return cursor;
}

static loom::kernel::configuration configure_chunks() {
  unsigned threads = loom::target::subgroup::size() * 4;
  return {{(chunks + threads - 1) / threads, 1, 1}, {threads, 1, 1}};
}

[[loom::kernel(configure_chunks)]]
void jpeg_speculate(const unsigned* entropy, const unsigned* jobs,
                    const unsigned* tables, const unsigned* blocks,
                    unsigned* summaries) {
  unsigned job = loom::kernel::workgroup::id.x * loom::kernel::workgroup::size.x +
                 loom::kernel::workitem::id.x;
  if (job >= chunks) return;
  unsigned offset = jobs[job * 3];
  unsigned limit = jobs[job * 3 + 1];
  unsigned interval = jobs[job * 3 + 2];
  unsigned chunk_bits = chunk_bytes * 8;
  unsigned first_boundary = interval * chunk_bits;
  unsigned last_boundary = first_boundary + chunk_bits;
  const unsigned* words = entropy + offset;
  Cursor cursor = {};
  cursor.position = interval ? first_boundary - chunk_bits : 0;
  cursor.budget = chunk_bits * 4 + 26;
  cursor.cached_word = 0xffffffffu;
  while (cursor.position < first_boundary && cursor.error == 0) {
    unsigned before = cursor.position;
    cursor = advance(words, tables, blocks, limit, cursor);
    if (cursor.error == 1) {
      cursor.position = before + 1;
      cursor.blocks = 0;
      cursor.block_index = 0;
      cursor.coefficient = 0;
      cursor.predictors = {};
      cursor.error = 0;
    }
  }
  unsigned first_bit = cursor.position;
  unsigned first_phase = cursor.block_index * 64 + cursor.coefficient;
  unsigned first_blocks = cursor.blocks;
  Predictors first_predictors = cursor.predictors;
  while (cursor.position < last_boundary && cursor.error == 0) {
    cursor = advance(words, tables, blocks, limit, cursor);
  }
  unsigned stride = (5 + component_count + 3) & ~3u;
  unsigned* output = summaries + job * stride;
  [[loom::unroll]]
  for (unsigned index = 0; index < stride; ++index) output[index] = 0;
  output[0] = 0xffffffffu;
  if (cursor.error == 0) {
    output[0] = first_bit;
    output[1] = first_phase;
    output[2] = cursor.position;
    output[3] = cursor.block_index * 64 + cursor.coefficient;
    output[4] = cursor.blocks - first_blocks;
    [[loom::unroll]]
    for (unsigned component = 0; component < component_count; ++component) {
      output[5 + component] = cursor.predictors[component] - first_predictors[component];
    }
  }
}
