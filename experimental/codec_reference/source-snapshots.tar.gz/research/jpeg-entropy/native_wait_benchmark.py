"""HIP graph comparison of pinned native artifacts; no compiler/runtime edits."""
import ast
import ctypes as c
import hashlib
import json
import os
from pathlib import Path
import re
import statistics
import struct
import time

root = Path(__file__).resolve().parent
assert os.environ['BENCHMARK_LOCK_LEASE_ID']
assert not list(Path('/sys/class/kfd/kfd/proc').iterdir())
manifest = json.loads((root / 'native-wait-control.json').read_text())
fixture = root / manifest['fixture']
stage = json.loads((fixture / 'stage.json').read_text())
for name, expected in stage['files'].items():
    assert hashlib.sha256((fixture / name).read_bytes()).hexdigest() == expected, name
for entry in manifest['entries']:
    assert hashlib.sha256((root / entry['artifact']).read_bytes()).hexdigest() == entry['sha256']
patch = manifest['patch']
assert hashlib.sha256((root / patch['candidate']).read_bytes()).hexdigest() == patch['candidate_sha256']
hip = c.CDLL('/opt/rocm/lib/libamdhip64.so')
pointer = c.c_void_p
pointer_pointer = c.POINTER(pointer)
hip.hipGetErrorString.argtypes = [c.c_int]
hip.hipGetErrorString.restype = c.c_char_p
signatures = {
    'hipInit': [c.c_uint], 'hipSetDevice': [c.c_int],
    'hipMalloc': [pointer_pointer, c.c_size_t], 'hipFree': [pointer],
    'hipMemset': [pointer, c.c_int, c.c_size_t],
    'hipMemsetD32': [pointer, c.c_int, c.c_size_t],
    'hipMemcpy': [pointer, pointer, c.c_size_t, c.c_int],
    'hipStreamCreate': [pointer_pointer], 'hipStreamDestroy': [pointer],
    'hipStreamSynchronize': [pointer],
    'hipModuleLoad': [pointer_pointer, c.c_char_p], 'hipModuleUnload': [pointer],
    'hipModuleGetFunction': [pointer_pointer, pointer, c.c_char_p],
    'hipModuleLaunchKernel': [pointer, *([c.c_uint] * 7), pointer, pointer_pointer, pointer_pointer],
    'hipStreamBeginCapture': [pointer, c.c_int], 'hipStreamEndCapture': [pointer, pointer_pointer],
    'hipGraphInstantiate': [pointer_pointer, pointer, pointer_pointer, c.c_char_p, c.c_size_t],
    'hipGraphLaunch': [pointer, pointer], 'hipGraphDestroy': [pointer], 'hipGraphExecDestroy': [pointer],
    'hipEventCreate': [pointer_pointer], 'hipEventDestroy': [pointer],
    'hipEventRecord': [pointer, pointer], 'hipEventSynchronize': [pointer],
    'hipEventElapsedTime': [c.POINTER(c.c_float), pointer, pointer],
}
for name, signature in signatures.items():
    getattr(hip, name).argtypes = signature
    getattr(hip, name).restype = c.c_int


def call(name, *arguments):
    result = getattr(hip, name)(*arguments)
    if result:
        raise RuntimeError((name, result, hip.hipGetErrorString(result).decode()))


def read_payload(path):
    with path.open('rb') as stream:
        assert stream.read(8) == b'\x93NUMPY\x01\x00'
        length, = struct.unpack('<H', stream.read(2))
        header = ast.literal_eval(stream.read(length).decode())
        assert header['descr'] == '<i4' and not header['fortran_order']
        data = stream.read()
        assert len(data) == header['shape'][0] * 4
        return data


call('hipInit', 0)
call('hipSetDevice', 0)
stream = pointer()
call('hipStreamCreate', c.byref(stream))
allocations = {}
bindings = {}
expectations = {}
inputs = {}
source = (fixture / 'summary.loom').read_text()
for name, path, count in re.findall(r'%(\w+) = check.file.read.npy path\("([^"]+)"\) : tensor<(\d+)xi32>', source):
    inputs[name] = read_payload(fixture / path)
    assert len(inputs[name]) == int(count) * 4
for name, count in re.findall(r'%(\w+) = check.generate.fill value\(17\) : tensor<(\d+)xi32>', source):
    expectations[name] = inputs[name.removesuffix('_output')]
    assert len(expectations[name]) == int(count) * 4
used = {name for entry in manifest['entries'] for name in entry['arguments']}
for name in used:
    data = expectations.get(name, inputs.get(name))
    assert data is not None
    allocation = pointer()
    call('hipMalloc', c.byref(allocation), len(data) + 128)
    allocations[name] = allocation
    bindings[name] = pointer(allocation.value + 64)
    call('hipMemset', allocation, 0xa5, len(data) + 128)
    if name in expectations:
        call('hipMemsetD32', bindings[name], 17, len(data) // 4)
    else:
        call('hipMemcpy', bindings[name], c.c_char_p(data), len(data), 1)
call('hipStreamSynchronize', stream)
assert len({value.value for value in allocations.values()}) == len(allocations)
modules = []
functions = []
arguments = []
for entry in manifest['entries']:
    module = pointer()
    function = pointer()
    call('hipModuleLoad', c.byref(module), str(root / entry['artifact']).encode())
    call('hipModuleGetFunction', c.byref(function), module, entry['entry'].encode())
    modules.append(module)
    functions.append(function)
    arguments.append((pointer * len(entry['arguments']))(
        *(c.cast(c.byref(bindings[name]), pointer) for name in entry['arguments'])))
module = pointer()
candidate = pointer()
call('hipModuleLoad', c.byref(module), str(root / patch['candidate']).encode())
call('hipModuleGetFunction', c.byref(candidate), module, b'jpeg_reconstruct')
modules.append(module)
graphs = []
executables = []
for variant in range(2):
    call('hipStreamBeginCapture', stream, 1)
    for operation in range(8):
        for index, entry in enumerate(manifest['entries']):
            workload = entry['workload']
            grid = [workload['workgroup_count'][key] for key in ('x', 'y', 'z')]
            block = [workload['workgroup_size'][key] for key in ('x', 'y', 'z')]
            function = candidate if variant and entry['entry'] == 'jpeg_reconstruct' else functions[index]
            call('hipModuleLaunchKernel', function, *grid, *block, 0, stream, arguments[index], None)
    graph = pointer()
    executable = pointer()
    call('hipStreamEndCapture', stream, c.byref(graph))
    call('hipGraphInstantiate', c.byref(executable), graph, None, None, 0)
    graphs.append(graph)
    executables.append(executable)
events = [pointer(), pointer()]
for event in events:
    call('hipEventCreate', c.byref(event))


def verify():
    for name in used:
        data = expectations.get(name, inputs.get(name))
        actual = c.create_string_buffer(len(data) + 128)
        call('hipMemcpy', actual, allocations[name], len(data) + 128, 2)
        raw = actual.raw
        assert raw[:64] == raw[-64:] == bytes([0xa5]) * 64, ('guard', name)
        assert raw[64:-64] == data, ('complete output/input', name)


rows = []
state = {'host': os.uname().nodename, 'lease': os.environ['BENCHMARK_LOCK_LEASE_ID'],
         'library_sha256': hashlib.sha256(Path('/opt/rocm/lib/libamdhip64.so').resolve().read_bytes()).hexdigest(),
         'batch_images': 16, 'operations_per_graph': 8, 'dispatches_per_graph': 48,
         'warmups': 2, 'samples': 9, 'boundary': 'HIP event duration of one graph containing eight complete six-kernel operations, divided by eight; one final wait per graph. Full pixels, metadata, input immutability, and guards checked before/after each window.'}
for variant in (0, 1, 0, 1, 0):
    executable = executables[variant]
    for unused in range(2):
        call('hipGraphLaunch', executable, stream)
        call('hipStreamSynchronize', stream)
    verify()
    samples = []
    for unused in range(9):
        before = time.monotonic_ns()
        call('hipEventRecord', events[0], stream)
        call('hipGraphLaunch', executable, stream)
        call('hipEventRecord', events[1], stream)
        call('hipEventSynchronize', events[1])
        elapsed = c.c_float()
        after = time.monotonic_ns()
        call('hipEventElapsedTime', c.byref(elapsed), *events)
        samples.append({'event_ms_per_operation': elapsed.value / 8,
                        'host_ms_per_operation': (after - before) / 8e6})
    verify()
    row = {'variant': 'wait-nop' if variant else 'compiler', 'samples': samples,
           'median_ms': statistics.median(sample['event_ms_per_operation'] for sample in samples),
           'exact_pixels_metadata_inputs_guards': True}
    rows.append(row)
    print(json.dumps(row), flush=True)
    (root / 'native-wait-results.json').write_text(json.dumps({'state': state, 'manifest': manifest, 'rows': rows}, indent=2) + '\n')
for event in events:
    call('hipEventDestroy', event)
for executable in executables:
    call('hipGraphExecDestroy', executable)
for graph in graphs:
    call('hipGraphDestroy', graph)
for module in modules:
    call('hipModuleUnload', module)
for allocation in allocations.values():
    call('hipFree', allocation)
call('hipStreamDestroy', stream)
print('All native comparison resources retired', flush=True)
