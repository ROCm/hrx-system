"""Stage the qualified small decoder and temporary ROCr closure for gfx1100."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import shlex
import subprocess
import tarfile
import tempfile

notes = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--host', choices=('noxa-pc', 'noxa-sharkbox'), required=True)
arguments = parser.parse_args()
receipt_path = notes / (arguments.host + '-stage.json')
active = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
tags = {name: Path(value) for name, value in json.loads(os.environ['BUREAU_TAG_ROOTS']).items()}
small = active / 'mixed-negative-base'
build = json.loads((notes / 'current-probe-asan-build.json').read_text())
capture = json.loads(subprocess.check_output(
    ['bureau-bazel', 'tag', 'inspect', 'codec-jpeg-rebased-checks', '--json'], text=True))
assert capture['capture'] == build['capture']['capture']
assert build['restored'] and build['build_returncode'] == 0
tool = tags['codec-jpeg-rebased-checks'] / 'loom/src/loom/tooling/target/amdgpu/serve/codec_command_probe'
files = {'codec_command_probe_asan': tool}
for name in ['summary.loombc', 'config.json', 'bindings.txt']:
    files['small/' + name] = small / name
logical = 0
for line in (small / 'bindings.txt').read_text().splitlines():
    name, is_input, width, count, relative = line.split()
    logical += int(width) * int(count)
    files['small/' + relative] = small / relative
assert logical < 1024 * 1024

closure_code = r'''
import hashlib,json,os,subprocess
from pathlib import Path
root=Path('/opt/rocm/lib/libhsa-runtime64.so.1')
listing=subprocess.check_output(['ldd',str(root)],text=True)
assert 'not found' not in listing,listing
files={'libhsa-runtime64.so.1':root.resolve()}
for line in listing.splitlines():
 fields=line.split()
 if len(fields)>=3 and fields[1]=='=>' and fields[2].startswith('/opt/rocm/'):
  files[fields[0]]=Path(fields[2]).resolve()
record={'ldd':listing,'files':{}}
for name,path in files.items():
 record['files'][name]={'source':str(path),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
print(json.dumps(record))
'''
closure = json.loads(subprocess.check_output(
    ['ssh', 'hrx-gorgon-4', shlex.join(['python3', '-B', '-c', closure_code])], text=True))
local = Path(tempfile.mkdtemp(prefix='codec-gfx1100-'))
(local / 'lib').mkdir()
for name, entry in closure['files'].items():
    path = local / 'lib' / name
    with path.open('wb') as output:
        subprocess.run(['ssh', 'hrx-gorgon-4', shlex.join(['cat', entry['source']])], stdout=output, check=True)
    assert path.stat().st_size == entry['bytes']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == entry['sha256']
    files['lib/' + name] = path
assert sum(path.stat().st_size for path in files.values()) < 160 * 1024 * 1024
remote = subprocess.check_output(
    ['ssh', arguments.host, 'mktemp -d /tmp/codec-gfx1100-XXXXXXXX'], text=True).strip()
record = {'host': arguments.host, 'directory': remote, 'local_directory': str(local),
          'build': build, 'closure': closure, 'logical_device_binding_bytes': logical,
          'retention_limit_bytes': 160 * 1024 * 1024,
          'scope': 'Small correctness corpus only; no performance measurement or system installation.',
          'files': {name: {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
                    for name, path in files.items()}}
receipt_path.write_text(json.dumps(record, indent=2) + '\n')
manifest = local / 'manifest.json'
manifest.write_text(json.dumps(record, indent=2) + '\n')
files['manifest.json'] = manifest
process = subprocess.Popen(['ssh', arguments.host, shlex.join(['tar', '-xf', '-', '-C', remote])], stdin=subprocess.PIPE)
with tarfile.open(fileobj=process.stdin, mode='w|', dereference=True) as archive:
    for name, path in files.items():
        archive.add(path, arcname=name, recursive=False)
process.stdin.close()
assert process.wait() == 0
verify = r'''
import hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path(sys.argv[1]); record=json.loads((root/'manifest.json').read_text())
for name,entry in record['files'].items():
 path=root/name
 assert path.stat().st_size==entry['bytes'],name
 assert hashlib.sha256(path.read_bytes()).hexdigest()==entry['sha256'],name
environment=dict(os.environ,LD_LIBRARY_PATH=str(root/'lib'))
for path in (root/'codec_command_probe_asan',root/'lib/libhsa-runtime64.so.1'):
 result=subprocess.run(['ldd',str(path)],env=environment,capture_output=True,text=True)
 assert result.returncode==0 and 'not found' not in result.stdout,result.stdout+result.stderr
 print(result.stdout)
print(json.dumps({'staged_bytes':sum(row['bytes'] for row in record['files'].values()),'logical_device_binding_bytes':record['logical_device_binding_bytes']}))
'''
result = subprocess.run(['ssh', arguments.host, shlex.join(['python3', '-B', '-c', verify, remote])], capture_output=True, text=True)
(notes / (arguments.host + '-stage-check.log')).write_text(result.stdout + result.stderr)
record['staging_returncode'] = result.returncode
receipt_path.write_text(json.dumps(record, indent=2) + '\n')
print(result.stdout + result.stderr, end='')
assert result.returncode == 0
