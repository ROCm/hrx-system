#pragma once
#include "device_entropy_cursor_certified.h"

template <bool RetainTotals>
static LOOM_FORCE_INLINE Cursor advance_state(const unsigned* words,
    const unsigned* tables, const unsigned* blocks, unsigned limit, Cursor cursor) {
  unsigned block_index = cursor.block_index;
  unsigned block_count = blocks_per_mcu;
  loom::assume(block_index < block_count);
  unsigned descriptor = blocks[block_index];
  unsigned dc_mask = 0u - static_cast<unsigned>(cursor.coefficient == 0);
  unsigned dc_table = (descriptor >> 8) & 255;
  unsigned ac_table = descriptor >> 16;
  unsigned table_index = ac_table ^ ((ac_table ^ dc_table) & dc_mask);
  unsigned available_tables = table_count;
  loom::assume(table_index < available_tables);
  Read input = peek(words, cursor);
  cursor = input.cursor;
  unsigned packed = tables[table_index * 832 + (input.value >> 23)];
  unsigned length = packed >> 8;
  unsigned symbol = packed & 255;
  unsigned category = symbol & (15u | dc_mask);
  unsigned consumed = length + category;
  if (length == 0 || consumed > limit - cursor.position ||
      consumed > cursor.budget - cursor.reads) {
    Cursor result = advance_symbol_slow(words, tables, blocks, limit, cursor).cursor;
    if constexpr (!RetainTotals) {
      result.blocks = cursor.blocks;
      result.predictors = cursor.predictors;
    }
    return result;
  }
  loom::assume(length <= 9u);
  loom::assume(category <= 11u);
  if (cursor.coefficient == 0) {
    if constexpr (RetainTotals) {
      unsigned amplitude_mask = (1u << category) - 1;
      unsigned value = (input.value >> (32 - consumed)) & amplitude_mask;
      unsigned negative_mask = 0u - static_cast<unsigned>(value < ((1u << category) >> 1));
      int amplitude = static_cast<int>(value + ((0u - amplitude_mask) & negative_mask));
      unsigned component = descriptor & 255;
      cursor.predictors[component] += amplitude;
    }
    cursor.coefficient = 1;
  } else {
    unsigned run = symbol >> 4;
    if (category == 0) {
      unsigned nonzero_run_mask = 0u - static_cast<unsigned>(run != 0);
      unsigned next = (cursor.coefficient + 16) & nonzero_run_mask;
      if (next > 64) cursor.error = 1;
      cursor.coefficient = next & 63;
    } else {
      unsigned index = cursor.coefficient + run;
      if (index >= 64) {
        // An invalid run consumes its codeword, but never its amplitude.
        consumed = length;
        cursor.error = 1;
      } else {
        cursor.coefficient = (index + 1) & 63;
      }
    }
    if (cursor.coefficient == 0 && cursor.error == 0) {
      if constexpr (RetainTotals) ++cursor.blocks;
      ++cursor.block_index;
      unsigned wrap_mask = 0u - static_cast<unsigned>(cursor.block_index != blocks_per_mcu);
      cursor.block_index &= wrap_mask;
    }
  }
  cursor.position += consumed;
  cursor.reads += consumed;
  return cursor;
}

