"""Flip one true JPEG padding bit; decoded coefficients/checkpoints stay fixed."""
from dataclasses import replace
import hashlib
import json
from pathlib import Path

from bounded import establish
from device_fixture import input_bytes, read_words, write_words
from recover_prefix import speculate
from sequential import InvalidJPEG, parse

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
key = 'ycbcr_444-scan0-chunk4096'
source = root / 'anchor-small'
output = root / 'anchor-errors'
output.mkdir(exist_ok=True)
descriptor = read_words(source / (key + '-segments.npy'))
checkpoints = read_words(source / (key + '-checkpoints.npy'))
assert len(descriptor) == 8 and len(checkpoints) == 16 and descriptor[3] == 1
position = checkpoints[8]
assert 0 < descriptor[1] - position < 8
words = list(read_words(root / (key + '-entropy.npy')))
words[descriptor[0] + position // 32] &= ~(1 << (31 - position % 32))
write_words(output / 'bad-padding-entropy.npy', words)
write_words(output / 'bad-padding-status.npy', [4])
frame = parse(input_bytes('ycbcr_444'))
scan = frame.scans[0]
segment = scan.segments[0]
data = bytearray(segment.data)
data[position // 8] &= ~(1 << (7 - position % 8))
segment = replace(segment, data=bytes(data))
summaries, counts = speculate(segment, scan, len(frame.components), 4096 * 8, 1, 1)
assert summaries == [None]
try:
    establish(segment, scan, len(frame.components), 4096 * 8, summaries)
except InvalidJPEG as error:
    assert 'invalid trailing padding' in str(error), error
else:
    raise AssertionError('Independent reference accepted the bad padding bit')
text = (source / (key + '.loom')).read_text()
text = text.replace('../' + key + '-entropy.npy', 'bad-padding-entropy.npy')
text = text.replace(key + '-status.npy', 'bad-padding-status.npy')
for name in ('segments', 'checkpoints'):
    text = text.replace(key + '-' + name + '.npy', '../anchor-small/' + key + '-' + name + '.npy')
(output / 'bad-padding.loom').write_text(text)
(output / 'bad-padding.json').write_bytes((source / (key + '.json')).read_bytes())
receipt = {'cases': [{'key': 'bad-padding', 'jobs': 1, 'segments': 1,
                      'mutation': {'position': position, 'value': 0}, 'expected_status': 4,
                      'reference_failure': 'partitioned decode has invalid trailing padding'}],
           'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(output / 'fixtures.json').write_text(json.dumps(receipt, indent=2) + '\n')
stage = json.loads((root / 'anchor-small-stage.json').read_text())
stage['files'].update({str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
                       for path in output.iterdir() if path.is_file()})
(root / 'anchor-errors-stage.json').write_text(json.dumps(stage, indent=2) + '\n')
(notes / 'device-anchor-padding.json').write_text(json.dumps(receipt, indent=2) + '\n')
