#include "device_entropy_cursor.h"

[[loom::config("jpeg.mcu_width"), loom::where(loom::predicate::range(1u, 65536u))]]
extern const unsigned scan_mcu_width;

using WideValues = long long __attribute__((ext_vector_type(8)));

static loom::kernel::configuration configure_output() {
  unsigned threads = loom::target::subgroup::size() * 4;
  unsigned interval_capacity = chunks * 2 + certification_segments;
  unsigned stripe = threads * certification_segments;
  return {{(interval_capacity + stripe - 1) / stripe, certification_segments, 1},
          {threads, 1, 1}};
}

static LOOM_FORCE_INLINE WideValues transform_block_axis(WideValues input) {
  long long sum = (input[0] + input[4]) * 8192;
  long long difference = (input[0] - input[4]) * 8192;
  long long rotation = (input[2] + input[6]) * 4433;
  long long two = rotation - input[6] * 15137;
  long long six = rotation + input[2] * 6270;
  long long even0 = sum + six;
  long long even1 = difference + two;
  long long even2 = difference - two;
  long long even3 = sum - six;
  long long odd_rotation = (input[1] + input[3] + input[5] + input[7]) * 9633;
  long long seven_three = odd_rotation - (input[7] + input[3]) * 16069;
  long long five_one = odd_rotation - (input[5] + input[1]) * 3196;
  long long seven_one = (input[7] + input[1]) * -7373;
  long long five_three = (input[5] + input[3]) * -20995;
  long long odd0 = input[1] * 12299 + seven_one + five_one;
  long long odd1 = input[3] * 25172 + five_three + seven_three;
  long long odd2 = input[5] * 16819 + five_three + five_one;
  long long odd3 = input[7] * 2446 + seven_one + seven_three;
  return {even0 + odd0, even1 + odd1, even2 + odd2, even3 + odd3,
          even3 - odd3, even2 - odd2, even1 - odd1, even0 - odd0};
}

static LOOM_FORCE_INLINE unsigned sample_byte(int value) {
  return value < 0 ? 0u : value > 255 ? 255u : static_cast<unsigned>(value);
}

// One logically private coefficient block per lane, stored frequency-major in
// shared memory. Each transform reuses that block for its first-pass results.
// Widened arithmetic covers the full 16-bit quantization range; the first-pass
// result is bounded by 2,005,829,745 for an 8-bit DCT coefficient magnitude 1024.
static LOOM_FORCE_INLINE void reconstruct_block(int* coefficients,
    unsigned threads, unsigned lane, bool any_ac, unsigned* pixels) {
  if (!any_ac) {
    unsigned value = sample_byte(((coefficients[lane] + 4) >> 3) + 128);
    unsigned packed = value * 0x01010101u;
    [[loom::unroll]]
    for (unsigned index = 0; index < 16; ++index) pixels[index] = packed;
  } else {
    for (unsigned column = 0; column < 8; ++column) {
      WideValues input = {};
      int ac = 0;
      [[loom::unroll]]
      for (unsigned row = 0; row < 8; ++row) {
        int value = coefficients[(row * 8 + column) * threads + lane];
        input[row] = value;
        if (row != 0) ac |= value;
      }
      WideValues result = {};
      if (ac == 0) {
        [[loom::unroll]]
        for (unsigned row = 0; row < 8; ++row) result[row] = input[0] * 4;
      } else {
        result = transform_block_axis(input);
        [[loom::unroll]]
        for (unsigned row = 0; row < 8; ++row) result[row] = (result[row] + 1024) >> 11;
      }
      [[loom::unroll]]
      for (unsigned row = 0; row < 8; ++row) {
        coefficients[(row * 8 + column) * threads + lane] = static_cast<int>(result[row]);
      }
    }
    for (unsigned row = 0; row < 8; ++row) {
      WideValues input = {};
      [[loom::unroll]]
      for (unsigned column = 0; column < 8; ++column) {
        input[column] = coefficients[(row * 8 + column) * threads + lane];
      }
      WideValues result = transform_block_axis(input);
      [[loom::unroll]]
      for (unsigned half = 0; half < 2; ++half) {
        unsigned packed = 0;
        [[loom::unroll]]
        for (unsigned column = 0; column < 4; ++column) {
          int value = static_cast<int>((result[half * 4 + column] + 131072) >> 18) + 128;
          packed |= sample_byte(value) << (column * 8);
        }
        pixels[row * 2 + half] = packed;
      }
    }
  }
}

static LOOM_FORCE_INLINE Symbol output_symbol(const unsigned* words,
    const unsigned* tables, const unsigned* blocks, unsigned limit, Cursor cursor) {
  Symbol symbol = advance_symbol(words, tables, blocks, limit, cursor);
  if (symbol.index == 0 && (symbol.value < -1024 || symbol.value > 1023)) {
    symbol.cursor.error = 5;
  }
  return symbol;
}

// The second grid dimension retains segment ownership. A grid-stride loop
// covers ragged segment lengths without searching metadata or host counts.
// Output is component-planar, with each 8x8 block contiguous in memory.
[[loom::kernel(configure_output)]]
void jpeg_reconstruct(const unsigned* entropy, const unsigned* segments,
    const unsigned* tables, const unsigned* blocks, const unsigned* intervals,
    const unsigned* geometry, const unsigned* quantization, const unsigned* zigzag,
    unsigned* pixels, unsigned* status) {
  unsigned segment = loom::kernel::workgroup::id.y;
  unsigned lane = loom::kernel::workitem::id.x;
  unsigned threads = loom::kernel::workgroup::size.x;
  unsigned interval_capacity = chunks * 2 + certification_segments;
  unsigned stripe = threads * certification_segments;
  unsigned group_count = (interval_capacity + stripe - 1) / stripe;
  const unsigned* descriptor = segments + segment * 8;
  unsigned count = descriptor[3];
  unsigned total_blocks = descriptor[4];
  unsigned first_interval = descriptor[2] * 2 + segment;
  unsigned stride = (4 + component_count + 3) & ~3u;
  const unsigned* words = entropy + descriptor[0];
  unsigned bit_limit = descriptor[1];
  auto* coefficients = loom::buffer::alloca<int, loom::memory_space::workgroup, 16>(threads * 64);
  for (unsigned interval = loom::kernel::workgroup::id.x * threads + lane;
       interval < count * 2 + 1; interval += group_count * threads) {
    const unsigned* entry = intervals + (first_interval + interval) * stride;
    Cursor cursor = {};
    cursor.position = entry[0];
    cursor.blocks = entry[2];
    cursor.block_index = entry[3] >> 6;
    cursor.coefficient = entry[3] & 63;
    cursor.budget = bit_limit;
    cursor.cached_word = 0xffffffffu;
    [[loom::unroll]]
    for (unsigned component = 0; component < component_count; ++component) {
      cursor.predictors[component] = static_cast<int>(entry[4 + component]);
    }
    if (entry[0] < entry[1]) {
      while ((cursor.block_index != 0 || cursor.coefficient != 0) && cursor.error == 0) {
        cursor = output_symbol(words, tables, blocks, bit_limit, cursor).cursor;
      }
      while (cursor.blocks < total_blocks && cursor.position < entry[1] && cursor.error == 0) {
        unsigned mcu = descriptor[6] + cursor.blocks / blocks_per_mcu;
        unsigned mcu_row = mcu / scan_mcu_width;
        unsigned mcu_column = mcu % scan_mcu_width;
        for (unsigned block = 0; block < blocks_per_mcu && cursor.error == 0; ++block) {
          [[loom::unroll]]
          for (unsigned index = 0; index < 64; ++index) coefficients[index * threads + lane] = 0;
          bool any_ac = false;
          do {
            Symbol symbol = output_symbol(words, tables, blocks, bit_limit, cursor);
            cursor = symbol.cursor;
            if (symbol.index != 0xffffffffu && cursor.error == 0) {
              unsigned natural = zigzag[symbol.index];
              unsigned component = blocks[block] & 255;
              unsigned components = component_count;
              loom::assume(natural < 64u);
              loom::assume(component < components);
              unsigned step = quantization[component * 64 + natural];
              loom::assume(step <= 65535u);
              coefficients[natural * threads + lane] = symbol.value * static_cast<int>(step);
              if (symbol.index != 0) any_ac = true;
            }
          } while (cursor.coefficient != 0 && cursor.error == 0);
          const unsigned* shape = geometry + block * 8;
          unsigned column = mcu_column * shape[3] + shape[5];
          unsigned row = mcu_row * shape[4] + shape[6];
          if (cursor.error == 0 && column < shape[1] && row < shape[2]) {
            unsigned offset = descriptor[7] + shape[0] + (row * shape[1] + column) * 16;
            reconstruct_block(coefficients, threads, lane, any_ac, pixels + offset);
          }
        }
      }
    }
    if (interval == count * 2 && cursor.error == 0) {
      if (cursor.blocks != total_blocks || cursor.coefficient != 0) {
        cursor.error = 3;
      } else {
        unsigned padding = bit_limit - cursor.position;
        if (padding >= 8) {
          cursor.error = 4;
        } else if (padding != 0) {
          Read input = peek(words, cursor);
          if ((input.value >> (32 - padding)) != (1u << padding) - 1) cursor.error = 4;
        }
      }
    }
    status[first_interval + interval] = cursor.error;
  }
}
