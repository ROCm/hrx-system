"""Matched, fixed-count complete RGB measurements under one short lease."""
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import statistics
import subprocess
import sys

root = Path(sys.argv[1])
connected_fixture = sys.argv[2] if len(sys.argv) > 2 else 'connected-stored-grid'
result_name = sys.argv[3] if len(sys.argv) > 3 else 'command-comparison'
control_fixture = sys.argv[4] if len(sys.argv) > 4 else 'command-control-batch16'
profile = len(sys.argv) > 5 and sys.argv[5] == 'profile'
assert os.environ['BENCHMARK_LOCK_LEASE_ID']
tree = ast.parse((root / 'cpu-current/machine-state.py').read_text())
node = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'state')
exec(compile(ast.Module(body=[node], type_ignores=[]), 'machine-state.py', 'exec'))
before = state()
assert before['governor'] == 'performance'
assert int(before['personality'], 16) & 0x40000
assert before['gpu_policy'] == 'high'
assert before['gpu_busy'] == 0 and not before['kfd_processes'] and not before['drm'], before
record = {'before': before, 'rows': [],
          'binary_sha256': hashlib.sha256((root / 'codec_command_probe').read_bytes()).hexdigest(),
          'fixtures': {name: json.loads((root / name / 'stage.json').read_text()) for name in
                       (control_fixture, connected_fixture)}, 'scope': {
    'control_fixture': control_fixture, 'candidate_fixture': connected_fixture,
    'image': '4032x3024 baseline 4:2:0 restart-free JPEG',
    'batch': 16, 'gpu_operations_per_submission': 8, 'warmups': 2, 'samples': 9,
    'gpu_timing': 'Whole-command completion, eight device-ordered full batches, divided by eight. Resident inputs, persistent outputs. Header parse, JIT, allocation, uploads and correctness downloads outside timing.',
    'cpu_timing': 'Full public libjpeg RGB decode including create/header/start/read/finish/destroy and internal codec allocations; caller-owned RGB outputs are preallocated. Sixteen physical CPU workers, nine samples after two warmups.'}}
for ordinal, name in enumerate(('cpu', 'control', 'connected', 'control', 'connected', 'cpu')):
    if name == 'cpu':
        command = ['taskset', '-c', '0-15', str(root / 'cpu-current/jpeg_baseline'),
                   'bench', '16', '16', '9', str(root / 'cpu-current/012mp-bus.jpg.r0.jpg')]
    else:
        fixture = control_fixture if name == 'control' else connected_fixture
        command = [str(root / 'codec_command_probe'), '--jpeg_fixture=' + str(root / fixture),
                   '--gtest_filter=JpegCommandTest.CompressedToRgb', '--jpeg_benchmark=true']
        if profile: command.append('--jpeg_profile=true')
    result = subprocess.run(command, capture_output=True, text=True)
    (root / (result_name + '-' + str(ordinal) + '-' + name + '.log')).write_text(result.stdout + result.stderr)
    assert result.returncode == 0, result.stdout + result.stderr
    rows = [json.loads(line) for line in result.stdout.splitlines() if line.startswith('{')]
    if name == 'cpu':
        assert len(rows) == 1 and rows[0]['full_rgb_and_guards']
        median = statistics.median(rows[0]['batch_ns'])
    else:
        measurements = [row for row in rows if row['phase'] == 'measurement']
        assert len(measurements) == 1
        median = measurements[0]['median_operation_ns']
    record['rows'].append({'name': name, 'command': command, 'median_batch_ns': median, 'rows': rows})
    (root / (result_name + '.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'name': name, 'median_batch_ms': median / 1e6}), flush=True)
record['after'] = state()
assert not record['after']['kfd_processes'] and not record['after']['drm'], record['after']
(root / (result_name + '.json')).write_text(json.dumps(record, indent=2) + '\n')
