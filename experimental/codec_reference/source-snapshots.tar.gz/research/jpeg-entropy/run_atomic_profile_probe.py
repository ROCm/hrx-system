"""Compile unchanged atomic input against explicit, independently queried facts."""
import hashlib
import json
from pathlib import Path
import subprocess

notes = Path(__file__).resolve().parent
source = Path('loom/src/loom/tooling/target/amdgpu/test/buffer_descriptor_extents.loom')
probe = notes / 'atomic_profile_probe.c'
source_text = source.read_text()
command = ['bureau-bazel', 'try', '--config=asan', '--dynamic_mode=off',
           '--dep=//loom/binding/c:loomc', '--dep=//loom/binding/c/target/spirv',
           str(probe), '--', source_text]
with (notes / 'atomic-profile-probe.log').open('w') as log:
    completed = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
rows = []
fields = ('named_profile', 'requested_device_scope', 'requested_atomic64',
          'queried_device_scope', 'queried_atomic64', 'succeeded',
          'executable_bytes', 'diagnostic_count')
for line in (notes / 'atomic-profile-probe.log').read_text().splitlines():
    if line.startswith('ROW '):
        rows.append(dict(zip(fields, map(int, line.split()[1:]))))
        rows[-1]['diagnostics'] = []
    elif line.startswith('DIAGNOSTIC ') and rows:
        rows[-1]['diagnostics'].append(line.removeprefix('DIAGNOSTIC '))
result = {
    'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'source_path': str(source),
    'source_sha256': hashlib.sha256(source_text.encode()).hexdigest(),
    'probe_sha256': hashlib.sha256(probe.read_bytes()).hexdigest(),
    'command_prefix': command[:-1],
    'source_transport': 'final argv value, included in native try action identity',
    'exit_code': completed.returncode,
    'fact_states': {'unknown': 0, 'false': 1, 'true': 2},
    'named_profiles': {1: 'spirv:vulkan1.3+bda',
                       2: 'spirv:vulkan1.3+bda+extended-types',
                       3: 'spirv:vulkan1.3+bda+subgroup32+ballot+hal'},
    'rows': rows,
}
(notes / 'atomic-profile-probe.json').write_text(json.dumps(result, indent=2) + '\n')
assert completed.returncode == 0, 'probe failed; inspect log'
assert len(rows) == 12, len(rows)
for row in rows:
    if row['named_profile']:
        assert row['queried_device_scope'] == row['queried_atomic64'] == 0, row
    else:
        assert row['requested_device_scope'] == row['queried_device_scope'], row
        assert row['requested_atomic64'] == row['queried_atomic64'], row
    fully_enabled = row['queried_device_scope'] == row['queried_atomic64'] == 2
    assert row['succeeded'] == fully_enabled, row
    assert (row['executable_bytes'] > 0) == fully_enabled, row
    assert len(row['diagnostics']) == row['diagnostic_count'], row
    if not fully_enabled:
        assert all(d.startswith('TARGET/003 ') for d in row['diagnostics']), row
    print({key: value for key, value in row.items() if key != 'diagnostics'})
