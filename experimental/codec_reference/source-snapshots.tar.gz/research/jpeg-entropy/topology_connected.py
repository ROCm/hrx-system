"""Observe indirect topology without executing the reconstruction loop."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
from device_fixture import write_words

notes = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--all-groups', action='store_true')
arguments = parser.parse_args()
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
directory = root / ('connected-topology-all' if arguments.all_groups else 'connected-topology')
directory.mkdir(exist_ok=True)
source = (notes / 'device_connected_pipeline.cxx').read_text()
source += '''
[[loom::kernel(configure_output)]]
void jpeg_observe_topology(unsigned* output) {
  if (QUERY_GROUP && loom::kernel::workitem::id.x == 0) {
    unsigned index = QUERY_INDEX;
    output[index + 0] = loom::kernel::workgroup::count.x;
    output[index + 1] = loom::kernel::workgroup::count.y;
    output[index + 2] = loom::kernel::workgroup::count.z;
    output[index + 3] = loom::kernel::workgroup::size.x;
    output[index + 4] = loom::kernel::subgroup::size();
  }
}
'''
source = source.replace('QUERY_GROUP', 'true' if arguments.all_groups else
                        'loom::kernel::workgroup::id.x == 0 && loom::kernel::workgroup::id.y == 0')
source = source.replace('QUERY_INDEX', '(loom::kernel::workgroup::id.y * 512 + loom::kernel::workgroup::id.x) * 5' if arguments.all_groups else '0')
source_path = notes / ('device_topology_all_pipeline.cxx' if arguments.all_groups else 'device_topology_pipeline.cxx')
source_path.write_text(source)
tags = json.loads(os.environ['BUREAU_TAG_ROOTS'])
base = Path(tags['codec-jpeg-rebased-tools']) / 'loom/src/loom/tools'
subprocess.run([str(base / 'loom-import-cxx/loom-import-cxx'), str(source_path),
                '--output=' + str(directory / 'library.loom')], check=True)
original = root / 'connected-through-4'
text = (original / 'summary.loom').read_text()
text = 'kernel.decl @jpeg_observe_topology(%counts: buffer, %offset: offset) launch(%topology: buffer)\n' + text
text = text.replace('command.program.def public @jpeg_decode() launch(', 'command.program.def public @jpeg_decode() launch(%topology: buffer, ')
text = text.replace('\n  }\n  command.return', '\n    kernel.launch @jpeg_observe_topology[%schedule, %schedule_offset](%topology) : [buffer, offset](buffer)\n  }\n  command.return')
(directory / 'summary.loom').write_text(text)
(directory / 'config.json').write_bytes((original / 'config.json').read_bytes())
group_count = 512 * 16 if arguments.all_groups else 1
write_words(directory / 'topology.npy', [512, 16, 1, 32, 32] * group_count)
(directory / 'bindings.txt').write_text(f'topology 0 4 {group_count * 5} topology.npy\n' + (original / 'bindings.txt').read_text())
subprocess.run([str(base / 'loom-link/loom-link'), str(directory / 'summary.loom'), str(directory / 'library.loom'),
               '--to=bc', '--output=' + str(directory / 'summary.loombc')], check=True)
files = {}
for line in (directory / 'bindings.txt').read_text().splitlines():
    path = (directory / line.split()[4]).resolve()
    files[os.path.relpath(path, directory)] = hashlib.sha256(path.read_bytes()).hexdigest()
files.update({path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in directory.iterdir() if path.name != 'stage.json'})
(directory / 'stage.json').write_text(json.dumps({'files': files, 'scope': 'GPU-derived launch dimensions observed through actual reconstruction topology queries; no reconstruction loop.'}, indent=2) + '\n')
