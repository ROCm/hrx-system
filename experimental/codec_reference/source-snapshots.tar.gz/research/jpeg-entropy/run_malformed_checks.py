"""Run the existing entropy error-boundary suite under one foreground lease."""
import argparse
import hashlib
import json
from pathlib import Path
import shlex
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('variant')
parser.add_argument('--candidate-config-directory')
parser.add_argument('--candidate-fixture-directory')
arguments = parser.parse_args()
variant = arguments.variant
notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
manifest = root / 'certified-malformed-libraries.json'
libraries = json.loads(manifest.read_text())
library = root / ('entropy-' + variant + '.loombc')
libraries[library.name] = hashlib.sha256(library.read_bytes()).hexdigest()
manifest.write_text(json.dumps(libraries, indent=2) + '\n')
subprocess.run(['scp', str(manifest), str(library), str(notes / 'certified_malformed_run.py'),
                'hrx-gorgon-4:' + str(root) + '/'], check=True)
command = ['/home/benvanik/.dotfiles/bin/benchmark-lock', '--label=codec-jpeg-' + variant + '-malformed',
           '--', 'env', 'LD_LIBRARY_PATH=/opt/rocm/lib', 'python3', '-B',
           str(root / 'certified_malformed_run.py'), '--candidate=' + variant]
assert not (arguments.candidate_config_directory and arguments.candidate_fixture_directory)
override = arguments.candidate_config_directory or arguments.candidate_fixture_directory
if override:
    subprocess.run(['scp', '-r', str(root / override),
                    'hrx-gorgon-4:' + str(root) + '/'], check=True)
    command.append(('--candidate-fixture-directory=' if arguments.candidate_fixture_directory else
                    '--candidate-config-directory=') + override)
with (notes / ('gorgon4-' + variant + '-malformed-run.log')).open('w') as log:
    result = subprocess.run(['ssh', 'hrx-gorgon-4', shlex.join(command)],
                            stdout=log, stderr=subprocess.STDOUT)
status = subprocess.run(['ssh', 'hrx-gorgon-4', '/home/benvanik/.dotfiles/bin/benchmark-lock --status'],
                        capture_output=True, text=True)
record = {'command': command, 'returncode': result.returncode,
          'broker_status_returncode': status.returncode,
          'broker_status_after': status.stdout + status.stderr}
(notes / ('gorgon4-' + variant + '-malformed-lease.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
if result.returncode:
    print((notes / ('gorgon4-' + variant + '-malformed-run.log')).read_text()[-4000:])
    raise SystemExit(result.returncode)
subprocess.run(['scp', 'hrx-gorgon-4:' + str(root / (variant + '-malformed-qualified.json')),
                str(notes / ('gorgon4-' + variant + '-malformed-qualified.json'))], check=True)
