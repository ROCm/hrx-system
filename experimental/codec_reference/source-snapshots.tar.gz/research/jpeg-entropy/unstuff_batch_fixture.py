"""One bounded sixteen-image compressed-input measurement with streamed arrays."""
from array import array
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
import sys

from byte_compaction_model import model, reference
from device_fixture import input_bytes, write_words
from unstuff_fixtures import entropy_start

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
directory = root / 'unstuff-batch16'
directory.mkdir(exist_ok=True)
data = input_bytes('012mp-bus.jpg.r0.jpg')
start = entropy_start(data)
valid, raw, records, prefixes = model(data, start)
assert (valid, raw) == reference(data, start) and valid
assert len(raw) == 3352410
tiles = (len(data) + 4095) // 4096
batch = 16
chunk = 1024
capacity = tiles * 4
job_count = (len(raw) + chunk - 1) // chunk
word_stride = tiles * 1024 + 2
# These geometric facts are independently decoded from the SOF header below.
position = 2
geometry = None
while position < start:
    assert data[position] == 255
    while data[position] == 255:
        position += 1
    marker = data[position]
    length = int.from_bytes(data[position + 1:position + 3], 'big')
    payload = data[position + 3:position + 1 + length]
    if marker in (0xc0, 0xc1):
        assert payload[0] == 8
        height, width = struct.unpack('>HH', payload[1:5])
        count = payload[5]
        sampling = [(payload[7 + i * 3] >> 4, payload[7 + i * 3] & 15) for i in range(count)]
        horizontal = max(h for h, v in sampling)
        vertical = max(v for h, v in sampling)
        mcu_count = ((width + horizontal * 8 - 1) // (horizontal * 8)) * ((height + vertical * 8 - 1) // (vertical * 8))
        block_count = mcu_count * sum(h * v for h, v in sampling)
        pixel_words = sum(((width * h + horizontal * 8 - 1) // (horizontal * 8)) *
                          ((height * v + vertical * 8 - 1) // (vertical * 8)) * 16 for h, v in sampling)
        geometry = {'width': width, 'height': height, 'blocks': block_count, 'pixel_words': pixel_words}
    if marker == 0xdd:
        assert payload == b'\x00\x00'
    position += 1 + length
assert geometry == {'width': 4032, 'height': 3024, 'blocks': 285768, 'pixel_words': 4572288}


def repeated(filename, payload, repeats, tail=b''):
    assert len(payload) % 4 == 0 and len(tail) % 4 == 0
    count = (len(payload) * repeats + len(tail)) // 4
    header = repr({'descr': '<i4', 'fortran_order': False, 'shape': (count,)}).encode()
    header += b' ' * ((64 - ((10 + len(header) + 1) % 64)) % 64) + b'\n'
    with filename.open('wb') as stream:
        stream.write(b'\x93NUMPY\x01\x00' + struct.pack('<H', len(header)) + header)
        for image in range(repeats):
            stream.write(payload)
        stream.write(tail)
    return count


sizes = {}
padded = data + bytes(tiles * 4096 + 16 - len(data))
sizes['compressed'] = repeated(directory / 'summary-compressed.npy', padded, batch)
encoded = raw + bytes((-len(raw)) % 4 + 8)
words = array('I')
words.frombytes(encoded)
if sys.byteorder == 'little':
    words.byteswap()
entropy_bytes = words.tobytes() + struct.pack('<I', 17) * (word_stride - len(words))
sizes['entropy'] = repeated(directory / 'summary-entropy.npy', entropy_bytes, batch, struct.pack('<I', 17) * 8)
values = {'headers': [], 'records': [], 'prefixes': [], 'segments': [], 'jobs': [], 'errors': []}
marker = min(row[1] for row in records)
code = min(row[2] for row in records)
for image in range(batch):
    values['headers'].extend([len(data), start, geometry['blocks'], image * geometry['pixel_words']])
    values['records'].extend(value for row in records for value in row)
    values['prefixes'].extend(prefixes)
    values['segments'].extend([image * word_stride, len(raw) * 8, image * capacity, job_count,
                               geometry['blocks'], 0, 0, image * geometry['pixel_words']])
    values['jobs'].extend(value for job in range(capacity) for value in
                          (image * word_stride, len(raw) * 8 if job < job_count else 0, job if job < job_count else 0))
    values['errors'].extend([0, marker, code, len(raw)])
for key, value in values.items():
    write_words(directory / ('summary-' + key + '.npy'), value)
    sizes[key] = len(value)
declarations = (root / 'unstuff-small/existing-exif.loom').read_text().split('check.case')[0]
lines = [declarations, 'check.case @summary {']
for key, count in sizes.items():
    lines.append(f'  %{key} = check.file.read.npy path("summary-{key}.npy") : tensor<{count}xi32>')
    if key not in ('compressed', 'headers'):
        lines.append(f'  %{key}_output = check.generate.fill value(17) : tensor<{count}xi32>')
for kernel, arguments in [
        ('jpeg_classify_bytes', ['compressed', 'headers', 'records_output']),
        ('jpeg_prefix_bytes', ['compressed', 'headers', 'records_output', 'prefixes_output', 'segments_output', 'jobs_output', 'errors_output']),
        ('jpeg_compact_bytes', ['compressed', 'headers', 'records_output', 'prefixes_output', 'segments_output', 'errors_output', 'entropy_output'])]:
    names = ', '.join('%' + name for name in arguments)
    types = ', '.join(f'tensor<{sizes[name.removesuffix("_output")]}xi32>' for name in arguments)
    lines.append(f'  kernel.launch @{kernel}({names}) : ({types})')
for key, count in sizes.items():
    if key not in ('compressed', 'headers'):
        lines.append(f'  check.expect.bitwise actual(%{key}_output) expected(%{key}) : tensor<{count}xi32>')
lines.extend(['  check.return', '}', '', 'check.benchmark<@summary> @summary_latency', ''])
(directory / 'summary.loom').write_text('\n'.join(lines))
(directory / 'config.json').write_text(json.dumps({'input': {'tiles': tiles, 'batch': batch, 'chunk_bytes': chunk}}, indent=2) + '\n')
tags = json.loads(os.environ['BUREAU_TAG_ROOTS'])
link = Path(tags['codec-jpeg-rebased-tools']) / 'loom/src/loom/tools/loom-link/loom-link'
library = root / 'entropy-unstuff.loombc'
command = [str(link), str(directory / 'summary.loom'), str(library), '--to=bc', '--output=' + str(directory / 'summary.loombc')]
subprocess.run(command, check=True)
stage = {'files': {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                   for path in directory.iterdir() if path.is_file() and path.name != 'stage.json'},
         'library': {'path': library.name, 'sha256': hashlib.sha256(library.read_bytes()).hexdigest()},
         'scope': 'Three preprocessing dispatches consume original JPEG bytes plus header-only facts, and produce exact unstuffed words and GPU-derived job/segment metadata. Entropy decoding/IDCT/RGB are absent. No host entropy walk/count is an input.',
         'geometry': geometry, 'sizes': sizes, 'jobs': job_count * batch,
         'configuration_capacity_jobs': capacity * batch, 'source_bytes_per_image': len(data),
         'source_sha256': hashlib.sha256(data).hexdigest(), 'header_sos_end': start,
         'link_command': command,
         'retention': 'One reusable compressed batch and one capacity-sized unstuffed expectation, each about54MB under /tmp. No additional coefficient/component/RGB image.'}
(directory / 'stage.json').write_text(json.dumps(stage, indent=2) + '\n')
(notes / 'unstuff-batch-stage.json').write_text(json.dumps(stage, indent=2) + '\n')
print(json.dumps({'sizes': sizes, 'tiles': tiles, 'source_bytes': len(data) * batch,
                  'retained_array_bytes': sum(path.stat().st_size for path in directory.glob('*.npy'))}), flush=True)
