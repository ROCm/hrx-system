"""Change only compressed-output image pitch and its owning segment/job facts."""
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess
from device_fixture import read_words, write_words

parser = argparse.ArgumentParser()
parser.add_argument('--padding', type=int, default=32)
parser.add_argument('--allocation-only', action='store_true')
arguments = parser.parse_args()
assert 2 <= arguments.padding <= 1024
notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
original = root / 'connected-batch16'
directory = root / ('connected-allocation' if arguments.allocation_only else 'connected-stride')
directory.mkdir(exist_ok=True)
configuration = json.loads((original / 'config.json').read_text())
configuration['input']['entropy_padding_words'] = 2 if arguments.allocation_only else arguments.padding
old_stride = configuration['input']['tiles'] * 1024 + 2
new_stride = configuration['input']['tiles'] * 1024 + arguments.padding
image_stride = old_stride if arguments.allocation_only else new_stride
batch = configuration['jpeg']['segments']
source = (notes / 'device_connected_pipeline.cxx').read_text()
needle = 'image * (tile_count * 1024 + 2)'
assert source.count(needle) == 1
declaration = ('[[loom::config("input.entropy_padding_words"), loom::where(loom::predicate::range(2u, 1024u))]]\n'
               'extern const unsigned entropy_padding_words;\n')
# The existing cursor header imports the config predicate API.
insertion = source.index('\n') + 1
source = source[:insertion] + declaration + source[insertion:]
source = source.replace(needle, 'image * (tile_count * 1024 + entropy_padding_words)')
source_path = notes / 'device_stride_pipeline.cxx'
source_path.write_text(source)
bindings = [line.split() for line in (original / 'bindings.txt').read_text().splitlines()]
paths = {row[0]: (original / row[4]).resolve() for row in bindings}
old_entropy = paths['entropy']
with old_entropy.open('rb') as reader:
    assert reader.read(8) == b'\x93NUMPY\x01\x00'
    header = ast.literal_eval(reader.read(struct.unpack('<H', reader.read(2))[0]).decode())
    assert header['shape'] == (old_stride * batch + 8,)
    header['shape'] = (new_stride * batch + 8,)
    text = repr(header)
    padding = (64 - (10 + len(text) + 1) % 64) % 64
    encoded = (text + ' ' * padding + '\n').encode()
    with (directory / 'entropy.npy').open('wb') as writer:
        writer.write(b'\x93NUMPY\x01\x00' + struct.pack('<H', len(encoded)) + encoded)
        for image in range(batch):
            data = reader.read(old_stride * 4)
            assert len(data) == old_stride * 4
            writer.write(data)
            if not arguments.allocation_only:
                writer.write(struct.pack('<I', 17) * (new_stride - old_stride))
        guards = reader.read()
        assert len(guards) == 32
        writer.write(guards)
        if arguments.allocation_only:
            writer.write(struct.pack('<I', 17) * (new_stride - old_stride) * batch)
schedule = read_words(paths['schedule'])
jobs = list(read_words(paths['jobs']))
for job in range(schedule[0]):
    assert jobs[job * 3] % old_stride == 0
    jobs[job * 3] = jobs[job * 3] // old_stride * image_stride
write_words(directory / 'jobs.npy', jobs)
segments = list(read_words(paths['segments']))
for image in range(batch):
    assert segments[image * 8] == image * old_stride
    segments[image * 8] = image * image_stride
write_words(directory / 'segments.npy', segments)
for name in ('entropy', 'jobs', 'segments'):
    paths[name] = directory / (name + '.npy')
for row in bindings:
    row[4] = os.path.relpath(paths[row[0]], directory)
    if row[0] == 'entropy': row[3] = str(new_stride * batch + 8)
(directory / 'bindings.txt').write_text('\n'.join(' '.join(row) for row in bindings) + '\n')
text = (original / 'summary.loom').read_text()
original_paths = {str((original / row[4]).resolve()): row[0] for row in
                  [line.split() for line in (original / 'bindings.txt').read_text().splitlines()]}
text = re.sub(r'check.file.read.npy path\("([^"]+)"\)', lambda match:
              'check.file.read.npy path("' + os.path.relpath(paths[original_paths[str((original / match[1]).resolve())]], directory) + '")', text)
text = text.replace(str(old_stride * batch + 8) + 'xi32', str(new_stride * batch + 8) + 'xi32')
(directory / 'summary.loom').write_text(text)
(directory / 'config.json').write_text(json.dumps(configuration, indent=2) + '\n')
tags = json.loads(os.environ['BUREAU_TAG_ROOTS'])
base = Path(tags['codec-jpeg-rebased-tools']) / 'loom/src/loom/tools'
subprocess.run([str(base / 'loom-import-cxx/loom-import-cxx'), str(source_path), '--output=' + str(directory / 'library.loom')], check=True)
subprocess.run([str(base / 'loom-link/loom-link'), str(directory / 'summary.loom'), str(directory / 'library.loom'),
               '--to=bc', '--output=' + str(directory / 'summary.loombc')], check=True)
files = {os.path.relpath(path, directory): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths.values()}
files.update({path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in directory.iterdir() if path.name != 'stage.json'})
(directory / 'stage.json').write_text(json.dumps({'files': files, 'padding_words': arguments.padding,
    'allocation_only': arguments.allocation_only,
    'scope': ('Allocation-only control: original per-image pitch, larger total entropy allocation identical to the stride candidate.' if arguments.allocation_only else
              'Same original-byte connected decoder; per-image entropy pitch changes from 4KiB*tiles+8 to 4KiB*tiles+padding*4 bytes. No host entropy fact enters the candidate.')}, indent=2) + '\n')
print(json.dumps({'old_pitch': old_stride * 4, 'new_pitch': image_stride * 4, 'extra_bytes': (new_stride - old_stride) * batch * 4}), flush=True)
