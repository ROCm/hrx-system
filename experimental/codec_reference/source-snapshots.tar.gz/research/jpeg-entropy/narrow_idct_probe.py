"""Exercise exact guarded IDCT across its numeric boundary and wide domain."""
import array
import hashlib
import json
import os
from pathlib import Path
import random
import struct
import subprocess
from device_fixture import write_words
from integer_idct import reconstruct

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes/'device-active.json').read_text())['directory'])
fixture = root/'narrow-probe'
fixture.mkdir(exist_ok=True)
coefficients = array.array('h')
quantization = []
expected = bytearray()
counts = {'narrow':0, 'wide':0, 'dc_only':0}
def append(values, steps):
    coefficients.extend(values)
    quantization.extend(steps)
    expected.extend(reconstruct(values, steps))
    bound=max(abs(a*b) for a,b in zip(values,steps))
    counts['narrow' if bound<=1024 else 'wide']+=1
    counts['dc_only']+=not any(values[1:])
for magnitude,step in ((341,3),(512,2),(205,5),(1023,65535)):
    for signs in range(256):
        values=[magnitude if ((signs >> (index & 7)) ^ (index // 8)) & 1 else -magnitude for index in range(64)]
        append(values,[step]*64)
random_generator=random.Random(0x1DC7)
for block in range(64):
    append([random_generator.randrange(-1023,1024) for _ in range(64)],
           [random_generator.randrange(1,65536) for _ in range(64)])
for block in range(32):
    append([(-1024 if block&1 else 1023)]+[0]*63,[1 if block<16 else 65535]*64)
count=len(coefficients)//64
assert count%32==0
header=repr({'descr':'<i2','fortran_order':False,'shape':(len(coefficients),)}).encode()
header+=b' '*((64-((10+len(header)+1)%64))%64)+b'\n'
with (fixture/'coefficients.npy').open('wb') as stream:
    stream.write(b'\x93NUMPY\x01\x00'+struct.pack('<H',len(header))+header)
    coefficients.tofile(stream)
write_words(fixture/'quantization.npy',quantization)
write_words(fixture/'pixels.npy',struct.unpack('<'+'I'*(len(expected)//4),expected))
(fixture/'check.loom').write_text(f'''kernel.decl @idct_probe() launch(%input: buffer, %quantization: buffer, %pixels: buffer)
check.case @guarded_idct {{
  %input = check.file.read.npy path("coefficients.npy") : tensor<{len(coefficients)}xi16>
  %quantization = check.file.read.npy path("quantization.npy") : tensor<{len(quantization)}xi32>
  %expected = check.file.read.npy path("pixels.npy") : tensor<{len(expected)//4}xi32>
  %output = check.generate.fill value(17) : tensor<{len(expected)//4}xi32>
  kernel.launch @idct_probe(%input, %quantization, %output) : (tensor<{len(coefficients)}xi16>, tensor<{len(quantization)}xi32>, tensor<{len(expected)//4}xi32>)
  check.expect.bitwise actual(%output) expected(%expected) : tensor<{len(expected)//4}xi32>
  check.return
}}
''')
(fixture/'config.json').write_text(json.dumps({'jpeg':{'probe_blocks':count}},indent=2)+'\n')
tags=json.loads(os.environ['BUREAU_TAG_ROOTS'])
base=Path(tags['codec-jpeg-rebased-tools'])/'loom/src/loom/tools'
subprocess.run([str(base/'loom-import-cxx/loom-import-cxx'),str(notes/'narrow_idct_probe.cxx'),'--output='+str(fixture/'library.loom')],check=True)
subprocess.run([str(base/'loom-link/loom-link'),str(fixture/'library.loom'),'--to=bc','--output='+str(fixture/'library.loombc')],check=True)
record={'blocks':count,'counts':counts,'scope':'Exact independent integer-model pixels for +/-1023, +/-1024, +/-1025, maximal 16-bit quantization, random wide blocks, and DC-only blocks.',
        'files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in fixture.iterdir() if p.is_file()},
        'sources':{name:hashlib.sha256((notes/name).read_bytes()).hexdigest() for name in ('narrow_idct_probe.cxx','narrow_idct_probe.py','device_reconstruct_narrow.cxx','integer_idct.py')}}
(notes/'narrow-probe-stage.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'blocks':count,'counts':counts}),flush=True)
