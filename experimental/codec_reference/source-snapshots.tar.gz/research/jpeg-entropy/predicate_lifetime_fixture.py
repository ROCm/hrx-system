"""Independent per-lane results for scalar/vector loop predicate transport."""

from pathlib import Path

from device_fixture import write_words


directory = Path('/tmp/codec-jpeg-device-y6frb_3u/rebase-1956')
inputs = []
expected = []
for lane in range(64):
    limit, first, second = lane % 5, (lane // 5) % 2, (lane // 10) % 2
    inputs.extend([limit, first, second])
    head, tail = first, second
    for _ in range(limit):
        head, tail = tail, head
    expected.extend([limit, head, tail, limit == 0, 0, limit > 0])
write_words(directory / 'predicate-input.npy', inputs)
write_words(directory / 'predicate-expected.npy', expected)
(directory / 'predicate-case.loom').write_text('''
kernel.decl @predicate_lifetime() launch(%input: buffer, %output: buffer)
check.case @predicate_values {
  %input = check.file.read.npy path("predicate-input.npy") : tensor<192xi32>
  %output = check.generate.fill value(17) : tensor<384xi32>
  %expected = check.file.read.npy path("predicate-expected.npy") : tensor<384xi32>
  kernel.launch @predicate_lifetime(%input, %output) : (tensor<192xi32>, tensor<384xi32>)
  check.file.write.npy value(%output) path("predicate.npy") mode(always) : tensor<384xi32>
  check.expect.bitwise actual(%output) expected(%expected) : tensor<384xi32>
  check.return
}
''')
