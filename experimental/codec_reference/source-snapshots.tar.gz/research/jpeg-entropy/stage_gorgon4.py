"""Stage one bounded experiment closure without holding a benchmark lease."""
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import tarfile

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
tag = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['codec-jpeg-unsigned-opt'])
files = {}


def add(path, name=None):
    path = path.resolve()
    name = str(path.relative_to(root)) if name is None else name
    assert not Path(name).is_absolute() and '..' not in Path(name).parts
    if name in files:
        assert files[name] == path
    files[name] = path


for name in ('parallel-small-stage.json', 'parallel-large-stage.json'):
    add(root / name)
    for path in json.loads((root / name).read_text())['files']:
        add(root / path)
for fixture in ('bridge-batch16-1024', 'parallel-batch16-1024'):
    stage = root / fixture / 'stage.json'
    add(stage)
    for path in json.loads(stage.read_text())['files']:
        add(stage.parent / path)
for name in ('entropy-bridges.loombc', 'entropy-parallel.loombc'):
    add(root / name)
tools = {}
for tool in ('iree-test-loom', 'iree-benchmark-loom'):
    path = tag / 'loom/src/loom/tools' / tool / tool
    name = tool + '-unsigned'
    add(path, name)
    tools[name] = hashlib.sha256(path.read_bytes()).hexdigest()
assert tools['iree-test-loom-unsigned'] == '5e267978d7e937b1009f64a2e005913a4cc36c002b1f24eef44776cc4683a632'
assert tools['iree-benchmark-loom-unsigned'] == '3ba3a3e1b3a85a876459320d21d1f32630fb625fd0d39347c45cb875d16c1dad'
(root / 'unsigned-tools.json').write_text(json.dumps({'files': tools}, indent=2) + '\n')
add(root / 'unsigned-tools.json')
add(notes / 'device_qualify.py', 'device_tables_qualify.py')
add(notes / 'device_batch_benchmark.py', 'device_batch_benchmark.py')
size = sum(path.stat().st_size for path in files.values())
assert size < 256 * 1024 * 1024, size
print(json.dumps({'files': len(files), 'uncompressed_bytes': size}), flush=True)
command = 'test ! -e ' + shlex.quote(str(root)) + ' && mkdir -m 700 ' + shlex.quote(str(root))
subprocess.run(['ssh', 'hrx-gorgon-4', command], check=True)
command = 'tar -xzf - -C ' + shlex.quote(str(root))
process = subprocess.Popen(['ssh', 'hrx-gorgon-4', command], stdin=subprocess.PIPE,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE)
with tarfile.open(fileobj=process.stdin, mode='w|gz', compresslevel=1) as archive:
    for name, path in files.items():
        archive.add(path, arcname=name, recursive=False)
process.stdin.close()
process.stdin = None
stdout, stderr = process.communicate()
assert process.returncode == 0, (stdout, stderr)
record = {'host': 'hrx-gorgon-4', 'directory': str(root), 'bytes': size,
          'files': {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in files.items()}}
(notes / 'gorgon4-staged.json').write_text(json.dumps(record, indent=2) + '\n')
print('Experiment closure staged without a lease', flush=True)
