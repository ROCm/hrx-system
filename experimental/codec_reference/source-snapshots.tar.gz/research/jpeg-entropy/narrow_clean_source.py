"""Correct the primary-only width diagnostic by deleting the unused bound work."""
from pathlib import Path

notes = Path(__file__).resolve().parent
source = (notes / 'device_reconstruct_narrow_static_diagnostic.cxx').read_text()
for line in (
    '      unsigned maximum = 0;\n',
    '        unsigned magnitude = static_cast<unsigned>(value < 0 ? -value : value);\n',
    '        maximum = magnitude > maximum ? magnitude : maximum;\n',
    '      unsigned block_maximum = loom::kernel::subgroup::reduce::maxui<8>(maximum);\n',
):
    assert source.count(line) == 1
    source = source.replace(line, '')
first = source.index('static LOOM_FORCE_INLINE unsigned sample_byte(')
last = source.index('static LOOM_FORCE_INLINE Symbol output_symbol(', first)
baseline = (notes / 'device_reconstruct_clamp_mask.cxx').read_text()
begin = baseline.index('static LOOM_FORCE_INLINE unsigned sample_byte(')
end = baseline.index('static LOOM_FORCE_INLINE Symbol output_symbol(', begin)
source = source[:first] + baseline[begin:end] + source[last:]
source = source.replace('chunks * 2 + certification_segments', 'chunks * (output_partitions + 1) + certification_segments')
source = source.replace('descriptor[2] * 2 + segment', 'descriptor[2] * (output_partitions + 1) + segment')
source = source.replace('count * 2', 'count * (output_partitions + 1)')
(notes / 'device_reconstruct_narrow_clean_diagnostic.cxx').write_text(source)
pipeline = '#include "device_entropy_cursor_short.h"\n'
pipeline += '''[[loom::config("jpeg.output_partitions"), loom::where(loom::predicate::range(2u, 8u))]]
extern const unsigned output_partitions;
'''
for name in ('device_entropy_partitioned.cxx','device_bridge.cxx','device_certify_partitioned.cxx','device_reconstruct_narrow_clean_diagnostic.cxx'):
    pipeline += '\n'+(notes/name).read_text().replace('#include "device_entropy_cursor.h"', '')+'\n'
(notes / 'device_narrow_clean_diagnostic_pipeline.cxx').write_text(pipeline)
