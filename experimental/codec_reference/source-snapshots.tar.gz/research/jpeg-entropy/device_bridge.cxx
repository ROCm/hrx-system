#include "device_entropy_cursor.h"

static loom::kernel::configuration configure_bridges() {
  unsigned threads = loom::target::subgroup::size() * 4;
  return {{(chunks + threads - 1) / threads, 1, 1}, {threads, 1, 1}};
}

// A record is a later summary index, completed-block delta, and DC deltas.
// An all-ones target means no local connection; only the restart-rooted path
// may certify a record. No absolute predictor or entropy checkpoint is supplied
// by the host. Every candidate trajectory has its own fixed read cap.
[[loom::kernel(configure_bridges)]]
void jpeg_bridge(const unsigned* entropy, const unsigned* jobs,
                 const unsigned* tables, const unsigned* blocks,
                 const unsigned* summaries, unsigned* bridges) {
  unsigned job = loom::kernel::workgroup::id.x * loom::kernel::workgroup::size.x +
                 loom::kernel::workitem::id.x;
  if (job >= chunks) return;
  unsigned stride = (2 + component_count + 3) & ~3u;
  unsigned* output = bridges + job * stride;
  [[loom::unroll]]
  for (unsigned index = 0; index < stride; ++index) output[index] = 0;
  output[0] = 0xffffffffu;
  unsigned interval = jobs[job * 3 + 2];
  unsigned first_job = job - interval;
  unsigned summary_stride = (5 + component_count + 3) & ~3u;
  unsigned start_bit = 0;
  unsigned start_phase = 0;
  bool active = interval == 0;
  if (interval != 0) {
    const unsigned* previous = summaries + (job - 1) * summary_stride;
    start_bit = previous[2];
    start_phase = previous[3];
    const unsigned* current = summaries + job * summary_stride;
    active = previous[0] != 0xffffffffu &&
             (current[0] != start_bit || current[1] != start_phase);
  }
  if (!active) return;
  unsigned bit_limit = jobs[job * 3 + 1];
  unsigned chunk_bits = chunk_bytes * 8;
  unsigned intervals = bit_limit / chunk_bits + (bit_limit % chunk_bits != 0);
  const unsigned* words = entropy + jobs[job * 3];
  Cursor cursor = {};
  cursor.position = start_bit;
  cursor.block_index = start_phase >> 6;
  cursor.blocks = cursor.block_index;
  unsigned first_blocks = cursor.blocks;
  cursor.coefficient = start_phase & 63;
  cursor.budget = chunk_bits * 4 + 26;
  cursor.cached_word = 0xffffffffu;
  unsigned target = 0xffffffffu;
  while (cursor.error == 0 && target == 0xffffffffu) {
    // A saved entry can overshoot its fixed boundary by at most 26 bits.
    // Tiny chunks may have several entries at one symbol; choose the first.
    unsigned lower = cursor.position > 26 ? (cursor.position - 26) / chunk_bits : 0;
    if (cursor.position - lower * chunk_bits > 26) ++lower;
    if (lower < interval) lower = interval;
    unsigned upper = cursor.position / chunk_bits;
    for (unsigned index = lower; index <= upper && index < intervals &&
                                  target == 0xffffffffu; ++index) {
      const unsigned* candidate = summaries + (first_job + index) * summary_stride;
      if (candidate[0] == cursor.position &&
          candidate[1] == cursor.block_index * 64 + cursor.coefficient) {
        target = index;
      }
    }
    if (target != 0xffffffffu || cursor.position - start_bit >= chunk_bits * 4) break;
    cursor = advance(words, tables, blocks, bit_limit, cursor);
  }
  if (target != 0xffffffffu) {
    output[0] = target;
    output[1] = cursor.blocks - first_blocks;
    [[loom::unroll]]
    for (unsigned component = 0; component < component_count; ++component) {
      output[2 + component] = cursor.predictors[component];
    }
  }
}
