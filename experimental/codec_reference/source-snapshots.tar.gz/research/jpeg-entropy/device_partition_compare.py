"""Fixed A/B/A/B/A windows under one lease; no concurrent staging or builds."""
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
assert os.environ['BENCHMARK_LOCK_LEASE_ID']
windows = [('a0', 'batch16'), ('b0', 'batch16-1024'), ('a1', 'batch16'),
           ('b1', 'batch16-1024'), ('a2', 'batch16')]
for name, fixture in windows:
    command = [sys.executable, str(root / 'device_batch_benchmark.py'),
               '--fixture=' + fixture, '--result-name=entropy-partition-' + name]
    subprocess.run(command, check=True)
