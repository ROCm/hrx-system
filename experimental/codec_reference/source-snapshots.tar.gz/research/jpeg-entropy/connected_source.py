"""Connect device-produced entropy, records, and indirect workgroup counts."""
from pathlib import Path

notes = Path(__file__).resolve().parent
pipeline = (notes / 'device_twolevel_pipeline.cxx').read_text()
old = 'unsigned* summaries, unsigned* points) {'
assert pipeline.count(old) == 1
pipeline = pipeline.replace(old, 'unsigned* summaries, unsigned* points, const unsigned* schedule) {')
old = 'const unsigned* summaries, unsigned* bridges) {'
assert pipeline.count(old) == 1
pipeline = pipeline.replace(old, 'const unsigned* summaries, unsigned* bridges, const unsigned* schedule) {')
assert pipeline.count('if (job >= chunks) return;') == 2
pipeline = pipeline.replace('if (job >= chunks) return;', 'if (job >= schedule[0]) return;')
old = 'unsigned group_count = (interval_capacity + stripe - 1) / stripe;'
assert pipeline.count(old) == 1
pipeline = pipeline.replace(old, 'unsigned group_count = loom::kernel::workgroup::count.x;')
for function in ('configure_chunks', 'configure_bridges', 'configure_output'):
    begin = pipeline.index('static loom::kernel::configuration ' + function + '() {')
    end = pipeline.index('\n}', begin) + 2
    reconstruction = function == 'configure_output'
    first = 4 if reconstruction else 1
    threads = 'loom::target::subgroup::size()' + ('' if reconstruction else ' * 4')
    pipeline = pipeline[:begin] + f'''static loom::kernel::configuration {function}(const unsigned* schedule) {{
  unsigned x = schedule[{first}];
  unsigned y = schedule[{first + 1}];
  unsigned z = schedule[{first + 2}];
  // Device job planning uses at most the configured chunk capacity and256
  // images; its grid fits the target's signed index domain.
  loom::assume(x <= 1048576u);
  loom::assume(y <= 256u);
  loom::assume(z == 1u);
  return {{{{x, y, z}}, {{{threads}, 1, 1}}}};
}}''' + pipeline[end:]
pipeline = pipeline.replace('[[loom::config("jpeg.segments"), loom::where(loom::predicate::range(1u, 1048576u))]]',
                            '[[loom::config("jpeg.segments"), loom::where(loom::predicate::range(1u, 256u))]]')

source = (notes / 'device_unstuff.cxx').read_text()
source = source.replace('''[[loom::config("input.batch"), loom::where(loom::predicate::range(1u, 65536u))]]
extern const unsigned image_count;
[[loom::config("input.chunk_bytes"), loom::where(loom::predicate::range(1u, 65536u))]]
extern const unsigned entropy_chunk_bytes;
''', '')
source = source.replace('image_count', 'certification_segments').replace('entropy_chunk_bytes', 'chunk_bytes')
source = source.replace('unsigned* segments, unsigned* jobs, unsigned* errors)',
                        'unsigned* segments, unsigned* errors)')
begin = source.index('  for (unsigned job = lane; job < capacity; job += 256) {')
end = source.index('  if (lane == 0) {', begin)
source = source[:begin] + source[end:]
# The image-prefix stage owns compact global job and suffix-record bases.
source = source.replace('segment[2] = image * capacity;', 'segment[2] = 0;')
source = source.replace('  unsigned capacity = (tile_count * 4096 + chunk_bytes - 1) / chunk_bytes;\n', '')
marker = '[[loom::kernel(configure_tiles)]]\nvoid jpeg_compact_bytes('
position = source.index(marker)
source = source[:position] + '''static loom::kernel::configuration configure_job_prefix() {
  return {{1, 1, 1}, {256, 1, 1}};
}

[[loom::kernel(configure_job_prefix)]]
void jpeg_plan_jobs(unsigned* segments, unsigned* schedule) {
  unsigned image = loom::kernel::workitem::id.x;
  unsigned count = image < certification_segments ? segments[image * 8 + 3] : 0;
  unsigned prefix = loom::kernel::workgroup::scan::addi<loom::kernel::scan_mode::exclusive>(count);
  unsigned total = loom::kernel::workgroup::reduce::addi(count);
  if (image < certification_segments) {
    segments[image * 8 + 2] = prefix;
    segments[image * 8 + 5] = prefix + image;
  }
  if (image == 0) {
    unsigned subgroup = loom::kernel::subgroup::size();
    unsigned intervals = total * (output_partitions + 1) + certification_segments;
    unsigned stripe = subgroup * certification_segments;
    schedule[0] = total;
    schedule[1] = (total + subgroup * 4 - 1) / (subgroup * 4);
    schedule[2] = 1;
    schedule[3] = 1;
    schedule[4] = (intervals + stripe - 1) / stripe;
    schedule[5] = certification_segments;
    schedule[6] = 1;
    schedule[7] = intervals;
  }
}

''' + source[position:]
source = source.replace('unsigned* entropy) {', 'unsigned* entropy, unsigned* jobs) {')
marker = '  unsigned total = errors[image * 4 + 3];'
assert source.count(marker) == 1
source = source.replace(marker, '''  const unsigned* segment = segments + image * 8;
  for (unsigned job = tile * 256 + lane; job < segment[3]; job += tile_count * 256) {
    unsigned* output = jobs + (segment[2] + job) * 3;
    output[0] = segment[0];
    output[1] = segment[1];
    output[2] = job;
  }
''' + marker)
(notes / 'device_unstuff_connected.cxx').write_text(source)
(notes / 'device_connected_pipeline.cxx').write_text(pipeline + '\n' + source)
