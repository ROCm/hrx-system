"""Change only partition size; retain exact connected metadata and final pixels."""
import argparse
import array
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
from bounded import State, Summary
from device_fixture import input_bytes, read_words, write_words
from parallel_bridges import construct, phase
from recover_prefix import speculate
from sequential import parse

parser=argparse.ArgumentParser()
parser.add_argument('chunk',type=int)
arguments=parser.parse_args()
notes=Path(__file__).resolve().parent
root=Path(json.loads((notes/'device-active.json').read_text())['directory'])
original=root/'clamp-mask-batch16-1024'
chunk=arguments.chunk
output=root/f'output-batch16-{chunk}'
output.mkdir(exist_ok=True)
frame=parse(input_bytes('012mp-bus.jpg.r0.jpg'))
scan,=frame.scans
segment,=scan.segments
components=len(frame.components)
assert components==3 and len(scan.blocks)==6
count=(len(segment.data)+chunk-1)//chunk
raw,speculation=speculate(segment,scan,components,chunk*8,1,count)
summaries=[]
expected=[]
for summary in raw:
    record=[0xffffffff]+[0]*7
    if summary is not None:
        a,b=summary.first,summary.last
        first=State(a.position,a.blocks%6,a.coefficient,(0,)*components)
        last=State(b.position,first.blocks+b.blocks-a.blocks,b.coefficient,
                   tuple(end-start for start,end in zip(a.predictors,b.predictors)))
        summary=Summary(first,last)
        record=[first.position,phase(first,6),last.position,phase(last,6),last.blocks-first.blocks,*last.predictors]
    summaries.append(summary)
    expected.extend(record)
trace={}
checkpoints,bridging,transitions=construct(segment,scan,components,summaries,chunk*8,chunk*32,trace)
record={'chunk_bytes':chunk,'jobs_per_image':count,'input_sha256':hashlib.sha256(input_bytes('012mp-bus.jpg.r0.jpg')).hexdigest(),
        'speculation':speculation,'bridging':bridging,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(notes/f'geometry-{chunk}-model.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
# Existing 1 KiB tail is 1,332 symbols; this preflight rejects a large serial
# residual rather than submitting an unexpected whole-image worker to the GPU.
assert bridging['residual_output_symbols']<=8192, 'Rejected: serial residual invalidates this partition'
bridges=[]
for index in range(count):
    bridge=transitions.get(index)
    row=[0xffffffff]+[0]*7
    if bridge is not None and bridge.target is not None:
        row[:5]=[bridge.target,bridge.last.blocks-bridge.first.blocks,*bridge.last.predictors]
    bridges.extend(row)
suffix=[[0]*8 for _ in range(count+1)]
suffix[count][0]=count
for index in range(count-1,-1,-1):
    current=summaries[index]
    following=summaries[index+1] if index+1<count else None
    connected=current is not None and following is not None and current.last.position==following.first.position and phase(current.last,6)==phase(following.first,6)
    suffix[index][0]=suffix[index+1][0] if connected else index+1
    suffix[index][1:]=suffix[index+1][1:]
    if current is not None:
        suffix[index][1]+=current.last.blocks-current.first.blocks
        for component in range(components):suffix[index][component+2]+=current.last.predictors[component]
ranges=[[0xffffffff]+[0]*7 for _ in range(count+1)]
intervals=[[0]*8 for _ in range(2*count+1)]
def interval_record(first,end):
    return [first.position,end,first.blocks,phase(first,6),*first.predictors,0]
for target,(limit,state) in trace['ranges'].items():
    ranges[target][:5]=[limit,state.blocks,*state.predictors]
    for index in range(target,limit):
        summary=summaries[index]
        assert (state.position,phase(state,6))==(summary.first.position,phase(summary.first,6))
        intervals[index]=interval_record(state,summary.last.position)
        state=State(summary.last.position,state.blocks+summary.last.blocks-summary.first.blocks,
                    summary.last.coefficient,tuple(a+b for a,b in zip(state.predictors,summary.last.predictors)))
for index,(first,last) in trace['bridges'].items():intervals[count+index]=interval_record(first,last.position)
intervals[count*2]=interval_record(trace['tail'],len(segment.data)*8)
actual=sorted((row for row in intervals if row[1]>row[0]),key=lambda row:row[0])
expected_intervals=[interval_record(a,b.position) for a,b in zip(checkpoints,checkpoints[1:])]
expected_intervals[-1][1]=len(segment.data)*8
assert actual==expected_intervals
text=(original/'summary.loom').read_text()
pattern=re.compile(r'%([a-z_]+) = check.file.read.npy path\("([^"]+)"\) : tensor<(\d+)xi32>')
paths={m[1]:(original/m[2]).resolve() for m in pattern.finditer(text)}
sizes={m[1]:int(m[3]) for m in pattern.finditer(text)}
segments=list(read_words(paths['segments']))
jobs=array.array('I')
for image in range(16):
    base=image*8
    segments[base+2]=image*count
    segments[base+3]=count
    segments[base+5]=image*(count+1)
    for index in range(count):jobs.extend((segments[base],segments[base+1],index))
values={'segments':segments,'jobs':jobs,'expected':expected*16,'bridges':bridges*16,
        'suffixes':[value for row in suffix for value in row]*16,
        'ranges':[value for row in ranges for value in row]*16,
        'intervals':[value for row in intervals for value in row]*16,
        'status':[0]*((2*count+1)*16)}
for name,value in values.items():
    paths[name]=output/(name+'.npy')
    write_words(paths[name],value)
    sizes[name]=len(value)
declarations=[('jpeg_speculate',('entropy','jobs','tables','blocks','expected')),
              ('jpeg_bridge',('entropy','jobs','tables','blocks','expected','bridges')),
              ('jpeg_index',('segments','expected','suffixes','ranges','intervals')),
              ('jpeg_certify',('segments','expected','bridges','suffixes','ranges','intervals')),
              ('jpeg_intervals',('segments','expected','suffixes','ranges','intervals')),
              ('jpeg_reconstruct',('entropy','segments','tables','blocks','intervals','geometry','quantization','zigzag','pixels','status'))]
outputs=('expected','bridges','suffixes','ranges','intervals','pixels','status')
lines=['kernel.decl @'+entry+'() launch('+', '.join('%'+name+': buffer' for name in names)+')' for entry,names in declarations]
lines+=['','check.case @summary {']
for name,path in paths.items():lines.append(f'  %{name} = check.file.read.npy path("{os.path.relpath(path,output)}") : tensor<{sizes[name]}xi32>')
for name in outputs:lines.append(f'  %{name}_output = check.generate.fill value(17) : tensor<{sizes[name]}xi32>')
for entry,names in declarations:
    arguments=', '.join('%'+name+('_output' if name in outputs else '') for name in names)
    types=', '.join(f'tensor<{sizes[name]}xi32>' for name in names)
    lines.append(f'  kernel.launch @{entry}({arguments}) : ({types})')
for name in outputs:lines.append(f'  check.expect.bitwise actual(%{name}_output) expected(%{name}) : tensor<{sizes[name]}xi32>')
lines+=['  check.return','}','','check.benchmark<@summary> @summary_latency']
(output/'summary.loom').write_text('\n'.join(lines)+'\n')
config=json.loads((original/'config.json').read_text());config['jpeg'].update({'chunk_bytes':chunk,'chunks':count*16})
(output/'config.json').write_text(json.dumps(config,indent=2)+'\n')
tags=json.loads(os.environ['BUREAU_TAG_ROOTS'])
linker=Path(tags['codec-jpeg-rebased-tools'])/'loom/src/loom/tools/loom-link/loom-link'
library=root/'entropy-clamp-mask.loombc'
command=[str(linker),str(output/'summary.loom'),str(library),'--to=bc','--output='+str(output/'summary.loombc')]
subprocess.run(command,check=True)
stage={'batch':16,'jobs':count*16,'sizes':sizes,'scope':'Same complete exact component pipeline and library; partition size alone changes. Final pixels reuse the existing expectation.',
       'library':{'path':library.name,'sha256':hashlib.sha256(library.read_bytes()).hexdigest()},'link_command':command,
       'files':{os.path.relpath(path,output):hashlib.sha256(path.read_bytes()).hexdigest() for path in paths.values()},
       'metadata_bytes':sum(sizes[name]*4 for name in outputs if name not in ('pixels','status')),
       'retention':'Only partition metadata is new in /tmp; existing entropy and complete pixel fixtures are shared.'}
stage['files'].update({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in output.iterdir() if p.is_file() and p.name!='stage.json'})
(output/'stage.json').write_text(json.dumps(stage,indent=2)+'\n')
(notes/f'geometry-{chunk}-stage.json').write_text(json.dumps(stage,indent=2)+'\n')
print(json.dumps({'ready':str(output),'metadata_bytes':stage['metadata_bytes']}),flush=True)
