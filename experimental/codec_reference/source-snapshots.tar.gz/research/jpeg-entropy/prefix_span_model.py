"""Bound the redundant prefix span independently of summary/bridge geometry."""
import argparse
import hashlib
import json
from pathlib import Path

from bounded import Cursor, State, Summary
from device_fixture import input_bytes
from parallel_bridges import construct
from recover_prefix import CountedBits, ReadBudgetExceeded
from sequential import InvalidJPEG, parse

parser = argparse.ArgumentParser()
parser.add_argument('prefix_bytes',type=int)
arguments = parser.parse_args()
notes = Path(__file__).resolve().parent
data = input_bytes('012mp-bus.jpg.r0.jpg')
frame = parse(data)
scan, = frame.scans
segment, = scan.segments
components = len(frame.components)
chunk_bits = 8192
prefix_bits = arguments.prefix_bytes*8
count = (len(segment.data)+1023)//1024
budget = 2*(chunk_bits+prefix_bits)+26
summaries = []
counts = {name:0 for name in ('symbols','overlap_symbols','attempts','read_bits','invalid','resets','exhausted')}
for interval in range(count):
    cursor = Cursor(segment,scan,components)
    cursor.reader = CountedBits(segment.data,max(0,interval*chunk_bits-prefix_bits),budget)
    first = None
    prefix_symbols = 0
    try:
        while cursor.reader.position < interval*chunk_bits:
            position = cursor.reader.position
            try:
                cursor.advance()
            except InvalidJPEG:
                cursor.reader.position = position+1
                cursor.blocks = cursor.coefficient = 0
                cursor.predictors = [0]*components
                counts['resets'] += 1
        first = cursor.state()
        prefix_symbols = cursor.reader.huffman_symbols
        while cursor.reader.position < (interval+1)*chunk_bits:
            cursor.advance()
        last = cursor.state()
        normalized_first = State(first.position,first.blocks%len(scan.blocks),first.coefficient,(0,)*components)
        normalized_last = State(last.position,normalized_first.blocks+last.blocks-first.blocks,last.coefficient,
                                tuple(end-start for start,end in zip(first.predictors,last.predictors)))
        summaries.append(Summary(normalized_first,normalized_last))
    except (InvalidJPEG,ReadBudgetExceeded) as error:
        summaries.append(None)
        counts['invalid'] += 1
        counts['exhausted'] += isinstance(error,ReadBudgetExceeded)
    counts['symbols'] += cursor.reader.huffman_symbols
    counts['attempts'] += cursor.reader.huffman_attempts
    counts['read_bits'] += cursor.reader.read_bits
    counts['overlap_symbols'] += prefix_symbols if first else cursor.reader.huffman_symbols
    assert cursor.reader.read_bits <= budget
trace = {}
checkpoints,bridges,transitions = construct(segment,scan,components,summaries,chunk_bits,chunk_bits*4,trace)
result = {'input_sha256':hashlib.sha256(data).hexdigest(),'prefix_bytes':arguments.prefix_bytes,
          'chunk_bytes':1024,'bridge_cap_bits':chunk_bits*4,'jobs':count,'speculation':counts,
          'bridges':bridges,'bounded_tail':bridges['residual_output_symbols']<=8192,
          'scope':'Independent exact primary-image model, not native timing or decoder selection.',
          'sources':{name:hashlib.sha256((notes/name).read_bytes()).hexdigest() for name in
                     ('prefix_span_model.py','recover_prefix.py','parallel_bridges.py','bounded.py','sequential.py')}}
(notes/f'prefix-span-{arguments.prefix_bytes}.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
