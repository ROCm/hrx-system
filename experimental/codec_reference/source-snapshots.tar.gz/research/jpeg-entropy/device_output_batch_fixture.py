"""One reusable sixteen-image packed component-output fixture under /tmp."""
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess

from device_fixture import read_words, write_words

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
tag = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['codec-jpeg-rebased-tools'])
source = root / 'parallel-batch16-1024'
output = root / 'output-batch16-1024'
output.mkdir(exist_ok=True)
original = json.loads((source / 'stage.json').read_text())
sizes = dict(original['sizes'])
key = '012mp-bus.jpg.r0.jpg-scan0-chunk1024'
case = next(case for case in json.loads((root / 'output-large/fixtures.json').read_text())['cases'] if case['key'] == key)
one_image = root / 'output-pixels/012mp-bus.jpg.r0.jpg-scan0.npy'
with one_image.open('rb') as stream:
    assert stream.read(8) == b'\x93NUMPY\x01\x00'
    length, = struct.unpack('<H', stream.read(2))
    header = ast.literal_eval(stream.read(length).decode())
    payload = stream.read()
assert header['shape'] == (case['sizes']['pixels'],) and len(payload) == header['shape'][0] * 4
sizes['pixels'] = header['shape'][0] * 16
header['shape'] = (sizes['pixels'],)
encoded = repr(header).encode()
encoded += b' ' * ((64 - ((10 + len(encoded) + 1) % 64)) % 64) + b'\n'
with (output / 'pixels.npy').open('wb') as stream:
    stream.write(b'\x93NUMPY\x01\x00' + struct.pack('<H', len(encoded)) + encoded)
    for image in range(16):
        stream.write(payload)
text = (source / 'summary.loom').read_text()
pattern = re.compile(r'%([a-z_]+) = check.file.read.npy path\("([^"]+)"\) : tensor<(\d+)xi32>')
paths = {match[1]: (source / match[2]).resolve() for match in pattern.finditer(text)}
segments = list(read_words(paths['segments']))
for image in range(16):
    segments[image * 8 + 7] = image * case['sizes']['pixels']
write_words(output / 'segments.npy', segments)
paths['segments'] = output / 'segments.npy'
for name in ('geometry', 'quantization', 'zigzag'):
    paths[name] = root / 'output-large' / (key + '-' + name + '.npy')
    sizes[name] = case['sizes'][name]
paths['pixels'] = output / 'pixels.npy'
paths['status'] = output / 'status.npy'
sizes['status'] = original['jobs'] * 2 + 16
write_words(paths['status'], [0] * sizes['status'])
text = pattern.sub(lambda match: '%' + match[1] + ' = check.file.read.npy path("' +
    os.path.relpath(paths[match[1]], output) + '") : tensor<' + match[3] + 'xi32>', text)
names = ('entropy', 'segments', 'tables', 'blocks', 'intervals_output', 'geometry',
         'quantization', 'zigzag', 'pixels_output', 'status_output')
text = 'kernel.decl @jpeg_reconstruct() launch(' + ', '.join('%' + name + ': buffer' for name in names) + ')\n' + text
lines = [f'  %{name} = check.file.read.npy path("{os.path.relpath(paths[name], output)}") : tensor<{sizes[name]}xi32>'
         for name in ('geometry', 'quantization', 'zigzag', 'pixels', 'status')]
lines += [f'  %{name}_output = check.generate.fill value(17) : tensor<{sizes[name]}xi32>' for name in ('pixels', 'status')]
position = text.index('  kernel.launch @jpeg_speculate')
text = text[:position] + '\n'.join(lines) + '\n' + text[position:]
types = ', '.join(f'tensor<{sizes[name.removesuffix("_output")]}xi32>' for name in names)
line = '  kernel.launch @jpeg_reconstruct(' + ', '.join('%' + name for name in names) + f') : ({types})\n'
position = text.index('  check.expect.bitwise')
text = text[:position] + line + text[position:]
lines = [f'  check.expect.bitwise actual(%{name}_output) expected(%{name}) : tensor<{sizes[name]}xi32>' for name in ('pixels', 'status')]
text = text.replace('  check.return', '\n'.join(lines) + '\n  check.return')
(output / 'summary.loom').write_text(text)
config = json.loads((root / 'output-config.json').read_text())
(output / 'config.json').write_text(json.dumps(config, indent=2) + '\n')
command = [str(tag / 'loom/src/loom/tools/loom-link/loom-link'), str(output / 'summary.loom'),
           str(root / 'entropy-output.loombc'), '--to=bc', '--output=' + str(output / 'summary.loombc')]
subprocess.run(command, check=True)
files = {os.path.relpath(path, output): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths.values()}
files.update({path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in output.iterdir()
              if path.is_file() and path.name != 'stage.json'})
stage = {'batch': 16, 'jobs': original['jobs'], 'sizes': sizes, 'files': files,
         'library': {'path': 'entropy-output.loombc',
                     'sha256': hashlib.sha256((root / 'entropy-output.loombc').read_bytes()).hexdigest()},
         'scope': 'Six GPU dispatches through exact component samples: speculation, bridges, suffixes, certification, intervals, fused entropy/dequantization/integer-IDCT output. Sixteen distinct image inputs/outputs; block-planar samples match public JDCT_ISLOW. Device destuffing, fancy chroma/RGB, and serving ownership remain absent.',
         'link_command': command, 'source_fixture': key,
         'retention': 'One reusable 292626432-byte expected component fixture in /tmp; retire at the comparison checkpoint. No full coefficient image.'}
(output / 'stage.json').write_text(json.dumps(stage, indent=2) + '\n')
(notes / 'device-output-batch.json').write_text(json.dumps(stage, indent=2) + '\n')
print(json.dumps({'jobs': stage['jobs'], 'pixel_bytes': sizes['pixels'] * 4, 'status_bytes': sizes['status'] * 4}), flush=True)
