"""Pin the native upload CPU qualification and its independent expectations."""

import hashlib
import json
from pathlib import Path
import subprocess


notes = Path(__file__).resolve().parent
build_log = notes / "native-upload-test.log"
test_log = Path("bazel-testlogs/experimental/codec_reference/research/jpeg-entropy/native_upload_test/test.log")
assert "2 tests pass." in build_log.read_text()
assert "[  PASSED  ] 7 tests." in test_log.read_text()
files = ["native_header.c", "native_header.h", "native_metadata.c", "native_metadata.h",
         "native_color.c", "native_color.h", "native_upload.c", "native_upload.h",
         "device_upload.h", "native_upload_cases.py", "native_upload_cases.inc",
         "native_upload_test.cc", "BUILD.bazel"]
record = {
    "passed": True, "tests": 7, "configuration": "asan",
    "compiler_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
    "command": ["iree-bazel-test", "--config=asan", "//experimental/codec_reference/research/jpeg-entropy:native_upload_test",
                "//experimental/codec_reference/research/jpeg-entropy:native_header_test"],
    "sources": {name: hashlib.sha256((notes / name).read_bytes()).hexdigest() for name in files},
    "cases": json.loads((notes / "native-upload-cases.json").read_text()),
    "test_log_sha256": hashlib.sha256(test_log.read_bytes()).hexdigest(),
    "build_log_sha256": hashlib.sha256(build_log.read_bytes()).hexdigest(),
    "scope": "Exact equality of nine immutable inputs for sixteen images and all 26 binding extents; disjoint aligned root ranges; unread poisoned entropy during preparation; opaque malformed-body copying; original input release; one upload allocation and failure cleanup; 4096-byte tile edges, maximum 4 MiB input and 256-image count; root/launch bounds before allocation; explicit per-image restart rejection. No device execution or HTTP/performance claim from these CPU tests.",
}
(notes / "native-upload-result.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"passed": True, "tests": 7, "images": record["cases"]["images"],
                  "immutable_bytes": record["cases"]["immutable_bytes"]}))
