"""Counterfactual guard attribution; fixture entropy count is not a valid input."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
original = root / 'connected-batch16'
directory = root / 'connected-constant-guard'
directory.mkdir(exist_ok=True)
source = (notes / 'device_connected_pipeline.cxx').read_text()
needle = 'if (job >= schedule[0]) return;'
assert source.count(needle) == 2
source = source.replace(needle, 'if (job >= 52384u) return;', 1)
source_path = notes / 'device_constant_guard_pipeline.cxx'
source_path.write_text(source)
tags = json.loads(os.environ['BUREAU_TAG_ROOTS'])
base = Path(tags['codec-jpeg-rebased-tools']) / 'loom/src/loom/tools'
subprocess.run([str(base / 'loom-import-cxx/loom-import-cxx'), str(source_path),
               '--output=' + str(directory / 'library.loom')], check=True)
text = (original / 'summary.loom').read_text()
text = re.sub(r'check.file.read.npy path\("([^"]+)"\)', lambda match: 'check.file.read.npy path("' + os.path.relpath((original / match[1]).resolve(), directory) + '")', text)
(directory / 'summary.loom').write_text(text)
(directory / 'config.json').write_bytes((original / 'config.json').read_bytes())
bindings = [line.split() for line in (original / 'bindings.txt').read_text().splitlines()]
files = {}
for row in bindings:
    path = (original / row[4]).resolve()
    row[4] = os.path.relpath(path, directory)
    files[row[4]] = hashlib.sha256(path.read_bytes()).hexdigest()
(directory / 'bindings.txt').write_text('\n'.join(' '.join(row) for row in bindings) + '\n')
subprocess.run([str(base / 'loom-link/loom-link'), str(directory / 'summary.loom'), str(directory / 'library.loom'),
               '--to=bc', '--output=' + str(directory / 'summary.loombc')], check=True)
files.update({path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in directory.iterdir() if path.name != 'stage.json'})
(directory / 'stage.json').write_text(json.dumps({'files': files, 'scope': 'Counterfactual only: speculate guard knows the fixture job count. Every other stage, launch, and data layout is unchanged. Forbidden as a production solution.'}, indent=2) + '\n')
