"""Join the pinned decoder bodies to the finite model's two buffer roots."""

import hashlib
import json
from pathlib import Path
import re


notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / "device-active.json").read_text())["directory"])
baseline = root / "mixed-current"
directory = root / "native-upload"
directory.mkdir(exist_ok=True)
source_manifest = json.loads((notes / "mixed-source.json").read_text())
for name, expected in source_manifest["files"].items():
    assert hashlib.sha256((baseline / name).read_bytes()).hexdigest() == expected
    if name.endswith(".h"):
        (directory / name).write_bytes((baseline / name).read_bytes())
(directory / "device_upload.h").write_bytes((notes / "device_upload.h").read_bytes())
source = (baseline / "mixed_pipeline.cxx").read_text()
inputs = {"tables", "blocks", "geometry", "quantization", "zigzag", "compressed",
          "headers", "color_tiles", "color_schedule"}
aliases = {"summaries": "expected", "components": "pixels"}
entries = []


def wrapper(match):
    configure, name, signature = match.groups()
    parameters = []
    for parameter in signature.split(","):
        spelling, variable = parameter.strip().rsplit("*", 1)
        variable = variable.strip()
        buffer = aliases.get(variable, variable)
        owner = "input" if buffer in inputs else "output"
        expression = f"{owner} + upload_offset(input, JPEG_{buffer.upper()})"
        parameters.append(f"reinterpret_cast<{spelling.strip()}*>({expression})")
    dynamic = configure in ("configure_chunks", "configure_bridges", "configure_output", "configure_color")
    configuration = configure
    config_arguments = "color" if configure == "configure_color" else "schedule" if dynamic else None
    entries.append({"name": name, "configure": configure, "configuration": configuration,
                    "config_arguments": config_arguments, "arguments": parameters})
    return f"static LOOM_FORCE_INLINE void {name}_body({signature}) {{"


source = re.sub(r"\[\[loom::kernel\((\w+)\)\]\]\s*void (jpeg_\w+)\(([^)]*)\)\s*\{", wrapper, source)
assert len(entries) == 12
source = '#include "device_upload.h"\n#include <loomcxx/kernel.h>\n#include <loomcxx/predicate.h>\n' + '''
// Every lane reads the same immutable directory. Retain that shared address
// explicitly instead of carrying identical pointers through per-lane arithmetic.
static LOOM_FORCE_INLINE unsigned upload_offset(const unsigned* input, unsigned buffer) {
  unsigned offset = loom::kernel::subgroup::broadcast_first(input[buffer]);
  loom::assume(loom::predicate::multiple_of(offset, 16u));
  return offset / 4;
}
''' + source
for entry in entries:
    if entry["config_arguments"] == "schedule":
        signature = f'static loom::kernel::configuration {entry["configure"]}(const unsigned* schedule) {{'
        assert source.count(signature) == 1
        source = source.replace(signature,
            f'static loom::kernel::configuration {entry["configure"]}(const unsigned* input, const unsigned* output) {{\n'
            '  const unsigned* schedule = output + input[JPEG_SCHEDULE] / 4;')
    elif entry["config_arguments"] == "color":
        signature = f'static loom::kernel::configuration {entry["configure"]}(const unsigned* color_schedule) {{'
        assert source.count(signature) == 1
        source = source.replace(signature,
            f'static loom::kernel::configuration {entry["configure"]}(const unsigned* input) {{\n'
            '  const unsigned* color_schedule = input + input[JPEG_COLOR_SCHEDULE] / 4;')
    source += f'''
[[loom::kernel({entry["configuration"]})]]
void {entry["name"]}(const unsigned* input, unsigned* output) {{
  {entry["name"]}_body({", ".join(entry["arguments"])});
}}
'''
(directory / "upload_pipeline.cxx").write_text(source)

declarations = []
launches = []
by_name = {entry["name"]: entry for entry in entries}
order = re.findall(r"    kernel.launch @(jpeg_\w+)", (baseline / "summary.loom").read_text())
assert len(order) == 12 and len(set(order)) == 12
for name in order:
    kind = by_name[name]["config_arguments"]
    declaration = "%launch_input: buffer, %input_offset: offset"
    arguments, types = "%input, %zero", "buffer, offset"
    if kind == "schedule":
        declaration += ", %launch_output: buffer, %output_offset: offset"
        arguments += ", %output, %zero"
        types += ", buffer, offset"
    if not kind:
        declaration = ""
    declarations.append(f"kernel.decl @{name}({declaration}) launch(%input: buffer, %output: buffer)")
    config = f"[{arguments}]" if kind else ""
    signature = f"[{types}]" if kind else ""
    launches.append(f"    kernel.launch @{name}{config}(%input, %output) : {signature}(buffer, buffer)")
program = "\n".join(declarations) + '''

command.program.def public @jpeg_upload_decode() launch(%input: buffer, %output: buffer) {
  %zero = index.constant 0 : offset
  command.serial {
''' + "\n".join(launches) + '''
  }
  command.return
}
'''
(directory / "command.loom").write_text(program)
(directory / "config.json").write_bytes((baseline / "config.json").read_bytes())
record = {"baseline": source_manifest, "entries": entries,
          "files": {name: hashlib.sha256((directory / name).read_bytes()).hexdigest()
                    for name in ("upload_pipeline.cxx", "command.loom", "mixed_cursor.h", "mixed_image.h", "device_upload.h", "config.json")}}
(notes / "upload-source.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"directory": str(directory), "kernels": len(entries), "source_bytes": len(source)}))
