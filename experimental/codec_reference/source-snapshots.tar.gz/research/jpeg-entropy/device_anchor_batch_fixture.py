"""Sixteen disjoint images through two connected device dispatches."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

from device_fixture import read_words, write_words

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
tag = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['codec-jpeg-rebased-tools'])
linker = tag / 'loom/src/loom/tools/loom-link/loom-link'
records = []
for chunk_bytes, source_name in ((4096, 'batch16'), (1024, 'batch16-1024')):
    output = root / ('anchor-' + source_name)
    output.mkdir(exist_ok=True)
    source = root / source_name
    original = json.loads((source / 'stage.json').read_text())
    key = f'012mp-bus.jpg.r0.jpg-scan0-chunk{chunk_bytes}'
    segment = read_words(root / 'anchor-large' / (key + '-segments.npy'))
    checkpoint = read_words(root / 'anchor-large' / (key + '-checkpoints.npy'))
    assert len(segment) == 8 and segment[0] == segment[2] == segment[5] == 0
    segments = []
    entropy_words = original['sizes']['entropy'] // 16
    jobs_per_image = original['jobs'] // 16
    checkpoints_per_image = len(checkpoint) // 8
    assert checkpoints_per_image == jobs_per_image + 1
    for image in range(16):
        descriptor = list(segment)
        descriptor[0] += image * entropy_words
        descriptor[2] += image * jobs_per_image
        descriptor[5] += image * checkpoints_per_image
        segments.extend(descriptor)
    write_words(output / 'segments.npy', segments)
    write_words(output / 'checkpoints.npy', checkpoint * 16)
    write_words(output / 'status.npy', [0] * 16)
    sizes = dict(original['sizes'])
    sizes.update({'segments': len(segments), 'checkpoints': len(checkpoint) * 16, 'status': 16})
    lines = [
        'kernel.decl @jpeg_speculate() launch(%entropy: buffer, %jobs: buffer, %tables: buffer, %blocks: buffer, %summaries: buffer)',
        'kernel.decl @jpeg_anchor() launch(%entropy: buffer, %segments: buffer, %tables: buffer, %blocks: buffer, %summaries: buffer, %checkpoints: buffer, %status: buffer)',
        '', 'check.case @summary {']
    for name in sizes:
        path = f'../{source_name}/{name}.npy' if name in original['sizes'] else name + '.npy'
        lines.append(f'  %{name} = check.file.read.npy path("{path}") : tensor<{sizes[name]}xi32>')
    for name in ('expected', 'checkpoints', 'status'):
        lines.append(f'  %{name}_output = check.generate.fill value(17) : tensor<{sizes[name]}xi32>')
    for entry, names in (
        ('jpeg_speculate', ('entropy', 'jobs', 'tables', 'blocks', 'expected_output')),
        ('jpeg_anchor', ('entropy', 'segments', 'tables', 'blocks', 'expected_output', 'checkpoints_output', 'status_output'))):
        types = ', '.join(f'tensor<{sizes[name.removesuffix("_output")]}xi32>' for name in names)
        lines.append(f'  kernel.launch @{entry}(' + ', '.join('%' + name for name in names) + f') : ({types})')
    for name in ('expected', 'checkpoints', 'status'):
        lines.append(f'  check.expect.bitwise actual(%{name}_output) expected(%{name}) : tensor<{sizes[name]}xi32>')
    lines.extend(('  check.return', '}', '', 'check.benchmark<@summary> @summary_latency'))
    (output / 'summary.loom').write_text('\n'.join(lines) + '\n')
    config = json.loads((source / 'config.json').read_text())
    config['jpeg'].update({'segments': 16, 'table_count': sizes['tables'] // 832, 'cache_tables': 0})
    (output / 'config.json').write_text(json.dumps(config, indent=2) + '\n')
    command = [str(linker), str(output / 'summary.loom'), str(root / 'entropy-pipeline.loombc'),
               '--to=bc', '--output=' + str(output / 'summary.loombc')]
    subprocess.run(command, check=True)
    files = {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
             for path in output.iterdir() if path.is_file() and path.name != 'stage.json'}
    files.update({'../' + source_name + '/' + name + '.npy': original['files'][name + '.npy']
                  for name in original['sizes']})
    stage = {'batch': 16, 'jobs': original['jobs'], 'sizes': sizes, 'files': files,
             'library': {'path': 'entropy-pipeline.loombc',
                         'sha256': hashlib.sha256((root / 'entropy-pipeline.loombc').read_bytes()).hexdigest()},
             'scope': 'GPU speculative summaries followed by exact anchor/repair/checkpoints. One lane per restart segment in the anchor experiment. Unstuffed resident inputs and verified geometry; device destuffing, coefficient output, IDCT, and RGB remain absent.',
             'link_command': command, 'source_fixture': key}
    (output / 'stage.json').write_text(json.dumps(stage, indent=2) + '\n')
    records.append({'directory': output.name, 'stage': stage})
    print(json.dumps({'directory': str(output), 'jobs': stage['jobs'],
                      'checkpoint_bytes': sizes['checkpoints'] * 4}), flush=True)
(notes / 'device-anchor-batches.json').write_text(json.dumps(records, indent=2) + '\n')
