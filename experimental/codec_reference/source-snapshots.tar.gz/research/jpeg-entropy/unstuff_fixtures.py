"""Original compressed inputs and exact byte/metadata expectations."""
import hashlib
import json
from pathlib import Path
import struct

from byte_compaction_model import model, reference
from device_fixture import input_bytes, write_words

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])


def entropy_start(data):
    """Only header marker lengths are inspected; entropy is never visited."""
    assert data[:2] == b'\xff\xd8'
    position = 2
    while position < len(data):
        assert data[position] == 255
        while data[position] == 255:
            position += 1
        marker = data[position]
        length = int.from_bytes(data[position + 1:position + 3], 'big')
        assert length >= 2 and position + 1 + length <= len(data)
        position += 1 + length
        if marker == 0xda:
            return position
    raise ValueError('No SOS')


def fixture(directory, name, data, start, chunk_bytes=1024):
    valid, raw, records, prefixes = model(data, start)
    assert (valid, raw) == reference(data, start)
    tiles = max(1, (len(data) + 4095) // 4096)
    if not records:
        records = [(0, 0xffffffff, 0xffffffff, 0xffffffff)]
        prefixes = [0]
    capacity = (tiles * 4096 + chunk_bytes - 1) // chunk_bytes
    padded_input = data + bytes(tiles * 4096 + 16 - len(data))
    marker = min(record[1] for record in records)
    code = min(record[2] for record in records)
    invalid = min(record[3] for record in records)
    error = 0
    if code == 0xffffffff:
        error = 1
    else:
        if data[code + 1] != 0xd9:
            error = 2
        if code + 2 != len(data) or invalid < code:
            error = 1
    assert (error == 0) == valid
    job_count = (len(raw) + chunk_bytes - 1) // chunk_bytes
    headers = [len(data), start, 6, 0]
    segments = [0, len(raw) * 8, 0, job_count, 6, 0, 0, 0]
    jobs = [value for job in range(capacity)
            for value in (0, len(raw) * 8 if job < job_count else 0, job if job < job_count else 0)]
    # Preserve untouched capacity and trailing guard words as distinct sentinels.
    entropy = [17] * (tiles * 1024 + 2 + 8)
    packed = raw + bytes((-len(raw)) % 4 + 8)
    entropy[:len(packed) // 4] = struct.unpack('>' + 'I' * (len(packed) // 4), packed)
    values = {'compressed': struct.unpack('<' + 'I' * (len(padded_input) // 4), padded_input),
              'headers': headers, 'records': [value for row in records for value in row],
              'prefixes': prefixes if valid else [0] * tiles, 'segments': segments,
              'jobs': jobs, 'errors': [error, marker, code, len(raw)], 'entropy': entropy}
    for key, words in values.items():
        write_words(directory / (name + '-' + key + '.npy'), words)
    declarations = [
        'kernel.decl @jpeg_classify_bytes() launch(%compressed: buffer, %headers: buffer, %records: buffer)',
        'kernel.decl @jpeg_prefix_bytes() launch(%compressed: buffer, %headers: buffer, %records: buffer, %prefixes: buffer, %segments: buffer, %jobs: buffer, %errors: buffer)',
        'kernel.decl @jpeg_compact_bytes() launch(%compressed: buffer, %headers: buffer, %records: buffer, %prefixes: buffer, %segments: buffer, %errors: buffer, %entropy: buffer)',
        '', 'check.case @bytes {']
    lines = declarations
    for key, words in values.items():
        lines.append(f'  %{key} = check.file.read.npy path("{name}-{key}.npy") : tensor<{len(words)}xi32>')
        if key not in ('compressed', 'headers'):
            lines.append(f'  %{key}_output = check.generate.fill value(17) : tensor<{len(words)}xi32>')
    for kernel, arguments in [
            ('jpeg_classify_bytes', ['compressed', 'headers', 'records_output']),
            ('jpeg_prefix_bytes', ['compressed', 'headers', 'records_output', 'prefixes_output', 'segments_output', 'jobs_output', 'errors_output']),
            ('jpeg_compact_bytes', ['compressed', 'headers', 'records_output', 'prefixes_output', 'segments_output', 'errors_output', 'entropy_output'])]:
        names = ', '.join('%' + name for name in arguments)
        types = ', '.join(f'tensor<{len(values[name.removesuffix("_output")])}xi32>' for name in arguments)
        lines.append(f'  kernel.launch @{kernel}({names}) : ({types})')
    for key, words in values.items():
        if key not in ('compressed', 'headers'):
            lines.append(f'  check.expect.bitwise actual(%{key}_output) expected(%{key}) : tensor<{len(words)}xi32>')
    lines.extend(['  check.return', '}', '', 'check.benchmark<@bytes> @bytes_latency', ''])
    (directory / (name + '.loom')).write_text('\n'.join(lines))
    (directory / (name + '.json')).write_text(json.dumps({'input': {'tiles': tiles, 'batch': 1, 'chunk_bytes': chunk_bytes}}, indent=2) + '\n')
    return {'key': name, 'jobs': capacity, 'valid': valid, 'size': len(data),
            'header_bytes': start, 'input_sha256': hashlib.sha256(data).hexdigest()}


if __name__ == '__main__':
    directory = root / 'unstuff-small'
    directory.mkdir(exist_ok=True)
    rows = []
    data = input_bytes('existing_exif_fixture')
    rows.append(fixture(directory, 'existing-exif', data, entropy_start(data)))
    prefix = b'\xff\xda\x00\x05\xff\x00\xd9'
    for boundary in (0, 15, 16, 4095, 4096):
        for name, ending in (
                ('stuffed', b'\xff\x00\x44\xff\x00\xff\xd9'),
                ('fill', b'\xff' * 37 + b'\xd9'),
                ('long-fill', b'\xff' * 4100 + b'\xd9'),
                ('fill-stuffed', b'\xff\xff\x00\xff\xd9'),
                ('truncated', b'\xff'),
                ('restart', b'\xff\xd0\x32\xff\xd9'),
                ('following-scan', b'\xff\xda'),
                ('trailing', b'\xff\xd9\x12')):
            data = prefix + b'\x23' * boundary + ending
            rows.append(fixture(directory, f'{name}-{boundary}', data, len(prefix)))
    for name, data in [('empty', b''), ('empty-entropy', b'\xff\xd9'),
                       ('no-marker', b'\x23' * 5000),
                       ('dense-stuffed', b'\xff\x00' * 4097 + b'\xff\xd9')]:
        rows.append(fixture(directory, name, data, 0, 32))
    (directory / 'fixtures.json').write_text(json.dumps({'cases': rows}, indent=2) + '\n')
    files = {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
             for path in directory.iterdir() if path.is_file()}
    stage = {'files': files, 'check_tool_sha256': '5e267978d7e937b1009f64a2e005913a4cc36c002b1f24eef44776cc4683a632'}
    (root / 'unstuff-small-stage.json').write_text(json.dumps(stage, indent=2) + '\n')
    (notes / 'unstuff-small-fixtures.json').write_text(json.dumps({'cases': rows, 'stage': stage}, indent=2) + '\n')
    print(len(rows), 'native fixture cases')
