"""Stage independent native-upload cases and run one bounded GPU check."""

import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import tarfile


notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / "device-active.json").read_text())["directory"])
directory = root / "native-upload"
cases = json.loads((notes / "upload-negative-cases.json").read_text())
assert len(cases["cases"]) == 28
build = json.loads((notes / "upload-probe-build.json").read_text())
assert build["restored"] and build["build_returncode"] == 0 and build["configuration"] == "asan"
for name, expected in build["sources"].items():
    assert hashlib.sha256((notes / name).read_bytes()).hexdigest() == expected, name
tag = "codec-jpeg-upload-checks"
capture = json.loads(subprocess.check_output(["bureau-bazel", "tag", "inspect", tag, "--json"], text=True))
assert capture["capture"] == build["capture"]["capture"]
binary = Path(json.loads(os.environ["BUREAU_TAG_ROOTS"])[tag]) / "loom/src/loom/tooling/target/amdgpu/serve/codec_upload_probe"
compiled = json.loads((notes / "upload-compile.json").read_text())
assert len(compiled["leaves"]) == 12
assert hashlib.sha256((directory / "summary.loombc").read_bytes()).hexdigest() == compiled["bytecode_sha256"]
files = {"codec_upload_probe": binary,
         "native-upload/summary.loombc": directory / "summary.loombc",
         "native-upload/config.json": directory / "config.json",
         "native-upload/cases.txt": directory / "cases.txt"}
assert hashlib.sha256((directory / "cases.txt").read_bytes()).hexdigest() == cases["cases_file_sha256"]
for case in cases["cases"]:
    for filename, expected in case["files"].items():
        path = directory / case["name"] / filename
        assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, str(path)
        files[str(path.relative_to(root))] = path
assert sum(path.stat().st_size for path in files.values()) < 128 * 1024 * 1024
manifest = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in files.items()}
(directory / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
files["native-upload/manifest.json"] = directory / "manifest.json"
process = subprocess.Popen(["ssh", "hrx-gorgon-4", "tar -xf - -C " + shlex.quote(str(root))], stdin=subprocess.PIPE)
with tarfile.open(fileobj=process.stdin, mode="w|", dereference=True) as archive:
    for name, path in files.items():
        archive.add(path, arcname=name, recursive=False)
process.stdin.close()
assert process.wait() == 0
verify = '''import hashlib,json,pathlib,sys
root=pathlib.Path(sys.argv[1]);files=json.loads((root/'native-upload/manifest.json').read_text())
for name,digest in files.items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
assert not list(pathlib.Path('/sys/class/kfd/kfd/proc').iterdir())
'''
subprocess.run(["ssh", "hrx-gorgon-4", shlex.join(["python3", "-B", "-c", verify, str(root)])], check=True)
command = ["/home/benvanik/.dotfiles/bin/benchmark-lock", "--label=codec-native-jpeg-upload-validity", "--",
           "timeout", "--signal=INT", "--kill-after=10s", "120s", "env", "LD_LIBRARY_PATH=/opt/rocm/lib",
           "stdbuf", "-oL", "-eL", str(root / "codec_upload_probe"),
           "--jpeg_fixture=" + str(directory), "--gtest_filter=NativeUploadDeviceTest.OriginalBytesThroughTwoRoots",
           "--amdgpu_asan=true", "--amdgpu_asan_report_policy=fail-device"]
log = notes / "gorgon4-native-upload-validity.log"
with log.open("w") as stream:
    result = subprocess.run(["ssh", "hrx-gorgon-4", shlex.join(command)], stdout=stream, stderr=subprocess.STDOUT)
status = subprocess.run(["ssh", "hrx-gorgon-4", "/home/benvanik/.dotfiles/bin/benchmark-lock --status"], capture_output=True, text=True)
record = {"command": command, "returncode": result.returncode,
          "broker_status_after": status.stdout + status.stderr, "broker_status_returncode": status.returncode,
          "build": build, "compiled": compiled, "manifest": manifest,
          "cases_sha256": hashlib.sha256((notes / "upload-negative-cases.json").read_bytes()).hexdigest(),
          "rows": [json.loads(line) for line in log.read_text().splitlines() if line.startswith('{"phase":')],
          "log_sha256": hashlib.sha256(log.read_bytes()).hexdigest(),
          "scope": "Native header facts and owned original-byte uploads through two execution roots; one positive and 27 entropy-invalid cohorts, one reused compiled command, independent all-binding expectations, host ASAN and device access checks. No HTTP lifecycle or performance qualification."}
(notes / "gorgon4-native-upload-validity.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"returncode": result.returncode, "broker_status_after": record["broker_status_after"]}), flush=True)
print(log.read_text()[-8000:], flush=True)
assert result.returncode == 0
assert len([row for row in record["rows"] if row["phase"] == "exact"]) == 26
assert len([row for row in record["rows"] if row["phase"] == "regions"]) == 27 * 26
assert len([row for row in record["rows"] if row["phase"] == "command"]) == 1
assert len([row for row in record["rows"] if row["phase"] == "complete"]) == 1
assert record["rows"][-1] == {"phase": "complete", "cases": 28, "compilations": 1}
qualified = json.loads((notes / "entropy-validity-result.json").read_text())
expected_errors = {f'negative/{name}-{row["ordinal"]}': row
                   for name, entries in qualified["classes"].items() for row in entries}
seen = set()
for row in record["rows"]:
    if row["phase"] == "case":
        case_name = row["name"]
    elif row["phase"] == "body_error":
        expected = expected_errors[case_name]
        assert row["ordinal"] == expected["ordinal"] and row["value"] == expected["status"]
        assert case_name not in seen
        seen.add(case_name)
assert seen == set(expected_errors)
