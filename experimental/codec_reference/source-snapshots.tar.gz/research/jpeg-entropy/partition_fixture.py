"""Independent retained-state expectations over the existing complete corpus."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
from bounded import Cursor, State
from device_fixture import input_bytes, read_words, write_words
from sequential import parse

parser=argparse.ArgumentParser()
parser.add_argument('--partitions',type=int,default=4)
parser.add_argument('--family',choices=('small','large'),required=True)
arguments=parser.parse_args()
partitions=arguments.partitions
notes=Path(__file__).resolve().parent
root=Path(json.loads((notes/'device-active.json').read_text())['directory'])
source=root/('output-'+arguments.family)
output=root/(f'partitions{partitions}-'+arguments.family)
output.mkdir(exist_ok=True)
pattern=re.compile(r'%([a-z_]+) = check.file.read.npy path\("([^"]+)"\) : tensor<(\d+)xi32>')
frames={};cases=[];all_paths=set()
outputs=('expected','bridges','suffixes','ranges','points','intervals','pixels','status')
declarations=[('jpeg_speculate',('entropy','jobs','tables','blocks','expected','points')),
              ('jpeg_bridge',('entropy','jobs','tables','blocks','expected','bridges')),
              ('jpeg_index',('segments','expected','suffixes','ranges','intervals')),
              ('jpeg_certify',('segments','expected','bridges','suffixes','ranges','intervals')),
              ('jpeg_intervals',('segments','expected','suffixes','ranges','points','intervals')),
              ('jpeg_reconstruct',('entropy','segments','tables','blocks','intervals','geometry','quantization','zigzag','pixels','status'))]

def signed(value):return value if value<0x80000000 else value-0x100000000

def write_case(path,paths,sizes):
    lines=['kernel.decl @'+entry+'() launch('+', '.join('%'+name+': buffer' for name in names)+')' for entry,names in declarations]
    lines+=['','check.case @summary {']
    for name,file in paths.items():lines.append(f'  %{name} = check.file.read.npy path("{os.path.relpath(file,path.parent)}") : tensor<{sizes[name]}xi32>')
    for name in outputs:lines.append(f'  %{name}_output = check.generate.fill value(17) : tensor<{sizes[name]}xi32>')
    for entry,names in declarations:
        values=', '.join('%'+name+('_output' if name in outputs else '') for name in names)
        types=', '.join(f'tensor<{sizes[name]}xi32>' for name in names)
        lines.append(f'  kernel.launch @{entry}({values}) : ({types})')
    for name in outputs:lines.append(f'  check.expect.bitwise actual(%{name}_output) expected(%{name}) : tensor<{sizes[name]}xi32>')
    lines+=['  check.return','}','','check.benchmark<@summary> @summary_latency']
    path.write_text('\n'.join(lines)+'\n')

for case in json.loads((source/'fixtures.json').read_text())['cases']:
    key=case['key'];name=case['name']
    if name not in frames:frames[name]=parse(input_bytes(name))
    frame=frames[name];scan=frame.scans[case['scan']];components=len(frame.components)
    text=(source/(key+'.loom')).read_text()
    paths={m[1]:(source/m[2]).resolve() for m in pattern.finditer(text)}
    sizes={m[1]:int(m[3]) for m in pattern.finditer(text)}
    summary_stride=(5+components+3)&~3
    point_stride=(3+components+3)&~3
    interval_stride=(4+components+3)&~3
    summaries=read_words(paths['expected']);descriptors=read_words(paths['segments'])
    ranges=read_words(paths['ranges'])
    range_stride=(2+components+3)&~3
    old_intervals=read_words(paths['intervals'])
    assert not any(read_words(paths['status']))
    points=[0]*(case['jobs']*(partitions-1)*point_stride)
    intervals=[0]*((case['jobs']*(partitions+1)+case['segments'])*interval_stride)
    captured=0
    for segment_index,segment in enumerate(scan.segments):
        descriptor=descriptors[segment_index*8:(segment_index+1)*8]
        first_job,count=descriptor[2:4]
        certified=[False]*count
        for index in range(count):
            limit=ranges[(descriptor[5]+index)*range_stride]
            if limit!=0xffffffff:
                assert index<limit<=count
                for accepted in range(index,limit):
                    assert not certified[accepted]
                    certified[accepted]=True
        old_base=first_job*2+segment_index
        new_base=first_job*(partitions+1)+segment_index
        for index in range(count):
            record=summaries[(first_job+index)*summary_stride:(first_job+index+1)*summary_stride]
            point_base=(first_job+index)*(partitions-1)*point_stride
            if record[0]!=0xffffffff:
                start=State(record[0],record[1]//64,record[1]&63,(0,)*components)
                cursor=Cursor(segment,scan,components,start)
                for partition in range(1,partitions):
                    boundary=index*case['chunk_bytes']*8+case['chunk_bytes']*8*partition//partitions
                    while cursor.reader.position<boundary:cursor.advance()
                    state=cursor.state()
                    value=[state.position,state.blocks-start.blocks,(state.blocks%len(scan.blocks))*64+state.coefficient,*state.predictors]
                    value += [0]*(point_stride-len(value))
                    offset=point_base+(partition-1)*point_stride
                    points[offset:offset+point_stride]=value
                    captured+=1
                while cursor.reader.position<record[2]:cursor.advance()
                assert cursor.reader.position==record[2] and cursor.blocks-start.blocks==record[4]
                assert tuple(cursor.predictors)==tuple(signed(x) for x in record[5:5+components])
            original=old_intervals[(old_base+index)*interval_stride:(old_base+index+1)*interval_stride]
            if certified[index]:
                assert record[0]!=0xffffffff
                assert original[0]==record[0] and original[1]==record[2]
                current=list(original)
                for partition in range(partitions):
                    if partition+1<partitions:
                        point=points[point_base+partition*point_stride:point_base+(partition+1)*point_stride]
                        current[1]=point[0]
                    else:current[1]=original[1]
                    target=(new_base+index*partitions+partition)*interval_stride
                    intervals[target:target+interval_stride]=current
                    if partition+1<partitions:
                        current=[point[0],0,original[2]+point[1],point[2],*[original[4+c]+point[3+c] for c in range(components)]]
                        current += [0]*(interval_stride-len(current))
            original=old_intervals[(old_base+count+index)*interval_stride:(old_base+count+index+1)*interval_stride]
            target=(new_base+partitions*count+index)*interval_stride
            intervals[target:target+interval_stride]=original
        target=(new_base+(partitions+1)*count)*interval_stride
        intervals[target:target+interval_stride]=old_intervals[(old_base+2*count)*interval_stride:(old_base+2*count+1)*interval_stride]
    values={'points':points,'intervals':intervals,'status':[0]*(len(intervals)//interval_stride)}
    for name,value in values.items():
        paths[name]=output/(key+'-'+name+'.npy');write_words(paths[name],value);sizes[name]=len(value)
    write_case(output/(key+'.loom'),paths,sizes)
    config=json.loads((source/(key+'.json')).read_text());config['jpeg']['output_partitions']=partitions
    (output/(key+'.json')).write_text(json.dumps(config,indent=2)+'\n')
    all_paths.update(paths.values())
    cases.append({**case,'sizes':sizes,'output_partitions':partitions,'captured_points':captured})
    print(json.dumps({'case':key,'partitions':partitions,'captured_points':captured}),flush=True)
receipt={'cases':cases,'sources':{name:hashlib.sha256((notes/name).read_bytes()).hexdigest() for name in ('partition_fixture.py','bounded.py','sequential.py')}}
(output/'fixtures.json').write_text(json.dumps(receipt,indent=2)+'\n')
all_paths.update(p for p in output.iterdir() if p.is_file())
(root/(output.name+'-stage.json')).write_text(json.dumps({'files':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in all_paths}},indent=2)+'\n')
(notes/(output.name+'-fixtures.json')).write_text(json.dumps(receipt,indent=2)+'\n')
