#include "device_entropy_cursor.h"

static loom::kernel::configuration configure_chunks() {
  unsigned threads = loom::target::subgroup::size() * 4;
  return {{(chunks + threads - 1) / threads, 1, 1}, {threads, 1, 1}};
}

[[loom::kernel(configure_chunks)]]
void jpeg_speculate(const unsigned* entropy, const unsigned* jobs,
                    const unsigned* tables, const unsigned* blocks,
                    unsigned* summaries) {
  unsigned lane = loom::kernel::workitem::id.x;
  unsigned threads = loom::kernel::workgroup::size.x;
  if (cache_tables) {
    auto* table_storage =
        loom::buffer::alloca<unsigned, loom::memory_space::workgroup, 16>(
            table_count * 832);
    auto* block_storage =
        loom::buffer::alloca<unsigned, loom::memory_space::workgroup, 16>(
            blocks_per_mcu);
    for (unsigned index = lane; index < table_count * 832; index += threads) {
      table_storage[index] = tables[index];
    }
    for (unsigned index = lane; index < blocks_per_mcu; index += threads) {
      block_storage[index] = blocks[index];
    }
    loom::kernel::workgroup::barrier();
    tables = table_storage;
    blocks = block_storage;
  }
  unsigned job = loom::kernel::workgroup::id.x * loom::kernel::workgroup::size.x +
                 loom::kernel::workitem::id.x;
  if (job >= chunks) return;
  unsigned offset = jobs[job * 3];
  unsigned limit = jobs[job * 3 + 1];
  unsigned interval = jobs[job * 3 + 2];
  unsigned chunk_bits = chunk_bytes * 8;
  unsigned first_boundary = interval * chunk_bits;
  unsigned last_boundary = first_boundary + chunk_bits;
  const unsigned* words = entropy + offset;
  Cursor cursor = {};
  cursor.position = interval ? first_boundary - chunk_bits : 0;
  cursor.budget = chunk_bits * 4 + 26;
  cursor.cached_word = 0xffffffffu;
  while (cursor.position < first_boundary && cursor.error == 0) {
    unsigned before = cursor.position;
    cursor = advance(words, tables, blocks, limit, cursor);
    if (cursor.error == 1) {
      cursor.position = before + 1;
      cursor.blocks = 0;
      cursor.block_index = 0;
      cursor.coefficient = 0;
      cursor.predictors = {};
      cursor.error = 0;
    }
  }
  unsigned first_bit = cursor.position;
  unsigned first_phase = cursor.block_index * 64 + cursor.coefficient;
  unsigned first_blocks = cursor.blocks;
  Predictors first_predictors = cursor.predictors;
  while (cursor.position < last_boundary && cursor.error == 0) {
    cursor = advance(words, tables, blocks, limit, cursor);
  }
  unsigned stride = (5 + component_count + 3) & ~3u;
  unsigned* output = summaries + job * stride;
  [[loom::unroll]]
  for (unsigned index = 0; index < stride; ++index) output[index] = 0;
  output[0] = 0xffffffffu;
  if (cursor.error == 0) {
    output[0] = first_bit;
    output[1] = first_phase;
    output[2] = cursor.position;
    output[3] = cursor.block_index * 64 + cursor.coefficient;
    output[4] = cursor.blocks - first_blocks;
    [[loom::unroll]]
    for (unsigned component = 0; component < component_count; ++component) {
      output[5 + component] = cursor.predictors[component] - first_predictors[component];
    }
  }
}
