#include <stdio.h>

#include "iree/async/semaphore.h"

int main(void) {
  printf("{\"timepoint_bytes\":%zu}\n",
         sizeof(iree_async_semaphore_timepoint_t));
  return 0;
}
