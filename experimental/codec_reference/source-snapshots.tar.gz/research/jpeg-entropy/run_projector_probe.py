"""Run one trained-projector observation under foreground broker ownership."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess

notes = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--prefix', default='gorgon3-projector-accuracy')
parser.add_argument('--stage', default='model-accuracy-stage.json')
arguments = parser.parse_args()
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
directory = root / 'vision-accuracy'
tag = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['codec-jpeg-vision-asan'])
probe = tag / 'loom/src/loom/tooling/target/amdgpu/serve/codec_projector_probe'
source_hash = hashlib.sha256((notes / 'projector_probe.cc').read_bytes()).hexdigest()
build = json.loads((notes / 'projector-probe-build.json').read_text())
assert build == {'source_sha256': source_hash, 'restored': True, 'returncode': 0}, build
manifest = json.loads((notes / arguments.stage).read_text())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == manifest['codec_commit']
binary_hash = hashlib.file_digest(probe.open('rb'), 'sha256').hexdigest()
remote_probe = directory / 'projector-probe'
subprocess.run(['scp', str(probe), 'hrx-gorgon-3:' + str(remote_probe)], check=True)
verification = '''
import hashlib, json
from pathlib import Path
p = Path(%r)
m = json.loads((p / 'manifest.json').read_text())
for name, expected in m['files'].items():
    actual = hashlib.file_digest((p / name).open('rb'), 'sha256').hexdigest()
    assert actual == expected, (name, actual, expected)
assert hashlib.file_digest((p / 'projector-probe').open('rb'), 'sha256').hexdigest() == %r
total = sum(f.stat().st_size for f in p.rglob('*') if f.is_file())
assert total + 340000000 < 1024**3, total
print(json.dumps({'input_manifest_verified': True, 'current_bytes': total}))
''' % (str(directory), binary_hash)
subprocess.run(['ssh', 'hrx-gorgon-3', 'python3 -B -'], input=verification, text=True, check=True)
remote_command = ['/home/benvanik/.dotfiles/bin/benchmark-lock',
                  '--label=codec-jpeg-projector-accuracy', '--', 'env',
                  'LD_LIBRARY_PATH=/opt/rocm/lib', str(remote_probe),
                  '--jpeg_fixture=' + str(directory),
                  '--image_width=' + str(manifest['image_geometry'][0]),
                  '--image_height=' + str(manifest['image_geometry'][1]),
                  '--target_width=' + str(manifest['target_geometry'][0]),
                  '--target_height=' + str(manifest['target_geometry'][1]),
                  '--gtest_filter=ProjectorProbe.DecoderControls']
command = ['ssh', 'hrx-gorgon-3', shlex.join(remote_command)]
with (notes / (arguments.prefix + '.log')).open('w') as log:
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    for line in process.stdout:
        log.write(line)
        log.flush()
        print(line, end='', flush=True)
    result = process.wait()
status = subprocess.run(['ssh', 'hrx-gorgon-3',
                         '/home/benvanik/.dotfiles/bin/benchmark-lock --status'],
                        capture_output=True, text=True)
receipt = {'command': command, 'returncode': result,
           'source_sha256': source_hash, 'binary_sha256': binary_hash,
           'build_config': 'asan', 'codec_commit': manifest['codec_commit'],
           'model_commit': manifest['model_commit'],
           'input_manifest_sha256': hashlib.sha256((notes / arguments.stage).read_bytes()).hexdigest(),
           'broker_status_returncode': status.returncode,
           'broker_status_after': status.stdout + status.stderr}
(notes / (arguments.prefix + '-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
raise SystemExit(result or status.returncode)
