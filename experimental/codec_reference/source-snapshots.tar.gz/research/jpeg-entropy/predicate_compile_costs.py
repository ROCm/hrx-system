"""Record emitted-resource deltas, not host-ASAN timing comparisons."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

notes = Path(__file__).resolve().parent
directory = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
roots = json.loads(os.environ['BUREAU_TAG_ROOTS'])
output = directory / 'predicate-costs'
output.mkdir(exist_ok=True)
rows = []
cases = [
    ('jpeg-small', directory / 'entropy.loombc', 'jpeg_speculate', directory / 'ycbcr_420-scan0-chunk32.json'),
    ('jpeg-large', directory / 'entropy.loombc', 'jpeg_speculate', directory / 'large/012mp-bus.jpg.r0.jpg-scan0-chunk4096.json'),
    ('wave32', directory / 'predicate-wave32.loom', 'loop_predicate_lifetimes', None),
    ('wave64', directory / 'predicate-wave64.loom', 'loop_predicate_lifetimes', None),
]
for label, tag in [('baseline', 'codec-jpeg-rebased-tools'), ('candidate', 'codec-jpeg-predicate-candidate')]:
    compiler = Path(roots[tag]) / 'loom/src/loom/tools/loom-compile/loom-compile'
    for name, source, symbol, config in cases:
        report = output / (label + '-' + name + '.json')
        command = [str(compiler), str(source), '--root=' + symbol,
                   '--target=amdgpu:gfx1151', '--output=' + str(output / (label + '-' + name + '.hsaco')),
                   '--compile-report=details', '--compile-report-output=' + str(report)]
        if config:
            command.append('--config-file=' + str(config))
        subprocess.run(command, check=True)
        data = json.loads(report.read_text())
        entry = data['entries']['rows'][0]
        row = {'label': label, 'case': name, 'tag': tag, 'command': command,
               'compiler_sha256': hashlib.sha256(compiler.read_bytes()).hexdigest(),
               'input_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
               'metrics': {key: entry[key] for key in (
                   'instruction_count', 'code_byte_count', 'private_memory_bytes',
                   'local_memory_bytes', 'target_resources', 'move_causes')}}
        rows.append(row)
        print(json.dumps({'label': label, 'case': name, 'metrics': row['metrics']}), flush=True)
(notes / 'predicate-lifetime-code-costs.json').write_text(json.dumps(rows, indent=2) + '\n')
