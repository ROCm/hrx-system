#include "device_entropy_cursor.h"
#include <loomcxx/atomic.h>

[[loom::config("jpeg.mcu_width"), loom::where(loom::predicate::range(1u, 65536u))]]
extern const unsigned scan_mcu_width;

using WideValues = long long __attribute__((ext_vector_type(8)));

static loom::kernel::configuration configure_output() {
  unsigned threads = loom::target::subgroup::size();
  unsigned interval_capacity = chunks * (output_partitions + 1) + certification_segments;
  unsigned stripe = threads * certification_segments;
  return {{(interval_capacity + stripe - 1) / stripe, certification_segments, 1},
          {threads * 2, 1, 1}};
}

static LOOM_FORCE_INLINE WideValues transform_block_axis(WideValues input) {
  long long sum = (input[0] + input[4]) * 8192;
  long long difference = (input[0] - input[4]) * 8192;
  long long rotation = (input[2] + input[6]) * 4433;
  long long two = rotation - input[6] * 15137;
  long long six = rotation + input[2] * 6270;
  long long even0 = sum + six;
  long long even1 = difference + two;
  long long even2 = difference - two;
  long long even3 = sum - six;
  long long odd_rotation = (input[1] + input[3] + input[5] + input[7]) * 9633;
  long long seven_three = odd_rotation - (input[7] + input[3]) * 16069;
  long long five_one = odd_rotation - (input[5] + input[1]) * 3196;
  long long seven_one = (input[7] + input[1]) * -7373;
  long long five_three = (input[5] + input[3]) * -20995;
  long long odd0 = input[1] * 12299 + seven_one + five_one;
  long long odd1 = input[3] * 25172 + five_three + seven_three;
  long long odd2 = input[5] * 16819 + five_three + five_one;
  long long odd3 = input[7] * 2446 + seven_one + seven_three;
  return {even0 + odd0, even1 + odd1, even2 + odd2, even3 + odd3,
          even3 - odd3, even2 - odd2, even1 - odd1, even0 - odd0};
}

static LOOM_FORCE_INLINE unsigned sample_byte(int value) {
  unsigned nonnegative = static_cast<unsigned>(value & ~(value >> 31));
  unsigned saturated = nonnegative | (0u - static_cast<unsigned>(nonnegative > 255u));
  return saturated & 255u;
}

static LOOM_FORCE_INLINE Symbol output_symbol(const unsigned* words,
    const unsigned* tables, const unsigned* blocks, unsigned limit,
    unsigned certified_end, Cursor cursor) {
  Symbol symbol = {};
  if (cursor.position < certified_end) {
    symbol = advance_symbol_certified(words, tables, blocks, cursor);
  } else {
    symbol = advance_symbol(words, tables, blocks, limit, cursor);
  }
  if (symbol.index == 0 && (symbol.value < -1024 || symbol.value > 1023)) {
    symbol.cursor.error = 5;
  }
  return symbol;
}

// The block owner has already consumed DC. Its retained table and the
// restart-rooted certificate establish the entire AC syntax transition.
static LOOM_FORCE_INLINE Symbol advance_ac_certified(const unsigned* words,
    const unsigned* table, Cursor cursor) {
  Read input = peek(words, cursor);
  cursor = input.cursor;
  unsigned packed = lookup_huffman(table, input.value);
  unsigned length = packed >> 8;
  unsigned symbol = packed & 255;

  loom::assume(length != 0 && length <= 16u);
  unsigned category = symbol & 15u;
  loom::assume(category <= 11u);
  unsigned consumed = length + category;
  unsigned amplitude_mask = (1u << category) - 1;
  unsigned value = (input.value >> (32 - consumed)) & amplitude_mask;
  unsigned negative_mask = 0u - static_cast<unsigned>(value < ((1u << category) >> 1));
  int amplitude = static_cast<int>(value + ((0u - amplitude_mask) & negative_mask));
  unsigned output_index = 0xffffffffu;
  int output_value = 0;
    unsigned run = symbol >> 4;
    if (category == 0) {
      unsigned nonzero_run_mask = 0u - static_cast<unsigned>(run != 0);
      cursor.coefficient = ((cursor.coefficient + 16) & nonzero_run_mask) & 63;
    } else {
      unsigned index = cursor.coefficient + run;
      loom::assume(index < 64u);
      cursor.coefficient = (index + 1) & 63;
      output_index = index;
      output_value = amplitude;
    }
    if (cursor.coefficient == 0) {
      ++cursor.blocks;
      ++cursor.block_index;
      unsigned wrap_mask = 0u - static_cast<unsigned>(cursor.block_index != blocks_per_mcu);
      cursor.block_index &= wrap_mask;
    }
  cursor.position += consumed;
  cursor.reads += consumed;
  return {cursor, output_index, output_value};
}

using Values = int __attribute__((ext_vector_type(8)));

// Exchange the low three bits of the register index with the lane index.
// Every shuffle is confined to a fully participating eight-lane block.
static LOOM_FORCE_INLINE Values transpose_block(Values values, unsigned axis) {
  [[loom::unroll]]
  for (unsigned stage = 0; stage < 3; ++stage) {
    unsigned mask = 1u << stage;
    Values exchanged = loom::kernel::subgroup::shuffle_xor(values, mask, 8).value;
    Values next = {};
    [[loom::unroll]]
    for (unsigned index = 0; index < 8; ++index) {
      int exchange_mask = -static_cast<int>(((axis ^ index) & mask) != 0);
      next[index] = values[index] ^ ((values[index] ^ exchanged[index ^ mask]) & exchange_mask);
    }
    values = next;
  }
  return values;
}

// Row-local owner permutation preserves the payload while distributing
// each eight-lane consumer's column across independent LDS banks.
static LOOM_FORCE_INLINE unsigned coefficient_index(unsigned natural,
    unsigned owner, unsigned stride) {
  return natural * stride + (owner ^ ((natural & 7u) * 2u));
}

// All lanes enter; each group of eight consumes one producer's block.
static LOOM_FORCE_INLINE void reconstruct_cooperative(const short* coefficients,
    unsigned coefficient_stride, unsigned threads, unsigned lane,
    unsigned owner, bool valid, bool any_ac, unsigned offset,
    const unsigned* quantization, unsigned* pixels) {
  bool owner_valid = loom::kernel::subgroup::shuffle_index(
      static_cast<unsigned>(valid), owner, threads).value != 0;
  bool owner_ac = loom::kernel::subgroup::shuffle_index(
      static_cast<unsigned>(any_ac), owner, threads).value != 0;
  unsigned owner_offset = loom::kernel::subgroup::shuffle_index(offset, owner, threads).value;
  unsigned axis = lane & 7;
  if (owner_valid) {
    unsigned long long packed = 0;
    if (!owner_ac) {
      int dc = static_cast<int>(coefficients[owner]) * static_cast<int>(quantization[0]);
      unsigned value = sample_byte(((dc + 4) >> 3) + 128);
      packed = static_cast<unsigned long long>(value) * 0x0101010101010101ull;
    } else {
      WideValues input = {};
      int ac = 0;
      [[loom::unroll]]
      for (unsigned row = 0; row < 8; ++row) {
        unsigned natural = row * 8 + axis;
        unsigned step = quantization[natural];
        loom::assume(step <= 65535u);
        int value = static_cast<int>(coefficients[coefficient_index(natural, owner, coefficient_stride)]) *
                    static_cast<int>(step);
        input[row] = value;
        if (row != 0) ac |= value;
      }
      Values columns = {};
      if (ac == 0) {
        [[loom::unroll]]
        for (unsigned row = 0; row < 8; ++row) columns[row] = static_cast<int>(input[0] * 4);
      } else {
        WideValues result = transform_block_axis(input);
        [[loom::unroll]]
        for (unsigned row = 0; row < 8; ++row) {
          columns[row] = static_cast<int>((result[row] + 1024) >> 11);
        }
      }
      Values row = transpose_block(columns, axis);
      [[loom::unroll]]
      for (unsigned column = 0; column < 8; ++column) input[column] = row[column];
      WideValues result = transform_block_axis(input);
      [[loom::unroll]]
      for (unsigned column = 0; column < 8; ++column) {
        int value = static_cast<int>((result[column] + 131072) >> 18) + 128;
        packed |= static_cast<unsigned long long>(sample_byte(value)) << (column * 8);
      }
    }
    reinterpret_cast<unsigned long long*>(pixels + owner_offset)[axis] = packed;
  }
}

// Only a subgroup leader observes a token; the subgroup rendezvous then
// imports that acquire before any lane consumes the published payload.
struct SlotObservation {
  // Publication state observed by the whole subgroup.
  unsigned state;
  // Atomic observations, including the successful one.
  unsigned polls;
};
static LOOM_FORCE_INLINE SlotObservation wait_slot(const unsigned* flag,
    unsigned lane, unsigned threads, bool empty) {
  unsigned state = 0;
  unsigned polls = 0;
  do {
    ++polls;
    unsigned observed = 0;
    if (lane == 0) {
      observed = loom::view::atomic::load<loom::atomic::ordering::acquire,
          loom::atomic::scope::workgroup>(flag);
    }
    state = loom::kernel::subgroup::broadcast(observed, 0);
  } while (empty ? state != 0 : state == 0);
  loom::kernel::barrier<loom::memory_space::workgroup,
      loom::atomic::scope::subgroup, loom::atomic::ordering::acq_rel>();
  return {state, polls};
}

// The rendezvous gathers all lane writes/reads into the leader's release.
static LOOM_FORCE_INLINE void publish_slot(unsigned* flag, unsigned value,
                                           unsigned lane) {
  loom::kernel::barrier<loom::memory_space::workgroup,
      loom::atomic::scope::subgroup, loom::atomic::ordering::acq_rel>();
  if (lane == 0) {
    loom::view::atomic::store<loom::atomic::ordering::release,
        loom::atomic::scope::workgroup>(value, flag);
  }
}

[[loom::kernel(configure_output)]]
void jpeg_reconstruct(const unsigned* entropy, const unsigned* segments,
    const unsigned* tables, const unsigned* blocks, const unsigned* intervals,
    const unsigned* geometry, const unsigned* quantization, const unsigned* zigzag,
    unsigned* pixels, unsigned* status, unsigned* statistics) {
  unsigned segment = loom::kernel::workgroup::id.y;
  unsigned item = loom::kernel::workitem::id.x;
  unsigned threads = loom::kernel::workgroup::size.x / 2;
  unsigned lane = loom::kernel::subgroup::lane_id();
  unsigned interval_capacity = chunks * (output_partitions + 1) + certification_segments;
  unsigned stripe = threads * certification_segments;
  unsigned group_count = (interval_capacity + stripe - 1) / stripe;
  const unsigned* descriptor = segments + segment * 8;
  unsigned count = descriptor[3];
  unsigned total_blocks = descriptor[4];
  unsigned first_interval = descriptor[2] * (output_partitions + 1) + segment;
  unsigned stride = (4 + component_count + 3) & ~3u;
  unsigned certified_end = intervals[
      (first_interval + (output_partitions + 1) * count) * stride];
  unsigned certified_blocks = intervals[
      (first_interval + (output_partitions + 1) * count) * stride + 2];
  const unsigned* words = entropy + descriptor[0];
  unsigned bit_limit = descriptor[1];
  unsigned coefficient_stride = threads;
  auto* storage = loom::buffer::alloca<short, loom::memory_space::workgroup, 16>(threads * 64 * 2);
  auto* metadata = loom::buffer::alloca<unsigned, loom::memory_space::workgroup, 16>(threads * 2 * 2);
  auto* control = loom::buffer::alloca<unsigned, loom::memory_space::workgroup, 16>(4);
  if (item == 0) {
    control[0] = 0;
    control[2] = 0;
  }
  loom::kernel::workgroup::barrier();
  unsigned sequence = 0;
  unsigned polls = 0;
  if (loom::kernel::subgroup::id() == 0) {
  for (unsigned first = loom::kernel::workgroup::id.x * threads;
       first < count * (output_partitions + 1) + 1; first += group_count * threads) {
    unsigned interval = first + lane;
    bool present = interval < count * (output_partitions + 1) + 1;
    Cursor cursor = {};
    cursor.budget = bit_limit;
    cursor.cached_word = 0xffffffffu;
    unsigned end = 0;
    if (present) {
      const unsigned* entry = intervals + (first_interval + interval) * stride;
      cursor.position = entry[0];
      end = entry[1];
      cursor.blocks = entry[2];
      cursor.block_index = entry[3] >> 6;
      cursor.coefficient = entry[3] & 63;
      [[loom::unroll]]
      for (unsigned component = 0; component < component_count; ++component) {
        cursor.predictors[component] = static_cast<int>(entry[4 + component]);
      }
      if (cursor.position < end) {
        while ((cursor.block_index != 0 || cursor.coefficient != 0) && cursor.error == 0) {
          cursor = output_symbol(words, tables, blocks, bit_limit, certified_end, cursor).cursor;
        }
      }
    }
    bool active = present && cursor.blocks < total_blocks && cursor.position < end && cursor.error == 0;
    while (loom::kernel::subgroup::vote::any(active)) {
      unsigned mcu = descriptor[6] + cursor.blocks / blocks_per_mcu;
      unsigned mcu_row = mcu / scan_mcu_width;
      unsigned mcu_column = mcu % scan_mcu_width;
      for (unsigned block = 0; block < blocks_per_mcu; ++block) {
        unsigned slot = sequence & 1u;
        polls += wait_slot(control + slot * 2, lane, threads, true).polls;
        short* coefficients = storage + slot * threads * 64;
        bool any_ac = false;
        bool output_valid = false;
        unsigned offset = 0;
        unsigned table_index = block_descriptor(block) >> 5;
        unsigned available_tables = table_count;
        loom::assume(table_index < available_tables);
        const unsigned* ac_table = tables + table_index * 2048;
        if (active && cursor.error == 0) {
          [[loom::unroll]]
          for (unsigned index = 0; index < 64; ++index) coefficients[coefficient_index(index, lane, coefficient_stride)] = 0;
          if (cursor.blocks < certified_blocks) {
            // The root certificate covers this whole block. Syntax is proven;
            // the absolute DC predictor remains a consumer-owned constraint.
            unsigned first_coefficient = cursor.coefficient;
            loom::assume(first_coefficient == 0);
            cursor.coefficient = first_coefficient;
            Symbol dc = advance_symbol_certified(words, tables, blocks, cursor);
            cursor = dc.cursor;
            if (dc.value < -1024 || dc.value > 1023) cursor.error = 5;
            if (cursor.error == 0) {
              coefficients[lane] = static_cast<short>(dc.value);
              do {
                Symbol symbol = advance_ac_certified(words, ac_table, cursor);
                cursor = symbol.cursor;
                if (symbol.index != 0xffffffffu) {
                  unsigned natural = zigzag[symbol.index];
                  loom::assume(natural < 64u);
                  coefficients[coefficient_index(natural, lane, coefficient_stride)] = static_cast<short>(symbol.value);
                  any_ac = true;
                }
              } while (cursor.coefficient != 0);
            }
          } else {
            do {
              Symbol symbol = advance_symbol(words, tables, blocks, bit_limit, cursor);
              cursor = symbol.cursor;
              if (symbol.index == 0 && (symbol.value < -1024 || symbol.value > 1023)) {
                cursor.error = 5;
              }
              if (symbol.index != 0xffffffffu && cursor.error == 0) {
                unsigned natural = zigzag[symbol.index];
                loom::assume(natural < 64u);
                coefficients[coefficient_index(natural, lane, coefficient_stride)] = static_cast<short>(symbol.value);
                if (symbol.index != 0) any_ac = true;
              }
            } while (cursor.coefficient != 0 && cursor.error == 0);
          }
          const unsigned* shape = geometry + block * 8;
          unsigned column = mcu_column * shape[3] + shape[5];
          unsigned row = mcu_row * shape[4] + shape[6];
          output_valid = cursor.error == 0 && column < shape[1] && row < shape[2];
          offset = descriptor[7] + shape[0] + (row * shape[1] + column) * 16;
        }
        metadata[(slot * threads + lane) * 2] = offset;
        metadata[(slot * threads + lane) * 2 + 1] =
            static_cast<unsigned>(output_valid) | (static_cast<unsigned>(any_ac) << 1);
        if (lane == 0) control[slot * 2 + 1] = block_descriptor(block) & 3u;
        publish_slot(control + slot * 2, 1u, lane);
        ++sequence;
      }
      active = present && cursor.blocks < total_blocks && cursor.position < end && cursor.error == 0;
    }
    if (present) {
      if (interval == count * (output_partitions + 1) && cursor.error == 0) {
        if (cursor.blocks != total_blocks || cursor.coefficient != 0) {
          cursor.error = 3;
        } else {
          unsigned padding = bit_limit - cursor.position;
          if (padding >= 8) {
            cursor.error = 4;
          } else if (padding != 0) {
            Read input = peek(words, cursor);
            if ((input.value >> (32 - padding)) != (1u << padding) - 1) cursor.error = 4;
          }
        }
      }
      status[first_interval + interval] = cursor.error;
    }
  }
    unsigned final_slot = sequence & 1u;
    polls += wait_slot(control + final_slot * 2, lane, threads, true).polls;
    publish_slot(control + final_slot * 2, 2u, lane);
  } else {
    bool finished = false;
    while (!finished) {
      unsigned slot = sequence & 1u;
      SlotObservation observation = wait_slot(control + slot * 2, lane, threads, false);
      polls += observation.polls;
      unsigned token = observation.state;
      finished = token == 2;
      if (!finished) {
        const short* coefficients = storage + slot * threads * 64;
        unsigned offset = metadata[(slot * threads + lane) * 2];
        unsigned flags = metadata[(slot * threads + lane) * 2 + 1];
        unsigned component = control[slot * 2 + 1];
        unsigned components = component_count;
        loom::assume(component < components);
        for (unsigned round = 0; round < 8; ++round) {
          unsigned owner = round * (threads / 8) + lane / 8;
          reconstruct_cooperative(coefficients, coefficient_stride, threads, lane,
              owner, (flags & 1u) != 0, (flags & 2u) != 0, offset,
              quantization + component * 64, pixels);
        }
        publish_slot(control + slot * 2, 0u, lane);
        ++sequence;
      }
    }
  }
  if (lane == 0) {
    unsigned group = segment * group_count + loom::kernel::workgroup::id.x;
    unsigned role = loom::kernel::subgroup::id();
    statistics[group * 4 + role * 2] = polls;
    statistics[group * 4 + role * 2 + 1] = sequence;
  }
}
