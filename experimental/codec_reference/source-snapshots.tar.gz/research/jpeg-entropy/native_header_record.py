"""Pin a successful native qualification and its independent fixture evidence."""

import argparse
import hashlib
import json
from pathlib import Path
import subprocess


notes = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("--build-log", type=Path, default=notes / "native-header-test.log")
parser.add_argument("--target", action="append")
arguments = parser.parse_args()
build_log = arguments.build_log
test_log = Path("bazel-testlogs/experimental/codec_reference/research/jpeg-entropy/native_header_test/test.log")
assert "Build completed successfully" in build_log.read_text()
assert "[  PASSED  ] 7 tests." in test_log.read_text()
files = ["native_header.c", "native_header.h", "native_metadata.c", "native_metadata.h",
         "native_header_test.cc", "native_header_cases.py", "native_header_cases.inc",
         "native_color.c", "native_color.h", "native_metadata_fixture_check.py",
         "sequential.py", "BUILD.bazel"]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


record = {
    "compiler_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
    "command": ["iree-bazel-test", "--config=asan"] +
               (arguments.target or ["//experimental/codec_reference/research/jpeg-entropy:native_header_test"]),
    "configuration": "asan",
    "passed": True,
    "tests": 7,
    "cases": json.loads((notes / "native-header-cases.json").read_text()),
    "sources": {name: digest(notes / name) for name in files},
    "test_log_sha256": digest(test_log),
    "build_log_sha256": digest(build_log),
    "fixture_comparison_sha256": digest(notes / "native-metadata-fixture-result.json"),
    "oracle_requalification": {
        name: digest(notes / name) for name in ("sequential-small.json", "sequential-rejections.json")
    },
    "scope": "Native header/color facts and exact device metadata/codebooks, independent input matrices and malformed families, complete public-libjpeg alias control, public header color interpretation, unread poisoned entropy, and preserved GPU-fixture equality including all sixteen prior color cases. Three u16-extent fixtures exceed libjpeg's 65500 limit and retain independently checked native JFIF/444 semantics. No new GPU execution, serving qualification, performance claim, or selected public ABI.",
}
(notes / "native-header-result.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"passed": True, "tests": record["tests"],
                  "positive": record["cases"]["positive_cases"],
                  "negative": record["cases"]["negative_cases"]}))
