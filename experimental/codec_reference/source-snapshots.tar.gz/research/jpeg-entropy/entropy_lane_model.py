"""Count logical issued lanes in the measured reconstruction ownership shape."""
from array import array
from bisect import bisect_left
import hashlib
import json
from pathlib import Path
import re

from device_fixture import input_bytes, read_words
from sequential import Bits, Huffman, parse, step

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
data = input_bytes('012mp-bus.jpg.r0.jpg')
frame = parse(data)
assert len(frame.scans) == 1 and len(frame.scans[0].segments) == 1
scan = frame.scans[0]
segment = scan.segments[0]
block_count = segment.mcu_count * len(scan.blocks)
reader = Bits(segment.data)
positions = array('I')
block_symbols = array('I', [0])
block_positions = array('I', [0])
lengths = array('B')
original_decode = Huffman.decode

def decode_length(self, source):
    before = source.position
    value = original_decode(self, source)
    lengths.append(source.position - before)
    return value

Huffman.decode = decode_length
for index in range(block_count):
    phase = 0
    while True:
        positions.append(reader.position)
        phase, _, _ = step(reader, scan.blocks[index % len(scan.blocks)], phase)
        if phase == 0:
            break
    block_symbols.append(len(positions))
    block_positions.append(reader.position)
positions.append(reader.position)
assert reader.huffman_symbols == 4637859 and reader.position <= reader.limit
mcu_positions = block_positions[::len(scan.blocks)]
assert len(mcu_positions) == segment.mcu_count + 1

def evaluate(family):
    key = '012mp-bus.jpg.r0.jpg-scan0-chunk1024'
    directory = root / family
    text = (directory / (key + '.loom')).read_text()
    path = directory / re.search(r'%intervals = check.file.read.npy path\("([^"]+)"',text)[1]
    words = read_words(path)
    stride = 8
    intervals = [words[index:index+stride] for index in range(0,len(words),stride)]
    lanes = []
    owned_mcus = 0
    skipped_symbols = 0
    useful_symbols = 0
    for entry in intervals:
        start, end = entry[:2]
        if start >= end:
            lanes.append((0,0,0))
            continue
        first = min(bisect_left(mcu_positions,start),segment.mcu_count)
        last = min(bisect_left(mcu_positions,end),segment.mcu_count)
        symbol = bisect_left(positions,start)
        assert positions[symbol] == start
        skip = block_symbols[first*len(scan.blocks)] - symbol
        symbols = block_symbols[last*len(scan.blocks)] - block_symbols[first*len(scan.blocks)]
        skipped_symbols += skip
        useful_symbols += symbols
        owned_mcus += last-first
        lanes.append((first,last,skip))
    assert owned_mcus == segment.mcu_count and useful_symbols == len(lengths)
    slots = continuous_slots = long_slots = skip_slots = 0
    mcu_slots = 0
    active_wave_count = 0
    for begin in range(0,len(lanes),32):
        wave = lanes[begin:begin+32]
        count = max(last-first for first,last,_ in wave)
        if count:
            active_wave_count += 1
        skip_slots += 32*max(skip for _,_,skip in wave)
        continuous_slots += 32*max(block_symbols[last*len(scan.blocks)]-block_symbols[first*len(scan.blocks)]
                                   for first,last,_ in wave)
        mcu_slots += count*32
        for iteration in range(count):
            active = [first+iteration for first,last,_ in wave if first+iteration<last]
            for block in range(len(scan.blocks)):
                starts = [block_symbols[mcu*len(scan.blocks)+block] for mcu in active]
                counts = [block_symbols[mcu*len(scan.blocks)+block+1]-start
                          for mcu,start in zip(active,starts)]
                maximum = max(counts)
                slots += maximum*32
                for symbol in range(maximum):
                    long_slots += 32*max(max(0,lengths[start+symbol]-9)
                                         for start,count in zip(starts,counts) if symbol<count)
    return {'family':family,'intervals':len(lanes),'active_wave_count':active_wave_count,
            'useful_mcus':owned_mcus,'issued_mcu_lane_slots':mcu_slots,
            'useful_symbols':useful_symbols,'leading_mcu_reread_symbols':skipped_symbols,
            'leading_mcu_issued_lane_slots':skip_slots,
            'block_lockstep_symbol_lane_slots':slots,
            'continuous_symbol_lane_slots':continuous_slots,
            'block_lockstep_symbol_efficiency':useful_symbols/slots,
            'continuous_symbol_efficiency':useful_symbols/continuous_slots,
            'long_code_loop_lane_slots':long_slots,
            'ideal_removed_block_sync_symbol_slots':slots-continuous_slots,
            'intervals_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}

rows = [evaluate(family) for family in ('output-large','partitions4-large')]
result = {'input_sha256':hashlib.sha256(data).hexdigest(),
          'scope':'Logical active/issued SIMD lane slots from exact bit/block boundaries, not measured instruction counts, occupancy, or time. Long-code loops assume the existing <=9-bit primary table.',
          'sources':{name:hashlib.sha256((notes/name).read_bytes()).hexdigest()
                     for name in ('entropy_lane_model.py','sequential.py','device_reconstruct_clamp_mask.cxx')},
          'rows':rows}
(notes/'entropy-lane-model.json').write_text(json.dumps(result,indent=2)+'\n')
for row in rows:
    print(json.dumps(row),flush=True)
