"""Interleaved optimized CLI cost; includes startup, parse, compile, and emit."""
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import time

root = Path(__file__).resolve().parent
lease = os.environ['BENCHMARK_LOCK_LEASE_ID']
tools = json.loads((root / 'predicate-opt-tools.json').read_text())
compilers = {name: root / ('loom-compile-' + name)
             for name in ('baseline', 'candidate')}
for name, compiler in compilers.items():
    assert hashlib.sha256(compiler.read_bytes()).hexdigest() == tools[compiler.name]
state = {'host': os.uname().nodename, 'lease': lease,
         'load_average': os.getloadavg(), 'cpu_affinity': sorted(os.sched_getaffinity(0)),
         'governors': sorted({p.read_text().strip() for p in
                             Path('/sys/devices/system/cpu').glob('cpu*/cpufreq/scaling_governor')})}
cases = [
    ('jpeg-large', root / 'entropy.loombc', 'jpeg_speculate',
     root / 'large/012mp-bus.jpg.r0.jpg-scan0-chunk4096.json'),
    ('predicate-wave32', root / 'predicate-wave32.loom',
     'loop_predicate_lifetimes', None),
]
rows = []
for label, source, symbol, config in cases:
    commands = {}
    for name, compiler in compilers.items():
        commands[name] = [str(compiler), str(source), '--root=' + symbol,
                          '--target=amdgpu:gfx1151', '--output=/dev/null']
        if config:
            commands[name].append('--config-file=' + str(config))
    for _ in range(2):
        for command in commands.values():
            subprocess.run(command, check=True, stdout=subprocess.DEVNULL)
    samples = []
    for index in range(21):
        for name in (('baseline', 'candidate') if index % 2 == 0
                     else ('candidate', 'baseline')):
            start = time.perf_counter_ns()
            subprocess.run(commands[name], check=True, stdout=subprocess.DEVNULL)
            samples.append({'index': index, 'variant': name,
                            'wall_ns': time.perf_counter_ns() - start})
    medians = {name: statistics.median(s['wall_ns'] for s in samples
                                     if s['variant'] == name)
               for name in compilers}
    rows.append({'case': label, 'commands': commands, 'samples': samples,
                 'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
                 'config_sha256': hashlib.sha256(config.read_bytes()).hexdigest() if config else None,
                 'median_wall_ns': medians,
                 'candidate_over_baseline': medians['candidate'] / medians['baseline']})
    print(json.dumps({k: v for k, v in rows[-1].items()
                      if k not in ('samples', 'commands')}), flush=True)
    (root / 'predicate-compile-timing.json').write_text(json.dumps({
        'state': state, 'tools': tools,
        'boundary': 'CLI process startup, input parsing, compilation, and emission to /dev/null; warm filesystem; no report instrumentation',
        'warmups_per_variant': 2, 'samples_per_variant': 21,
        'order': 'AB BA repeated', 'rows': rows}, indent=2) + '\n')
