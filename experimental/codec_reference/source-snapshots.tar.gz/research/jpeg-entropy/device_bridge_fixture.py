"""Compare GPU-produced local bridges with the independently qualified model."""
import argparse
import hashlib
import json
import os
from pathlib import Path

from bounded import State, Summary
from device_fixture import input_bytes, read_words, write_words
from parallel_bridges import construct
from sequential import parse

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
parser = argparse.ArgumentParser()
parser.add_argument('--fixtures', default='fixtures.json')
parser.add_argument('--output', default='bridge-small')
arguments = parser.parse_args()
source = root / arguments.fixtures
output = root / arguments.output
output.mkdir(exist_ok=True)
frames = {}
cases = []
for case in json.loads(source.read_text())['cases']:
    name, key = case['name'], case['key']
    if name not in frames:
        data = input_bytes(name)
        assert hashlib.sha256(data).hexdigest() == case['input_sha256']
        frames[name] = parse(data)
    frame = frames[name]
    scan = frame.scans[case['scan']]
    components = len(frame.components)
    summary_stride = (5 + components + 3) & ~3
    bridge_stride = (2 + components + 3) & ~3
    paths = {name: source.parent / (key + '-' + name + '.npy')
             for name in ('entropy', 'jobs', 'tables', 'blocks', 'expected')}
    words = {name: read_words(path) for name, path in paths.items()}
    expected = []
    first_job = 0
    joined = 0
    for segment in scan.segments:
        intervals = (len(segment.data) + case['chunk_bytes'] - 1) // case['chunk_bytes']
        summaries = []
        for index in range(first_job, first_job + intervals):
            record = words['expected'][index * summary_stride:(index + 1) * summary_stride]
            if record[0] == 0xffffffff:
                summaries.append(None)
            else:
                blocks = record[1] // 64
                first = State(record[0], blocks, record[1] & 63, (0,) * components)
                last = State(record[2], blocks + record[4], record[3] & 63,
                             tuple(value if value < 0x80000000 else value - 0x100000000
                                   for value in record[5:5 + components]))
                summaries.append(Summary(first, last))
        checkpoints, counts, transitions = construct(segment, scan, components, summaries,
                                                     case['chunk_bytes'] * 8, case['chunk_bytes'] * 32)
        for interval in range(intervals):
            record = [0xffffffff] + [0] * (bridge_stride - 1)
            bridge = transitions.get(interval)
            if bridge is not None and bridge.target is not None:
                record[0] = bridge.target
                record[1] = bridge.last.blocks - bridge.first.blocks
                record[2:2 + components] = bridge.last.predictors
                joined += 1
            expected.extend(record)
        first_job += intervals
    assert first_job == case['jobs']
    write_words(output / (key + '-bridges.npy'), expected)
    sizes = {name: len(values) for name, values in words.items()}
    sizes['bridges'] = len(expected)
    lines = [
        'kernel.decl @jpeg_speculate() launch(%entropy: buffer, %jobs: buffer, %tables: buffer, %blocks: buffer, %summaries: buffer)',
        'kernel.decl @jpeg_bridge() launch(%entropy: buffer, %jobs: buffer, %tables: buffer, %blocks: buffer, %summaries: buffer, %bridges: buffer)',
        '', 'check.case @summary {']
    for name, path in paths.items():
        lines.append(f'  %{name} = check.file.read.npy path("{os.path.relpath(path, output)}") : tensor<{sizes[name]}xi32>')
    lines.append(f'  %bridges = check.file.read.npy path("{key}-bridges.npy") : tensor<{sizes["bridges"]}xi32>')
    for name in ('expected', 'bridges'):
        lines.append(f'  %{name}_output = check.generate.fill value(17) : tensor<{sizes[name]}xi32>')
    for entry, names in (
        ('jpeg_speculate', ('entropy', 'jobs', 'tables', 'blocks', 'expected_output')),
        ('jpeg_bridge', ('entropy', 'jobs', 'tables', 'blocks', 'expected_output', 'bridges_output'))):
        types = ', '.join(f'tensor<{sizes[name.removesuffix("_output")]}xi32>' for name in names)
        lines.append(f'  kernel.launch @{entry}(' + ', '.join('%' + name for name in names) + f') : ({types})')
    for name in ('expected', 'bridges'):
        lines.append(f'  check.expect.bitwise actual(%{name}_output) expected(%{name}) : tensor<{sizes[name]}xi32>')
    lines.extend(('  check.return', '}', '', 'check.benchmark<@summary> @summary_latency'))
    (output / (key + '.loom')).write_text('\n'.join(lines) + '\n')
    config = json.loads((source.parent / (key + '.json')).read_text())
    config['jpeg'].update({'segments': len(scan.segments), 'table_count': sizes['tables'] // 832, 'cache_tables': 0})
    (output / (key + '.json')).write_text(json.dumps(config, indent=2) + '\n')
    cases.append({**case, 'bridge_words': len(expected), 'joined_bridges': joined})
    print(json.dumps({'case': key, 'jobs': first_job, 'joined_bridges': joined}), flush=True)
receipt = {'cases': cases, 'sources': {name: hashlib.sha256((notes / name).read_bytes()).hexdigest()
                                     for name in ('device_bridge_fixture.py', 'device_fixture.py',
                                                  'parallel_bridges.py', 'device_bridge.cxx', 'device_entropy_cursor.h')}}
(output / 'fixtures.json').write_text(json.dumps(receipt, indent=2) + '\n')
files = {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
         for path in output.iterdir() if path.is_file()}
for case in cases:
    for name in ('entropy', 'jobs', 'tables', 'blocks', 'expected'):
        path = source.parent / (case['key'] + '-' + name + '.npy')
        files[str(path.relative_to(root))] = hashlib.sha256(path.read_bytes()).hexdigest()
(root / (arguments.output + '-stage.json')).write_text(json.dumps({'files': files}, indent=2) + '\n')
(notes / (arguments.output + '-fixtures.json')).write_text(json.dumps(receipt, indent=2) + '\n')
