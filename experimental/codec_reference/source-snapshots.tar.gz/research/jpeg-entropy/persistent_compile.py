"""Compile the ordinary CXX resident-worker experiment with pinned tools."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--connected', action='store_true')
parser.add_argument('--case')
arguments = parser.parse_args()
notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory']) / 'persistent'
case = root / arguments.case if arguments.case else None
if arguments.connected:
    root /= 'connected'
receipt_path = notes / ('persistent-connected-compile.json' if arguments.connected else 'persistent-compile.json')
configuration = (case if case else root) / 'config.json'
tools = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['codec-jpeg-rebased-tools']) / 'loom/src/loom/tools'
commands = [
    [str(tools / 'loom-import-cxx/loom-import-cxx'), str(root / 'persistent.cxx'), '--output=' + str(root / 'persistent.loom')],
    [str(tools / 'loom-link/loom-link'), str(root / 'persistent.loom'), '--to=bc', '--output=' + str(root / 'persistent.loombc')],
]
for entry in ('jpeg_stream_init', 'jpeg_stream'):
    commands.append([str(tools / 'loom-compile/loom-compile'), str(root / 'persistent.loombc'),
                     '--root=' + entry, '--target=amdgpu:gfx1100', '--config-file=' + str(configuration),
                     '--output=' + str(root / (entry + '.hsaco')), '--compile-report=details',
                     '--compile-report-output=' + str(root / (entry + '.report.json'))])
result = {'source_sha256': hashlib.sha256((root / 'persistent.cxx').read_bytes()).hexdigest(),
          'compiler_sha256': hashlib.sha256((tools / 'loom-compile/loom-compile').read_bytes()).hexdigest(),
          'configuration': json.loads(configuration.read_text()), 'commands': []}
if case:
    commands.append([str(tools / 'loom-link/loom-link'), str(root / 'persistent.loombc'),
                     str(case / 'check.loom'), '--to=bc', '--output=' + str(case / 'check.loombc')])
for command in commands:
    process = subprocess.run(command, capture_output=True, text=True)
    result['commands'].append({'command': command, 'returncode': process.returncode,
                               'output': process.stdout + process.stderr})
    receipt_path.write_text(json.dumps(result, indent=2) + '\n')
    print(command[0].split('/')[-1], ' '.join(command[2:]), process.returncode, flush=True)
    if process.returncode:
        print(process.stdout + process.stderr, flush=True)
        raise SystemExit(process.returncode)
result['resources'] = {entry: json.loads((root / (entry + '.report.json')).read_text())['entries']['rows'][0]
                       for entry in ('jpeg_stream_init', 'jpeg_stream')}
result['artifacts'] = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in
                       ('persistent.loombc', 'jpeg_stream_init.hsaco', 'jpeg_stream.hsaco')}
receipt_path.write_text(json.dumps(result, indent=2) + '\n')
for entry, row in result['resources'].items():
    print(entry, json.dumps({key: row[key] for key in ('instruction_count','code_byte_count','private_memory_bytes','local_memory_bytes','target_resources')}), flush=True)
