struct loom_serve_finite_statuses_t {
  // Caller and accepted download capture share this allocation.
  iree_atomic_ref_count_t ref_count;
  // Allocator owning the header and trailing outcomes.
  iree_allocator_t host_allocator;
  // Timeline and source pool survive model removal and early caller release.
  loom_serve_execution_t* execution;
  // One LE u32 outcome per original request, written by device feedback.
  uint8_t values[];
};

static iree_status_t loom_serve_finite_input_status(uint32_t value) {
  return value ? iree_make_status(IREE_STATUS_INVALID_ARGUMENT,
                                  "source rejected input (code %u)", value)
               : iree_ok_status();
}

void loom_serve_finite_statuses_release(loom_serve_finite_statuses_t* statuses) {
  if (statuses && iree_atomic_ref_count_dec(&statuses->ref_count) == 1) {
    loom_serve_execution_release(statuses->execution);
    iree_allocator_free(statuses->host_allocator, statuses);
  }
}

static void loom_serve_finite_statuses_retired(void* user_data,
                                             iree_hal_buffer_t* buffer) {
  loom_serve_finite_statuses_release(user_data);
}

iree_status_t loom_serve_finite_result_download_statuses(
    loom_serve_finite_result_t* result,
    loom_serve_finite_statuses_t** out_statuses,
    loom_serve_execution_frontier_t* out_frontier) {
  *out_statuses = NULL;
  *out_frontier = result->ready;
  if (!result->status_offset) return iree_ok_status();
  // Result-plan bounds already prove this fits the physical output extent.
  const iree_host_size_t length = result->request_count * sizeof(uint32_t);
  iree_host_size_t allocation_size = 0;
  if (!iree_host_size_checked_add(sizeof(loom_serve_finite_statuses_t), length,
                                  &allocation_size)) {
    return iree_make_status(IREE_STATUS_RESOURCE_EXHAUSTED,
                            "input outcomes exceed host address space");
  }
  loom_serve_finite_statuses_t* statuses = NULL;
  IREE_RETURN_IF_ERROR(iree_allocator_malloc_uninitialized(
      result->host_allocator, allocation_size, (void**)&statuses));
  iree_atomic_ref_count_init(&statuses->ref_count);
  statuses->host_allocator = result->host_allocator;
  statuses->execution = result->execution;
  loom_serve_execution_retain(statuses->execution);
  iree_hal_buffer_t* source = NULL;
  iree_status_t status = iree_hal_subspan_buffer_create_with_callback(
      result->buffer, result->status_offset, length,
      (iree_hal_buffer_release_callback_t){loom_serve_finite_statuses_retired,
                                           statuses},
      result->host_allocator, &source);
  if (iree_status_is_ok(status)) {
    iree_atomic_ref_count_inc(&statuses->ref_count);
    const iree_hal_transfer_operation_t download = {
        .type = IREE_HAL_TRANSFER_OPERATION_TYPE_DOWNLOAD,
        .download = {.source_buffer = source,
                     .target = statuses->values,
                     .length = length}};
    uint64_t value = 0;
    status = loom_serve_execution_feedback(result->execution, 1, &download,
                                           &value);
  }
  iree_hal_buffer_release(source);
  if (iree_status_is_ok(status)) {
    *out_statuses = statuses;
    *out_frontier = loom_serve_execution_frontier(result->execution);
  } else {
    loom_serve_finite_statuses_release(statuses);
  }
  return status;
}

iree_status_t loom_serve_finite_statuses_request(
    const loom_serve_finite_statuses_t* statuses, iree_host_size_t request) {
  return statuses ? loom_serve_finite_input_status(
                        iree_unaligned_load_le_u32(statuses->values + request * 4))
                  : iree_ok_status();
}

iree_status_t loom_serve_finite_snapshot_status(
    const loom_serve_finite_snapshot_t* snapshot, iree_host_size_t request) {
  return snapshot->status_offset
             ? loom_serve_finite_input_status(iree_unaligned_load_le_u32(
                   snapshot->storage + snapshot->status_offset + request * 4))
             : iree_ok_status();
}
