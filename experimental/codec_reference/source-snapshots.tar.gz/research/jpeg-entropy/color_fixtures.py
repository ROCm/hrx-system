"""Native color fixtures from public raw/RGB output, independent of our math."""
import hashlib
import json
from pathlib import Path
import struct

from device_fixture import input_bytes
from sequential import parse

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
directory = root / 'color-small'
directory.mkdir(exist_ok=True)


def write_bytes(path, data):
    header = repr({'descr': '|i1', 'fortran_order': False, 'shape': (len(data),)}).encode()
    header += b' ' * ((64 - ((10 + len(header) + 1) % 64)) % 64) + b'\n'
    path.write_bytes(b'\x93NUMPY\x01\x00' + struct.pack('<H', len(header)) + header + data)


def configuration(frame, color_space, batch=1):
    horizontal = max(component.horizontal for component in frame.components)
    vertical = max(component.vertical for component in frame.components)
    result = {'width': frame.width, 'height': frame.height, 'batch': batch, 'color_space': color_space}
    for index in range(3):
        if index < len(frame.components):
            component = frame.components[index]
            assert horizontal % component.horizontal == 0 and vertical % component.vertical == 0
            result['horizontal' + str(index)] = horizontal // component.horizontal
            result['vertical' + str(index)] = vertical // component.vertical
        else:
            result['horizontal' + str(index)] = result['vertical' + str(index)] = 1
    return {'image': result}


def fixture(name, encoded, color_space, planes, rgb):
    frame = parse(encoded)
    config = configuration(frame, color_space)
    pixels = bytearray()
    for index, plane in enumerate(planes):
        component = frame.components[index]
        width, height = plane['width'], plane['height']
        assert width == (frame.width + config['image']['horizontal' + str(index)] - 1) // config['image']['horizontal' + str(index)]
        assert height == (frame.height + config['image']['vertical' + str(index)] - 1) // config['image']['vertical' + str(index)]
        raw = bytes.fromhex(plane['hex'])
        assert len(raw) == width * height
        offset = len(pixels)
        pixels.extend(bytes([237]) * (component.block_width * component.block_height * 64))
        for y in range(height):
            for x in range(width):
                address = offset + ((y // 8) * component.block_width + x // 8) * 64 + (y % 8) * 8 + x % 8
                pixels[address] = raw[y * width + x]
    expected = rgb + bytes([17]) * 32
    write_bytes(directory / (name + '-components.npy'), pixels)
    write_bytes(directory / (name + '-rgb.npy'), expected)
    (directory / (name + '.json')).write_text(json.dumps(config, indent=2) + '\n')
    (directory / (name + '.loom')).write_text(f'''kernel.decl @jpeg_color() launch(%components: buffer, %rgb: buffer)

check.case @color {{
  %components = check.file.read.npy path("{name}-components.npy") : tensor<{len(pixels)}xi8>
  %expected = check.file.read.npy path("{name}-rgb.npy") : tensor<{len(expected)}xi8>
  %output = check.generate.fill value(17) : tensor<{len(expected)}xi8>
  kernel.launch @jpeg_color(%components, %output) : (tensor<{len(pixels)}xi8>, tensor<{len(expected)}xi8>)
  check.expect.bitwise actual(%output) expected(%expected) : tensor<{len(expected)}xi8>
  check.return
}}
''')
    return {'key': name, 'name': name, 'jobs': 1, 'input_sha256': hashlib.sha256(encoded).hexdigest(),
            'rgb_sha256': hashlib.sha256(rgb).hexdigest(), 'rgb_bytes': len(rgb), 'config': config}


if __name__ == '__main__':
    cases = []
    for line in (notes / 'color-oracle-small.log').read_text().splitlines():
        if not line.startswith('{"name":'):
            continue
        row = json.loads(line)
        cases.append(fixture(row['name'], bytes.fromhex(row['input_hex']), row['color_space'], row['planes'], bytes.fromhex(row['rgb_hex'])))
    raw_groups = {}
    for line in (notes.parent / 'jpeg-gpu-oracle/raw-reference-small.log').read_text().splitlines():
        if line.startswith('{"name":'):
            row = json.loads(line)
            if row['method'] == 0:
                raw_groups.setdefault(row['name'], []).append(row)
    for line in (notes.parent / 'jpeg-reference/probe.log').read_text().splitlines():
        if not line.startswith('{"kind":"result"'):
            continue
        row = json.loads(line)
        if row['mode'] == 1 and row['complete'] and row['name'] in raw_groups:
            planes = sorted(raw_groups[row['name']], key=lambda value: value['component'])
            cases.append(fixture(row['name'], input_bytes(row['name']), row['color_space'], planes, bytes.fromhex(row['rgb_hex'])))
    assert len(cases) == 121
    (directory / 'fixtures.json').write_text(json.dumps({'cases': cases}, indent=2) + '\n')
    stage = {'files': {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
                       for path in directory.iterdir() if path.is_file()}}
    (root / 'color-small-stage.json').write_text(json.dumps(stage, indent=2) + '\n')
    (root / 'entropy-color.loombc').write_bytes((root / 'color.loombc').read_bytes())
    (notes / 'color-fixtures.json').write_text(json.dumps({'cases': cases,
        'sources': {name: hashlib.sha256((notes / name).read_bytes()).hexdigest()
                    for name in ('color_fixtures.py', 'color-oracle-small.log', 'color_oracle.cc')}}, indent=2) + '\n')
    print(len(cases), 'public RGB cases', flush=True)
