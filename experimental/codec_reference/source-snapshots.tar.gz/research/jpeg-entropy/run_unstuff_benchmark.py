"""Measure only the newly owned compressed-byte boundary under one lease."""
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import tarfile

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
fixture = root / 'unstuff-batch16'
files = {str(path.relative_to(root)): path for path in fixture.iterdir() if path.is_file()}
files['entropy-unstuff.loombc'] = root / 'entropy-unstuff.loombc'
assert sum(path.stat().st_size for path in files.values()) < 128 * 1024 * 1024
process = subprocess.Popen(['ssh', 'hrx-gorgon-4', 'tar -xf - -C ' + shlex.quote(str(root))], stdin=subprocess.PIPE)
with tarfile.open(fileobj=process.stdin, mode='w|') as archive:
    for name, path in files.items():
        archive.add(path, arcname=name, recursive=False)
process.stdin.close()
assert process.wait() == 0
script = '''import pathlib,subprocess,sys
root=pathlib.Path(sys.argv[1]);fixture=root/'unstuff-batch16'
subprocess.run([str(root/'iree-test-loom-unsigned'),str(fixture/'summary.loombc'),'--config-file='+str(fixture/'config.json'),'--device=amdgpu','--target=amdgpu:gfx1151','--sanitizer=access'],check=True)
for index in range(3):
 subprocess.run(['python3','-B',str(root/'device_batch_benchmark.py'),'--fixture=unstuff-batch16','--result-name=gorgon4-unstuff-'+str(index),'--runner=iree-benchmark-loom-unsigned','--runner-sha256=3ba3a3e1b3a85a876459320d21d1f32630fb625fd0d39347c45cb875d16c1dad'],check=True)
'''
command = ['/home/benvanik/.dotfiles/bin/benchmark-lock', '--label=codec-jpeg-unstuff-batch16',
           '--', 'env', 'LD_LIBRARY_PATH=/opt/rocm/lib', 'python3', '-B', '-c', script, str(root)]
with (notes / 'gorgon4-unstuff-benchmark.log').open('w') as stream:
    result = subprocess.run(['ssh', 'hrx-gorgon-4', shlex.join(command)], stdout=stream, stderr=subprocess.STDOUT)
status = subprocess.run(['ssh', 'hrx-gorgon-4', '/home/benvanik/.dotfiles/bin/benchmark-lock --status'], capture_output=True, text=True)
record = {'command': command, 'returncode': result.returncode, 'broker_status_after': status.stdout + status.stderr,
          'staged_files': {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in files.items()}}
(notes / 'gorgon4-unstuff-benchmark-lease.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k:v for k,v in record.items() if k != 'staged_files'}), flush=True)
if result.returncode:
    print((notes / 'gorgon4-unstuff-benchmark.log').read_text()[-7000:])
    raise SystemExit(result.returncode)
script = '''import json,pathlib,sys
root=pathlib.Path(sys.argv[1]);result=[]
for index in range(3):
 name='gorgon4-unstuff-'+str(index)
 rows=[json.loads(line) for line in (root/(name+'.jsonl')).read_text().splitlines()]
 result.append({'rows':[r for r in rows if r['row']!='compile'],'receipt':json.loads((root/(name+'-receipt.json')).read_text())})
print(json.dumps(result))'''
output = subprocess.check_output(['ssh', 'hrx-gorgon-4', shlex.join(['python3', '-B', '-c', script, str(root)])])
records = json.loads(output)
(notes / 'gorgon4-unstuff-measurements.json').write_text(json.dumps(records, indent=2) + '\n')
for record in records:
    result = next(row['benchmark_result'] for row in record['rows'] if row['row'] == 'benchmark')
    stages = {row['function_name']: row['timing']['mean_ns'] / 1e6
              for row in result['profile_replay']['summary']['rows'] if row.get('type') == 'dispatch_function'}
    print(json.dumps({'total_ms': result['measurement']['operation_timing_ns']['p50'] / 1e6,
                      'stages_ms': stages, 'correctness': result['correctness']}), flush=True)
