"""Recheck captured roots, guards, final hashes, and failed-image publication."""
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

notes=Path(__file__).resolve().parent
root=Path(json.loads((notes/'device-active.json').read_text())['directory'])/'persistent-resize'
path=notes/'resize-output-audit.json'
rows={row['case']:row for row in json.loads(path.read_text())} if path.exists() else {}
for name in sys.argv[1:]:
    case=root/name;fixture=json.loads((case/'fixture.json').read_text())
    actual={key:np.memmap(case/'actual'/(key+'.bin'),dtype=np.uint8,mode='r') for key in ('input','output')}
    expected={'input':np.load(case/'input.npy',mmap_mode='r').view(np.uint8),
              'output':np.load(case/'output-expected.npy',mmap_mode='r').view(np.uint8)}
    counts={'input':0,'output':0}
    for line in (case/'regions.txt').read_text().splitlines():
        owner,offset,length,kind=line.split();offset=int(offset);length=int(length)
        assert kind=='exact'
        assert np.array_equal(actual[owner][offset:offset+length],expected[owner][offset:offset+length]),(name,owner,offset,length)
        counts[owner]+=length
    final=fixture['ranges']['resized'];validity=fixture['ranges']['validity']
    errors=actual['output'][validity['offset']:validity['offset']+validity['bytes']].view(np.uint32).tolist()
    hashes=[]
    for index,im in enumerate(fixture['images']):
        offset=final['offset']+im['output_offset'];value=actual['output'][offset:offset+im['output_bytes']]
        digest=hashlib.sha256(value).hexdigest();hashes.append(digest)
        if errors[index]:assert np.all(value==17)
        else:assert digest==im['output_sha256'],(name,index)
        guard=actual['output'][offset+im['output_bytes']:offset+im['output_bytes']+32]
        assert np.all(guard==17)
    row={'case':name,'checked_output_bytes':counts['output'],'guard_bytes':fixture['guard_bytes'],
         'captures':{key+'.bin':hashlib.sha256(value).hexdigest() for key,value in actual.items()},
         'final_hashes':hashes,'validity':errors,'passed':True}
    rows[name]=row
    print(json.dumps({key:value for key,value in row.items() if key not in ('captures','final_hashes')}))
path.write_text(json.dumps(list(rows.values()),indent=2)+'\n')
