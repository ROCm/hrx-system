#include "device_entropy.cxx"

[[loom::kernel, loom::workgroup_count(1, 1, 1), loom::workgroup_size(1, 1, 1)]]
void jpeg_probe(const unsigned* entropy, const unsigned* jobs,
                const unsigned* tables, const unsigned* blocks,
                unsigned* output) {
  Cursor cursor = {};
  cursor.budget = chunk_bytes * 32 + 26;
  cursor.cached_word = 0xffffffffu;
  const unsigned* words = entropy + jobs[0];
  output[0] = words[0];
  output[1] = words[1];
  Read input = peek(words, cursor);
  output[2] = input.value;
  output[3] = tables[input.value >> 23];
  Read code = codeword(words, tables, jobs[1], cursor);
  output[4] = code.cursor.position;
  output[5] = code.cursor.reads;
  output[6] = code.cursor.error;
  output[7] = code.value;
  Read value = amplitude(words, code.value, jobs[1], code.cursor);
  output[8] = value.cursor.position;
  output[9] = value.cursor.reads;
  output[10] = value.cursor.error;
  output[11] = value.value;
  cursor = advance(words, tables, blocks, jobs[1], cursor);
  output[12] = cursor.position;
  output[13] = cursor.coefficient;
  output[14] = cursor.error;
  output[15] = cursor.predictors[0];
  cursor = advance(words, tables, blocks, jobs[1], cursor);
  output[16] = cursor.position;
  output[17] = cursor.coefficient;
  output[18] = cursor.error;
  output[19] = cursor.predictors[0];
  output[20] = cursor.budget;
  output[21] = jobs[1];
  output[22] = blocks[0];
  output[23] = cursor.reads;
}

[[loom::kernel, loom::workgroup_count(1, 1, 1), loom::workgroup_size(32, 1, 1)]]
void jpeg_probe_prefix(const unsigned* entropy, const unsigned* jobs,
                       const unsigned* tables, const unsigned* blocks,
                       unsigned* output) {
  unsigned job = loom::kernel::workitem::id.x;
  if (job >= 2) return;
  Cursor cursor = {};
  cursor.budget = 58;
  cursor.cached_word = 0xffffffffu;
  unsigned interval = jobs[job * 3 + 2];
  cursor.position = interval ? interval * 8 - 8 : 0;
  unsigned limit = jobs[job * 3 + 1];
  const unsigned* words = entropy + jobs[job * 3];
  while (cursor.position < interval * 8 && cursor.error == 0) {
    unsigned before = cursor.position;
    cursor = advance(words, tables, blocks, limit, cursor);
    if (cursor.error == 1) {
      cursor.position = before + 1;
      cursor.blocks = 0;
      cursor.block_index = 0;
      cursor.coefficient = 0;
      cursor.predictors = {};
      cursor.error = 0;
    }
  }
  Cursor first = cursor;
  while (cursor.position < (interval + 1) * 8 && cursor.error == 0) {
    cursor = advance(words, tables, blocks, limit, cursor);
  }
  unsigned* result = output + job * 12;
  result[0] = first.position;
  result[1] = first.reads;
  result[2] = first.coefficient;
  result[3] = first.error;
  result[4] = first.predictors[0];
  result[5] = first.cached_word;
  result[6] = cursor.position;
  result[7] = cursor.reads;
  result[8] = cursor.coefficient;
  result[9] = cursor.error;
  result[10] = cursor.predictors[0];
  result[11] = cursor.cached_word;
}
