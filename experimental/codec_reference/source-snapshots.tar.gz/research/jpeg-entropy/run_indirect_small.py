"""Interleave reduced-grid acquire controls without retaining a benchmark lease."""
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess

notes = Path(__file__).resolve().parent
roots = {key: Path(value) for key, value in json.loads(os.environ['BUREAU_TAG_ROOTS']).items()}
build = json.loads((notes / 'indirect-small-build.json').read_text())
assert build['returncode'] == 0 and build['restored']
relative = 'runtime/src/iree/hal/drivers/amdgpu/indirect_dispatch_test'
binaries = {kind: roots['codec-indirect-' + kind] / relative for kind in ('baseline', 'candidate')}
hashes = {kind: hashlib.sha256(path.read_bytes()).hexdigest() for kind, path in binaries.items()}
host = 'hrx-gorgon-4'
remote = subprocess.check_output(['ssh', host, 'mktemp -d /tmp/codec-indirect-small-XXXXXX'], text=True).strip()
receipt = {'host': host, 'directory': remote, 'hashes': hashes, 'build': build, 'retired': False}
receipt_path = notes / 'gorgon4-indirect-small-receipt.json'
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
for kind, path in binaries.items():
    subprocess.run(['scp', str(path), host + ':' + remote + '/' + kind], check=True)
runner = r'''
import hashlib,json,os,re,subprocess,sys
from pathlib import Path
root=Path(sys.argv[1]);expected=json.loads(sys.argv[2]);assert os.environ['BENCHMARK_LOCK_LEASE_ID']
reaped=set()
for name,digest in expected.items():
 with (root/name).open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==digest
def state():
 gpus={}
 for d in Path('/sys/class/drm').glob('card*/device'):
  if (d/'gpu_busy_percent').exists():
   gpus[str(d)]={n:(d/n).read_text().strip() for n in ('gpu_busy_percent','power_dpm_force_performance_level','mem_info_vram_used')}
 kfd=[p.name for p in Path('/sys/class/kfd/kfd/proc').iterdir()]
 return {'gpus':gpus,'kfd':kfd,'live_kfd':[pid for pid in kfd if Path('/proc',pid).exists()],
         'loadavg':Path('/proc/loadavg').read_text().strip(),
         'governor':Path('/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor').read_text().strip()}
record={'before':state(),'rows':[],'scope':'ASAN native correctness and test wall duration; no simulator timing.'}
assert not record['before']['kfd']
assert all(g['gpu_busy_percent']=='0' for g in record['before']['gpus'].values())
for index,name in enumerate(('candidate','baseline','candidate','baseline','candidate','baseline')):
 process=subprocess.Popen([str(root/name)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 stdout,stderr=process.communicate();reaped.add(str(process.pid))
 print('CONTROL '+str(index)+' '+name,flush=True);print(stdout+stderr,flush=True)
 text=stdout+stderr
 row={'kind':name,'pid':process.pid,'returncode':process.returncode,'log':text,
      'case_wall_ms':[int(x) for x in re.findall(r'\((\d+) ms\)',text)],
      'after':state()}
 record['rows'].append(row)
 (root/'result.json').write_text(json.dumps(record,indent=2)+'\n')
 if name=='candidate':
  assert process.returncode==0 and '[  PASSED  ] 2 tests.' in text,text
 else:
  assert process.returncode==1 and '2 FAILED TESTS' in text,text
  for mode in ('Ordinary','Timestamps'):
   assert re.search(r'\[  FAILED  \].*/'+mode+r'.*\(\d+ ms\)',text),text
  assert text.count('Which is: 0')==2 and text.count('Which is: 32')==2,text
record['after']=state();(root/'result.json').write_text(json.dumps(record,indent=2)+'\n')
assert not record['after']['live_kfd']
assert set(record['after']['kfd']).issubset(reaped)
print('REDUCED_GRID_CONTROLS_PASS',flush=True)
'''
command = ['/home/benvanik/.dotfiles/bin/benchmark-lock', '--label=codec-indirect-small', '--',
           'timeout', '--signal=INT', '--kill-after=10s', '120s', 'env', 'LD_LIBRARY_PATH=/opt/rocm/lib',
           'python3', '-B', '-c', runner, remote, json.dumps(hashes)]
receipt['command'] = command
with (notes / 'gorgon4-indirect-small.log').open('w') as log:
    result = subprocess.run(['ssh', host, shlex.join(command)], stdout=log, stderr=subprocess.STDOUT)
receipt['returncode'] = result.returncode
status = subprocess.run(['ssh', host, '~/.dotfiles/bin/benchmark-lock --status'], capture_output=True, text=True)
receipt['broker_status_after'] = status.stdout + status.stderr
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
fetch = subprocess.run(['ssh', host, shlex.join(['cat', remote + '/result.json'])], capture_output=True)
if fetch.returncode == 0:
    (notes / 'gorgon4-indirect-small-result.json').write_bytes(fetch.stdout)
retire = r'''
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]);hashes=json.loads(sys.argv[2])
for name,digest in hashes.items():
 with (root/name).open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==digest
for name in hashes:(root/name).unlink()
'''
subprocess.run(['ssh', host, shlex.join(['python3', '-B', '-c', retire, remote, json.dumps(hashes)])], check=True)
receipt['retired'] = True
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
print((notes / 'gorgon4-indirect-small.log').read_text(), end='')
print(receipt['broker_status_after'], end='')
assert result.returncode == 0
