"""Retire only the hash-checked arrays of a completed cohort experiment."""
import argparse
import json
from pathlib import Path
import shlex
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--images', type=int, choices=(32, 64, 128), required=True)
arguments = parser.parse_args()
notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
comparison = json.loads((notes / f'gorgon4-cohort-{arguments.images}-comparison-run.json').read_text())
assert comparison['returncode'] == 0
status = subprocess.check_output(['ssh', 'hrx-gorgon-4', '~/.dotfiles/bin/benchmark-lock --status'], text=True)
assert 'idle; policy idle; queued 0' in status, status
script = '''import hashlib,json,sys
from pathlib import Path
directory=Path(sys.argv[1]); stage=json.loads((directory/'stage.json').read_text())
assert directory.name=='mixed-wide' and stage['cohort']=='wide-primary' and len(stage['images'])==int(sys.argv[2])
assert not list(Path('/sys/class/kfd/kfd/proc').iterdir())
retired=[]
for name,expected in stage['files'].items():
 if not name.endswith('.npy'): continue
 assert Path(name).name==name
 path=directory/name
 with path.open('rb') as stream: assert hashlib.file_digest(stream,'sha256').hexdigest()==expected,name
 retired.append({'name':name,'bytes':path.stat().st_size,'sha256':expected})
for row in retired: (directory/row['name']).unlink()
print(json.dumps({'retired':retired,'retired_bytes':sum(row['bytes'] for row in retired),'remaining_bytes':sum(path.stat().st_size for path in directory.iterdir() if path.is_file()),'scope':'Only reproducible candidate arrays. Baseline, sources, manifests, numerical reference evidence, and tools preserved.'}))
'''
output = subprocess.check_output(['ssh', 'hrx-gorgon-4', shlex.join([
    'python3', '-B', '-c', script, str(root / 'mixed-wide'), str(arguments.images)])], text=True)
record = json.loads(output)
record['broker_status_before'] = status
(notes / f'mixed-{arguments.images}-retention.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'retired_bytes': record['retired_bytes'], 'remaining_bytes': record['remaining_bytes']}))
