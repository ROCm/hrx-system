"""Run a fixed-shape producer comparison; hash warmups before accepting timing."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

parser = argparse.ArgumentParser()
parser.add_argument('directory',type=Path)
parser.add_argument('--configuration',choices=('asan','opt'),required=True)
parser.add_argument('--samples',type=int,default=0)
parser.add_argument('--iterations',type=int,default=2)
parser.add_argument('--order',default='cpu,gpu')
args = parser.parse_args()
assert args.samples >= 0 and args.iterations > 0
assert args.configuration == 'opt' or args.samples == 0
assert os.environ.get('BENCHMARK_LOCK_LEASE_ID'), 'A foreground benchmark lease is required.'
order=args.order.split(',')
assert all(mode in ('cpu','gpu') for mode in order)
root=args.directory

def state():
 governors = sorted({path.read_text().strip() for path in Path('/sys/devices/system/cpu').glob('cpu*/cpufreq/scaling_governor')})
 devices = {}
 for path in Path('/sys/class/drm').glob('card*/device'):
  if not (path/'gpu_busy_percent').exists():
   continue
  devices[str(path)] = {name:(path/name).read_text().strip() for name in
                       ('vendor','device','gpu_busy_percent','power_dpm_force_performance_level')}
 return {'host':platform.node(),'kernel':platform.release(),
         'lease':os.environ['BENCHMARK_LOCK_LEASE_ID'],
         'personality':Path('/proc/self/personality').read_text().strip(),
         'governors':governors,'gpu_devices':devices,
         'kfd_processes':[path.name for path in Path('/sys/class/kfd/kfd/proc').iterdir()],
         'loadavg':Path('/proc/loadavg').read_text().strip()}

before=state()
assert not before['kfd_processes'],before
if args.samples:
 assert before['governors']==['performance'],before
 assert int(before['personality'],16)&0x40000,before
 assert before['gpu_devices'],before
 assert all(device['gpu_busy_percent']=='0' and device['power_dpm_force_performance_level']=='high'
            for device in before['gpu_devices'].values()),before
manifest=json.loads((root/f'pipeline-{args.configuration}-manifest.json').read_text())
binary=root/('pipeline-probe-'+args.configuration)
assert hashlib.file_digest(binary.open('rb'),'sha256').hexdigest()==manifest['binary_sha256']
expected={'cpu':'c566a37d3e0b99c6f06cf209a125f728e1ac174e3fefe6aaec10c2cf74c8e029',
          'gpu':'b086417f5030e9e74bd1bf69c158c5da0da1ed66bc983463dbba2130d11ef28b'}
record={'configuration':args.configuration,'capture':manifest['capture'],
        'binary_sha256':manifest['binary_sha256'],'samples':args.samples,
        'iterations':args.iterations,'order':order,'cases':[],'passed':False,
        'before':before,'environment':{name:value for name,value in os.environ.items()
          if name.startswith('JSIMD_') or name in ('OMP_NUM_THREADS','GPU_MAX_HW_QUEUES')}}
assert not any(name.startswith('JSIMD_') for name in record['environment'])
result_path=root/f'pipeline-{args.configuration}-results.json'
result_path.write_text(json.dumps(record,indent=2)+'\n')
retired_children=set()
for ordinal,mode in enumerate(order):
 admission=state()
 assert all(pid in retired_children and not (Path('/proc')/pid).exists()
            for pid in admission['kfd_processes']),admission
 compressed='true' if mode=='gpu' else 'false'
 command=[str(binary),'--jpeg_fixture='+str(root),'--compressed='+compressed,
          '--codec_jpeg='+compressed,'--gtest_filter=ProjectorPipelineTest.OriginalBytesToReadyFeatures',
          '--pipeline_samples='+str(args.samples),'--pipeline_iterations='+str(args.iterations)]
 if args.configuration=='asan':
  command.extend(['--amdgpu_asan=true','--amdgpu_asan_report_policy=fail-device'])
 log_path=root/f'pipeline-{args.configuration}-{ordinal}-{mode}.log'
 started=time.monotonic()
 with log_path.open('w') as log:
  process=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  process_id=process.pid
  for line in process.stdout:
   log.write(line);log.flush();print(line,end='',flush=True)
  returncode=process.wait()
 retired_children.add(str(process_id))
 case={'mode':mode,'ordinal':ordinal,'command':command,'returncode':returncode,
       'process_id':process_id,'admission':admission,
       'process_wall_seconds':time.monotonic()-started,'rows':[]}
 for line in log_path.read_text().splitlines():
  if line.startswith('{'):
   case['rows'].append(json.loads(line))
 record['cases'].append(case)
 result_path.write_text(json.dumps(record,indent=2)+'\n')
 if returncode: sys.exit(returncode)
 feature=root/('pipeline-'+mode+'.features')
 case['feature_bytes']=feature.stat().st_size
 case['feature_sha256']=hashlib.file_digest(feature.open('rb'),'sha256').hexdigest()
 case['expected_feature_sha256']=expected[mode]
 case['log_sha256']=hashlib.file_digest(log_path.open('rb'),'sha256').hexdigest()
 result_path.write_text(json.dumps(record,indent=2)+'\n')
 assert case['feature_bytes']==19906560 and case['feature_sha256']==expected[mode],case
 assert [row['images'] for row in case['rows'] if row['phase']=='verified_features']==[1,4]
 assert len([row for row in case['rows'] if row['phase']=='sample'])==args.samples*2
 print(json.dumps({'mode':mode,'ordinal':ordinal,'feature_sha256':case['feature_sha256'],'passed':True}),flush=True)
record['after']=state()
record['after']['live_kfd_processes']=[pid for pid in record['after']['kfd_processes']
                                     if (Path('/proc')/pid).exists()]
result_path.write_text(json.dumps(record,indent=2)+'\n')
# waitpid and the probe's completed producer/drained teardown establish our
# child completion. KFD's sysfs process entry may be retired later by the kernel;
# retain that observation rather than confusing dead-owned metadata with work.
assert all(pid in retired_children and pid not in record['after']['live_kfd_processes']
           for pid in record['after']['kfd_processes']),record['after']
record['passed']=True
for mode in ('cpu','gpu'):
 feature=root/('pipeline-'+mode+'.features')
 if feature.exists():
  assert hashlib.file_digest(feature.open('rb'),'sha256').hexdigest()==expected[mode]
  feature.unlink()
record['feature_pair_retired']=True
result_path.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'passed':True,'configuration':args.configuration,'order':order}),flush=True)
