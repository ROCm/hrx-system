import hashlib, json, subprocess
from pathlib import Path
root = Path('/tmp/codec-indirect-acquire-A3jMfx')
hashes = {'baseline': '9ccffa2a2b3f21fb69c50d113d25257f0dbf99b2b30a656ee015ba8bf8cedc14', 'candidate': '49ae7dd59391a3ecd2989fde8199534885b99e9fd8a5040f7ec1aeef7fcfef05'}
results = {}
for name, expected in hashes.items():
    assert hashlib.file_digest((root / name).open('rb'), 'sha256').hexdigest() == expected
for name in hashes:
    print('CONTROL ' + name, flush=True)
    results[name] = subprocess.run([str(root / name)]).returncode
print('RESULT ' + json.dumps(results), flush=True)
raise SystemExit(results['candidate'])
