"""Use reconstruction's existing block ownership to specialize its AC loop."""
from pathlib import Path

notes = Path(__file__).resolve().parent
transition = (notes / 'device_entropy_cursor_certified.h').read_text()
begin = transition.index('  Read input = peek(words, cursor);')
transition = transition[begin:]
transition = transition.replace('symbol & (15u | dc_mask)', 'symbol & 15u')
begin = transition.index('  if (cursor.coefficient == 0) {')
end = transition.index('    unsigned run = symbol >> 4;', begin)
transition = transition[:begin] + transition[end:]
old = '  }\n  cursor.position += consumed;'
assert transition.count(old) == 1
transition = transition.replace(old, '  cursor.position += consumed;')
transition = '''// The block owner has already consumed DC. Its retained table and the
// restart-rooted certificate establish the entire AC syntax transition.
static LOOM_FORCE_INLINE Symbol advance_ac_certified(const unsigned* words,
    const unsigned* table, Cursor cursor) {
''' + transition

source = (notes / 'device_reconstruct_certified.cxx').read_text()
marker = 'using Values = int __attribute__((ext_vector_type(8)));'
assert source.count(marker) == 1
source = source.replace(marker, transition + '\n' + marker)
old = '''        unsigned offset = 0;
        if (active && cursor.error == 0) {'''
new = '''        unsigned offset = 0;
        unsigned table_index = blocks[block] >> 16;
        unsigned available_tables = table_count;
        loom::assume(table_index < available_tables);
        const unsigned* ac_table = tables + table_index * 832;
        if (active && cursor.error == 0) {'''
assert source.count(old) == 1
source = source.replace(old, new)
old = '''          do {
            Symbol symbol = output_symbol(words, tables, blocks, bit_limit, certified_end, cursor);
            cursor = symbol.cursor;
            if (symbol.index != 0xffffffffu && cursor.error == 0) {
              unsigned natural = zigzag[symbol.index];
              loom::assume(natural < 64u);
              coefficients[natural * coefficient_stride + lane] = static_cast<short>(symbol.value);
              if (symbol.index != 0) any_ac = true;
            }
          } while (cursor.coefficient != 0 && cursor.error == 0);'''
new = '''          // Interval alignment and the completed preceding block establish
          // a DC codeword here. Only that transition updates the predictors.
          unsigned first_coefficient = cursor.coefficient;
          loom::assume(first_coefficient == 0);
          cursor.coefficient = first_coefficient;
          Symbol dc = output_symbol(words, tables, blocks, bit_limit, certified_end, cursor);
          cursor = dc.cursor;
          if (cursor.error == 0) coefficients[lane] = static_cast<short>(dc.value);
          while (cursor.coefficient != 0 && cursor.error == 0) {
            Symbol symbol = {};
            if (cursor.position < certified_end) {
              symbol = advance_ac_certified(words, ac_table, cursor);
            } else {
              symbol = advance_symbol(words, tables, blocks, bit_limit, cursor);
            }
            cursor = symbol.cursor;
            if (symbol.index != 0xffffffffu && cursor.error == 0) {
              unsigned natural = zigzag[symbol.index];
              loom::assume(natural < 64u);
              coefficients[natural * coefficient_stride + lane] = static_cast<short>(symbol.value);
              any_ac = true;
            }
          }'''
assert source.count(old) == 1
source = source.replace(old, new)
(notes / 'device_reconstruct_block_ac.cxx').write_text(source)
pipeline = '#include "device_entropy_cursor_certified.h"\n'
pipeline += '''[[loom::config("jpeg.output_partitions"), loom::where(loom::predicate::range(2u, 8u))]]
extern const unsigned output_partitions;
'''
for name in ('device_entropy_partitioned.cxx', 'device_bridge.cxx',
             'device_certify_partitioned.cxx', 'device_reconstruct_block_ac.cxx'):
    pipeline += '\n' + (notes / name).read_text().replace('#include "device_entropy_cursor.h"', '') + '\n'
(notes / 'device_block_ac_pipeline.cxx').write_text(pipeline)
