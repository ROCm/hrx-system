#pragma once

#include "device_entropy_cursor_short.h"

// The restart-rooted certificate proves every complete symbol before its
// exclusive frontier. Absolute DC bounds remain the output consumer's job.
static LOOM_FORCE_INLINE Symbol advance_symbol_certified(const unsigned* words,
    const unsigned* tables, const unsigned* blocks, Cursor cursor) {
  unsigned block_index = cursor.block_index;
  unsigned block_count = blocks_per_mcu;
  loom::assume(block_index < block_count);
  unsigned descriptor = blocks[block_index];
  unsigned dc_mask = 0u - static_cast<unsigned>(cursor.coefficient == 0);
  unsigned dc_table = (descriptor >> 8) & 255;
  unsigned ac_table = descriptor >> 16;
  unsigned table_index = ac_table ^ ((ac_table ^ dc_table) & dc_mask);
  unsigned available_tables = table_count;
  loom::assume(table_index < available_tables);
  const unsigned* table = tables + table_index * 832;
  Read input = peek(words, cursor);
  cursor = input.cursor;
  unsigned packed = table[input.value >> 23];
  unsigned length = packed >> 8;
  unsigned symbol = packed & 255;
  if (length == 0) {
    unsigned prefix = input.value >> 16;
    for (unsigned candidate = 10; candidate <= 16 && length == 0; ++candidate) {
      unsigned value = prefix >> (16 - candidate);
      unsigned first = table[512 + candidate * 3];
      unsigned count = table[513 + candidate * 3];
      if (value >= first && value - first < count) {
        unsigned base = table[514 + candidate * 3];
        unsigned symbol_index = base + value - first;
        loom::assume(symbol_index < 256u);
        symbol = table[563 + symbol_index];
        length = candidate;
      }
    }
  }
  loom::assume(length != 0 && length <= 16u);
  unsigned category = symbol & (15u | dc_mask);
  loom::assume(category <= 11u);
  unsigned consumed = length + category;
  unsigned amplitude_mask = (1u << category) - 1;
  unsigned value = (input.value >> (32 - consumed)) & amplitude_mask;
  unsigned negative_mask = 0u - static_cast<unsigned>(value < ((1u << category) >> 1));
  int amplitude = static_cast<int>(value + ((0u - amplitude_mask) & negative_mask));
  unsigned output_index = 0xffffffffu;
  int output_value = 0;
  if (cursor.coefficient == 0) {
    unsigned component = descriptor & 255;
    cursor.predictors[component] += amplitude;
    cursor.coefficient = 1;
    output_index = 0;
    output_value = cursor.predictors[component];
  } else {
    unsigned run = symbol >> 4;
    if (category == 0) {
      unsigned nonzero_run_mask = 0u - static_cast<unsigned>(run != 0);
      cursor.coefficient = ((cursor.coefficient + 16) & nonzero_run_mask) & 63;
    } else {
      unsigned index = cursor.coefficient + run;
      loom::assume(index < 64u);
      cursor.coefficient = (index + 1) & 63;
      output_index = index;
      output_value = amplitude;
    }
    if (cursor.coefficient == 0) {
      ++cursor.blocks;
      ++cursor.block_index;
      unsigned wrap_mask = 0u - static_cast<unsigned>(cursor.block_index != blocks_per_mcu);
      cursor.block_index &= wrap_mask;
    }
  }
  cursor.position += consumed;
  cursor.reads += consumed;
  return {cursor, output_index, output_value};
}
