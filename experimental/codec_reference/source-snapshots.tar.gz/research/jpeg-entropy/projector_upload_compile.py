"""Verify the complete source join before the finite-model execution witness."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

notes = Path(__file__).resolve().parent
directory = Path(json.loads((notes / "device-active.json").read_text())["directory"]) / "native-projector"
model = directory / "sources/experimental/loom_serve/models/qwen"
tools = Path(json.loads(os.environ["BUREAU_TAG_ROOTS"])["codec-jpeg-rebased-tools"]) / "loom/src/loom/tools"
settings = json.loads((directory / "deployment.json").read_text())["definition"]
inputs = [str(model / "vision_prepare.loom"), str(model / "vision_control.loom")]
inputs += [str((model / name).resolve()) for name in settings["sources"]]
commands = [
    [str(tools / "loom-import-cxx/loom-import-cxx"), str(directory / "projector_decoder.cxx"), "--output=" + str(directory / "decoder.loom")],
    [str(tools / "loom-link/loom-link"), str(directory / "decoder_command.loom"), str(directory / "decoder.loom"), "--to=bc", "--output=" + str(directory / "decoder.loombc")],
    [str(tools / "loom-link/loom-link"), *inputs, "--to=bc", "--output=" + str(directory / "projector.loombc")],
    [str(tools / "loom-compile/loom-compile"), str(directory / "projector.loombc"), "--target=vm:core", "--root=prepare_request", "--root=prepare_batch", "--root=run", "--output=" + str(directory / "control.vm")],
    [str(tools / "loom-compile/loom-compile"), str(directory / "projector.loombc"), "--target=amdgpu:gfx1151", "--root=qwen38_vision_resize", "--sanitizer=access", "--output=" + str(directory / "resize.hsaco")],
]
record = {"source_receipt_sha256": hashlib.sha256((notes / "projector-upload-source.json").read_bytes()).hexdigest(), "commands": []}
for command in commands:
    result = subprocess.run(command, capture_output=True, text=True)
    record["commands"].append({"command": command, "returncode": result.returncode, "output": result.stdout + result.stderr})
    (notes / "projector-upload-compile.json").write_text(json.dumps(record, indent=2) + "\n")
    print(result.stdout + result.stderr, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
record["artifacts"] = {name: hashlib.sha256((directory / name).read_bytes()).hexdigest()
                       for name in ("decoder.loombc", "projector.loombc", "control.vm", "resize.hsaco")}
(notes / "projector-upload-compile.json").write_text(json.dumps(record, indent=2) + "\n")
print("Linked the complete model and compiled the preparation VM and checked resize kernel.", flush=True)
