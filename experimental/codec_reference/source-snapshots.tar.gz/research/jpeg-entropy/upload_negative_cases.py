"""Relocate the qualified rejection oracle without decoding or deriving pixels."""

import copy
import hashlib
import json
from pathlib import Path
import struct

from wide_fixture import digest, payload, write_array


notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / "device-active.json").read_text())["directory"])
directory = root / "native-upload"
source_path = notes / "entropy-validity-cases.json"
assert digest(source_path) == "84d4699a7f93ed7e0316f099c4a7f7c624a4f8ac635a0d13fb1fb6051ed18bba"
source = json.loads(source_path.read_text())
qualification = json.loads((notes / "entropy-validity-result.json").read_text())
assert qualification["baseline_passed"] and qualification["negative_cases_passed"] == 27
cases = [{"directory": "mixed-negative-base", "stage": source["baseline"]}] + source["cases"]
results = []


def words(data):
    return list(struct.unpack("<" + "I" * (len(data) // 4), data))


def packed(values):
    return bytearray(struct.pack("<" + "I" * len(values), *values))


for case in cases:
    origin = root / case["directory"]
    stage = json.loads((origin / "stage.json").read_text())
    assert stage == case["stage"]
    for name, expected in stage["files"].items():
        assert digest(origin / name) == expected, (origin.name, name)
    name = "negative/" + origin.name if "mutation" in case else "."
    target = directory / name
    target.mkdir(parents=True, exist_ok=True)
    bindings = [line.split() for line in (origin / "bindings.txt").read_text().splitlines()]
    values = {key: bytearray(payload(origin / filename)) for key, _, _, _, filename in bindings}
    old = [image["header"] for image in stage["images"]]
    headers = copy.deepcopy(old)
    assert len(old) == 16
    assert words(values["headers"]) == [word for row in old for word in row] + [17] * 8
    mappings = {}
    # Each tuple names the retained image-header field, its byte scale, and
    # whether a binding-wide guard follows the per-image slices.
    pools = {"pixels": (3, 4, 0), "compressed": (4, 4, 32),
             "entropy": (5, 4, 0), "records": (6, 16, 32),
             "prefixes": (6, 4, 32), "tables": (8, 4, 32),
             "geometry": (9, 4, 32), "quantization": (10, 4, 32),
             "rgb": (14, 1, 0)}
    for key, (field, scale, guard) in pools.items():
        data = values[key]
        end = len(data) - guard
        starts = sorted(header[field] * scale for header in old)
        assert len(set(starts)) == len(old) and starts[0] == 0
        limits = dict(zip(starts, starts[1:] + [end]))
        result = bytearray()
        mapping = []
        for ordinal, header in enumerate(old):
            start = header[field] * scale
            limit = limits[start]
            assert start < limit <= end and len(result) % scale == 0
            replacement = len(result)
            result.extend(data[start:limit])
            headers[ordinal][field] = replacement // scale
            mapping.append({"ordinal": ordinal, "old_offset": start,
                            "new_offset": replacement, "length": limit - start,
                            "sha256": hashlib.sha256(data[start:limit]).hexdigest()})
        if guard:
            result.extend(data[end:])
        assert len(result) == len(data)
        values[key] = result
        mappings[key] = mapping
    assert all(row["new_offset"] // 16 == other["new_offset"] // 4
               for row, other in zip(mappings["records"], mappings["prefixes"]))
    values["headers"] = packed([word for row in headers for word in row] + [17] * 8)
    segments = words(values["segments"])
    for ordinal, header in enumerate(headers):
        assert segments[ordinal * 8] == old[ordinal][5]
        assert segments[ordinal * 8 + 7] == old[ordinal][3]
        segments[ordinal * 8] = header[5]
        segments[ordinal * 8 + 7] = header[3]
    values["segments"] = packed(segments)
    jobs = words(values["jobs"])
    for index in range(words(values["schedule"])[0]):
        ordinal = jobs[index * 4 + 3]
        assert jobs[index * 4] == old[ordinal][5]
        jobs[index * 4] = headers[ordinal][5]
    values["jobs"] = packed(jobs)
    color = words(values["color_tiles"])
    tiles = [color[index:index + 3] for index in range(0, len(color) - 8, 3)]
    assert all(len(tile) == 3 for tile in tiles)
    values["color_tiles"] = packed([word for ordinal in range(len(old))
        for tile in tiles if tile[0] == ordinal for word in tile] + color[-8:])
    assert len(values["color_tiles"]) == len(color) * 4

    regions = []
    if "mutation" in case:
        for line in (origin / "verification.txt").read_text().splitlines():
            key, offset, length, mode = line.split()
            offset, length = int(offset), int(length)
            if key == "pixels":
                owner, = [row for row in mappings[key]
                          if row["old_offset"] <= offset and
                          offset + length <= row["old_offset"] + row["length"]]
                offset += owner["new_offset"] - owner["old_offset"]
            assert 0 <= offset < offset + length <= len(values[key])
            regions.append(f"{key} {offset} {length} {mode}")
        (target / "verification.txt").write_text("\n".join(regions) + "\n")
    else:
        assert not (target / "verification.txt").exists()
    for key, _, width, count, filename in bindings:
        assert len(values[key]) == int(width) * int(count)
        if name == ".":
            assert values[key] == payload(origin / filename), key
        write_array(target / filename, int(width), int(count), [values[key]])
    (target / "bindings.txt").write_bytes((origin / "bindings.txt").read_bytes())
    filenames = []
    for ordinal, image in enumerate(stage["images"]):
        header = headers[ordinal]
        encoded = values["compressed"][header[4] * 4:header[4] * 4 + header[0]]
        assert hashlib.sha256(encoded).hexdigest() == image["input_sha256"]
        filename = f"original-{ordinal}.jpg"
        (target / filename).write_bytes(encoded)
        filenames.append(filename)
    (target / "inputs.txt").write_text("\n".join(filenames) + "\n")
    retained = [row[-1] for row in bindings] + filenames + ["bindings.txt", "inputs.txt"]
    if regions:
        retained.append("verification.txt")
    results.append({"name": name, "source_directory": str(origin),
                    "source_stage_sha256": digest(origin / "stage.json"),
                    "files": {filename: digest(target / filename) for filename in retained},
                    "mappings": mappings,
                    "mutation": case.get("mutation"), "ordinal": case.get("ordinal"),
                    "verification_regions": len(regions)})
    print(json.dumps({"case": name, "verification_regions": len(regions)}), flush=True)

(directory / "cases.txt").write_text("\n".join(case["name"] for case in results) + "\n")
fixture_bytes = sum((directory / case["name"] / filename).stat().st_size
                    for case in results for filename in case["files"])
assert fixture_bytes < 32 * 1024**2
receipt = {"source_sha256": digest(source_path),
           "qualified_result_sha256": digest(notes / "entropy-validity-result.json"),
           "generator_sha256": digest(Path(__file__)), "cases": results,
           "cases_file_sha256": digest(directory / "cases.txt"),
           "fixture_bytes": fixture_bytes,
           "scope": "Pure relocation of already-qualified per-image pools, pointers, and exact verification ranges. Original JPEGs and pixel/guard bytes are preserved; no decoding or native constructor supplies expectations."}
(notes / "upload-negative-cases.json").write_text(json.dumps(receipt, indent=2) + "\n")
