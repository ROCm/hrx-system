"""Keep the task-pool baseline unchanged except for public IDCT selection."""
import hashlib
import json
from pathlib import Path

notes = Path(__file__).resolve().parent
source = (notes.parent / 'jpeg-baseline/jpeg_baseline.cc').read_text()
assert hashlib.sha256(source.encode()).hexdigest() == json.loads((notes / 'cpu-refresh-stage.json').read_text())['source_sha256']
needle = '  codec.out_color_space = JCS_RGB;\n  jpeg_start_decompress(&codec);'
assert source.count(needle) == 1
candidate = source.replace(needle, '  codec.out_color_space = JCS_RGB;\n  codec.dct_method = CODEC_REFERENCE_IDCT;\n  jpeg_start_decompress(&codec);')
assert candidate.count('codec.dct_method != JDCT_ISLOW') == 1
candidate = candidate.replace('codec.dct_method != JDCT_ISLOW', 'codec.dct_method != CODEC_REFERENCE_IDCT')
candidate = candidate.replace('// Same public settings and scanline loop as the serving callback. Output',
                              '// Same task pool and scanline loop, with explicit public IDCT selection. Output')
(notes / 'cpu_idct_baseline.cc').write_text(candidate)
(notes / 'cpu-idct-source.json').write_text(json.dumps({
    'baseline_sha256': hashlib.sha256(source.encode()).hexdigest(),
    'candidate_sha256': hashlib.sha256(candidate.encode()).hexdigest(),
    'difference': 'Only codec.dct_method assignment and matching contract assertion; IDCT enum is a build-time define. Output allocation, workers, inputs, warmup, sampling, guards, and timing remain unchanged.'}, indent=2) + '\n')
