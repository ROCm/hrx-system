"""Sixteen disjoint images through the complete GPU certificate sequence."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

from device_fixture import read_words, write_words

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
tag = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['codec-jpeg-rebased-tools'])
linker = tag / 'loom/src/loom/tools/loom-link/loom-link'
source = root / 'batch16-1024'
output = root / 'parallel-batch16-1024'
output.mkdir(exist_ok=True)
original = json.loads((source / 'stage.json').read_text())
sizes = dict(original['sizes'])
paths = {name: '../batch16-1024/' + name + '.npy' for name in sizes}
paths.update({'segments': '../anchor-batch16-1024/segments.npy',
              'bridges': '../bridge-batch16-1024/bridges.npy'})
sizes['segments'] = len(read_words(output / paths['segments']))
sizes['bridges'] = len(read_words(output / paths['bridges']))
key = '012mp-bus.jpg.r0.jpg-scan0-chunk1024'
for name in ('suffixes', 'ranges', 'intervals'):
    words = read_words(root / 'parallel-large' / (key + '-' + name + '.npy'))
    write_words(output / (name + '.npy'), words * 16)
    sizes[name] = len(words) * 16
    paths[name] = name + '.npy'
declarations = [
    ('jpeg_speculate', ('entropy', 'jobs', 'tables', 'blocks', 'expected')),
    ('jpeg_bridge', ('entropy', 'jobs', 'tables', 'blocks', 'expected', 'bridges')),
    ('jpeg_index', ('segments', 'expected', 'suffixes', 'ranges', 'intervals')),
    ('jpeg_certify', ('segments', 'expected', 'bridges', 'suffixes', 'ranges', 'intervals')),
    ('jpeg_intervals', ('segments', 'expected', 'suffixes', 'ranges', 'intervals'))]
lines = ['kernel.decl @' + entry + '() launch(' + ', '.join('%' + name + ': buffer' for name in names) + ')'
         for entry, names in declarations]
lines.extend(('', 'check.case @summary {'))
for name, path in paths.items():
    lines.append(f'  %{name} = check.file.read.npy path("{path}") : tensor<{sizes[name]}xi32>')
outputs = ('expected', 'bridges', 'suffixes', 'ranges', 'intervals')
for name in outputs:
    lines.append(f'  %{name}_output = check.generate.fill value(17) : tensor<{sizes[name]}xi32>')
for entry, names in declarations:
    names = tuple(name + '_output' if name in outputs else name for name in names)
    types = ', '.join(f'tensor<{sizes[name.removesuffix("_output")]}xi32>' for name in names)
    lines.append(f'  kernel.launch @{entry}(' + ', '.join('%' + name for name in names) + f') : ({types})')
for name in outputs:
    lines.append(f'  check.expect.bitwise actual(%{name}_output) expected(%{name}) : tensor<{sizes[name]}xi32>')
lines.extend(('  check.return', '}', '', 'check.benchmark<@summary> @summary_latency'))
(output / 'summary.loom').write_text('\n'.join(lines) + '\n')
config = json.loads((source / 'config.json').read_text())
config['jpeg'].update({'segments': 16, 'table_count': sizes['tables'] // 832, 'cache_tables': 0})
(output / 'config.json').write_text(json.dumps(config, indent=2) + '\n')
command = [str(linker), str(output / 'summary.loom'), str(root / 'entropy-parallel.loombc'),
           '--to=bc', '--output=' + str(output / 'summary.loombc')]
subprocess.run(command, check=True)
files = {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
         for path in output.iterdir() if path.is_file() and path.name != 'stage.json'}
files.update({path: hashlib.sha256((output / path).read_bytes()).hexdigest() for path in paths.values()})
stage = {'batch': 16, 'jobs': original['jobs'], 'sizes': sizes, 'files': files,
         'library': {'path': 'entropy-parallel.loombc',
                     'sha256': hashlib.sha256((root / 'entropy-parallel.loombc').read_bytes()).hexdigest()},
         'scope': 'Five queued GPU dispatches: speculation, independent bridges, suffix indexing, restart-root certification, and interval materialization. No host entropy checkpoints. Device destuffing, coefficient output, IDCT, and RGB remain absent.',
         'link_command': command, 'source_fixture': key}
(output / 'stage.json').write_text(json.dumps(stage, indent=2) + '\n')
(notes / 'device-parallel-batch.json').write_text(json.dumps(stage, indent=2) + '\n')
print(json.dumps({'jobs': stage['jobs'], 'metadata_bytes': sum(sizes[name] * 4 for name in outputs)}), flush=True)
