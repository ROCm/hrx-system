"""Exercise original compressed input through the real trained HTTP service."""
import argparse
import base64
import hashlib
import http.client
import json
import os
from pathlib import Path
import signal
import socket
import struct
import subprocess
import time


parser = argparse.ArgumentParser()
parser.add_argument("directory", type=Path)
parser.add_argument("--mode", choices=("control", "candidate", "lifecycle"), required=True)
arguments = parser.parse_args()
directory = arguments.directory.resolve()
mode = arguments.mode
manifest = json.loads((directory / "stage-manifest.json").read_text())
for name, expected in manifest["files"].items():
    with (directory / name).open("rb") as stream:
        assert hashlib.file_digest(stream, "sha256").hexdigest() == expected, name

port = 18185
prompt = "Describe the vehicle in the foreground and any readable text on it. Answer in one short sentence."
command = [str(directory / "loom-serve"), "--device=amdgpu", "--workers=16",
           "--pool_backing=fixed", f"--listen=127.0.0.1:{port}", "--connections=16",
           "--request_body_bytes=67108864", "--heartbeat_ms=0",
           "--amdgpu_asan=true", "--amdgpu_asan_report_policy=fail-device",
           "--codec_jpeg=" + str(mode != "control").lower(),
           "--model=" + str(directory / ("control-deployment.json" if mode == "control" else "deployment.json"))]
receipt = {"mode": mode, "command": command,
           "manifest_sha256": hashlib.sha256((directory / "stage-manifest.json").read_bytes()).hexdigest(),
           "lease": os.environ.get("BENCHMARK_LOCK_LEASE_ID"), "cases": []}
result_path = directory / (mode + "-result.json")
log_path = directory / (mode + ".log")
connections = set()


def record():
    result_path.write_text(json.dumps(receipt, indent=2) + "\n")


def begin_request(path, payload=None, headers=None):
    connection = http.client.HTTPConnection("127.0.0.1", port)
    connections.add(connection)
    try:
        body = None if payload is None else json.dumps(payload, separators=(",", ":")).encode()
        connection.request("GET" if payload is None else "POST", path, body,
                           {"Content-Type": "application/json", "Connection": "close", **(headers or {})})
        return connection
    except BaseException:
        connection.close()
        connections.remove(connection)
        raise


def finish_request(connection):
    try:
        response = connection.getresponse()
        data = response.read()
        content_type = response.getheader("Content-Type")
        return {"http_status": response.status, "content_type": content_type,
                "body": json.loads(data) if content_type and "application/json" in content_type
                else data.decode("utf-8")}
    finally:
        connection.close()
        connections.remove(connection)


def request(path, payload=None, headers=None):
    return finish_request(begin_request(path, payload, headers))


def cancel(connection):
    assert connection.sock is not None
    # FIN is a legal request half-close: the server still owes a response.
    # An aborted client instead resets the connection while work is pending.
    connection.sock.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER,
                               struct.pack("ii", 1, 0))
    connection.close()
    connections.remove(connection)


def payload(names, streaming=False):
    content = []
    for name in names:
        mime = "image/x-portable-arbitrarymap" if name.endswith(".pam") else "image/jpeg"
        encoded = base64.b64encode((directory / name).read_bytes()).decode("ascii")
        content.append({"type": "image_url", "image_url": {"url": f"data:{mime};base64,{encoded}"}})
    content.append({"type": "text", "text": prompt})
    return {"model": "codec-jpeg-publication", "temperature": 0,
            "max_tokens": 32 if len(names) > 1 else 64, "enable_thinking": False,
            "stream": streaming, "messages": [{"role": "user", "content": content}]}


def events():
    return [json.loads(line) for line in log_path.read_text().splitlines()
            if line.startswith('{"phase":"jpeg_http_')]


def normalized(response):
    body = response["body"]
    assert response["http_status"] == 200, response
    assert body["usage"]["prompt_tokens_details"]["cached_tokens"] == 0, body
    return {"choices": body["choices"], "usage": body["usage"]}


def status():
    if server.poll() is not None:
        raise RuntimeError(f"server exited during request: {server.returncode}")
    response = request("/v1/status")
    assert response["http_status"] == 200, response
    state = response["body"]["data"][0]["loom"]
    assert state["registration"] == "ready" and not state.get("error"), state
    return state["status"]


def until(predicate):
    while True:
        state = status()
        if predicate(state):
            return state
        time.sleep(0.002)


def cohorts(start):
    result = []
    for event in events()[start:]:
        if event["phase"] == "jpeg_http_submit":
            result.append({"submit": event, "published": []})
        else:
            assert result, event
            result[-1]["published"].append(event)
    return result


def before_publication(start, expected_images):
    while True:
        state = status()
        groups = cohorts(start)
        if groups:
            current = groups[-1]
            if current["submit"]["images"] == expected_images:
                assert not current["published"], (state, groups)
                if state["phase"] == "image_execute":
                    return {"status": state, "cohorts": groups}
        time.sleep(0.002)


def run_lifecycle(oracle):
    good = payload(["original.jpg"])
    bad = payload(["empty-entropy.jpg"], streaming=True)
    check("lifecycle-warmup", ["original.jpg"], 200, oracle)

    start = len(events())
    print(json.dumps({"case": "independent-peers", "phase": "request"}), flush=True)
    leader = begin_request("/v1/chat/completions", good)
    observation = before_publication(start, 1)
    invalid = begin_request("/v1/chat/completions", bad)
    valid = begin_request("/v1/chat/completions", good)
    responses = {"leader": finish_request(leader), "invalid": finish_request(invalid),
                 "valid": finish_request(valid)}
    row = {"case": "independent-peers", "observation": observation,
           "responses": responses, "cohorts": cohorts(start)}
    receipt["cases"].append(row)
    record()
    print(json.dumps(row), flush=True)
    assert normalized(responses["leader"]) == normalized(responses["valid"]) == oracle
    assert responses["invalid"]["http_status"] == 400
    assert "source rejected input (code 768)" in json.dumps(responses["invalid"]["body"])
    assert any(group["submit"]["images"] == 2 and
               sorted(event["status"] for event in group["published"]) == [0, 3]
               for group in row["cohorts"]), row

    start = len(events())
    print(json.dumps({"case": "cancel-before-image-preparation", "phase": "request"}), flush=True)
    leader = begin_request("/v1/chat/completions", good)
    active = until(lambda state: state["active_requests"] == 1)
    discarded = begin_request("/v1/chat/completions", good)
    queued = until(lambda state: state["active_requests"] == 1 and state["queued_requests"] == 1)
    inventory = request("/v1/requests", headers={"X-Loom-Model": "codec-jpeg-publication"})
    cancel(discarded)
    removed = until(lambda state: state["queued_requests"] == 0)
    response = finish_request(leader)
    idle = until(lambda state: state["active_requests"] == 0 and
                 state["queued_requests"] == 0 and state["phase"] == "idle")
    row = {"case": "cancel-before-image-preparation", "active": active,
           "queued": queued, "inventory": inventory, "removed": removed, "idle": idle,
           "response": response, "cohorts": cohorts(start)}
    receipt["cases"].append(row)
    record()
    print(json.dumps(row), flush=True)
    assert normalized(response) == oracle
    assert len(row["cohorts"]) == 1 and row["cohorts"][0]["submit"]["images"] == 1, row

    start = len(events())
    print(json.dumps({"case": "cancel-after-submit-with-valid-peer", "phase": "request"}), flush=True)
    leader = begin_request("/v1/chat/completions", good)
    before_publication(start, 1)
    discarded = begin_request("/v1/chat/completions", good)
    valid = begin_request("/v1/chat/completions", good)
    response = finish_request(leader)
    observation = before_publication(start, 2)
    inventory = request("/v1/requests", headers={"X-Loom-Model": "codec-jpeg-publication"})
    cancel(discarded)
    peer = finish_request(valid)
    idle = until(lambda state: state["active_requests"] == 0 and
                 state["queued_requests"] == 0 and state["phase"] == "idle")
    row = {"case": "cancel-after-submit-with-valid-peer", "observation": observation,
           "inventory": inventory, "idle": idle, "leader": response, "peer": peer,
           "cohorts": cohorts(start)}
    receipt["cases"].append(row)
    record()
    print(json.dumps(row), flush=True)
    assert normalized(response) == normalized(peer) == oracle
    assert len(row["cohorts"]) == 2, row
    assert row["cohorts"][1]["submit"]["images"] == 2, row
    assert len(row["cohorts"][1]["published"]) == 1, row
    assert row["cohorts"][1]["published"][0]["status"] == 0, row
    check("valid-after-cancellations", ["original.jpg"], 200, oracle)


def check(name, names, expected, oracle=None):
    before = len(events())
    print(json.dumps({"case": name, "phase": "request", "mode": mode}), flush=True)
    response = request("/v1/chat/completions", payload(names, streaming=expected != 200))
    row = {"case": name, "inputs": names, "stream_requested": expected != 200,
           "response": response, "events": events()[before:]}
    receipt["cases"].append(row)
    record()
    print(json.dumps(row), flush=True)
    assert response["http_status"] == expected, row
    if expected == 400:
        assert "source rejected input (code 768)" in json.dumps(response["body"]), row
        assert any(event.get("status") == 3 for event in row["events"]), row
    elif oracle is not None:
        assert normalized(response) == oracle, row
    else:
        normalized(response)
    return response


with log_path.open("w") as log:
    server = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT)
    receipt["server_pid"] = server.pid
    previous = None
    try:
        while True:
            if server.poll() is not None:
                raise RuntimeError(f"server exited during registration: {server.returncode}")
            try:
                response = request("/v1/status")
            except ConnectionRefusedError:
                time.sleep(0.05)
                continue
            assert response["http_status"] == 200, response
            state = response["body"]["data"][0]["loom"]
            current = state.get("registration")
            if current != previous:
                print(json.dumps({"mode": mode, "registration": current}), flush=True)
                previous = current
            if state.get("error") or current == "failed":
                raise RuntimeError(f"model registration failed: {state}")
            if current == "ready":
                receipt["ready"] = response["body"]
                break
            time.sleep(0.05)
        if mode == "control":
            response = check("lossless-control", ["loom-float32.pam"], 200)
            receipt["oracle"] = normalized(response)
        else:
            control = json.loads((directory / "control-result.json").read_text())
            assert control["passed"]
            oracle = control["oracle"]
            if mode == "lifecycle":
                run_lifecycle(oracle)
            else:
                check("original-jpeg", ["original.jpg"], 200, oracle)
                check("invalid-stream", ["empty-entropy.jpg"], 400)
                check("invalid-first-sibling", ["empty-entropy.jpg", "original.jpg"], 400)
                check("invalid-last-sibling", ["original.jpg", "empty-entropy.jpg"], 400)
                check("valid-after-rejections", ["original.jpg"], 200, oracle)
        receipt["final_status"] = request("/v1/status")["body"]
        receipt["passed"] = True
    except BaseException as error:
        receipt["error"] = repr(error)
        raise
    finally:
        for connection in connections:
            connection.close()
        if server.poll() is None:
            server.send_signal(signal.SIGINT)
        receipt["server_exit"] = server.wait()
        record()
if receipt["server_exit"] != 0:
    raise RuntimeError(f"server shutdown failed: {receipt['server_exit']}")
print(json.dumps({"mode": mode, "passed": True, "server_exit": receipt["server_exit"]}), flush=True)
