"""One bounded synchronization comparison; preserve baseline source and fixtures."""
import hashlib
import json
from pathlib import Path

notes=Path(__file__).resolve().parent
root=Path(json.loads((notes/'device-active.json').read_text())['directory'])/'persistent-resize'
source=root/'source-polling';source.mkdir(exist_ok=True)
baseline=(root/'source/resize.cxx').read_text()
assert hashlib.sha256(baseline.encode()).hexdigest()=='c4cddfed2a1fcd031f271a15ed6b6fc1c63ac722c2745216d4e91a268efb4e21'
text=baseline
marker='static LOOM_FORCE_INLINE unsigned observe(const unsigned* address) {'
assert text.count(marker)==1
text=text.replace(marker,'''static LOOM_FORCE_INLINE unsigned poll(const unsigned* address) {
  return loom::view::atomic::load<loom::atomic::ordering::relaxed,
      loom::atomic::scope::device>(address);
}

'''+marker)
begin=text.index('static LOOM_FORCE_INLINE bool claim_decode(')
end=text.index('\n}',begin)+2
old=text[begin:end]
new=old.replace('unsigned first = observe(head);','''unsigned first = poll(head);
  if (first == absent) return false;
  // A published head owns the linked chain until a successful claim removes
  // it. Another claimant makes our CAS fail; a task never reenters this row.
  loom::buffer::fence<loom::atomic::ordering::acquire,
      loom::atomic::scope::device>();''')
new=new.replace('observe(links + next)','poll(links + next)')
text=text[:begin]+new+text[end:]
begin=text.index('static LOOM_FORCE_INLINE void jpeg_resize_stream_body(')
end=text.index('\nstatic LOOM_FORCE_INLINE void jpeg_resize_publish_body(',begin)
old=text[begin:end]
new=old.replace('observe(', 'poll(')
marker='''      }
    }
    role = loom::kernel::subgroup::broadcast(role, 0);'''
assert new.count(marker)==1
new=new.replace(marker,'''      }
      // Successful selection consumes the release-published readiness facts.
      // Failed polls touch no payload and require no acquire invalidation.
      if (role != 0) loom::buffer::fence<loom::atomic::ordering::acquire,
          loom::atomic::scope::device>();
    }
    role = loom::kernel::subgroup::broadcast(role, 0);''')
text=text[:begin]+new+text[end:]
(source/'resize.cxx').write_text(text)
for name in ('mixed_cursor.h','mixed_image.h','command.loom','directory.json'):
    (source/name).write_bytes((root/'source'/name).read_bytes())
for base in ('primary-r3-w128','small-r3-w1','small-r3-w128-invalid','small-r3-w128-invalid-padding'):
    target=root/(base+'-polling');target.mkdir(exist_ok=True)
    for name in ('input.npy','output.npy','output-expected.npy','bindings.txt','regions.txt','config.json','command.loom'):
        path=target/name
        if path.is_symlink():assert path.resolve()==(root/base/name).resolve()
        else:path.symlink_to(root/base/name)
    fixture=json.loads((root/base/'fixture.json').read_text())
    fixture.update(case=target.name,source_sha256=hashlib.sha256(text.encode()).hexdigest(),
                   baseline_case=base,variant='Acquire published data at ownership handoff; return immediately for empty queues.')
    (target/'fixture.json').write_text(json.dumps(fixture,indent=2)+'\n')
receipt={'baseline_source_sha256':hashlib.sha256(baseline.encode()).hexdigest(),
         'source_sha256':hashlib.sha256(text.encode()).hexdigest(),'source':str(source),
         'changes':'Empty queue returns; acquire head before relaxed links; acquire readiness once after selection; all producer ordering preserved.'}
(notes/'resize-polling-source.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
