"""Stage the bounded transform witness, verify identities, and check on GPU."""
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import tarfile

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
directory = root / 'float-probe'
tool = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['codec-jpeg-unsigned-opt']) / 'loom/src/loom/tools/iree-test-loom/iree-test-loom'
digest = hashlib.sha256(tool.read_bytes()).hexdigest()
files = {str(path.relative_to(root)): path for path in directory.iterdir() if path.is_file()}
files['float32-check-tool'] = tool
process = subprocess.Popen(['ssh', 'hrx-gorgon-4', 'tar -xf - -C ' + shlex.quote(str(root))], stdin=subprocess.PIPE)
with tarfile.open(fileobj=process.stdin, mode='w|', dereference=True) as archive:
    for name, path in files.items(): archive.add(path, arcname=name, recursive=False)
process.stdin.close()
assert process.wait() == 0
verify = '''import hashlib,json,pathlib,sys
root=pathlib.Path(sys.argv[1]); directory=root/'float-probe'
for name,digest in json.loads((directory/'stage.json').read_text())['files'].items():
 assert hashlib.sha256((directory/name).read_bytes()).hexdigest()==digest,name
assert hashlib.sha256((root/'float32-check-tool').read_bytes()).hexdigest()==sys.argv[2]
assert not list(pathlib.Path('/sys/class/kfd/kfd/proc').iterdir())
'''
subprocess.run(['ssh', 'hrx-gorgon-4', shlex.join(['python3', '-B', '-c', verify, str(root), digest])], check=True)
command = ['/home/benvanik/.dotfiles/bin/benchmark-lock', '--label=codec-float32-block-check', '--',
           'env', 'LD_LIBRARY_PATH=/opt/rocm/lib', str(root / 'float32-check-tool'), str(directory / 'check.loom'),
           '--library=' + str(directory / 'library.loombc'), '--config-file=' + str(directory / 'config.json'),
           '--device=amdgpu', '--target=amdgpu:gfx1151', '--sanitizer=access']
result = subprocess.run(['ssh', 'hrx-gorgon-4', shlex.join(command)], capture_output=True, text=True)
(notes / 'gorgon4-float32-block-check.log').write_text(result.stdout + result.stderr)
status = subprocess.check_output(['ssh', 'hrx-gorgon-4', '/home/benvanik/.dotfiles/bin/benchmark-lock --status'], text=True)
record = {'command': command, 'returncode': result.returncode, 'tool_sha256': digest,
          'stage': json.loads((directory / 'stage.json').read_text()), 'broker_status_after': status}
if result.returncode == 0:
    report = json.loads(result.stdout)
    assert report['failed_sample_count'] == 0 and report['sample_count'] == 1
    record['report'] = report
(notes / 'gorgon4-float32-block-check.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'returncode': result.returncode, 'broker_status_after': status}), flush=True)
if result.returncode: print(result.stdout + result.stderr, flush=True)
raise SystemExit(result.returncode)
