"""Render the controlled gfx1100 comparison from retained measurements."""
import hashlib
import json
from pathlib import Path
import statistics

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


root = Path(__file__).resolve().parent
data = json.loads((root / 'sharkbox-measure-result.json').read_text())
profile = json.loads((root / 'sharkbox-profile-result.json').read_text())
gpu_rows = [row for row in data['rows'] if row['policy'] == 'gpu']
gpu_ns = statistics.median(row['median_128_image_ns'] for row in gpu_rows)
gpu_samples = [sample / 1e6 for row in gpu_rows for result in row['result']
               if result.get('phase') == 'measurement' for sample in result['batch_ns']]
profiles = [row for row in profile['records'] if row.get('phase') == 'profile']
profile_total = sum(row['total_ns'] for row in profiles)
cpu_rows = [row for row in data['rows'] if row['policy'] != 'gpu']
summary = {
    'evidence': {name: hashlib.sha256((root / name).read_bytes()).hexdigest()
                 for name in ('sharkbox-measure-result.json', 'sharkbox-profile-result.json',
                              'sharkbox-check-result.json', 'sharkbox-primary-stage.json')},
    'gpu_median_128_image_ms': gpu_ns / 1e6,
    'gpu_sample_range_ms': [min(gpu_samples), max(gpu_samples)],
    'cpu': [{'policy': row['policy'], 'workers': row['workers'],
             'median_128_image_ms': row['median_128_image_ns'] / 1e6,
             'gpu_time_divided_by_cpu_time': gpu_ns / row['median_128_image_ns']}
            for row in cpu_rows],
    'gpu_profile_total_ms': profile_total / 1e6,
    'gpu_profile': [{'function': row['function'], 'milliseconds': row['total_ns'] / 1e6,
                     'fraction': row['total_ns'] / profile_total}
                    for row in sorted(profiles, key=lambda row: row['total_ns'], reverse=True)],
    'gpu_logical_bytes': data['scope']['gpu_logical_binding_bytes'],
    'cpu_preallocated_rgb_bytes': data['scope']['cpu_rgb_bytes_per_completion'],
}
(root / 'sharkbox-comparison-summary.json').write_text(json.dumps(summary, indent=2) + '\n')

plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10,
                     'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.titleweight': 'bold', 'svg.fonttype': 'none'})
fig, (ax, stages) = plt.subplots(1, 2, figsize=(12.8, 5.6),
                                gridspec_kw={'width_ratios': [1.2, 1]})
fig.subplots_adjust(left=.065, right=.98, top=.77, bottom=.23, wspace=.34)
fig.text(.065, .93, 'JPEG decode: W7900 vs libjpeg-turbo', fontsize=21, weight='bold', color='#152437')
fig.text(.065, .865, 'gfx1100 W7900  •  Threadripper PRO 7995WX  •  128 mixed images per completion',
         fontsize=11, color='#526174')
ax.axhspan(min(gpu_samples), max(gpu_samples), color='#e98025', alpha=.18, linewidth=0)
ax.axhline(gpu_ns / 1e6, color='#d76812', lw=2, label=f'Loom GPU: {gpu_ns / 1e6:.1f} ms')
for policy, label, color, marker in [('islow', 'libjpeg ISLOW', '#7a65ae', 's'),
                                      ('ifast', 'libjpeg IFAST', '#17669b', 'o')]:
    rows = sorted([row for row in cpu_rows if row['policy'] == policy], key=lambda row: row['workers'])
    x = [row['workers'] for row in rows]
    y = [row['median_128_image_ns'] / 1e6 for row in rows]
    low = [value - min(row['result'][0]['batch_ns']) / 1e6 for row, value in zip(rows, y)]
    high = [max(row['result'][0]['batch_ns']) / 1e6 - value for row, value in zip(rows, y)]
    ax.errorbar(x, y, yerr=[low, high], label=label, color=color, marker=marker,
                markersize=6, capsize=3, lw=1.8, alpha=.95)
ax.set(xlim=(10, 102), ylim=(0, 130), xticks=[16, 32, 64, 96],
       xlabel='Physical CPU workers', ylabel='Milliseconds',
       title='Completion time · lower is better')
ax.grid(axis='y', color='#e2e7ed', linewidth=.8)
ax.set_axisbelow(True)
ax.legend(frameon=False, loc='lower left', fontsize=9)
ax.annotate('35.4 ms', xy=(96, 35.400529), xytext=(92, 19),
            ha='right', weight='bold', color='#17669b',
            arrowprops={'arrowstyle': '-', 'color': '#17669b'})

names = ['Reconstruction', 'Speculative entropy', 'Bridging', 'Color conversion', 'Other dispatches']
functions = ['jpeg_reconstruct', 'jpeg_speculate', 'jpeg_bridge', 'jpeg_color']
values = [sum(row['total_ns'] for row in profiles if row['function'] == function) / 1e6
          for function in functions]
values.append(profile_total / 1e6 - sum(values))
colors = ['#d76812', '#e69b54', '#efb77c', '#f5cda5', '#b7c4d4']
stages.barh(names, values, color=colors, height=.62)
stages.invert_yaxis()
stages.set(xlim=(0, 46), xlabel='GPU timestamp duration (ms)',
           title=f'Where the GPU spends {profile_total / 1e6:.1f} ms')
for i, value in enumerate(values):
    stages.text(value + .6, i, f'{value:.1f}', va='center', fontsize=10)
stages.grid(axis='x', color='#e2e7ed', linewidth=.8)
stages.set_axisbelow(True)
fig.text(.065, .12, '9 samples per row; CPU bars show observed ranges. GPU band covers 27 samples across 3 interleaved runs.',
         fontsize=9, color='#526174')
fig.text(.065, .075, 'GPU: 8 × 16-image commands; resident compressed inputs; 426 MB logical buffers. CPU: 128 queued decode jobs.',
         fontsize=9, color='#526174')
fig.text(.065, .03, 'GPU excludes headers, transfers, allocation, and JIT; CPU includes codec setup. Different IDCT policies. Profiling is a separate run.',
         fontsize=9, color='#526174')
for suffix in ('png', 'svg'):
    fig.savefig(root / ('sharkbox-comparison.' + suffix), dpi=160, facecolor='white')
print(json.dumps({'gpu_ms': gpu_ns / 1e6, 'profile_ms': profile_total / 1e6,
                  'png': str(root / 'sharkbox-comparison.png')}))
