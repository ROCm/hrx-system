"""Connect device speculation to anchor repair; CPU checkpoints are assertions only."""
import argparse
from bisect import bisect_left
import hashlib
import json
import os
from pathlib import Path

from bounded import State, Summary, establish
from device_fixture import input_bytes, read_words, write_words
from sequential import parse

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
parser = argparse.ArgumentParser()
parser.add_argument('--fixtures', default='fixtures.json')
parser.add_argument('--output', default='anchor-small')
arguments = parser.parse_args()
source = root / arguments.fixtures
directory = root / arguments.output
directory.mkdir(exist_ok=True)


def signed(word):
    return word if word < 0x80000000 else word - 0x100000000


frames = {}
cases = []
for case in json.loads(source.read_text())['cases']:
    name, key = case['name'], case['key']
    if name not in frames:
        data = input_bytes(name)
        assert hashlib.sha256(data).hexdigest() == case['input_sha256']
        frames[name] = parse(data)
    frame = frames[name]
    scan = frame.scans[case['scan']]
    components = len(frame.components)
    summary_stride = (5 + components + 3) & ~3
    checkpoint_stride = (3 + components + 3) & ~3
    paths = {name: source.parent / (key + '-' + name + '.npy')
             for name in ('entropy', 'jobs', 'tables', 'blocks', 'expected')}
    words = {name: read_words(path) for name, path in paths.items()}
    segments, checkpoints = [], []
    first_job = 0
    total_repair = 0
    for segment in scan.segments:
        intervals = (len(segment.data) + case['chunk_bytes'] - 1) // case['chunk_bytes']
        first_checkpoint = len(checkpoints) // checkpoint_stride
        entropy_offset = words['jobs'][first_job * 3]
        segments.extend((entropy_offset, len(segment.data) * 8, first_job, intervals,
                         segment.mcu_count * len(scan.blocks), first_checkpoint, 0, 0))
        summaries = []
        for interval in range(intervals):
            job = first_job + interval
            assert words['jobs'][job * 3:job * 3 + 3] == (
                entropy_offset, len(segment.data) * 8, interval)
            record = words['expected'][job * summary_stride:(job + 1) * summary_stride]
            if record[0] == 0xffffffff:
                summaries.append(None)
                continue
            first_blocks = record[1] // 64
            assert (first_blocks + record[4]) % len(scan.blocks) == record[3] // 64
            first = State(record[0], first_blocks, record[1] & 63, (0,) * components)
            last = State(record[2], first_blocks + record[4], record[3] & 63,
                         tuple(signed(value) for value in record[5:5 + components]))
            summaries.append(Summary(first, last))
        established, counts = establish(segment, scan, components,
                                        case['chunk_bytes'] * 8, summaries)
        total_repair += counts['repair_symbols']
        positions = [state.position for state in established]
        for boundary in range(intervals + 1):
            index = min(bisect_left(positions, boundary * case['chunk_bytes'] * 8),
                        len(established) - 1)
            state = established[index]
            record = [state.position, state.blocks,
                      (state.blocks % len(scan.blocks)) * 64 + state.coefficient,
                      *state.predictors]
            checkpoints.extend(record + [0] * (checkpoint_stride - len(record)))
        first_job += intervals
    assert first_job == case['jobs']
    segment_count = len(scan.segments)
    values = {'segments': segments, 'checkpoints': checkpoints, 'status': [0] * segment_count}
    for name, value in values.items():
        write_words(directory / (key + '-' + name + '.npy'), value)
    sizes = {name: len(value) for name, value in words.items()}
    sizes.update({name: len(value) for name, value in values.items()})
    lines = [
        'kernel.decl @jpeg_speculate() launch(%entropy: buffer, %jobs: buffer, %tables: buffer, %blocks: buffer, %summaries: buffer)',
        'kernel.decl @jpeg_anchor() launch(%entropy: buffer, %segments: buffer, %tables: buffer, %blocks: buffer, %summaries: buffer, %checkpoints: buffer, %status: buffer)',
        '', 'check.case @summary {']
    for name, path in paths.items():
        relative = os.path.relpath(path, directory)
        lines.append(f'  %{name} = check.file.read.npy path("{relative}") : tensor<{sizes[name]}xi32>')
    for name in values:
        lines.append(f'  %{name} = check.file.read.npy path("{key}-{name}.npy") : tensor<{sizes[name]}xi32>')
    for name in ('expected', 'checkpoints', 'status'):
        lines.append(f'  %{name}_output = check.generate.fill value(17) : tensor<{sizes[name]}xi32>')
    summary_arguments = ('entropy', 'jobs', 'tables', 'blocks', 'expected_output')
    anchor_arguments = ('entropy', 'segments', 'tables', 'blocks', 'expected_output', 'checkpoints_output', 'status_output')
    for entry, names in (('jpeg_speculate', summary_arguments), ('jpeg_anchor', anchor_arguments)):
        types = ', '.join(f'tensor<{sizes[name.removesuffix("_output")]}xi32>' for name in names)
        lines.append(f'  kernel.launch @{entry}(' + ', '.join('%' + name for name in names) + f') : ({types})')
    for name in ('expected', 'checkpoints', 'status'):
        lines.append(f'  check.expect.bitwise actual(%{name}_output) expected(%{name}) : tensor<{sizes[name]}xi32>')
    lines.extend(('  check.return', '}', '', 'check.benchmark<@summary> @summary_latency'))
    (directory / (key + '.loom')).write_text('\n'.join(lines) + '\n')
    config = json.loads((source.parent / (key + '.json')).read_text())
    config['jpeg'].update({'segments': segment_count, 'table_count': sizes['tables'] // 832, 'cache_tables': 0})
    (directory / (key + '.json')).write_text(json.dumps(config, indent=2) + '\n')
    cases.append({**case, 'segments': segment_count, 'checkpoint_words': len(checkpoints),
                  'repair_symbols': total_repair})
    print(json.dumps({'case': key, 'segments': segment_count, 'jobs': first_job,
                      'checkpoints': len(checkpoints) // checkpoint_stride,
                      'repair_symbols': total_repair}), flush=True)

sources = ('device_anchor_fixture.py', 'device_fixture.py', 'device_entropy_cursor.h', 'device_entropy_tables.cxx',
           'device_anchor.cxx', 'device_entropy_pipeline.cxx', 'bounded.py', 'sequential.py')
receipt = {'sources': {name: hashlib.sha256((notes / name).read_bytes()).hexdigest()
                       for name in sources}, 'cases': cases}
(directory / 'fixtures.json').write_text(json.dumps(receipt, indent=2) + '\n')
files = {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
         for path in directory.iterdir() if path.is_file()}
for case in cases:
    for name in ('entropy', 'jobs', 'tables', 'blocks', 'expected'):
        path = source.parent / (case['key'] + '-' + name + '.npy')
        files[str(path.relative_to(root))] = hashlib.sha256(path.read_bytes()).hexdigest()
stage = {'files': files}
(root / (arguments.output + '-stage.json')).write_text(json.dumps(stage, indent=2) + '\n')
(notes / (arguments.output + '-fixtures.json')).write_text(json.dumps(receipt, indent=2) + '\n')
