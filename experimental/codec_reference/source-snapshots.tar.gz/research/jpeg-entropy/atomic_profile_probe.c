// Bounded API experiment: profile knowledge and compilation are separate facts.
#include <inttypes.h>
#include <stdio.h>
#include <string.h>

#include "loomc/loomc.h"
#include "loomc/target/spirv.h"

#define TRY(expression)                           \
  do {                                            \
    status = (expression);                        \
    if (!loomc_status_is_ok(status)) goto cleanup; \
  } while (0)

static void print_diagnostics(const loomc_result_t* result) {
  for (loomc_host_size_t i = 0; i < loomc_result_diagnostic_count(result); ++i) {
    const loomc_diagnostic_t* diagnostic = loomc_result_diagnostic_at(result, i);
    printf("DIAGNOSTIC %.*s %.*s\n", (int)diagnostic->code.size,
           diagnostic->code.data, (int)diagnostic->message.size,
           diagnostic->message.data);
  }
}

static loomc_status_t require_success(loomc_result_t** result) {
  print_diagnostics(*result);
  bool succeeded = loomc_result_succeeded(*result);
  loomc_result_release(*result);
  *result = NULL;
  return succeeded ? loomc_ok_status()
                   : loomc_make_status(LOOMC_STATUS_FAILED_PRECONDITION,
                                       "probe setup failed");
}

static int run_case(const char* source_text, int device_scope, int atomic64,
                    int named_profile) {
  loomc_target_environment_t* environment = NULL;
  loomc_context_t* context = NULL;
  loomc_workspace_t* workspace = NULL;
  loomc_source_t* source = NULL;
  loomc_module_t* module = NULL;
  loomc_target_profile_t* profile = NULL;
  loomc_compiler_t* compiler = NULL;
  loomc_pass_program_t* pipeline = NULL;
  loomc_result_t* result = NULL;
  loomc_status_t status = loomc_ok_status();
  int failed = 0;
  printf("CASE named=%d device_scope=%d atomic64=%d\n", named_profile,
         device_scope, atomic64);
  TRY(loomc_target_environment_create_spirv(loomc_allocator_system(),
                                           &environment));
  loomc_context_target_options_t target_options = {
      .type = LOOMC_STRUCTURE_TYPE_CONTEXT_TARGET_OPTIONS,
      .structure_size = sizeof(target_options),
      .target_environment = environment,
  };
  loomc_context_options_t context_options = {
      .type = LOOMC_STRUCTURE_TYPE_CONTEXT_OPTIONS,
      .structure_size = sizeof(context_options),
      .next = &target_options,
  };
  TRY(loomc_context_create(&context_options, loomc_allocator_system(), &context));
  TRY(loomc_workspace_create(NULL, loomc_allocator_system(), &workspace));
  loomc_source_options_t source_options = {
      .type = LOOMC_STRUCTURE_TYPE_SOURCE_OPTIONS,
      .structure_size = sizeof(source_options),
      .format = LOOMC_SOURCE_FORMAT_TEXT,
      .identifier = loomc_make_cstring_view("buffer_descriptor_extents.loom"),
      .contents = loomc_make_byte_span(source_text, strlen(source_text)),
      .storage = LOOMC_SOURCE_STORAGE_BORROWED,
  };
  TRY(loomc_source_create(&source_options, loomc_allocator_system(), &source));
  TRY(loomc_module_deserialize_from_source(context, workspace, source, NULL,
                                          loomc_allocator_system(), &module,
                                          &result));
  TRY(require_success(&result));
  if (named_profile) {
    const char* selectors[] = {
        "spirv:vulkan1.3+bda",
        "spirv:vulkan1.3+bda+extended-types",
        "spirv:vulkan1.3+bda+subgroup32+ballot+hal",
    };
    TRY(loomc_target_profile_select(
        environment, loomc_make_cstring_view(selectors[named_profile - 1]),
        loomc_allocator_system(), &profile));
  } else {
    const loomc_spirv_feature_fact_t features[] = {
        {.feature = LOOMC_SPIRV_FEATURE_VULKAN_MEMORY_MODEL_DEVICE_SCOPE,
         .state = (loomc_target_fact_state_t)device_scope,
         .provenance = loomc_make_cstring_view("controlled device-scope fact")},
        {.feature = LOOMC_SPIRV_FEATURE_STORAGE_BUFFER_INT64_ATOMICS,
         .state = (loomc_target_fact_state_t)atomic64,
         .provenance = loomc_make_cstring_view("controlled storage-i64 fact")},
    };
    loomc_spirv_profile_options_t profile_options = {
        .type = LOOMC_STRUCTURE_TYPE_SPIRV_PROFILE_OPTIONS,
        .structure_size = sizeof(profile_options),
        .identifier = loomc_make_cstring_view("controlled-atomic-profile"),
        .preset = LOOMC_SPIRV_PROFILE_PRESET_VULKAN_1_3_BDA,
        .feature_facts = features,
        .feature_fact_count = 2,
    };
    TRY(loomc_target_profile_create_spirv(environment, &profile_options,
                                         loomc_allocator_system(), &profile,
                                         &result));
    TRY(require_success(&result));
  }
  loomc_target_fact_state_t queried_scope, queried_atomic64;
  TRY(loomc_spirv_target_profile_query_feature(
      profile, LOOMC_SPIRV_FEATURE_VULKAN_MEMORY_MODEL_DEVICE_SCOPE,
      &queried_scope));
  TRY(loomc_spirv_target_profile_query_feature(
      profile, LOOMC_SPIRV_FEATURE_STORAGE_BUFFER_INT64_ATOMICS,
      &queried_atomic64));
  if (!named_profile &&
      (queried_scope != device_scope || queried_atomic64 != atomic64)) {
    status = loomc_make_status(LOOMC_STATUS_FAILED_PRECONDITION,
                               "profile query lost supplied feature state");
    goto cleanup;
  }
  TRY(loomc_compiler_create(context, NULL, loomc_allocator_system(), &compiler));
  loomc_target_pipeline_options_t pipeline_options = {
      .type = LOOMC_STRUCTURE_TYPE_TARGET_PIPELINE_OPTIONS,
      .structure_size = sizeof(pipeline_options),
      .identifier = loomc_make_cstring_view("atomic-profile-prepared-low"),
      .kind = LOOMC_TARGET_PIPELINE_KIND_PREPARED_LOW,
      .control_flow_lowering = LOOMC_TARGET_CONTROL_FLOW_LOWERING_STRUCTURED_LOW,
      .source_to_low_max_errors = 20,
  };
  TRY(loomc_pass_program_create_from_target_pipeline(
      context, &pipeline_options, loomc_allocator_system(), &pipeline, &result));
  TRY(require_success(&result));
  const loomc_string_view_t root = loomc_make_cstring_view("atomic_record_fields");
  loomc_emit_options_t emit_options = {
      .type = LOOMC_STRUCTURE_TYPE_EMIT_OPTIONS,
      .structure_size = sizeof(emit_options),
      .artifact_format = loomc_make_cstring_view(LOOMC_ARTIFACT_FORMAT_SPIRV),
      .identifier = loomc_make_cstring_view("atomic_record_fields.spv"),
      .artifact_flags = LOOMC_EMIT_ARTIFACT_FLAG_PRIMARY,
  };
  loomc_compile_artifact_options_t compile_options = {
      .type = LOOMC_STRUCTURE_TYPE_COMPILE_ARTIFACT_OPTIONS,
      .structure_size = sizeof(compile_options),
      .roots = &root,
      .root_count = 1,
      .target_profile = profile,
      .emit_options = &emit_options,
  };
  TRY(loomc_compile_artifact(compiler, workspace, pipeline, module,
                            &compile_options, loomc_allocator_system(), &result));
  uint64_t executable_bytes = 0;
  for (loomc_host_size_t i = 0; i < loomc_result_artifact_count(result); ++i) {
    const loomc_artifact_t* artifact = loomc_result_artifact_at(result, i);
    if (artifact->kind == LOOMC_ARTIFACT_KIND_EXECUTABLE &&
        loomc_string_view_equal(artifact->format,
            loomc_make_cstring_view(LOOMC_ARTIFACT_FORMAT_SPIRV))) {
      executable_bytes += loomc_byte_sequence_length(artifact->contents);
    }
  }
  bool succeeded = loomc_result_succeeded(result);
  printf("ROW %d %d %d %d %d %d %" PRIu64 " %zu\n", named_profile,
         device_scope, atomic64, queried_scope, queried_atomic64, succeeded,
         executable_bytes, (size_t)loomc_result_diagnostic_count(result));
  print_diagnostics(result);
  if (!named_profile && device_scope == LOOMC_TARGET_FACT_STATE_TRUE &&
      atomic64 == LOOMC_TARGET_FACT_STATE_TRUE &&
      (!succeeded || executable_bytes == 0)) {
    failed = 1;
  }
cleanup:
  if (!loomc_status_is_ok(status)) {
    char text[2048];
    loomc_host_size_t length = 0;
    loomc_status_format(status, sizeof(text), text, &length);
    fprintf(stderr, "SETUP %.*s\n", (int)length, text);
    failed = 1;
    loomc_status_free(status);
  }
  loomc_result_release(result);
  loomc_pass_program_release(pipeline);
  loomc_compiler_release(compiler);
  loomc_target_profile_release(profile);
  loomc_module_release(module);
  loomc_source_release(source);
  loomc_workspace_release(workspace);
  loomc_context_release(context);
  loomc_target_environment_release(environment);
  return failed;
}

int main(int argc, char** argv) {
  if (argc != 2) return 2;
  int failed = 0;
  for (int named_profile = 1; named_profile <= 3; ++named_profile) {
    failed |= run_case(argv[1], 0, 0, named_profile);
  }
  for (int scope = LOOMC_TARGET_FACT_STATE_UNKNOWN;
       scope <= LOOMC_TARGET_FACT_STATE_TRUE; ++scope) {
    for (int atomic64 = LOOMC_TARGET_FACT_STATE_UNKNOWN;
         atomic64 <= LOOMC_TARGET_FACT_STATE_TRUE; ++atomic64) {
      failed |= run_case(argv[1], scope, atomic64, false);
    }
  }
  return failed;
}
