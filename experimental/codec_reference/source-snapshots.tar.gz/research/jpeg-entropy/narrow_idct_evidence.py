"""Prove the bounded integer path and count actual primary block admission."""
from collections import Counter
import hashlib
import json
from pathlib import Path
from integer_idct import transform
from device_fixture import input_bytes
from sequential import parse, decode

class Linear:
    peaks = []
    def __init__(self, values):
        self.values = tuple(values)
        self.peaks.append(sum(map(abs, self.values)))
    def __add__(self, other):
        return Linear(a+b for a,b in zip(self.values, other.values))
    def __sub__(self, other):
        return Linear(a-b for a,b in zip(self.values, other.values))
    def __mul__(self, scale):
        return Linear(value*scale for value in self.values)

basis = [Linear(int(i==j) for i in range(8)) for j in range(8)]
outputs = transform(basis)
maximum = max(Linear.peaks)
first = (maximum * 1024 + 1024) >> 11
second = maximum * first + 131072
assert maximum == 61214 and first == 30607 and second < 2**31
notes = Path(__file__).resolve().parent
data = input_bytes('012mp-bus.jpg.r0.jpg')
frame = parse(data)
planes, _ = decode(frame)
counts = Counter()
maximum_input = 0
for component, plane in zip(frame.components, planes):
    for offset in range(0, len(plane), 64):
        bound = max(abs(plane[offset+i] * component.quantization[i]) for i in range(64))
        counts[bound <= 1024] += 1
        maximum_input = max(maximum_input, bound)
result = {'scope':'Symbolic proof of every arithmetic intermediate; exact primary block-frequency analysis, not timing.',
          'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'model_sha256':hashlib.sha256((notes/'integer_idct.py').read_bytes()).hexdigest(),
          'input_sha256':hashlib.sha256(data).hexdigest(),
          'arithmetic_intermediate_max_l1':maximum,'first_rounded_bound':first,
          'second_arithmetic_with_rounding_bound':second,'dequantized_bound':1024,
          'safe_primary_blocks':counts[True],'wide_primary_blocks':counts[False],
          'maximum_primary_dequantized_magnitude':maximum_input}
(notes/'narrow-idct-evidence.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
