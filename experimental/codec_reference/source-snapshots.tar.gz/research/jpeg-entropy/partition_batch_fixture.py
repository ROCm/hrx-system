"""Reuse complete batch pixels while expanding retained cursor metadata only."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

from device_fixture import read_words, write_words

parser = argparse.ArgumentParser()
parser.add_argument('--partitions', type=int, default=4)
arguments = parser.parse_args()
partitions = arguments.partitions
notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
source = root / 'clamp-mask-batch16-1024'
output = root / 'partitioned-batch16-1024'
output.mkdir(exist_ok=True)
original = json.loads((source / 'stage.json').read_text())
sizes = dict(original['sizes'])
key = '012mp-bus.jpg.r0.jpg-scan0-chunk1024'
single = root / f'partitions{partitions}-large'
case = next(case for case in json.loads((single / 'fixtures.json').read_text())['cases']
            if case['key'] == key)
pattern = re.compile(r'%([a-z_]+) = check.file.read.npy path\("([^"]+)"\) : tensor<(\d+)xi32>')
paths = {match[1]: (source / match[2]).resolve()
         for match in pattern.finditer((source / 'summary.loom').read_text())}
for name in ('points', 'intervals', 'status'):
    words = read_words(single / (key + '-' + name + '.npy'))
    paths[name] = output / (name + '.npy')
    write_words(paths[name], words * 16)
    sizes[name] = len(words) * 16
assert sum(paths[name].stat().st_size for name in ('points','intervals','status')) < 64 * 1024 * 1024
outputs = ('expected','bridges','suffixes','ranges','points','intervals','pixels','status')
declarations = [
    ('jpeg_speculate',('entropy','jobs','tables','blocks','expected','points')),
    ('jpeg_bridge',('entropy','jobs','tables','blocks','expected','bridges')),
    ('jpeg_index',('segments','expected','suffixes','ranges','intervals')),
    ('jpeg_certify',('segments','expected','bridges','suffixes','ranges','intervals')),
    ('jpeg_intervals',('segments','expected','suffixes','ranges','points','intervals')),
    ('jpeg_reconstruct',('entropy','segments','tables','blocks','intervals','geometry','quantization','zigzag','pixels','status')),
]
lines = ['kernel.decl @'+entry+'() launch('+', '.join('%'+name+': buffer' for name in names)+')'
         for entry,names in declarations]
lines += ['', 'check.case @summary {']
for name,path in paths.items():
    lines.append(f'  %{name} = check.file.read.npy path("{os.path.relpath(path,output)}") : tensor<{sizes[name]}xi32>')
for name in outputs:
    lines.append(f'  %{name}_output = check.generate.fill value(17) : tensor<{sizes[name]}xi32>')
for entry,names in declarations:
    values = ', '.join('%'+name+('_output' if name in outputs else '') for name in names)
    types = ', '.join(f'tensor<{sizes[name]}xi32>' for name in names)
    lines.append(f'  kernel.launch @{entry}({values}) : ({types})')
for name in outputs:
    lines.append(f'  check.expect.bitwise actual(%{name}_output) expected(%{name}) : tensor<{sizes[name]}xi32>')
lines += ['  check.return', '}', '', 'check.benchmark<@summary> @summary_latency']
(output / 'summary.loom').write_text('\n'.join(lines)+'\n')
config = json.loads((source / 'config.json').read_text())
config['jpeg']['output_partitions'] = partitions
(output / 'config.json').write_text(json.dumps(config,indent=2)+'\n')
tag = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['codec-jpeg-rebased-tools'])
library = root / 'entropy-partitioned.loombc'
command = [str(tag / 'loom/src/loom/tools/loom-link/loom-link'), str(output / 'summary.loom'),
           str(library), '--to=bc', '--output='+str(output / 'summary.loombc')]
subprocess.run(command,check=True)
files = {os.path.relpath(path,output): hashlib.sha256(path.read_bytes()).hexdigest()
         for path in paths.values()}
files.update({path.name: hashlib.sha256(path.read_bytes()).hexdigest()
              for path in output.iterdir() if path.is_file() and path.name != 'stage.json'})
stage = {**original, 'sizes': sizes, 'files': files, 'output_partitions': partitions,
         'library': {'path': library.name, 'sha256': hashlib.sha256(library.read_bytes()).hexdigest()},
         'link_command': command, 'source_fixture': key,
         'retention': 'Existing 293 MB full component expectation is shared; only bounded cursor/interval/status metadata is added in /tmp.',
         'sources': {name: hashlib.sha256((notes / name).read_bytes()).hexdigest()
                     for name in ('partition_batch_fixture.py','partition_fixture.py','partition_source.py')}}
(output / 'stage.json').write_text(json.dumps(stage,indent=2)+'\n')
(notes / 'device-partitioned-batch.json').write_text(json.dumps(stage,indent=2)+'\n')
print(json.dumps({'partitions': partitions, 'jobs': stage['jobs'],
                  'extra_metadata_bytes': sum(sizes[name]*4 for name in ('points','intervals','status'))}),flush=True)
