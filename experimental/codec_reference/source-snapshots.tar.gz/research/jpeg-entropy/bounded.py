"""Bounded checkpoint speculation with an explicitly anchored repair pass.

An independent candidate owns each fixed bit interval. It begins a bounded
number of intervals earlier in block-zero/DC state. Only its two endpoint
states, completed-block delta, and component DC sums survive speculation.
The anchor uses a summary only after matching its entire entry syntax state.
Every rejected interval is decoded once from the established state. A final
partitioned pass checks that these checkpoints reproduce every coefficient.

This is an algorithm/work-space experiment. The output planes and Python
objects are reference instrumentation, not a selected GPU storage layout.
"""

from array import array
from bisect import bisect_left
from dataclasses import dataclass

from sequential import Bits, InvalidJPEG, ZIGZAG, destination, divide_up, require, step


@dataclass(frozen=True)
class State:
    # Segment-relative next entropy bit.
    position: int
    # Completed blocks from this trajectory's starting point.
    blocks: int
    # Next block's zigzag coefficient index; zero means DC.
    coefficient: int
    # Per-component predictor values or trajectory-relative DC sums.
    predictors: tuple


@dataclass(frozen=True)
class Summary:
    # State at the first symbol boundary at/after the owned interval's start.
    first: State
    # State at the first symbol boundary at/after the owned interval's end.
    last: State


class Cursor:
    def __init__(self, segment, scan, components, state=None):
        # Trusted scan descriptor shared with the exact sequential parser.
        self.scan = scan
        # Bounded reader; speculative cursors know bytes, not the true end bit.
        self.reader = Bits(segment.data, state.position if state else 0)
        # Block count relative to the starting trajectory, or the segment anchor.
        self.blocks = state.blocks if state else 0
        # Coefficient phase immediately before the next Huffman symbol.
        self.coefficient = state.coefficient if state else 0
        # DC sums in frame-component order; meaningful absolutely only if anchored.
        self.predictors = list(state.predictors) if state else [0] * components
        # Complete syntax transitions, including EOB and ZRL.
        self.symbols = 0

    def state(self):
        return State(self.reader.position, self.blocks, self.coefficient,
                     tuple(self.predictors))

    def advance(self):
        block = self.scan.blocks[self.blocks % len(self.scan.blocks)]
        coefficient, index, value = step(self.reader, block, self.coefficient)
        if index == 0:
            self.predictors[block.component] += value
            value = self.predictors[block.component]
        self.symbols += 1
        self.coefficient = coefficient
        if coefficient == 0:
            self.blocks += 1
        return block, index, value


def speculate(segment, scan, components, chunk_bits, lookbehind, intervals):
    summaries = []
    symbols = 0
    consumed_bits = 0
    attempts = 0
    overlap_symbols = 0
    overlap_bits = 0
    failed = 0
    for interval in range(intervals):
        start = max(0, interval - lookbehind) * chunk_bits
        cursor = Cursor(segment, scan, components)
        cursor.reader.position = start
        first = None
        prefix_symbols = 0
        try:
            while cursor.reader.position < interval * chunk_bits:
                cursor.advance()
            first = cursor.state()
            prefix_symbols = cursor.reader.huffman_symbols
            while cursor.reader.position < (interval + 1) * chunk_bits:
                cursor.advance()
            summaries.append(Summary(first, cursor.state()))
        except InvalidJPEG:
            # Arbitrary starting bits can be invalid even in a valid JPEG.
            # An unavailable summary always sends its interval to the anchor.
            summaries.append(None)
            failed += 1
        consumed = cursor.reader.position - start
        # A complete syntax transition uses at most 16 Huffman + 11 value bits.
        assert consumed <= (lookbehind + 1) * chunk_bits + 26
        symbols += cursor.reader.huffman_symbols
        attempts += cursor.reader.huffman_attempts
        consumed_bits += consumed
        overlap_symbols += prefix_symbols if first else cursor.reader.huffman_symbols
        overlap_bits += first.position - start if first else consumed
    return summaries, {"speculative_symbols": symbols,
                       "speculative_symbol_attempts": attempts,
                       "speculative_bits": consumed_bits,
                       "speculative_overlap_symbols": overlap_symbols,
                       "speculative_overlap_bits": overlap_bits,
                       "invalid_speculations": failed,
                       "speculative_bit_bound": intervals * ((lookbehind + 1) * chunk_bits + 26)}


def establish(segment, scan, components, chunk_bits, summaries):
    cursor = Cursor(segment, scan, components)
    block_count = segment.mcu_count * len(scan.blocks)
    checkpoints = [cursor.state()]
    repair_bits = 0
    reused = 0
    repaired = 0
    for interval, summary in enumerate(summaries):
        if cursor.blocks == block_count:
            break
        before = cursor.reader.position
        same_entry = (summary is not None and summary.first.position == before and
                      summary.first.blocks % len(scan.blocks) == cursor.blocks % len(scan.blocks) and
                      summary.first.coefficient == cursor.coefficient)
        if same_entry:
            block_delta = summary.last.blocks - summary.first.blocks
            # The final interval belongs to the anchor, which knows the exact
            # MCU count and stops before pad bits even if they look like symbols.
            same_entry = cursor.blocks + block_delta < block_count
        if same_entry:
            cursor.reader.position = summary.last.position
            cursor.blocks += block_delta
            cursor.coefficient = summary.last.coefficient
            cursor.predictors = [current + end - start for current, start, end in zip(
                cursor.predictors, summary.first.predictors, summary.last.predictors, strict=True)]
            reused += 1
        else:
            while cursor.blocks < block_count and cursor.reader.position < (interval + 1) * chunk_bits:
                cursor.advance()
            repair_bits += cursor.reader.position - before
            repaired += 1
        if cursor.reader.position != before:
            checkpoints.append(cursor.state())
    require(cursor.blocks == block_count and cursor.coefficient == 0,
            "anchored partition did not finish exactly at the last block")
    end = cursor.reader.position
    padding = cursor.reader.limit - end
    require(0 <= padding < 8 and cursor.reader.take(padding) == (1 << padding) - 1,
            "partitioned decode has invalid trailing padding")
    return checkpoints, {"repair_symbols": cursor.symbols,
                         "repair_bits": repair_bits,
                         "reused_intervals": reused,
                         "repaired_intervals": repaired,
                         "entropy_bits": end}


def emit(frame, scan, segment, checkpoints, planes):
    symbols = 0
    for first, last in zip(checkpoints, checkpoints[1:]):
        cursor = Cursor(segment, scan, len(frame.components), first)
        while cursor.reader.position < last.position:
            mcu = segment.first_mcu + cursor.blocks // len(scan.blocks)
            block, index, value = cursor.advance()
            if index >= 0:
                if index == 0:
                    require(-1024 <= value <= 1023, "partitioned DC outside 8-bit DCT range")
                base = destination(frame, scan, mcu, block)
                if base is not None:
                    planes[block.component][base + ZIGZAG[index]] = value
        # This comparison includes predictors and absolute placement, beyond
        # the syntax-only equality that is sufficient for summary acceptance.
        assert cursor.state() == last
        symbols += cursor.symbols
    return symbols


def evaluate(frame, chunk_bytes, lookbehind, expected_planes, expected_traces, speculator=speculate):
    chunk_bits = chunk_bytes * 8
    components = len(frame.components)
    output = [array("h", [0]) * len(plane) for plane in expected_planes]
    totals = {key: 0 for key in (
        "intervals", "segments", "speculative_symbols", "speculative_bits",
        "speculative_symbol_attempts", "speculative_overlap_symbols", "speculative_overlap_bits",
        "invalid_speculations", "repair_symbols", "repair_bits", "reused_intervals",
        "repaired_intervals", "entropy_bits", "output_symbols", "unstuffed_bytes",
        "encoded_entropy_bytes", "speculative_bit_bound", "split_block_checkpoints",
        "prefix_resets", "budget_exhaustions")}
    maximum_repair_symbols = 0
    trace_index = 0
    for scan in frame.scans:
        for segment in scan.segments:
            # Partitioning sees only the original descriptor and bytes. The
            # oracle trace is consulted after execution, solely for checking.
            intervals = divide_up(len(segment.data), chunk_bytes)
            summaries, speculative = speculator(segment, scan, components, chunk_bits, lookbehind, intervals)
            checkpoints, anchored = establish(segment, scan, components, chunk_bits, summaries)
            output_symbols = emit(frame, scan, segment, checkpoints, output)
            trace = expected_traces[trace_index]
            trace_index += 1
            assert output_symbols == len(trace.positions) - 1
            assert anchored["entropy_bits"] == trace.positions[-1]
            for state in checkpoints:
                index = bisect_left(trace.positions, state.position)
                assert trace.positions[index] == state.position
                assert trace.blocks[index] == state.blocks
                assert trace.phases[index] == (state.blocks % len(scan.blocks)) * 64 + state.coefficient
            for values in (speculative, anchored):
                for key, value in values.items():
                    totals[key] += value
            totals["intervals"] += intervals
            totals["segments"] += 1
            totals["output_symbols"] += output_symbols
            totals["unstuffed_bytes"] += len(segment.data)
            totals["encoded_entropy_bytes"] += segment.source_bytes
            totals["split_block_checkpoints"] += sum(state.coefficient != 0 for state in checkpoints[1:-1])
            maximum_repair_symbols = max(maximum_repair_symbols, anchored["repair_symbols"])
    assert trace_index == len(expected_traces)
    assert all(actual == expected for actual, expected in zip(output, expected_planes, strict=True))
    assert totals["speculative_bits"] <= totals["speculative_bit_bound"]
    # Explicit possible packed device records, rounded to 16-byte alignment:
    # summary = two (bit, phase) pairs, block delta, DC sums, and flags;
    # established entry = bit, absolute block, phase, and DC predictors.
    summary_stride = divide_up(20 + components * 4, 16) * 16
    checkpoint_stride = divide_up(12 + components * 4, 16) * 16
    metadata = totals["intervals"] * (summary_stride + checkpoint_stride)
    return {"chunk_bytes": chunk_bytes, "lookbehind_intervals": lookbehind,
            **totals,
            "all_partition_coefficients_equal": True,
            "maximum_segment_serial_repair_symbols": maximum_repair_symbols,
            "repair_symbol_fraction": totals["repair_symbols"] / totals["output_symbols"],
            "total_symbol_work_ratio": (totals["speculative_symbols"] + totals["repair_symbols"] +
                                        totals["output_symbols"]) / totals["output_symbols"],
            "total_symbol_attempt_ratio": (totals["speculative_symbol_attempts"] + totals["repair_symbols"] +
                                           totals["output_symbols"]) / totals["output_symbols"],
            "summary_record_bytes": summary_stride,
            "checkpoint_record_bytes": checkpoint_stride,
            "checkpoint_metadata_bytes": metadata,
            "metadata_per_entropy_byte": metadata / totals["unstuffed_bytes"],
            "full_coefficient_bytes_if_materialized": sum(len(p) * p.itemsize for p in output),
            "entropy_addressing": "unstuffed copy; preprocessing reads/writes additional bytes",
            "scope": "counts and coefficient correctness, no GPU timing or production layout"}
