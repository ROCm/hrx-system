"""Stage a single bounded experiment and release exclusion when it finishes."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import tarfile

parser=argparse.ArgumentParser()
parser.add_argument('case')
parser.add_argument('--tag',default='codec-jpeg-resize-check')
parser.add_argument('--mode',choices=('check','bench','profile'),default='check')
parser.add_argument('--host',default='hrx-gorgon-3')
parser.add_argument('--capture',action='store_true')
parser.add_argument('--stage-only',action='store_true')
args=parser.parse_args()
notes=Path(__file__).resolve().parent
root=Path(json.loads((notes/'device-active.json').read_text())['directory'])/'persistent-resize'
case=root/args.case
remote=Path('/tmp/codec-jpeg-resize')
tag=Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])[args.tag])
files={'codec_command_probe':tag/'loom/src/loom/tooling/target/amdgpu/serve/codec_command_probe',
       'persistent_window.py':notes/'persistent_window.py','sharkbox_window.py':notes/'sharkbox_window.py'}
closure=json.loads((notes/'noxa-sharkbox-stage.json').read_text())['closure']['files']
for name,metadata in closure.items():
    path=Path('/tmp/codec-gfx1100-y90vg6rv/lib')/name
    assert hashlib.file_digest(path.open('rb'),'sha256').hexdigest()==metadata['sha256']
    files['lib/'+name]=path
for name in ('input.npy','output.npy','output-expected.npy','bindings.txt','regions.txt','config.json','summary.loombc','fixture.json'):
    files[args.case+'/'+name]=case/name
fixture=json.loads((case/'fixture.json').read_text())
manifest={'case':args.case,'mode':args.mode,'host':args.host,'tag':args.tag,
          'files':{name:{'bytes':path.stat().st_size,'sha256':hashlib.file_digest(path.open('rb'),'sha256').hexdigest()}
                   for name,path in files.items()}}
assert sum(r['bytes'] for r in manifest['files'].values())<512*1024*1024
subprocess.run(['ssh','-o','ConnectTimeout=8',args.host,shlex.join(['mkdir','-p',str(remote)])],check=True)
inventory='''import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]); expected=json.load(sys.stdin); changed=[]
for name,row in expected.items():
 p=root/name
 if not p.is_file() or p.stat().st_size!=row['bytes'] or hashlib.file_digest(p.open('rb'),'sha256').hexdigest()!=row['sha256']:changed.append(name)
print(json.dumps(changed))
'''
p=subprocess.run(['ssh',args.host,shlex.join(['python3','-B','-c',inventory,str(remote)])],
                 input=json.dumps(manifest['files']),text=True,capture_output=True,check=True)
changed=json.loads(p.stdout)
print(json.dumps({'phase':'stage','bytes':sum(files[name].stat().st_size for name in changed)}),flush=True)
p=subprocess.Popen(['ssh',args.host,shlex.join(['tar','-xzf','-','-C',str(remote)])],stdin=subprocess.PIPE)
with tarfile.open(fileobj=p.stdin,mode='w|gz',compresslevel=1) as archive:
    for name in changed:archive.add(files[name].resolve(),arcname=name,recursive=False)
p.stdin.close();assert p.wait()==0
script='''import json,os,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import persistent_window as harness
root=Path(__file__).resolve().parent
manifest=json.loads((root/'run-manifest.json').read_text())
assert os.environ['BENCHMARK_LOCK_LEASE_ID']
before=harness.state()
before['governor']=Path('/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor').read_text().strip()
before['loadavg']=Path('/proc/loadavg').read_text().strip()
before['gpu_power']={str(p):p.read_text().strip() for p in Path('/sys/class/drm').glob('card*/device/power_dpm_force_performance_level')}
assert harness.excluded(before),before
case=root/manifest['case']; (case/'actual').mkdir(exist_ok=True)
command=[str(root/'codec_command_probe'),'--jpeg_fixture='+str(case),'--jpeg_initial=.',
 '--jpeg_regions=regions.txt','--gtest_filter=JpegCommandTest.CompressedToRgb',
 '--jpeg_repetitions='+str(manifest['repetitions'])]
if manifest['capture']:command+=['--jpeg_capture='+str(case/'actual')]
if manifest['mode']=='check':command+=['--jpeg_access=true','--amdgpu_asan=true','--amdgpu_asan_report_policy=fail-device']
else:command+=['--jpeg_'+('benchmark' if manifest['mode']=='bench' else 'profile')+'=true']
if manifest['mode']!='check':assert before['governor']=='performance',before
started=time.monotonic(); result=harness.run_group(command,90)
record={'manifest':manifest,'before':before,'result':result,'after':harness.state(),
 'wall_seconds':time.monotonic()-started,'lease':os.environ['BENCHMARK_LOCK_LEASE_ID']}
(case/('result-'+manifest['mode']+'.json')).write_text(json.dumps(record,indent=2)+'\\n')
print(result['output'],flush=True)
assert not record['after']['live_kfd'],record['after']
raise SystemExit(result['returncode'] or bool(result.get('harness_timeout')))
'''
(root/'execute.py').write_text(script)
manifest.update(repetitions=fixture['repetitions'],capture=args.capture)
(root/'run-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
subprocess.run(['scp',str(root/'execute.py'),str(root/'run-manifest.json'),args.host+':'+str(remote)+'/'],check=True)
if args.stage_only:
    raise SystemExit(0)
command=['~/.dotfiles/bin/benchmark-lock','--label=codec-jpeg-resize-'+args.mode,'--','env','LD_LIBRARY_PATH='+str(remote/'lib'),
         'python3','-B',str(remote/'execute.py')]
remote_command='~/.dotfiles/bin/benchmark-lock '+shlex.join(command[1:])
log=notes/('resize-'+args.host+'-'+args.case+'-'+args.mode+'.log')
with log.open('w') as output:
    p=subprocess.run(['ssh',args.host,remote_command],stdout=output,stderr=subprocess.STDOUT)
print(log.read_text()[-12000:],flush=True)
subprocess.run(['scp',args.host+':'+str(remote/args.case/('result-'+args.mode+'.json')),
                str(notes/('resize-'+args.host+'-'+args.case+'-'+args.mode+'.json'))],check=True)
status=subprocess.run(['ssh',args.host,'~/.dotfiles/bin/benchmark-lock --status'],capture_output=True,text=True,check=True)
print(status.stdout,flush=True)
if args.capture:
    subprocess.run(['scp','-C','-r',args.host+':'+str(remote/args.case/'actual'),str(case)],check=True)
raise SystemExit(p.returncode)
