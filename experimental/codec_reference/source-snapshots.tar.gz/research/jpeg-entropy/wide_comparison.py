"""Compare cohort sizes while retaining 128 images per completion."""
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import shlex
import statistics
import subprocess
import sys
import tarfile


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def run(root):
    directory = root / "wide-comparison"
    manifest = json.loads((directory / "manifest.json").read_text())
    assert os.environ["BENCHMARK_LOCK_LEASE_ID"]
    assert not any(name.startswith("JSIMD_") for name in os.environ)
    for name, expected in manifest["files"].items():
        assert digest(root / name) == expected, name
    tree = ast.parse((root / "cpu-current/machine-state.py").read_text())
    node = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "state")
    namespace = dict(globals())
    exec(compile(ast.Module(body=[node], type_ignores=[]), "machine-state.py", "exec"), namespace)
    state = namespace["state"]
    before = state()
    assert before["governor"] == "performance" and before["gpu_policy"] == "high"
    assert int(before["personality"], 16) & 0x40000
    assert not before["kfd_processes"] and not before["drm"] and before["gpu_busy"] == 0
    images = [root / "mixed-cpu" / name for name in manifest["image_names"]]
    candidate_images = len(manifest["wide_fixture"]["images"])
    assert candidate_images in (32, 64, 128)
    record = {"manifest": manifest, "before": before, "rows": [],
              "scope": {"images_per_completion": 128, "normalization_images": 16,
                        "cpu_workers": 16, "cpu_affinity": "0-15", "warmups": 2, "samples": 9,
                        "cpu": "128 independent public IFAST decode jobs, disjoint RGB outputs, four immutable inputs shared.",
                        "gpu_serial": "Eight serial sixteen-image commands, sixteen output spans reused.",
                        "gpu_wide": f"{128 // candidate_images} serial {candidate_images}-image commands, disjoint output/scratch within each command; storage reused between commands; immutable sixteen-image input spans shared.",
                        "gpu_excludes": "Header parsing, JIT, allocation, upload, and verification download.",
                        "cpu_includes": "Task submission, codec setup/header/decode/destruction/internal allocations and final retirement; output allocation/checking excluded.",
                        "numerics": "Same independently qualified GPU pixels for both shapes; CPU policy retains separately measured numerical differences."}}
    output = directory / "comparison.json"
    output.write_text(json.dumps(record, indent=2) + "\n")
    for ordinal, policy in enumerate(("ifast", "serial", "wide", "serial", "wide", "ifast", "wide", "serial", "ifast")):
        if policy == "ifast":
            command = ["taskset", "-c", "0-15", str(root / "cpu-pipeline/jpeg_pipeline_ifast"),
                       "bench", "128", "16", "9", *(str(image) for image in images)]
        else:
            fixture = "mixed-wide" if policy == "wide" else "mixed-current"
            repetitions = 128 // candidate_images if policy == "wide" else 8
            command = [str(root / "codec_command_probe"), "--jpeg_fixture=" + str(root / fixture),
                       "--gtest_filter=JpegCommandTest.CompressedToRgb", "--jpeg_benchmark=true",
                       "--jpeg_repetitions=" + str(repetitions)]
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        stdout, stderr = process.communicate()
        result = subprocess.CompletedProcess(command, process.returncode, stdout, stderr)
        log = directory / (str(ordinal) + "-" + policy + ".log")
        log.write_text(result.stdout + result.stderr)
        assert result.returncode == 0, result.stdout + result.stderr
        rows = [json.loads(line) for line in result.stdout.splitlines() if line.startswith("{")]
        if policy == "ifast":
            row, = rows
            assert row["full_rgb_and_guards"] and row["batch"] == 128 and len(row["batch_ns"]) == 9
            assert row["rgb_bytes"] == manifest["cpu_rgb_bytes_per_completion"]
            duration = statistics.median(row["batch_ns"]) / 8
        else:
            measurement, = [row for row in rows if row.get("phase") == "measurement"]
            assert measurement["operations_per_submission"] == repetitions
            assert len(measurement["batch_ns"]) == 9
            assert len([row for row in rows if row.get("phase") == "exact"]) == 52
            commands = [row for row in rows if row.get("phase") == "command"]
            assert [row["commands"] for row in commands] == [16, 16 * repetitions]
            duration = statistics.median(measurement["batch_ns"]) / 8
        record["rows"].append({"policy": policy, "pid": process.pid, "command": command,
                               "median_16_image_ns": duration, "result": rows,
                               "children_peak_rss_kib": resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
                               "log_sha256": digest(log)})
        output.write_text(json.dumps(record, indent=2) + "\n")
        print(json.dumps({"policy": policy, "median_16_image_ms": duration / 1e6}), flush=True)
    record["after"] = state()
    record["after_processes"] = {}
    for process_id in record["after"]["kfd_processes"]:
        path = Path('/proc') / process_id / 'comm'
        try:
            record["after_processes"][process_id] = path.read_text().strip()
        except FileNotFoundError:
            record["after_processes"][process_id] = None
    output.write_text(json.dumps(record, indent=2) + "\n")
    # Completed children can outlive their process only as deferred KFD entries.
    assert not record["after"]["drm"]
    assert set(record["after"]["kfd_processes"]) <= {str(row["pid"]) for row in record["rows"]}
    assert all(value is None for value in record["after_processes"].values())


def stage(image_count):
    notes = Path(__file__).resolve().parent
    root = Path(json.loads((notes / "device-active.json").read_text())["directory"])
    previous = json.loads((notes / "gorgon4-mixed-comparison.json").read_text())["manifest"]
    wide = json.loads((notes / f"mixed-{image_count}-stage.json").read_text())
    assert len(wide["images"]) == image_count
    checked = json.loads((notes / f"gorgon4-mixed-{image_count}-access.json").read_text())
    assert checked["returncode"] == 0 and checked["stage"] == wide
    build = json.loads((notes / "wide-caller-build.json").read_text())
    capture = json.loads(subprocess.check_output(["bureau-bazel", "tag", "inspect", build["tag"], "--json"], text=True))
    assert build["restored"] and build["build_returncode"] == 0 and capture["capture"] == build["capture"]["capture"]
    tag = Path(json.loads(os.environ["BUREAU_TAG_ROOTS"])[build["tag"]])
    binary = tag / "loom/src/loom/tooling/target/amdgpu/serve/codec_command_probe"
    files = {"codec_command_probe": binary, "wide-comparison/compare.py": Path(__file__).resolve()}
    hashes = {name: expected for name, expected in previous["files"].items()
              if name.startswith(("mixed-current/", "mixed-cpu/")) or
              name in ("cpu-pipeline/jpeg_pipeline_ifast", "cpu-current/machine-state.py")}
    hashes.update({"mixed-wide/" + name: expected for name, expected in wide["files"].items()})
    hashes.update({name: digest(path) for name, path in files.items()})
    manifest = {"files": hashes, "wide_fixture": wide, "baseline_fixture": previous["fixture"],
                "cpu_build": previous["cpu_build"], "gpu_build": build,
                "image_names": previous["image_names"],
                "cpu_rgb_bytes_per_completion": previous["cpu_rgb_bytes_per_completion"]}
    directory = root / "wide-comparison"
    directory.mkdir(exist_ok=True)
    (directory / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    files["wide-comparison/manifest.json"] = directory / "manifest.json"
    assert sum(path.stat().st_size for path in files.values()) < 64 * 1024**2
    process = subprocess.Popen(["ssh", "hrx-gorgon-4", "tar -xf - -C " + shlex.quote(str(root))], stdin=subprocess.PIPE)
    with tarfile.open(fileobj=process.stdin, mode="w|", dereference=True) as archive:
        for name, path in files.items(): archive.add(path, arcname=name, recursive=False)
    process.stdin.close()
    assert process.wait() == 0
    command = ["/home/benvanik/.dotfiles/bin/benchmark-lock", f"--label=codec-jpeg-cohort-{image_count}", "--",
               "timeout", "--signal=INT", "--kill-after=10s", "300s", "env", "LD_LIBRARY_PATH=/opt/rocm/lib",
               "python3", "-B", str(directory / "compare.py"), "--remote", str(root)]
    log = notes / f"gorgon4-cohort-{image_count}-comparison.log"
    with log.open("w") as stream:
        result = subprocess.run(["ssh", "hrx-gorgon-4", shlex.join(command)], stdout=stream, stderr=subprocess.STDOUT)
    status = subprocess.run(["ssh", "hrx-gorgon-4", "~/.dotfiles/bin/benchmark-lock --status"], capture_output=True, text=True)
    receipt = {"command": command, "returncode": result.returncode, "broker_status_after": status.stdout + status.stderr,
               "broker_status_returncode": status.returncode, "manifest": manifest}
    (notes / f"gorgon4-cohort-{image_count}-comparison-run.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(log.read_text(), end="")
    print(status.stdout + status.stderr, end="", flush=True)
    assert result.returncode == 0 and status.returncode == 0
    output = subprocess.check_output(["ssh", "hrx-gorgon-4", "cat " + shlex.quote(str(directory / "comparison.json"))])
    (notes / f"gorgon4-cohort-{image_count}-comparison.json").write_bytes(output)


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "--remote": run(Path(sys.argv[2]))
    else:
        parser = argparse.ArgumentParser()
        parser.add_argument('--images', type=int, choices=(32, 64, 128), required=True)
        stage(parser.parse_args().images)
