"""Capture diagnostic polling counts with full exact RGB qualification."""
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import tarfile

from device_fixture import read_words

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
fixture = root / 'counted-batch16-1024'
files = {str(p.relative_to(root)): p for p in fixture.iterdir() if p.is_file()}
library = root / 'entropy-counted.loombc'
files[library.name] = library
assert sum(p.stat().st_size for p in files.values()) < 1024 * 1024
process = subprocess.Popen(['ssh', 'hrx-gorgon-4', 'tar -xf - -C ' + shlex.quote(str(root))], stdin=subprocess.PIPE)
with tarfile.open(fileobj=process.stdin, mode='w|') as archive:
    for name, path in files.items():
        archive.add(path, arcname=name, recursive=False)
process.stdin.close()
assert process.wait() == 0
script = '''import hashlib,json,pathlib,subprocess,sys
root=pathlib.Path(sys.argv[1]);fixture=root/'counted-batch16-1024'
stage=json.loads((fixture/'stage.json').read_text())
for name,digest in stage['files'].items():
 assert hashlib.sha256((fixture/name).read_bytes()).hexdigest()==digest,name
assert hashlib.sha256((root/'entropy-counted.loombc').read_bytes()).hexdigest()==stage['library']['sha256']
runner=root/'iree-test-loom-unsigned'
assert hashlib.sha256(runner.read_bytes()).hexdigest()=='5e267978d7e937b1009f64a2e005913a4cc36c002b1f24eef44776cc4683a632'
for sanitizer in ('access','none'):
 output=root/('counted-asan' if sanitizer=='access' else 'counted-actual');output.mkdir(exist_ok=True)
 command=[str(runner),str(fixture/'summary.loombc'),'--config-file='+str(fixture/'config.json'),'--device=amdgpu','--target=amdgpu:gfx1151','--file-output-root='+str(output)]
 if sanitizer=='access':command.append('--sanitizer=access')
 subprocess.run(command,check=True)
'''
command = ['/home/benvanik/.dotfiles/bin/benchmark-lock', '--label=codec-jpeg-overlap-statistics',
           '--', 'env', 'LD_LIBRARY_PATH=/opt/rocm/lib', 'python3', '-B', '-c', script, str(root)]
with (notes / 'gorgon4-overlap-statistics.log').open('w') as stream:
    result = subprocess.run(['ssh', 'hrx-gorgon-4', shlex.join(command)], stdout=stream, stderr=subprocess.STDOUT)
status = subprocess.run(['ssh', 'hrx-gorgon-4', '/home/benvanik/.dotfiles/bin/benchmark-lock --status'], capture_output=True, text=True)
record = {'command': command, 'returncode': result.returncode, 'broker_status_after': status.stdout + status.stderr,
          'staged_files': {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in files.items()}}
(notes / 'gorgon4-overlap-statistics-lease.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k:v for k,v in record.items() if k != 'staged_files'}), flush=True)
if result.returncode:
    print((notes / 'gorgon4-overlap-statistics.log').read_text()[-4000:])
    raise SystemExit(result.returncode)
destination = notes / 'gorgon4-overlap-statistics.npy'
subprocess.run(['scp', 'hrx-gorgon-4:' + str(root / 'counted-actual/overlap-statistics.npy'), str(destination)], check=True)
words = read_words(destination)
assert len(words) == 512 * 16 * 4
assert all(words[i + 1] == words[i + 3] for i in range(0, len(words), 4))
assert all(value != 0xffffffff for value in words)
slots = sum(words[1::4])
result = {'workgroups': len(words) // 4, 'data_publications': slots,
          'producer_observations': sum(words[0::4]), 'consumer_observations': sum(words[2::4]),
          'producer_failed_observations': sum(words[0::4]) - slots - len(words) // 4,
          'consumer_failed_observations': sum(words[2::4]) - slots - len(words) // 4,
          'scope': 'Instrumented optimized full batch following access-sanitized qualification; counters perturb scheduling and are not timing evidence.',
          'sha256': hashlib.sha256(destination.read_bytes()).hexdigest()}
(notes / 'gorgon4-overlap-statistics.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
