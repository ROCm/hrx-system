"""Connect certified GPU intervals to full block-planar sample assertions."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import struct

from device_fixture import input_bytes, read_words, write_words
from integer_idct import reconstruct
from sequential import ZIGZAG, decode, divide_up, parse

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
parser = argparse.ArgumentParser()
parser.add_argument('--family', choices=('small', 'large'), default='small')
arguments = parser.parse_args()
source = root / ('parallel-' + arguments.family)
output = root / ('output-' + arguments.family)
output.mkdir(exist_ok=True)
pixel_directory = root / 'output-pixels'
pixel_directory.mkdir(exist_ok=True)
file_pattern = re.compile(r'%([a-z_]+) = check.file.read.npy path\("([^"]+)"\) : tensor<(\d+)xi32>')
frames = {}
pixel_files = {}
all_paths = set()
cases = []


def write_pixels(path, pixels):
    assert len(pixels) % 4 == 0
    header = repr({'descr': '<i4', 'fortran_order': False, 'shape': (len(pixels) // 4,)}).encode()
    header += b' ' * ((64 - ((10 + len(header) + 1) % 64)) % 64) + b'\n'
    with path.open('wb') as stream:
        stream.write(b'\x93NUMPY\x01\x00' + struct.pack('<H', len(header)) + header)
        stream.write(pixels)


for case in json.loads((source / 'fixtures.json').read_text())['cases']:
    name, key = case['name'], case['key']
    if name not in frames:
        data = input_bytes(name)
        assert hashlib.sha256(data).hexdigest() == case['input_sha256']
        frame = parse(data)
        planes = None
        if arguments.family == 'small':
            planes, unused = decode(frame)
        frames[name] = (frame, planes)
    frame, planes = frames[name]
    scan = frame.scans[case['scan']]
    components = len(frame.components)
    offsets = []
    total_words = 0
    for component in frame.components:
        offsets.append(total_words)
        total_words += component.block_width * component.block_height * 16
    pixel_key = (name, case['scan'])
    if pixel_key not in pixel_files:
        # Other components remain untouched in a separate-scan invocation.
        pixels = bytearray(b'\x11\x00\x00\x00') * total_words
        present = {block.component for block in scan.blocks}
        for component_index in present:
            component = frame.components[component_index]
            base = offsets[component_index] * 4
            if arguments.family == 'small':
                plane = planes[component_index]
                for block in range(component.block_width * component.block_height):
                    pixels[base + block * 64:base + (block + 1) * 64] = reconstruct(
                        plane[block * 64:(block + 1) * 64], component.quantization)
            else:
                width = divide_up(frame.width * component.horizontal,
                                  max(value.horizontal for value in frame.components))
                height = divide_up(frame.height * component.vertical,
                                   max(value.vertical for value in frame.components))
                assert width % 8 == height % 8 == 0
                path = root / 'public-planes' / (name + f'.m0.c{component_index}.raw')
                plane = path.read_bytes()
                reference = json.loads((notes / 'output-public-planes.json').read_text())['files'][path.name]
                assert len(plane) == width * height and hashlib.sha256(plane).hexdigest() == reference['sha256']
                for block_row in range(component.block_height):
                    for block_column in range(component.block_width):
                        target = base + (block_row * component.block_width + block_column) * 64
                        for row in range(8):
                            offset = (block_row * 8 + row) * width + block_column * 8
                            pixels[target + row * 8:target + row * 8 + 8] = plane[offset:offset + 8]
        pixel_path = pixel_directory / (name + f'-scan{case["scan"]}.npy')
        write_pixels(pixel_path, pixels)
        pixel_files[pixel_key] = pixel_path
    pixel_path = pixel_files[pixel_key]
    text = (source / (key + '.loom')).read_text()
    sizes = {}
    paths = {}
    for match in file_pattern.finditer(text):
        variable, relative, count = match.groups()
        sizes[variable] = int(count)
        paths[variable] = (source / relative).resolve()
    segments = list(read_words(paths['segments']))
    for segment_index, segment in enumerate(scan.segments):
        segments[segment_index * 8 + 6] = segment.first_mcu
    write_words(output / (key + '-segments.npy'), segments)
    paths['segments'] = output / (key + '-segments.npy')
    geometry = []
    for block in scan.blocks:
        component = frame.components[block.component]
        geometry.extend((offsets[block.component], component.block_width, component.block_height,
                         component.horizontal if scan.interleaved else 1,
                         component.vertical if scan.interleaved else 1,
                         block.column, block.row, 0))
    values = {'geometry': geometry, 'quantization': [value for component in frame.components for value in component.quantization],
              'zigzag': list(ZIGZAG), 'status': [0] * (case['jobs'] * 2 + case['segments'])}
    for variable, value in values.items():
        path = output / (key + '-' + variable + '.npy')
        write_words(path, value)
        paths[variable] = path
        sizes[variable] = len(value)
    paths['pixels'] = pixel_path
    sizes['pixels'] = total_words
    text = file_pattern.sub(lambda match: '%' + match[1] + ' = check.file.read.npy path("' +
        os.path.relpath(paths[match[1]], output) + '") : tensor<' + match[3] + 'xi32>', text)
    names = ('entropy', 'segments', 'tables', 'blocks', 'intervals_output', 'geometry',
             'quantization', 'zigzag', 'pixels_output', 'status_output')
    declaration = 'kernel.decl @jpeg_reconstruct() launch(' + ', '.join('%' + name + ': buffer' for name in names) + ')\n'
    text = declaration + text
    lines = [f'  %{name} = check.file.read.npy path("{os.path.relpath(paths[name], output)}") : tensor<{sizes[name]}xi32>'
             for name in (*values, 'pixels')]
    lines += [f'  %{name}_output = check.generate.fill value(17) : tensor<{sizes[name]}xi32>'
              for name in ('pixels', 'status')]
    position = text.index('  kernel.launch @jpeg_speculate')
    text = text[:position] + '\n'.join(lines) + '\n' + text[position:]
    types = ', '.join(f'tensor<{sizes[name.removesuffix("_output")]}xi32>' for name in names)
    line = '  kernel.launch @jpeg_reconstruct(' + ', '.join('%' + name for name in names) + f') : ({types})\n'
    position = text.index('  check.expect.bitwise')
    text = text[:position] + line + text[position:]
    lines = [f'  check.expect.bitwise actual(%{name}_output) expected(%{name}) : tensor<{sizes[name]}xi32>'
             for name in ('pixels', 'status')]
    text = text.replace('  check.return', '\n'.join(lines) + '\n  check.return')
    (output / (key + '.loom')).write_text(text)
    config = json.loads((source / (key + '.json')).read_text())
    config['jpeg']['mcu_width'] = scan.mcu_width
    (output / (key + '.json')).write_text(json.dumps(config, indent=2) + '\n')
    all_paths.update(paths.values())
    cases.append({**case, 'sizes': sizes, 'pixel_reference': ('public JDCT_ISLOW planes' if arguments.family == 'large'
                  else 'qualified independent integer model, including unused edge samples')})
    print(json.dumps({'case': key, 'pixel_bytes': total_words * 4}), flush=True)
receipt = {'cases': cases, 'sources': {name: hashlib.sha256((notes / name).read_bytes()).hexdigest()
    for name in ('device_output_fixture.py', 'integer_idct.py', 'device_entropy_cursor.h', 'device_reconstruct.cxx')}}
(output / 'fixtures.json').write_text(json.dumps(receipt, indent=2) + '\n')
all_paths.update(path for path in output.iterdir() if path.is_file())
files = {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest() for path in all_paths}
(root / (output.name + '-stage.json')).write_text(json.dumps({'files': files}, indent=2) + '\n')
(notes / (output.name + '-fixtures.json')).write_text(json.dumps(receipt, indent=2) + '\n')
