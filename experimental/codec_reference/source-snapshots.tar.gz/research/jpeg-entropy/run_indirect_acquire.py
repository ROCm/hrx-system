import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess

notes = Path(__file__).resolve().parent
roots = json.loads(os.environ['BUREAU_TAG_ROOTS'])
host = 'hrx-gorgon-4'
relative = Path('runtime/src/iree/hal/drivers/amdgpu/indirect_dispatch_test')
binaries = {kind: Path(roots['codec-indirect-' + kind]) / relative for kind in ['baseline', 'candidate']}
hashes = {kind: hashlib.file_digest(binary.open('rb'), 'sha256').hexdigest() for kind, binary in binaries.items()}
remote = subprocess.check_output(['ssh', host, 'mktemp -d /tmp/codec-indirect-acquire-XXXXXX'], text=True).strip()
receipt = {'host': host, 'directory': remote, 'hashes': hashes, 'retired': False}
(notes / 'gorgon4-indirect-acquire-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
for kind, binary in binaries.items():
    subprocess.run(['scp', str(binary), f'{host}:{remote}/{kind}'], check=True)
runner = '''import hashlib, json, subprocess
from pathlib import Path
root = Path(%r)
hashes = %r
results = {}
for name, expected in hashes.items():
    assert hashlib.file_digest((root / name).open('rb'), 'sha256').hexdigest() == expected
for name in hashes:
    print('CONTROL ' + name, flush=True)
    results[name] = subprocess.run([str(root / name)]).returncode
print('RESULT ' + json.dumps(results), flush=True)
raise SystemExit(results['candidate'])
''' % (remote, hashes)
local_runner = notes / 'indirect_acquire_runner.py'
local_runner.write_text(runner)
subprocess.run(['scp', str(local_runner), f'{host}:{remote}/run.py'], check=True)
command = ['ssh', host, shlex.join(['/home/benvanik/.dotfiles/bin/benchmark-lock', '--label=codec-indirect-acquire', '--', 'env', 'LD_LIBRARY_PATH=/opt/rocm/lib', 'python3', '-B', remote + '/run.py'])]
with (notes / 'gorgon4-indirect-acquire.log').open('w') as log:
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    for line in process.stdout:
        log.write(line)
        log.flush()
        print(line, end='', flush=True)
    receipt['returncode'] = process.wait()
receipt['command'] = command
status = subprocess.run(['ssh', host, '/home/benvanik/.dotfiles/bin/benchmark-lock --status'], capture_output=True, text=True)
receipt['broker_status_after'] = status.stdout + status.stderr
receipt['broker_status_returncode'] = status.returncode
(notes / 'gorgon4-indirect-acquire-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
assert status.returncode == 0 and 'idle' in receipt['broker_status_after']
retire = '''import hashlib
from pathlib import Path
root = Path(%r)
for name, expected in %r.items():
    assert hashlib.file_digest((root / name).open('rb'), 'sha256').hexdigest() == expected
for name in %r:
    (root / name).unlink()
(root / 'run.py').unlink()
root.rmdir()
''' % (remote, hashes, list(hashes))
subprocess.run(['ssh', host, 'python3 -B -'], input=retire, text=True, check=True)
receipt['retired'] = True
(notes / 'gorgon4-indirect-acquire-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
raise SystemExit(receipt['returncode'])
