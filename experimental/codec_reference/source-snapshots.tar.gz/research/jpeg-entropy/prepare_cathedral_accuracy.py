"""Reuse the qualified serving deployment with the second GPU-checked image."""
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
directory = root / 'vision-accuracy'
tag = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['codec-jpeg-vision-asan'])
reference = tag / 'experimental/codec_reference/research/jpeg-entropy/float_reference'
server = tag / 'loom/src/loom/tools/loom-serve/loom-serve'
stage = json.loads((notes / 'float-corpus-006mp-cathedral.jpg.r0.jpg-stage.json').read_text())
old = json.loads((notes / 'model-accuracy-stage.json').read_text())
assert hashlib.file_digest(reference.open('rb'), 'sha256').hexdigest() == stage['reference_binary_sha256']
assert hashlib.file_digest(server.open('rb'), 'sha256').hexdigest() == old['files']['loom-serve']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == old['codec_commit']
original = notes.parent / 'jpeg-baseline/inputs/006mp-cathedral.jpg.r0.jpg'
assert hashlib.file_digest(original.open('rb'), 'sha256').hexdigest() == stage['input_sha256']

verify = '''
import hashlib, json
from pathlib import Path
p = Path(%r)
m = json.loads((p / 'manifest.json').read_text())
assert m == %r
for name, expected in m['files'].items():
    assert hashlib.file_digest((p / name).open('rb'), 'sha256').hexdigest() == expected, name
assert not any((p / 'observations').glob('*.prepared'))
assert not any((p / 'resize-observations').glob('*.npy'))
print('Bus inputs/source/server verified; completed observation arrays retired.', flush=True)
''' % (str(directory), old)
subprocess.run(['ssh', 'hrx-gorgon-3', 'python3 -B -'], input=verify, text=True, check=True)
subprocess.run(['ssh', 'hrx-gorgon-3', shlex.join(['mkdir', '-p', str(directory / 'reference-current')])], check=True)
for source, destination in [(reference, 'reference-current/float-reference'),
                            (original, 'reference-current/input.jpg'),
                            (notes / 'model_accuracy.py', 'model_accuracy.py'),
                            (notes / 'compare_projector_features.py', 'compare_projector_features.py'),
                            (notes / 'observe_model_resize.py', 'observe_model_resize.py')]:
    subprocess.run(['scp', str(source), 'hrx-gorgon-3:' + str(directory / destination)], check=True)

configuration = {'directory': str(directory), 'stage': stage,
                 'prompt': 'What kind of place is shown, and what are two visible architectural details? Answer in one short sentence.'}
code = '''
import hashlib, json, shutil, subprocess
from pathlib import Path
configuration = CONFIGURATION
directory = Path(configuration['directory'])
references = directory / 'reference-current'
stage = configuration['stage']
tool = references / 'float-reference'
assert hashlib.file_digest(tool.open('rb'), 'sha256').hexdigest() == stage['reference_binary_sha256']
original = references / 'input.jpg'
assert hashlib.file_digest(original.open('rb'), 'sha256').hexdigest() == stage['input_sha256']
result = subprocess.run([str(tool), str(original), str(references)], capture_output=True, text=True)
(directory / 'cathedral-reference.log').write_text(result.stdout + result.stderr)
assert result.returncode == 0, result.stdout + result.stderr
numerical = [json.loads(line) for line in result.stdout.splitlines()]
assert numerical == stage['numerical'], numerical
for name, expected in stage['reference_sha256'].items():
    assert hashlib.file_digest((references / name).open('rb'), 'sha256').hexdigest() == expected, name
width, height = numerical[-1]['width'], numerical[-1]['height']
assert (width, height) == (2000, 3008)
header = f'P7\\nWIDTH {width}\\nHEIGHT {height}\\nDEPTH 3\\nMAXVAL 255\\nTUPLTYPE RGB\\nENDHDR\\n'.encode()
inputs = {}
for name, filename in [('loom-float32', 'rgb.raw'), ('islow', 'islow.rgb'),
                       ('cosine', 'cosine.rgb'), ('float', 'float.rgb'), ('ifast', 'ifast.rgb')]:
    pixels = (references / filename).read_bytes()
    assert len(pixels) == width * height * 3
    path = directory / 'inputs' / (name + '.pam')
    path.write_bytes(header + pixels)
    assert path.read_bytes()[len(header):] == pixels
    inputs[name] = {'file': str(path.relative_to(directory)), 'mime': 'image/x-portable-arbitrarymap',
                    'rgb_sha256': hashlib.sha256(pixels).hexdigest()}
shutil.copyfile(original, directory / 'inputs/original.jpg')
inputs['jpeg'] = {'file': 'inputs/original.jpg', 'mime': 'image/jpeg'}
manifest = json.loads((directory / 'manifest.json').read_text())
manifest.update(inputs=inputs, witness='cathedral', prompt=configuration['prompt'],
                image_geometry=[width, height], target_geometry=[832, 1248],
                reference_rows=numerical, reference_binary_sha256=stage['reference_binary_sha256'])
manifest['reference_source_sha256'] = REFERENCE_SOURCE
for name in [item['file'] for item in inputs.values()] + ['model_accuracy.py', 'compare_projector_features.py', 'observe_model_resize.py']:
    manifest['files'][name] = hashlib.file_digest((directory / name).open('rb'), 'sha256').hexdigest()
(directory / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\\n')
retired = []
for name, expected in stage['reference_sha256'].items():
    path = references / name
    assert hashlib.file_digest(path.open('rb'), 'sha256').hexdigest() == expected
    retired.append({'name': name, 'bytes': path.stat().st_size, 'sha256': expected})
    path.unlink()
(directory / 'cathedral-reference-retirement.json').write_text(json.dumps(retired, indent=2) + '\\n')
total = sum(path.stat().st_size for path in directory.rglob('*') if path.is_file())
assert total + 470000000 < 1024**3, total
print(json.dumps({'reference_hashes_match_gpu_qualified_inputs': True,
                  'source_geometry': [width, height], 'target_geometry': [832,1248],
                  'retired_reference_bytes': sum(row['bytes'] for row in retired),
                  'active_bytes': total}), flush=True)
'''.replace('CONFIGURATION', repr(configuration)).replace(
        'REFERENCE_SOURCE', repr(hashlib.sha256((notes / 'float_reference.cc').read_bytes()).hexdigest()))
subprocess.run(['ssh', 'hrx-gorgon-3', 'python3 -B -'], input=code, text=True, check=True)
for name, destination in [('manifest.json', 'model-accuracy-cathedral-stage.json'),
                           ('cathedral-reference.log', 'cathedral-model-reference.log'),
                           ('cathedral-reference-retirement.json', 'cathedral-reference-retirement.json')]:
    subprocess.run(['scp', 'hrx-gorgon-3:' + str(directory / name), str(notes / destination)], check=True)
