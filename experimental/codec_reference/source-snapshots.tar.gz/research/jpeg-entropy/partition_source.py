"""Retain fine cursor states without reducing the proven synchronization span."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

notes=Path(__file__).resolve().parent
root=Path(json.loads((notes/'device-active.json').read_text())['directory'])
configuration='''[[loom::config("jpeg.output_partitions"), loom::where(loom::predicate::range(2u, 8u))]]
extern const unsigned output_partitions;
'''
source=(notes/'device_entropy_tables.cxx').read_text()
source=source.replace('unsigned* summaries) {','unsigned* summaries, unsigned* points) {')
needle='  while (cursor.position < last_boundary && cursor.error == 0) {'
position=source.index(needle)
extra='''  unsigned point_stride = (3 + component_count + 3) & ~3u;
  unsigned* job_points = points + job * (output_partitions - 1) * point_stride;
  for (unsigned partition = 1; partition < output_partitions; ++partition) {
    unsigned boundary = first_boundary + chunk_bits * partition / output_partitions;
    while (cursor.position < boundary && cursor.error == 0) {
      cursor = advance(words, tables, blocks, limit, cursor);
    }
    unsigned* point = job_points + (partition - 1) * point_stride;
    [[loom::unroll]]
    for (unsigned field = 0; field < point_stride; ++field) point[field] = 0;
    point[0] = cursor.position;
    point[1] = cursor.blocks - first_blocks;
    point[2] = cursor.block_index * 64 + cursor.coefficient;
    [[loom::unroll]]
    for (unsigned component = 0; component < component_count; ++component) {
      point[3 + component] = cursor.predictors[component] - first_predictors[component];
    }
  }
'''
source=source[:position]+extra+source[position:]
position=source.rindex('\n}')
source=source[:position]+''' else {
    // Invalid speculative summaries never publish partial subdivision facts.
    for (unsigned partition = 0; partition + 1 < output_partitions; ++partition) {
      [[loom::unroll]]
      for (unsigned field = 0; field < point_stride; ++field) {
        job_points[partition * point_stride + field] = 0;
      }
    }
  }'''+source[position:]
(notes/'device_entropy_partitioned.cxx').write_text(source)
source=(notes/'device_certify.cxx').read_text()
source=source.replace('(2 * first_job + segment)', '((output_partitions + 1) * first_job + segment)')
source=source.replace('2 * count * interval_stride','(output_partitions + 1) * count * interval_stride')
source=source.replace('(count + source) * interval_stride','(output_partitions * count + source) * interval_stride')
old='''        output[index * interval_stride + field] = 0;
        output[(count + index) * interval_stride + field] = 0;'''
new='''        for (unsigned partition = 0; partition <= output_partitions; ++partition) {
          output[(partition * count + index) * interval_stride + field] = 0;
        }'''
assert old in source
source=source.replace(old,new)
source=source.replace('const unsigned* suffixes, const unsigned* ranges,\n                    unsigned* intervals)', 'const unsigned* suffixes, const unsigned* ranges,\n                    const unsigned* points, unsigned* intervals)')
old='''        write_interval(output + index * interval_stride,
                       summary[0], summary[2], blocks, summary[1], dc);'''
new='''        unsigned point_stride = (3 + component_count + 3) & ~3u;
        const unsigned* job_points = points + (first_job + index) *
                                     (output_partitions - 1) * point_stride;
        unsigned position = summary[0];
        unsigned phase = summary[1];
        unsigned absolute_blocks = blocks;
        Sums absolute_dc = dc;
        for (unsigned partition = 0; partition + 1 < output_partitions; ++partition) {
          const unsigned* point = job_points + partition * point_stride;
          write_interval(output + (index * output_partitions + partition) * interval_stride,
                         position, point[0], absolute_blocks, phase, absolute_dc);
          position = point[0];
          absolute_blocks = blocks + point[1];
          phase = point[2];
          [[loom::unroll]]
          for (unsigned component = 0; component < component_count; ++component) {
            absolute_dc[component] = dc[component] + point[3 + component];
          }
        }
        write_interval(output + (index * output_partitions + output_partitions - 1) * interval_stride,
                       position, summary[2], absolute_blocks, phase, absolute_dc);'''
assert old in source
source=source.replace(old,new)
(notes/'device_certify_partitioned.cxx').write_text(source)
source=(notes/'device_reconstruct_clamp_mask.cxx').read_text()
source=source.replace('chunks * 2 + certification_segments','chunks * (output_partitions + 1) + certification_segments')
source=source.replace('descriptor[2] * 2 + segment','descriptor[2] * (output_partitions + 1) + segment')
source=source.replace('count * 2','count * (output_partitions + 1)')
(notes/'device_reconstruct_partitioned.cxx').write_text(source)
pipeline='#include "device_entropy_cursor_fused.h"\n'+configuration
for name in ('device_entropy_partitioned.cxx','device_bridge.cxx','device_certify_partitioned.cxx','device_reconstruct_partitioned.cxx'):
    pipeline+='\n'+(notes/name).read_text().replace('#include "device_entropy_cursor.h"','')+'\n'
(notes/'device_partitioned_pipeline.cxx').write_text(pipeline)
config=json.loads((root/'output-config.json').read_text());config['jpeg']['output_partitions']=4
(root/'partitioned-config.json').write_text(json.dumps(config,indent=2)+'\n')
tags=json.loads(os.environ['BUREAU_TAG_ROOTS'])
base=Path(tags['codec-jpeg-rebased-tools'])/'loom/src/loom/tools'
native=Path(tags['codec-jpeg-unsigned-opt'])/'loom/src/loom/tools'
commands=[[str(base/'loom-import-cxx/loom-import-cxx'),str(notes/'device_partitioned_pipeline.cxx'),'--output='+str(root/'entropy-partitioned.loom')],
          [str(base/'loom-link/loom-link'),str(root/'entropy-partitioned.loom'),'--to=bc','--output='+str(root/'entropy-partitioned.loombc')]]
for command in commands:subprocess.run(command,check=True)
rows=[]
for entry in ('jpeg_speculate','jpeg_index','jpeg_certify','jpeg_intervals','jpeg_reconstruct'):
    report=root/(entry+'-partitioned-report.json')
    command=[str(native/'loom-compile/loom-compile'),str(root/'entropy-partitioned.loombc'),'--root='+entry,'--target=amdgpu:gfx1151','--config-file='+str(root/'partitioned-config.json'),'--output='+str(root/(entry+'-partitioned.hsaco')),'--compile-report=details','--compile-report-output='+str(report)]
    subprocess.run(command,check=True);commands.append(command)
    d=json.loads(report.read_text())['entries']['rows'][0]
    row={'entry':entry,'metrics':{k:d[k] for k in ('instruction_count','code_byte_count','private_memory_bytes','local_memory_bytes','target_resources')}}
    rows.append(row);print(json.dumps(row),flush=True)
record={'commands':commands,'rows':rows,'library_sha256':hashlib.sha256((root/'entropy-partitioned.loombc').read_bytes()).hexdigest(),
        'sources':{name:hashlib.sha256((notes/name).read_bytes()).hexdigest() for name in ('partition_source.py','device_entropy_cursor_fused.h','device_entropy_partitioned.cxx','device_bridge.cxx','device_certify_partitioned.cxx','device_reconstruct_partitioned.cxx','device_partitioned_pipeline.cxx')}}
(notes/'device-partitioned-code.json').write_text(json.dumps(record,indent=2)+'\n')
