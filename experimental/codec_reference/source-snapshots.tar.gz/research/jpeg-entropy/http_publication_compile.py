"""Compile both five-word-plan controls before native HTTP execution."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

notes = Path(__file__).resolve().parent
directory = Path(json.loads((notes / "http-publication-source.json").read_text())["directory"])
tools = Path(json.loads(os.environ["BUREAU_TAG_ROOTS"])["codec-jpeg-rebased-tools"]) / "loom/src/loom/tools"
record = {"source_sha256": hashlib.sha256((notes / "http-publication-source.json").read_bytes()).hexdigest(), "commands": []}
for name, deployment in (("candidate", "deployment.json"), ("control", "control-deployment.json")):
    document = json.loads((directory / deployment).read_text())
    model = Path(document["base_directory"])
    inputs = [str(model / "vision_prepare.loom"), str(model / "vision_control.loom")]
    inputs += [str((model / path).resolve()) for path in document["definition"]["sources"]]
    commands = [
        [str(tools / "loom-link/loom-link"), *inputs, "--to=bc", "--output=" + str(directory / (name + ".loombc"))],
        [str(tools / "loom-compile/loom-compile"), str(directory / (name + ".loombc")), "--target=vm:core",
         "--root=prepare_request", "--root=prepare_batch", "--root=run", "--output=" + str(directory / (name + ".vm"))],
    ]
    for command in commands:
        result = subprocess.run(command, capture_output=True, text=True)
        record["commands"].append({"command": command, "returncode": result.returncode, "output": result.stdout + result.stderr})
        (notes / "http-publication-compile.json").write_text(json.dumps(record, indent=2) + "\n")
        print(name, result.returncode, result.stdout + result.stderr, flush=True)
        if result.returncode:
            raise SystemExit(result.returncode)
