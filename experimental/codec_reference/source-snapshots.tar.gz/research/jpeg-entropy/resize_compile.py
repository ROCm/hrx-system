"""Compile and account for the exact experimental consumer before native use."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

parser=argparse.ArgumentParser()
parser.add_argument('case')
parser.add_argument('--target',default='gfx1151')
parser.add_argument('--resources',action='store_true')
parser.add_argument('--source',default='source')
args=parser.parse_args()
notes=Path(__file__).resolve().parent
root=Path(json.loads((notes/'device-active.json').read_text())['directory'])/'persistent-resize'
source=root/args.source;case=root/args.case
tools=Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['codec-jpeg-rebased-tools'])/'loom/src/loom/tools'
record={'case':args.case,'target':args.target,'source_sha256':hashlib.sha256((source/'resize.cxx').read_bytes()).hexdigest(),
        'compiler_sha256':hashlib.file_digest((tools/'loom-compile/loom-compile').open('rb'),'sha256').hexdigest(),
        'commands':[],'resources':{}}
receipt=notes/('resize-'+args.case+'-compile.json')
def run(name,arguments):
    command=[str(tools/name/name)]+arguments
    p=subprocess.run(command,capture_output=True,text=True)
    record['commands'].append({'command':command,'returncode':p.returncode,'output':p.stdout+p.stderr})
    receipt.write_text(json.dumps(record,indent=2)+'\n')
    print(name,p.returncode,p.stdout+p.stderr,flush=True)
    if p.returncode:raise SystemExit(p.returncode)
run('loom-import-cxx',[str(source/'resize.cxx'),'--output='+str(source/'resize.loom')])
run('loom-link',[str(source/'resize.loom'),str(case/'command.loom'),'--to=bc','--output='+str(case/'summary.loombc')])
if args.resources:
    for entry in ('jpeg_resize_init','jpeg_resize_stream','jpeg_resize_publish'):
        report=source/(entry+'.report.json')
        run('loom-compile',[str(case/'summary.loombc'),'--root='+entry,'--target=amdgpu:'+args.target,
            '--config-file='+str(case/'config.json'),'--output='+str(source/(entry+'.hsaco')),
            '--compile-report=details','--compile-report-output='+str(report)])
        value=json.loads(report.read_text())['entries']['rows'][0]
        record['resources'][entry]=value
        print(entry,json.dumps({k:value[k] for k in ('instruction_count','code_byte_count','local_memory_bytes','private_memory_bytes','target_resources')}),flush=True)
        receipt.write_text(json.dumps(record,indent=2)+'\n')
        # Detailed reports are reproducible cache payload; the exact entry and
        # native object remain pinned by this experiment's source/configuration.
        report.unlink()
record['module_sha256']=hashlib.sha256((case/'summary.loombc').read_bytes()).hexdigest()
receipt.write_text(json.dumps(record,indent=2)+'\n')
