"""Pin optimized CPU code and stage inputs without holding a benchmark lease."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tarfile

parser=argparse.ArgumentParser()
parser.add_argument('--host',default='hrx-gorgon-3')
args=parser.parse_args()
notes=Path(__file__).resolve().parent
root=Path(json.loads((notes/'device-active.json').read_text())['directory'])/'persistent-resize'
tag=Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['codec-jpeg-resize-cpu'])/'experimental/codec_reference/research/jpeg-baseline'
files={}
native={}
for policy in ('islow','ifast'):
    binary=tag/('jpeg_resize_'+policy);files[binary.name]=binary
    assembly=subprocess.check_output(['/home/ben/tools/llvm/latest/bin/llvm-objdump','-d','--no-show-raw-insn',str(binary)],text=True)
    chunks=[]
    for match in re.finditer(r'^([0-9a-f]+) <([^>]+)>:\n(.*?)(?=^[0-9a-f]+ <|\Z)',assembly,re.M|re.S):
        if 'Decode' in match[2] or re.match(r'jsimd_(idct_'+policy+'|h2v2_fancy_upsample|ycc_rgb_convert)_(sse2|avx2)',match[2]):chunks.append(match[0])
    native_path=notes/('resize-cpu-'+policy+'.native.s');native_path.write_text(''.join(chunks))
    native[policy]=hashlib.sha256(native_path.read_bytes()).hexdigest()
for path in (root/'cpu').glob('*.plan'):
    files['cpu/'+path.name]=path
    image=path.name.removesuffix('.plan')
    files['cpu/'+image]=notes.parent/'jpeg-baseline/inputs'/image
manifest={'configuration':'--config=opt --copt=-march=znver5; -ffp-contract=off implements separate float32 multiply/add',
    'source_sha256':hashlib.sha256((notes.parent/'jpeg-baseline/jpeg_resize_baseline.cc').read_bytes()).hexdigest(),
    'native_sha256':native,'files':{name:{'bytes':p.stat().st_size,'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest()} for name,p in files.items()}}
(notes/'resize-cpu-stage.json').write_text(json.dumps(manifest,indent=2)+'\n')
p=subprocess.Popen(['ssh',args.host,'tar -xzf - -C /tmp/codec-jpeg-resize'],stdin=subprocess.PIPE)
with tarfile.open(fileobj=p.stdin,mode='w|gz',compresslevel=1) as archive:
    for name,path in files.items():archive.add(path.resolve(),arcname=name,recursive=False)
p.stdin.close();assert p.wait()==0
print(json.dumps({'staged_bytes':sum(row['bytes'] for row in manifest['files'].values()),'native_sha256':native}),flush=True)
