"""Qualify original compressed inputs, reusing one full-image fixture at a time."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import struct
import subprocess
import tarfile

from byte_compaction_model import model, reference
from connected_fixture import header_geometry, shape
from device_fixture import input_bytes, read_words, write_words

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
directory = root / 'float-corpus-current'
directory.mkdir(exist_ok=True)
references = directory / 'reference'
references.mkdir(exist_ok=True)
tags = json.loads(os.environ['BUREAU_TAG_ROOTS'])
oracle = Path(tags['codec-jpeg-float-reference']) / 'experimental/codec_reference/research/jpeg-entropy/float_reference'
link = Path(tags['codec-jpeg-rebased-tools']) / 'loom/src/loom/tools/loom-link/loom-link'
tool = Path(tags['codec-jpeg-rebased-checks']) / 'loom/src/loom/tooling/target/amdgpu/serve/codec_command_probe'
library = root / 'connected-main-requalified/library.loom'
identity = json.loads((notes / 'connected-requalified-stage.json').read_text())
library_hash = hashlib.file_digest(library.open('rb'), 'sha256').hexdigest()
assert library_hash == identity['files']['library.loom']
assert hashlib.sha256((notes / 'device_float_pipeline.cxx').read_bytes()).hexdigest() == identity['source_sha256']
build_record = json.loads((notes / 'current-probe-asan-build.json').read_text())
assert build_record['restored'] and build_record['build_returncode'] == 0
capture = json.loads(subprocess.check_output(
    ['bureau-bazel', 'tag', 'inspect', 'codec-jpeg-rebased-checks', '--json'], text=True))
assert capture['capture'] == build_record['capture']['capture']
output_prefix = 'rebased-float-corpus-'
order = [line.split()[0] for line in (root / 'connected-float-small/bindings.txt').read_text().splitlines()]
program = (root / 'connected-float-small/summary.loom').read_text().split('check.scenario')[0]
inputs = {'compressed', 'headers', 'tables', 'blocks', 'geometry', 'quantization', 'zigzag'}
cases = {}
for family in ('small', 'large'):
    base = root / ('twolevel-' + family)
    for case in json.loads((base / 'fixtures.json').read_text())['cases']:
        if case['scan'] == 0 and case['chunk_bytes'] == 1024:
            cases[case['name']] = (base, case)
names = ['existing_exif_fixture', 'ycbcr_444', 'ycbcr_422', 'ycbcr_420',
         'ycbcr_440', 'ycbcr_411', 'ycbcr_410', 'ycbcr_444_extended_quantization',
         'rgb_sequential', 'grayscale', 'dense-periodic', 'mcu-phase',
         'synthetic-256.jpg.r0.jpg', 'synthetic-1024.jpg.r0.jpg',
         '006mp-cathedral.jpg.r0.jpg', '012mp-bus.jpg.r0.jpg']
parser = argparse.ArgumentParser()
parser.add_argument('--names', nargs='+', choices=names)
arguments = parser.parse_args()
names = arguments.names or names


def numpy_bytes(path, data, element_bytes):
    assert len(data) % element_bytes == 0
    header = repr({'descr': '|i1' if element_bytes == 1 else '<i4',
                   'fortran_order': False, 'shape': (len(data) // element_bytes,)}).encode()
    header += b' ' * ((64 - (10 + len(header) + 1) % 64) % 64) + b'\n'
    path.write_bytes(b'\x93NUMPY\x01\x00' + struct.pack('<H', len(header)) + header + data)


def prepare(name):
    base, case = cases[name]
    assert case['segments'] == 1
    encoded = input_bytes(name)
    assert hashlib.sha256(encoded).hexdigest() == case['input_sha256']
    (directory / 'input.jpg').write_bytes(encoded)
    start, geometry = header_geometry(encoded)
    valid, raw, records, prefixes = model(encoded, start)
    assert valid and (valid, raw) == reference(encoded, start)
    count = (len(raw) + 1023) // 1024
    assert count == case['jobs']
    result = subprocess.run([str(oracle), str(directory / 'input.jpg'), str(references)],
                            capture_output=True, text=True)
    (notes / (output_prefix + name + '-reference.log')).write_text(result.stdout + result.stderr)
    assert result.returncode == 0, result.stdout + result.stderr
    numerical = [json.loads(line) for line in result.stdout.splitlines()]
    dimensions = numerical[-1]
    assert (dimensions['width'], dimensions['height']) == (geometry['width'], geometry['height'])
    config = json.loads((base / (case['key'] + '.json')).read_text())
    assert config['jpeg']['components'] in (1, 3)
    tiles = (len(encoded) + 4095) // 4096
    capacity = tiles * 4
    config['jpeg']['chunks'] = capacity
    config['input'] = {'tiles': tiles, 'entropy_padding_words': 32}
    horizontal = max(value[0] for value in geometry['sampling'])
    vertical = max(value[1] for value in geometry['sampling'])
    image = {'width': geometry['width'], 'height': geometry['height'],
             'batch': 1, 'color_space': dimensions['color_space']}
    for index in range(3):
        sampling = geometry['sampling'][index] if index < len(geometry['sampling']) else (horizontal, vertical)
        assert horizontal % sampling[0] == 0 and vertical % sampling[1] == 0
        image['horizontal' + str(index)] = horizontal // sampling[0]
        image['vertical' + str(index)] = vertical // sampling[1]
    config['image'] = image
    paths = {key: (base / value).resolve() for key, value in re.findall(
        r'%([a-z_]+) = check.file.read.npy path\("([^"]+)"\)', (base / (case['key'] + '.loom')).read_text())}
    partitions = config['jpeg']['output_partitions']
    state_stride = (5 + config['jpeg']['components'] + 3) & ~3
    point_stride = (3 + config['jpeg']['components'] + 3) & ~3
    interval_stride = (4 + config['jpeg']['components'] + 3) & ~3
    padded = {'expected': capacity * state_stride, 'bridges': capacity * state_stride,
              'suffixes': (capacity + 1) * state_stride, 'ranges': (capacity + 1) * state_stride,
              'points': capacity * (partitions - 1) * point_stride,
              'intervals': (capacity * (partitions + 1) + 1) * interval_stride,
              'status': capacity * (partitions + 1) + 1}
    for key, size in padded.items():
        words = read_words(paths[key])
        assert len(words) <= size, (key, len(words), size)
        write_words(directory / (key + '.npy'), list(words) + [17] * (size - len(words)))
    interval_count = count * (partitions + 1) + 1
    values = {'headers': [len(encoded), start, geometry['blocks'], 0],
              'segments': [0, len(raw) * 8, 0, count, geometry['blocks'], 0, 0, 0],
              'jobs': [value for job in range(count) for value in (0, len(raw) * 8, job)] + [17] * ((capacity - count) * 3),
              'records': [value for row in records for value in row], 'prefixes': prefixes,
              'errors': [0, min(row[1] for row in records), min(row[2] for row in records), len(raw)],
              'schedule': [count, (count + 127) // 128, 1, 1, (interval_count + 31) // 32, 1, 1, interval_count]}
    for key, words in values.items():
        write_words(directory / (key + '.npy'), words)
    numpy_bytes(directory / 'compressed.npy', encoded + bytes(tiles * 4096 + 16 - len(encoded)), 4)
    packed = raw + bytes((-len(raw)) % 4 + 8)
    words = list(struct.unpack('>' + 'I' * (len(packed) // 4), packed))
    write_words(directory / 'entropy.npy', words + [17] * (tiles * 1024 + 32 + 8 - len(words)))
    pixels = (references / 'pixels.raw').read_bytes()
    rgb = (references / 'rgb.raw').read_bytes()
    assert len(pixels) == geometry['pixel_words'] * 4
    numpy_bytes(directory / 'pixels.npy', pixels + struct.pack('<I', 17) * 8, 4)
    numpy_bytes(directory / 'rgb.npy', rgb + bytes([17]) * 32, 1)
    for key in ('tables', 'blocks', 'geometry', 'quantization', 'zigzag'):
        shutil.copyfile(paths[key], directory / (key + '.npy'))
    bindings = []
    for key in order:
        size, dtype = shape(directory / (key + '.npy'))
        bindings.append(f'{key} {int(key in inputs)} {1 if dtype == "i8" else 4} {size} {key}.npy')
    (directory / 'bindings.txt').write_text('\n'.join(bindings) + '\n')
    (directory / 'config.json').write_text(json.dumps(config, indent=2) + '\n')
    (directory / 'summary.loom').write_text(program)
    subprocess.run([str(link), str(directory / 'summary.loom'), str(library),
                    '--to=bc', '--output=' + str(directory / 'summary.loombc')], check=True)
    files = {path.name: hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()
             for path in directory.iterdir() if path.is_file() and path.suffix in ('.npy', '.loombc', '.json', '.txt', '.loom') and path.name != 'stage.json'}
    stage = {'name': name, 'input_sha256': case['input_sha256'], 'configuration': config,
             'geometry': geometry, 'files': files, 'numerical': numerical,
             'reference_sha256': {path.name: hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()
                                  for path in references.iterdir() if path.is_file()},
             'library_sha256': library_hash,
             'reference_binary_sha256': hashlib.file_digest(oracle.open('rb'), 'sha256').hexdigest()}
    assert sum(path.stat().st_size for path in directory.rglob('*') if path.is_file()) < 384 * 1024**2
    (directory / 'stage.json').write_text(json.dumps(stage, indent=2) + '\n')
    (notes / (output_prefix + name + '-stage.json')).write_text(json.dumps(stage, indent=2) + '\n')
    return stage


remote_tool = root / 'codec_command_probe'
transfer = subprocess.Popen(['ssh', 'hrx-gorgon-4', 'tar -xf - -C ' + shlex.quote(str(root))], stdin=subprocess.PIPE)
with tarfile.open(fileobj=transfer.stdin, mode='w|', dereference=True) as archive:
    archive.add(tool, arcname=remote_tool.name, recursive=False)
transfer.stdin.close()
assert transfer.wait() == 0
tool_hash = hashlib.file_digest(tool.open('rb'), 'sha256').hexdigest()
for name in names:
    stage = prepare(name)
    subprocess.run(['ssh', 'hrx-gorgon-4', 'mkdir -p ' + shlex.quote(str(directory))], check=True)
    transfer = subprocess.Popen(['ssh', 'hrx-gorgon-4', 'tar -xf - -C ' + shlex.quote(str(directory))], stdin=subprocess.PIPE)
    with tarfile.open(fileobj=transfer.stdin, mode='w|') as archive:
        for filename in (*stage['files'], 'stage.json'):
            archive.add(directory / filename, arcname=filename, recursive=False)
    transfer.stdin.close()
    assert transfer.wait() == 0
    verify = '''import hashlib,json,pathlib
p=pathlib.Path(%r)
for name,digest in json.loads((p/'stage.json').read_text())['files'].items():
 assert hashlib.file_digest((p/name).open('rb'),'sha256').hexdigest()==digest,name
assert hashlib.file_digest(pathlib.Path(%r).open('rb'),'sha256').hexdigest()==%r
''' % (str(directory), str(remote_tool), tool_hash)
    subprocess.run(['ssh', 'hrx-gorgon-4', 'python3 -B -'], input=verify, text=True, check=True)
    command = ['/home/benvanik/.dotfiles/bin/benchmark-lock', '--label=codec-jpeg-float-corpus', '--',
               'timeout', '--signal=INT', '--kill-after=10s', '300s',
               'env', 'LD_LIBRARY_PATH=/opt/rocm/lib', str(remote_tool),
               '--jpeg_fixture=' + str(directory), '--gtest_filter=JpegCommandTest.CompressedToRgb',
               '--jpeg_access=true', '--amdgpu_asan=true', '--amdgpu_asan_report_policy=fail-device']
    result = subprocess.run(['ssh', 'hrx-gorgon-4', shlex.join(command)], capture_output=True, text=True)
    (notes / ('gorgon4-' + output_prefix + name + '.log')).write_text(result.stdout + result.stderr)
    status = subprocess.run(['ssh', 'hrx-gorgon-4', '/home/benvanik/.dotfiles/bin/benchmark-lock --status'], capture_output=True, text=True)
    record = {'name': name, 'command': command, 'returncode': result.returncode,
              'tool_sha256': tool_hash, 'build_config': 'asan', 'stage': stage,
              'build_commit': build_record['commit'], 'build_capture': capture['capture'],
              'caller_source_sha256': build_record['source_sha256'],
              'broker_status_after': status.stdout + status.stderr,
              'broker_status_returncode': status.returncode}
    (notes / ('gorgon4-' + output_prefix + name + '.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'name': name, 'returncode': result.returncode,
                      'broker_status_after': status.stdout + status.stderr}), flush=True)
    if result.returncode or status.returncode:
        print(result.stdout + result.stderr, flush=True)
        raise SystemExit(result.returncode or status.returncode)
