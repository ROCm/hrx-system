"""Stage the active experiment's fixtures in one streamed archive."""
import hashlib
import json
from pathlib import Path
import subprocess

notes = Path(__file__).resolve().parent
directory = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
receipt = json.loads((notes / 'device-stage.json').read_text())
files = sorted(p for p in directory.iterdir() if p.suffix in ('.npy', '.json', '.loom', '.loombc'))
files = [p for p in files if p.name != 'stage.json']
for name in ('device_qualify.py',):
    destination = directory / name
    destination.write_bytes((notes / name).read_bytes())
    files.append(destination)
receipt['files'] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(notes / 'device-stage.json').write_text(json.dumps(receipt, indent=2) + '\n')
(directory / 'stage.json').write_text(json.dumps(receipt, indent=2) + '\n')
command = ['tar', '-czf', '-', '-C', str(directory), *[p.name for p in files], 'stage.json']
archive = subprocess.Popen(command, stdout=subprocess.PIPE)
try:
    result = subprocess.run(['ssh', receipt['host'], 'tar -xzf - -C ' + receipt['remote_root']],
                            stdin=archive.stdout)
finally:
    archive.stdout.close()
    archive_status = archive.wait()
assert archive_status == 0 and result.returncode == 0, (archive_status, result.returncode)
print(json.dumps({'files': len(files), 'bytes': sum(p.stat().st_size for p in files)}), flush=True)
