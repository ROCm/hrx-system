"""Evaluate wave64 with two independent 32-lane reconstruction teams."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

notes=Path(__file__).resolve().parent
root=Path(json.loads((notes/'device-active.json').read_text())['directory'])
tags=json.loads(os.environ['BUREAU_TAG_ROOTS'])
base=Path(tags['codec-jpeg-rebased-tools'])/'loom/src/loom/tools'
native=Path(tags['codec-jpeg-unsigned-opt'])/'loom/src/loom/tools'
original=root/'certified-batch16-1024'
fixture=root/'wave64-batch16-1024'
fixture.mkdir(exist_ok=True)
pipeline=(notes/'device_certified_pipeline.cxx').read_text()
old='''  bool owner_valid = loom::kernel::subgroup::shuffle_index('''
new='''  unsigned team_width = minimum(threads, 32u);
  unsigned team_owner = owner % team_width;
  bool owner_valid = loom::kernel::subgroup::shuffle_index('''
assert pipeline.count(old)==1
pipeline=pipeline.replace(old,new)
assert pipeline.count('owner, threads).value')==3
pipeline=pipeline.replace('owner, threads).value','team_owner, team_width).value')
old='''          unsigned owner = round * (threads / 8) + lane / 8;'''
new='''          unsigned team_width = minimum(threads, 32u);
          unsigned owner = (lane / team_width) * team_width +
              round * (team_width / 8) + (lane % team_width) / 8;'''
assert pipeline.count(old)==1
pipeline=pipeline.replace(old,new)
pipeline_path=notes/'device_wave64_pipeline.cxx'
pipeline_path.write_text(pipeline)
commands=[[str(base/'loom-import-cxx/loom-import-cxx'),str(pipeline_path),
           '--output='+str(root/'entropy-wave64.loom')]]
subprocess.run(commands[-1],check=True)
source=(root/'entropy-wave64.loom').read_text()
assert source.count('kernel.def @')==6
source='amdgpu.target<gfx11-generic> @jpeg_wave64 {subgroup_size = 64}\n'+source.replace('kernel.def @','kernel.def target(@jpeg_wave64) @')
(root/'entropy-wave64.loom').write_text(source)
library=root/'entropy-wave64.loombc'
commands.append([str(base/'loom-link/loom-link'),str(root/'entropy-wave64.loom'),'--to=bc','--output='+str(library)])
subprocess.run(commands[-1],check=True)
rows=[]
for entry in ('jpeg_speculate','jpeg_bridge','jpeg_index','jpeg_certify','jpeg_intervals','jpeg_reconstruct'):
    report=root/(entry+'-wave64-report.json')
    binary=root/(entry+'-wave64.hsaco')
    command=[str(native/'loom-compile/loom-compile'),str(library),'--root='+entry,
             '--target=amdgpu:gfx1151','--config-file='+str(original/'config.json'),
             '--output='+str(binary),'--compile-report=details','--compile-report-output='+str(report)]
    commands.append(command);subprocess.run(command,check=True)
    data=json.loads(report.read_text())['entries']['rows'][0]
    row={'entry':entry,'metrics':{key:data[key] for key in ('instruction_count','code_byte_count','private_memory_bytes','local_memory_bytes','target_resources')},
         'native_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
    assert row['metrics']['target_resources']['subgroup_size']==64
    rows.append(row);print(json.dumps(row),flush=True)
paths={}
def relocate(match):
    path=(original/match[1]).resolve()
    relative=os.path.relpath(path,fixture);paths[relative]=path
    return 'check.file.read.npy path("'+relative+'")'
scenario=re.sub(r'check.file.read.npy path\("([^"]+)"\)',relocate,(original/'summary.loom').read_text())
(fixture/'summary.loom').write_text(scenario)
(fixture/'config.json').write_bytes((original/'config.json').read_bytes())
command=[str(base/'loom-link/loom-link'),str(fixture/'summary.loom'),str(library),
         '--to=bc','--output='+str(fixture/'summary.loombc')]
commands.append(command);subprocess.run(command,check=True)
stage=json.loads((original/'stage.json').read_text())
stage['files']={relative:hashlib.sha256(path.read_bytes()).hexdigest() for relative,path in paths.items()}
stage['files'].update({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in fixture.iterdir() if p.is_file() and p.name!='stage.json'})
stage['library']={'path':library.name,'sha256':hashlib.sha256(library.read_bytes()).hexdigest()}
stage['scope']='Certified component algorithm, late wave64 profile and independent 32-lane reconstruction teams; launch geometry follows target subgroup queries. Still no device destuffing or RGB.'
(fixture/'stage.json').write_text(json.dumps(stage,indent=2)+'\n')
record={'commands':commands,'stage':stage,'rows':rows,
        'baseline_ir_sha256':hashlib.sha256((root/'entropy-certified.loom').read_bytes()).hexdigest(),
        'candidate_ir_sha256':hashlib.sha256((root/'entropy-wave64.loom').read_bytes()).hexdigest(),
        'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'pipeline_sha256':hashlib.sha256(pipeline_path.read_bytes()).hexdigest()}
(notes/'device-wave64-code.json').write_text(json.dumps(record,indent=2)+'\n')
