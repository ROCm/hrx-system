"""Bounded small/large certificate qualification inside one foreground lease."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
tools = json.loads((root / 'unsigned-tools.json').read_text())
library_hash = hashlib.sha256((root / 'entropy-parallel.loombc').read_bytes()).hexdigest()
assert library_hash == 'ae76e520f40e40276521778d2553ab731c452157099a8196d22d79408a38d28e'
for family in ('small', 'large'):
    name = 'parallel-' + family
    command = [sys.executable, str(root / 'device_tables_qualify.py'),
               '--stage=' + name + '-stage.json', '--fixtures=' + name + '/fixtures.json',
               '--runner=iree-test-loom-unsigned',
               '--runner-sha256=' + tools['files']['iree-test-loom-unsigned'],
               '--library=entropy-parallel.loombc', '--library-sha256=' + library_hash,
               '--output-directory=' + name + '-actual']
    subprocess.run(command, check=True)
