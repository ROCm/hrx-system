// Original JPEG bytes through the actual finite-model command and trained rows.
#include <array>
#include <atomic>
#include <condition_variable>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <mutex>
#include <string>
#include <vector>

#include "native_upload.h"
#include "iree/base/internal/base64.h"
#include "iree/base/tooling/flags.h"
#include "iree/testing/gtest.h"
#include "iree/testing/status_matchers.h"
#include "iree/vm/buffer.h"
#include "loom/serve/media/image_request.h"
#include "loom/serve/runtime/device/device.h"
#include "loom/serve/runtime/execution/execution.h"
#include "loom/serve/runtime/host/wake.h"
#include "loom/serve/runtime/parameter/residency.h"
#include "loom/serve/service/finite/model.h"
#include "loom/serve/service/finite/result.h"
#include "loom/serve/testing/compiler.h"
#include "loom/serve/testing/device.h"
#include "loom/serve/testing/model.h"

IREE_FLAG(string, jpeg_fixture, "", "Pinned source, compressed input, and independent pixels.");
IREE_FLAG(bool, compressed, false, "Execute the native compressed source contract.");

namespace {

struct Request {
  // Baseline codec input, retained through synchronous pixel materialization.
  loom_serve_media_image_input_t image = {};
  // Owned native request packet passed to the actual source prepare_request.
  iree_vm_buffer_t* packet = nullptr;
  // Owned source-prepared bytes and compatibility facts.
  loom_serve_finite_prepared_t prepared = {};

  ~Request() {
    iree_vm_buffer_release(prepared.bytes);
    iree_vm_buffer_release(packet);
    loom_serve_media_image_input_deinitialize(&image);
  }
};

struct Upload {
  // One native-owned immutable upload, released after copying into the packet.
  jpeg_upload_t value = {};
  ~Upload() { jpeg_upload_deinitialize(&value); }
};

class ProjectorUploadTest : public ::testing::Test {
 protected:
  void SetUp() override {
    directory_ = FLAG_jpeg_fixture;
    IREE_ASSERT_OK(document_.Load((directory_ /
        (FLAG_compressed ? "deployment.json" : "control-deployment.json")).string()));
    IREE_ASSERT_OK(loom_serve_test_host_create(16, allocator_, &host_));
    iree_hal_driver_t* driver = nullptr;
    IREE_ASSERT_OK(loom_serve_test_driver_create(host_, allocator_, &driver));
    const loom_serve_device_options_t options = {
        .driver = driver, .uri = IREE_SV("amdgpu"),
        .backing = LOOM_SERVE_DEVICE_BACKING_FIXED};
    auto status = loom_serve_device_group_allocate(host_, 1, &options, allocator_, &group_);
    iree_hal_driver_release(driver);
    IREE_ASSERT_OK(status);
    device_ = loom_serve_device_group_at(group_, 0);
    IREE_ASSERT_OK(loom_serve_device_create_execution(device_, &observer_));
    auto sources = document_.value().sources;
    const auto& image = document_.value().text.image;
    sources.prepare = image.prepare;
    sources.control = image.control;
    const loom_serve_finite_model_options_t model_options = {
        .sources = sources, .asset_directory = image.assets,
        .options = image.options, .specialization_cache = image.specialization_cache};
    IREE_ASSERT_OK(loom_serve_finite_model_allocate(device_, &model_options, allocator_, &model_));
    loom_serve_finite_model_set_observer(model_, {Wake, this});
    if (FLAG_compressed) {
      std::ifstream stream(directory_ / "baseline.features", std::ios::binary);
      ASSERT_TRUE(stream.good());
      reference_.assign(std::istreambuf_iterator<char>(stream), std::istreambuf_iterator<char>());
      ASSERT_EQ(reference_.size(), kRows * kRowBytes);
    }
  }

  void TearDown() override {
    if (batch_pending_) {
      IREE_EXPECT_OK(Resolve(true));
      loom_serve_finite_model_release_batch(model_);
    }
    if (observer_) IREE_EXPECT_OK(loom_serve_execution_drain(observer_));
    IREE_EXPECT_OK(loom_serve_finite_model_free(model_));
    loom_serve_finite_snapshot_release(snapshot_);
    loom_serve_finite_result_release(result_);
    loom_serve_execution_release(observer_);
    if (device_) IREE_EXPECT_OK(loom_serve_test_device_trim_and_drain(device_, 0));
    IREE_EXPECT_OK(loom_serve_device_group_free(group_));
    loom_serve_host_release(host_);
  }

  static void Wake(void* pointer) {
    auto* self = static_cast<ProjectorUploadTest*>(pointer);
    std::lock_guard<std::mutex> lock(self->mutex_);
    ++self->wakes_;
    self->condition_.notify_all();
  }

  iree_status_t Resolve(bool cancel = false) {
    bool complete = false;
    while (!complete) {
      const auto previous = wakes_.load();
      IREE_RETURN_IF_ERROR(loom_serve_finite_model_advance_batch(model_, cancel, &complete));
      if (!complete) {
        std::unique_lock<std::mutex> lock(mutex_);
        condition_.wait(lock, [&] { return wakes_.load() != previous; });
      }
    }
    return iree_ok_status();
  }

  void PrepareCompressed(Request& request, bool invalid) {
    std::ifstream stream(directory_ / "original.jpg", std::ios::binary);
    ASSERT_TRUE(stream.good());
    std::vector<uint8_t> encoded(std::istreambuf_iterator<char>(stream), {});
    jpeg_upload_image_t image;
    IREE_ASSERT_OK(jpeg_upload_image_initialize(
        iree_make_const_byte_span(encoded.data(), encoded.size()), &image));
    ASSERT_EQ(image.header.width, 4032u);
    ASSERT_EQ(image.header.height, 3024u);
    if (invalid) {
      // Input construction only: retain every header byte and replace entropy
      // with EOI. The independently qualified empty-body contract is code 768.
      encoded.resize(image.header.entropy_start);
      encoded.push_back(0xff);
      encoded.push_back(0xd9);
      IREE_ASSERT_OK(jpeg_upload_image_initialize(
          iree_make_const_byte_span(encoded.data(), encoded.size()), &image));
    }
    Upload upload;
    IREE_ASSERT_OK(jpeg_upload_create(1, &image, allocator_, &upload.value));
    const size_t length = 80 + upload.value.input.data_length;
    IREE_ASSERT_OK(iree_vm_buffer_create(length, 16, allocator_, &request.packet));
    iree_byte_span_t packet;
    IREE_ASSERT_OK(iree_vm_buffer_map_write(request.packet, 0, length, &packet));
    // This input's orientation-one/no-EXIF identity is pinned by the independent
    // image qualification. The selected target geometry is its real chat policy.
    const uint32_t header[20] = {
        0x4745504a, 2, image.header.width, image.header.height,
        image.header.width, image.header.height, 1, kRows,
        64, 8, 80, static_cast<uint32_t>(upload.value.input.data_length),
        3, upload.value.output_length, image.header.width * image.header.height * 3u, 0,
        kWidth, kHeight, 0, 0};
    for (unsigned i = 0; i < 20; ++i) {
      iree_unaligned_store_le_u32(packet.data + i * 4, header[i]);
    }
    std::memcpy(packet.data + 80, upload.value.input.data, upload.value.input.data_length);
    std::printf("{\"phase\":\"native_packet\",\"invalid\":%s,\"compressed_bytes\":%zu,\"upload_bytes\":%zu,\"decoder_output_bytes\":%u}\n",
        invalid ? "true" : "false", encoded.size(), upload.value.input.data_length, upload.value.output_length);
    // Encoded and native-upload storage are both released before finite source
    // preparation; only the packet's owned compressed copy crosses that boundary.
  }

  void PrepareControl(Request& request) {
    std::ifstream stream(directory_ / "loom-float32.pam", std::ios::binary);
    ASSERT_TRUE(stream.good());
    const std::vector<uint8_t> encoded(std::istreambuf_iterator<char>(stream), {});
    std::string url = "data:image/x-portable-arbitrarymap;base64,";
    const size_t prefix = url.size();
    const size_t length = iree_base64_encoded_size(encoded.size());
    url.resize(prefix + length);
    size_t written = 0;
    IREE_ASSERT_OK(iree_base64_encode(iree_make_const_byte_span(encoded.data(), encoded.size()),
        {url.data() + prefix, length}, &written));
    ASSERT_EQ(written, length);
    const loom_serve_media_image_limits_t limits = {67108864, 4096, 4096, 16777216};
    IREE_ASSERT_OK(loom_serve_media_image_input_initialize(
        iree_make_string_view(url.data(), url.size()), &limits, allocator_, &request.image));
    const std::array<uint32_t, 2> geometry = {kWidth, kHeight};
    const loom_serve_media_image_request_t image_request = {
        .image = &request.image,
        .metadata = iree_make_const_byte_span(geometry.data(), sizeof(geometry)),
        .output_rows = kRows};
    iree_status_t image_status = iree_ok_status();
    auto status = loom_serve_media_image_request_create_batch(
        1, &image_request, allocator_, &request.packet, &image_status);
    IREE_EXPECT_OK(image_status);
    IREE_ASSERT_OK(status);
  }

  void Observe(const char* name, unsigned count, int invalid_ordinal) {
    SCOPED_TRACE(name);
    std::printf("{\"phase\":\"case\",\"name\":\"%s\",\"images\":%u}\n", name, count);
    std::array<Request, 4> requests;
    std::array<loom_serve_finite_prepared_t, 4> prepared = {};
    std::array<iree_host_size_t, 4> rows = {};
    size_t prepared_bytes = 0;
    for (unsigned i = 0; i < count; ++i) {
      if (FLAG_compressed) {
        ASSERT_NO_FATAL_FAILURE(PrepareCompressed(requests[i], int(i) == invalid_ordinal));
      } else {
        ASSERT_NO_FATAL_FAILURE(PrepareControl(requests[i]));
      }
      IREE_ASSERT_OK(loom_serve_finite_model_prepare_request(model_, requests[i].packet, &requests[i].prepared));
      prepared[i] = requests[i].prepared;
      rows[i] = kRows;
      prepared_bytes += iree_vm_buffer_length(prepared[i].bytes);
    }
    IREE_ASSERT_OK(loom_serve_finite_model_prepare_batch(model_, count, prepared.data(), rows.data()));
    batch_pending_ = true;
    IREE_ASSERT_OK(Resolve());
    loom_serve_residency_admission_t admission;
    IREE_ASSERT_OK(loom_serve_residency_try_admit(loom_serve_finite_model_residency(model_), &admission));
    ASSERT_EQ(admission, LOOM_SERVE_RESIDENCY_ADMISSION_ACQUIRED);
    loom_serve_execution_frontier_t ready;
    batch_pending_ = false;
    IREE_ASSERT_OK(loom_serve_finite_model_submit(model_, &result_, &ready));
    const size_t feature_bytes = count * kRows * kRowBytes;
    ASSERT_EQ(loom_serve_finite_result_length(result_), feature_bytes);
    uint64_t status_completion = 0;
    if (FLAG_compressed) {
      statuses_.fill(0xeeeeeeeeu);
      IREE_ASSERT_OK(loom_serve_execution_barrier(observer_,
          {IREE_ARRAYSIZE(ready.semaphores), ready.semaphores, ready.values}));
      const auto first = loom_serve_finite_result_row(result_, 0, 0);
      ASSERT_EQ(first.offset, 0u);
      iree_hal_transfer_operation_t transfer = {};
      transfer.type = IREE_HAL_TRANSFER_OPERATION_TYPE_DOWNLOAD;
      transfer.download.source_buffer = first.buffer;
      transfer.download.source_offset = feature_bytes;
      transfer.download.target = statuses_.data();
      transfer.download.length = count * sizeof(uint32_t);
      IREE_ASSERT_OK(loom_serve_execution_feedback(observer_, 1, &transfer, &status_completion));
    }
    IREE_ASSERT_OK(loom_serve_finite_result_download(result_, &snapshot_, &ready));
    for (size_t i = 0; i < IREE_ARRAYSIZE(ready.semaphores); ++i) {
      IREE_ASSERT_OK(iree_hal_semaphore_wait(ready.semaphores[i], ready.values[i],
          iree_infinite_timeout(), IREE_ASYNC_WAIT_FLAG_NONE));
    }
    if (FLAG_compressed) IREE_ASSERT_OK(loom_serve_execution_feedback_wait(observer_, status_completion));
    std::ofstream output;
    if (std::strcmp(name, "single") == 0) {
      output.open(directory_ / (FLAG_compressed ? "candidate.features" : "baseline.features"), std::ios::binary);
      ASSERT_TRUE(output.good());
    }
    for (unsigned i = 0; i < count; ++i) {
      if (FLAG_compressed) {
        ASSERT_EQ(statuses_[i], int(i) == invalid_ordinal ? 768u : 0u) << i;
        std::printf("{\"phase\":\"status\",\"image\":%u,\"value\":%u}\n", i, statuses_[i]);
      }
      for (size_t row = 0; row < kRows; ++row) {
        const auto values = loom_serve_finite_snapshot_row(snapshot_, i, row);
        ASSERT_EQ(values.data_length, kRowBytes);
        if (FLAG_compressed && int(i) != invalid_ordinal) {
          ASSERT_EQ(std::memcmp(values.data, reference_.data() + row * kRowBytes, kRowBytes), 0) << "image " << i << " row " << row;
        }
        if (output.is_open()) output.write(reinterpret_cast<const char*>(values.data), values.data_length);
      }
      if (FLAG_compressed && int(i) != invalid_ordinal) {
        std::printf("{\"phase\":\"exact_features\",\"image\":%u,\"bytes\":%zu}\n", i, kRows * kRowBytes);
      }
    }
    if (output.is_open()) ASSERT_TRUE(output.good());
    std::printf("{\"phase\":\"complete\",\"name\":\"%s\",\"prepared_bytes\":%zu,\"feature_bytes\":%zu,\"physical_output_bytes\":%zu}\n",
        name, prepared_bytes, feature_bytes, size_t(loom_serve_finite_result_output_length(result_)));
    loom_serve_finite_model_complete(model_);
    loom_serve_finite_snapshot_release(snapshot_); snapshot_ = nullptr;
    loom_serve_finite_result_release(result_); result_ = nullptr;
  }

  // Trained geometry chosen by the pinned chat policy for this original image.
  static constexpr uint32_t kWidth = 1152;
  // Trained geometry chosen by the pinned chat policy for this original image.
  static constexpr uint32_t kHeight = 864;
  // Four patch rows merge into each final feature row.
  static constexpr size_t kRows = (kWidth / 32) * (kHeight / 32);
  // One row contains 5120 little-endian F32 feature values.
  static constexpr size_t kRowBytes = 5120 * sizeof(float);
  // Allocator retained through all native owners.
  iree_allocator_t allocator_ = iree_allocator_system();
  // Scratch source/input and the single retained feature comparison pair.
  std::filesystem::path directory_;
  // Parsed deployment owns every source and asset locator.
  loom_serve::testing::ModelDocument document_;
  // Shared host workers retained through model destruction.
  loom_serve_host_t* host_ = nullptr;
  // Device group owns queues and allocation pools.
  loom_serve_device_group_t* group_ = nullptr;
  // Borrowed sole device of the group.
  loom_serve_device_t* device_ = nullptr;
  // Real trained vision component with its usual source and checkpoint owners.
  loom_serve_finite_model_t* model_ = nullptr;
  // Separate observation branch imports producer readiness without a host wait.
  loom_serve_execution_t* observer_ = nullptr;
  // Device output is retained independently of model parameters.
  loom_serve_finite_result_t* result_ = nullptr;
  // Explicit full-feature host observer for independent exact comparison.
  loom_serve_finite_snapshot_t* snapshot_ = nullptr;
  // Destinations remain live through accepted feedback even after a failed check.
  std::array<uint32_t, 4> statuses_ = {};
  // Current-compiler control features from independently qualified GPU pixels.
  std::vector<uint8_t> reference_;
  // An unsubmitted prepared cohort needs cancellation before destruction.
  bool batch_pending_ = false;
  // Synchronizes asynchronous compilation wake publication.
  std::mutex mutex_;
  // Outer observer waits; no shared worker waits for another worker.
  std::condition_variable condition_;
  // Monotonic generation closes the check-to-wait race.
  std::atomic<uint64_t> wakes_ = 0;
};

TEST_F(ProjectorUploadTest, TrainedFeaturesAndPeers) {
  ASSERT_NO_FATAL_FAILURE(Observe("single", 1, -1));
  if (FLAG_compressed) {
    ASSERT_NO_FATAL_FAILURE(Observe("two", 2, -1));
    ASSERT_NO_FATAL_FAILURE(Observe("invalid-first", 2, 0));
    ASSERT_NO_FATAL_FAILURE(Observe("invalid-last", 2, 1));
    ASSERT_NO_FATAL_FAILURE(Observe("recovery", 1, -1));
  }
}
}  // namespace
