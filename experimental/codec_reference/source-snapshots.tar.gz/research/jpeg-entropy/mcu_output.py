"""Prove whole-MCU output ownership from certified arbitrary-bit checkpoints.

Each output worker discards its partial leading MCU, owns every MCU whose
first bit lies in its interval, and finishes its last owned MCU. A single MCU
coefficient buffer feeds the sink. The sink here checks the qualified oracle;
an IDCT consumer is not implemented or assumed by this experiment.
"""

from array import array
import argparse
import base64
import hashlib
import json
from pathlib import Path

from bounded import Cursor, establish
from recover_prefix import speculate
from sequential import ZIGZAG, decode, destination, divide_up, parse


ROOT = Path(__file__).resolve().parent
BASELINE = ROOT.parent / "jpeg-baseline"


def emit_mcus(frame, scan, segment, checkpoints, expected, coverage):
    block_count = len(scan.blocks)
    total_blocks = segment.mcu_count * block_count
    # One reusable worker buffer, never one per image coefficient or chunk.
    coefficients = array("h", [0]) * (block_count * 64)
    emitted_symbols = 0
    repeated_symbols = 0
    emitted_bits = 0
    repeated_bits = 0
    emitted_mcus = 0
    empty_workers = 0
    maximum_worker_symbols = 0
    for first, last in zip(checkpoints, checkpoints[1:]):
        cursor = Cursor(segment, scan, len(frame.components), first)
        while cursor.coefficient != 0 or cursor.blocks % block_count != 0:
            cursor.advance()
        repeated_symbols += cursor.symbols
        repeated_bits += cursor.reader.position - first.position
        assert cursor.reader.position - first.position <= block_count * 64 * 27
        if cursor.reader.position >= last.position:
            empty_workers += 1
        while cursor.blocks < total_blocks and cursor.reader.position < last.position:
            mcu = segment.first_mcu + cursor.blocks // block_count
            start_symbols = cursor.symbols
            start_bits = cursor.reader.position
            for index in range(len(coefficients)):
                coefficients[index] = 0
            for block_index in range(block_count):
                while True:
                    _, index, value = cursor.advance()
                    if index >= 0:
                        coefficients[block_index * 64 + ZIGZAG[index]] = value
                    if cursor.coefficient == 0:
                        break
            # A production consumer would read this one MCU here. The full
            # image allocation below belongs exclusively to the oracle.
            for block_index, block in enumerate(scan.blocks):
                base = destination(frame, scan, mcu, block)
                if base is None:
                    continue
                component = block.component
                index = base // 64
                assert coverage[component][index] == 0, "MCU owned by two intervals"
                coverage[component][index] = 1
                actual = coefficients[block_index * 64:(block_index + 1) * 64]
                assert actual == expected[component][base:base + 64]
            emitted_symbols += cursor.symbols - start_symbols
            emitted_bits += cursor.reader.position - start_bits
            emitted_mcus += 1
        maximum_worker_symbols = max(maximum_worker_symbols, cursor.symbols)
    return {"emitted_mcus": emitted_mcus,
            "emitted_symbols": emitted_symbols,
            "repeated_head_symbols": repeated_symbols,
            "emitted_bits": emitted_bits,
            "repeated_head_bits": repeated_bits,
            "empty_output_intervals": empty_workers,
            "maximum_output_worker_symbols": maximum_worker_symbols,
            "coefficient_buffer_bytes_per_worker": len(coefficients) * coefficients.itemsize}


def evaluate(frame, planes, chunk_bytes):
    coverage = [bytearray(len(plane) // 64) for plane in planes]
    totals = {key: 0 for key in (
        "emitted_mcus", "emitted_symbols", "repeated_head_symbols", "emitted_bits",
        "repeated_head_bits", "empty_output_intervals", "intervals", "repair_symbols",
        "speculative_symbol_attempts", "speculative_bits", "prefix_resets", "budget_exhaustions")}
    maximum_symbols = 0
    maximum_storage = 0
    for scan in frame.scans:
        for segment in scan.segments:
            intervals = divide_up(len(segment.data), chunk_bytes)
            summaries, spec = speculate(segment, scan, len(frame.components), chunk_bytes * 8, 1, intervals)
            checkpoints, repair = establish(segment, scan, len(frame.components), chunk_bytes * 8, summaries)
            emitted = emit_mcus(frame, scan, segment, checkpoints, planes, coverage)
            assert emitted["emitted_mcus"] == segment.mcu_count
            assert emitted["emitted_bits"] == repair["entropy_bits"]
            totals["intervals"] += intervals
            totals["repair_symbols"] += repair["repair_symbols"]
            for key in ("speculative_symbol_attempts", "speculative_bits", "prefix_resets", "budget_exhaustions"):
                totals[key] += spec[key]
            for key in ("emitted_mcus", "emitted_symbols", "repeated_head_symbols", "emitted_bits",
                        "repeated_head_bits", "empty_output_intervals"):
                totals[key] += emitted[key]
            maximum_symbols = max(maximum_symbols, emitted["maximum_output_worker_symbols"])
            maximum_storage = max(maximum_storage, emitted["coefficient_buffer_bytes_per_worker"])
    assert all(all(plane) for plane in coverage), "unowned coefficient block"
    return {"chunk_bytes": chunk_bytes, **totals,
            "each_real_block_owned_once": True,
            "all_coefficients_equal": True,
            "output_overlap_symbol_fraction": totals["repeated_head_symbols"] / totals["emitted_symbols"],
            "output_overlap_bit_fraction": totals["repeated_head_bits"] / totals["emitted_bits"],
            "total_symbol_attempt_ratio": (totals["speculative_symbol_attempts"] + totals["repair_symbols"] +
                                           totals["emitted_symbols"] + totals["repeated_head_symbols"]) /
                                          totals["emitted_symbols"],
            "maximum_output_worker_symbols": maximum_symbols,
            "coefficient_buffer_bytes_per_worker": maximum_storage,
            "full_coefficient_image_bytes_in_candidate": 0,
            "reference_coefficient_bytes": sum(len(p) * p.itemsize for p in planes),
            "scope": "MCU ownership, exact coefficients, and logical work; IDCT/output pixels and GPU allocation unproved"}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", action="append", required=True)
    parser.add_argument("--chunk-bytes", nargs="+", type=int, default=[1024, 4096])
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    assert all(value > 0 for value in args.chunk_bytes)
    records = [json.loads(line) for line in (ROOT.parent / "jpeg-reference/probe.log").read_text().splitlines()
               if line.startswith('{"kind":')]
    inputs = {r["name"]: bytes.fromhex(r["hex"]) for r in records if r["kind"] == "input"}
    fixture = ROOT.parents[2] / "loom/src/loom/serve/media/testdata/image_fuzz/jpeg.txt"
    inputs["existing_exif_fixture"] = base64.b64decode(fixture.read_text().strip().split(",", 1)[1], validate=True)
    small = json.loads((ROOT / "sequential-small.json").read_text())
    large = json.loads((ROOT / "sequential-large.json").read_text())
    reference = {r["name"]: r for r in [*small["exact_public_oracle_cases"],
                 *small["exact_periodic_cases"], *large["coefficient_signature_cases"]]}
    digest = lambda data: hashlib.sha256(data).hexdigest()
    assert digest((ROOT / "sequential.py").read_bytes()) == small["sources"]["sequential.py"]
    result = {"state": "Whole-MCU output ownership experiment; no GPU timing or production design selected.",
              "sources": {name: digest((ROOT / name).read_bytes()) for name in
                          ("sequential.py", "bounded.py", "recover_prefix.py", "mcu_output.py")}, "cases": []}
    for name in args.input:
        if name in inputs:
            data = inputs[name]
        elif name in ("dense-periodic", "mcu-phase"):
            data = (ROOT / (name + ".jpg")).read_bytes()
        else:
            data = (BASELINE / "inputs" / name).read_bytes()
        assert digest(data) == reference[name]["input_sha256"]
        frame = parse(data)
        planes, _ = decode(frame)
        assert [digest(p.tobytes()) for p in planes] == reference[name]["coefficient_planes_sha256"]
        case = {"name": name, "input_sha256": digest(data), "variants": []}
        for chunk in args.chunk_bytes:
            observation = evaluate(frame, planes, chunk)
            assert observation["emitted_symbols"] == reference[name]["symbols"]
            case["variants"].append(observation)
            print(json.dumps({"name": name, **observation}), flush=True)
        result["cases"].append(case)
        del frame, planes, data
        (ROOT / args.output).write_text(json.dumps(result, indent=2) + "\n")
    print("All whole-MCU outputs match; every real block has exactly one owner.", flush=True)


if __name__ == "__main__":
    main()
