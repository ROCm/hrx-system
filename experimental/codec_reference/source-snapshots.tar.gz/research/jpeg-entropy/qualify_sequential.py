"""Check the independent parser against retained public-libjpeg observations."""

import argparse
import base64
import hashlib
import json
from pathlib import Path
import struct
import sys

from sequential import decode, parse, InvalidJPEG, UnsupportedJPEG


ROOT = Path(__file__).resolve().parent
REFERENCE = ROOT.parent / "jpeg-reference"
BASELINE = ROOT.parent / "jpeg-baseline"
REPOSITORY = ROOT.parents[2]


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def coefficient_signature(frame, planes):
    """The byte-for-byte FNV signature used by the public-libjpeg CPU oracle."""
    assert sys.byteorder == "little", "oracle signature is pinned to x86-64"
    value = 14695981039346656037
    for component, plane in zip(frame.components, planes, strict=True):
        header = struct.pack("<66H", component.block_width, component.block_height,
                             *component.quantization)
        for block in (header, memoryview(plane).cast("B")):
            for byte in block:
                value = ((value ^ byte) * 1099511628211) & 0xFFFFFFFFFFFFFFFF
    return f"{value:016x}"


def observation(name, data, frame, planes, traces):
    return {
        "name": name,
        "input_sha256": sha256(data),
        "compressed_bytes": len(data),
        "dimensions": [frame.width, frame.height],
        "scans": len(frame.scans),
        "segments": len(traces),
        "symbols": sum(len(t.positions) - 1 for t in traces),
        "entropy_bits": sum(t.positions[-1] for t in traces),
        "coefficients": sum(len(p) for p in planes),
        "coefficient_planes_sha256": [sha256(p.tobytes()) for p in planes],
        "trace_payload_bytes": sum(len(t.positions) * 10 for t in traces),
    }


def small_matrix():
    rows = [json.loads(line) for line in (REFERENCE / "probe.log").read_text().splitlines()
            if line.startswith('{"kind":')]
    results = {(r["name"], r["mode"]): r for r in rows if r["kind"] == "result"}
    inputs = [(r["name"], bytes.fromhex(r["hex"])) for r in rows if r["kind"] == "input"]
    fixture = REPOSITORY / "loom/src/loom/serve/media/testdata/image_fuzz/jpeg.txt"
    inputs.append(("existing_exif_fixture", base64.b64decode(fixture.read_text().strip().split(",", 1)[1], validate=True)))
    supported, rejected = [], []
    for name, data in inputs:
        try:
            frame = parse(data)
        except UnsupportedJPEG as error:
            rejected.append({"name": name, "reason": str(error)})
            continue
        planes, traces = decode(frame, True)
        oracle = results[name, 0]
        assert oracle["complete"] and not oracle["warnings"]
        for component, plane, geometry, expected in zip(
                frame.components, planes, oracle["components"], oracle["coefficients"], strict=True):
            assert component.block_width == geometry["block_width"]
            assert component.block_height == geometry["block_height"]
            assert list(component.quantization) == expected["quantization"], name
            assert list(plane) == expected["values"], (name, component.identifier)
        row = observation(name, data, frame, planes, traces)
        row["all_coefficients_and_tables_equal"] = True
        supported.append(row)
    assert len(supported) == 15 and len(rejected) == 9
    periodic = []
    for name, ac in (("dense-periodic", -1), ("mcu-phase", 0)):
        data = (ROOT / (name + ".jpg")).read_bytes()
        frame = parse(data)
        planes, traces = decode(frame, True)
        for plane in planes:
            assert all(value == (0 if index % 64 == 0 else ac)
                       for index, value in enumerate(plane))
        row = observation(name, data, frame, planes, traces)
        row["all_constructed_coefficients_equal"] = True
        periodic.append(row)
    # These prefixes cannot contain a complete image. Exercise every byte
    # boundary across tables, stuffing, entropy, restart markers, and EOI.
    names = ("ycbcr_420", "ycbcr_420_restart_1", "ycbcr_420_separate_scans")
    truncations = 0
    for name, data in inputs:
        if name not in names:
            continue
        for length in range(len(data)):
            try:
                decode(parse(data[:length]))
            except InvalidJPEG:
                truncations += 1
            else:
                raise AssertionError((name, "accepted truncation", length))
    return {"exact_public_oracle_cases": supported,
            "explicit_process_rejections": rejected,
            "exact_periodic_cases": periodic,
            "rejected_truncated_prefixes": truncations}


def large_matrix():
    oracle = json.loads((BASELINE / "qualified.json").read_text())
    results = []
    for expected in oracle["rows"]:
        if expected["kind"] != "prepared" or ".progressive." in expected["name"]:
            continue
        name = expected["name"]
        data = (BASELINE / "inputs" / name).read_bytes()
        assert len(data) == expected["compressed_bytes"]
        frame = parse(data)
        planes, traces = decode(frame, True)
        signature = coefficient_signature(frame, planes)
        assert signature == expected["coefficient_hash"], (name, signature, expected)
        row = observation(name, data, frame, planes, traces)
        row["coefficient_signature"] = signature
        row["public_oracle_signature_equal"] = True
        results.append(row)
        print(json.dumps(row), flush=True)
        # No trace or coefficient allocation survives into the next image.
        del planes, traces, frame, data
    assert len(results) == 8
    return {"coefficient_signature_cases": results,
            "oracle_record_sha256": sha256((BASELINE / "qualified.json").read_bytes())}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("small", "large"))
    args = parser.parse_args()
    result = small_matrix() if args.mode == "small" else large_matrix()
    result["state"] = "Independent coefficient parser qualification; no GPU timing or decoder selection."
    result["sources"] = {name: sha256((ROOT / name).read_bytes())
                         for name in ("sequential.py", "qualify_sequential.py")}
    result["reference_log_sha256"] = sha256((REFERENCE / "probe.log").read_bytes())
    (ROOT / f"sequential-{args.mode}.json").write_text(json.dumps(result, indent=2) + "\n")
    print(f"Qualified {args.mode} independent sequential parser matrix.")


if __name__ == "__main__":
    main()
