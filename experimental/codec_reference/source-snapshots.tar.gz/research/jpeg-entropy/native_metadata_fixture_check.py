"""Check native test expectations against preserved, GPU-qualified metadata."""

import hashlib
import json
from pathlib import Path
import re

from device_fixture import input_bytes, read_words


notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / "device-active.json").read_text())["directory"])
source = (notes / "native_header_cases.inc").read_text()
cases = json.loads((notes / "native-header-cases.json").read_text())
arrays = {
    name: tuple(map(int, values.split(",")))
    for name, values in re.findall(
        r"static const uint(?:8|32)_t (\w+)\[\] = \{([\d,]+)\};", source
    )
}
expected = {}
for index, name in enumerate(cases["corpus"]):
    metadata = arrays[f"metadata_{index}"]
    blocks = metadata[9]
    expected[name] = {
        "table_count": metadata[0],
        "block_count": metadata[1],
        "pixel_words": metadata[2],
        "blocks": metadata[6:10],
        "geometry": metadata[10 : 10 + blocks * 8],
        "quantization": metadata[10 + blocks * 8 :],
        "tables": tuple(
            word
            for table in arrays[f"table_indices_{index}"]
            for word in arrays[f"table_{table}"]
        ),
    }

rows = []
for group in ("small", "large"):
    directory = root / ("twolevel-" + group)
    fixtures = json.loads((directory / "fixtures.json").read_text())
    for case in fixtures["cases"]:
        if case["name"] not in expected or case["scan"] or case["chunk_bytes"] != 1024:
            continue
        name = case["name"]
        values = expected[name]
        encoded_hash = hashlib.sha256(input_bytes(name)).hexdigest()
        assert encoded_hash == case["input_sha256"], name
        configuration = json.loads((directory / (case["key"] + ".json")).read_text())["jpeg"]
        assert values["table_count"] == configuration["table_count"], name
        assert values["pixel_words"] == case["sizes"]["pixels"], name
        assert values["blocks"] == tuple(
            configuration[key] for key in ("layout0", "layout1", "layout2", "blocks")
        ), name
        program = (directory / (case["key"] + ".loom")).read_text()
        paths = dict(re.findall(r'%([a-z_]+) = check.file.read.npy path\("([^"]+)"\)', program))
        hashes = {}
        for binding in ("geometry", "quantization", "tables"):
            path = (directory / paths[binding]).resolve()
            assert values[binding] == read_words(path), (name, binding)
            hashes[binding] = hashlib.sha256(path.read_bytes()).hexdigest()
        rows.append({"name": name, "input_sha256": encoded_hash, "arrays": hashes})
assert len(rows) == len(cases["corpus"])

mixed_rows = []
for directory_name in ("mixed-current", "mixed-negative-base"):
    directory = root / directory_name
    stage = json.loads((directory / "stage.json").read_text())
    values = {}
    for binding in ("tables", "geometry", "quantization", "blocks"):
        path = directory / (binding + ".npy")
        assert hashlib.sha256(path.read_bytes()).hexdigest() == stage["files"][path.name]
        values[binding] = read_words(path)
    for image in stage["images"]:
        name = image["name"]
        assert hashlib.sha256(input_bytes(name)).hexdigest() == image["input_sha256"]
        metadata = expected[name]
        header = image["header"]
        assert metadata["block_count"] == header[2], name
        for binding, offset in (("tables", header[8]), ("geometry", header[9]),
                                ("quantization", header[10]), ("blocks", image["ordinal"] * 4)):
            words = metadata[binding]
            assert values[binding][offset : offset + len(words)] == words, (name, binding)
    mixed_rows.append({
        "directory": directory_name,
        "images": len(stage["images"]),
        "stage_sha256": hashlib.sha256((directory / "stage.json").read_bytes()).hexdigest(),
        "arrays": {binding: stage["files"][binding + ".npy"] for binding in values},
    })

record = {
    "passed": True,
    "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "expectations_sha256": hashlib.sha256(source.encode()).hexdigest(),
    "individual_fixtures": rows,
    "mixed_fixtures": mixed_rows,
    "scope": "Exact equality of native ASAN-test expectations and preserved device arrays; no new GPU execution or performance measurement.",
}
(notes / "native-metadata-fixture-result.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"passed": True, "individual_fixtures": len(rows),
                  "mixed_images": sum(row["images"] for row in mixed_rows)}))
