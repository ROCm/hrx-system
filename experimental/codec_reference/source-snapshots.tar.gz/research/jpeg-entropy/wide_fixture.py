"""Lift the qualified mixed cohort while preserving 128 images per completion."""
import argparse
import array
import ast
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import struct
import subprocess
import sys
import tarfile


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def payload(path):
    with path.open("rb") as stream:
        prefix = stream.read(10)
        assert prefix[:8] == b"\x93NUMPY\x01\x00"
        header = ast.literal_eval(stream.read(struct.unpack("<H", prefix[8:])[0]).decode())
        data = stream.read()
    width = {"|i1": 1, "<i4": 4}[header["descr"]]
    assert not header["fortran_order"] and len(header["shape"]) == 1
    assert len(data) == header["shape"][0] * width
    return data


def words(path):
    data = array.array("I")
    data.frombytes(payload(path))
    return data


def write_array(path, width, count, chunks):
    header = repr({"descr": "|i1" if width == 1 else "<i4",
                   "fortran_order": False, "shape": (count,)}).encode()
    header += b" " * ((64 - (10 + len(header) + 1) % 64) % 64) + b"\n"
    written = 0
    with path.open("wb") as stream:
        stream.write(b"\x93NUMPY\x01\x00" + struct.pack("<H", len(header)) + header)
        for chunk in chunks:
            stream.write(chunk)
            written += len(chunk)
    assert written == count * width, (path.name, written, count * width)


def generate(root):
    base = root / "mixed-current"
    directory = root / "mixed-wide"
    stage = json.loads((base / "stage.json").read_text())
    control = json.loads((directory / "control.json").read_text())
    assert stage == control["baseline"]
    for name, expected in stage["files"].items():
        assert digest(base / name) == expected, name
    for name, expected in control["files"].items():
        assert digest(directory / name) == expected, name
    assert stage["cohort"] == "primary" and stage["invalid_index"] is None
    assert array.array("I").itemsize == 4 and sys.byteorder == "little"
    replicas = control["images_per_cohort"] // 16
    assert replicas in (2, 4, 8)
    assert not list(directory.glob('*.npy')), 'Retire the previous candidate before replacement.'
    image_count = len(stage["images"])
    assert image_count == 16
    job_count = sum(image["jobs"] for image in stage["images"])
    tile_count = sum(image["header"][7] for image in stage["images"])
    capacity = tile_count * 4
    interval_count = job_count * 5 + image_count
    entropy_words = stage["bytes"]["entropy"] // 4
    pixel_words = stage["bytes"]["pixels"] // 4
    rgb_bytes = stage["bytes"]["rgb"]
    unchanged = {"compressed", "tables", "geometry", "quantization", "zigzag"}
    active = {"expected": job_count * 8, "bridges": job_count * 8,
              "suffixes": (job_count + image_count) * 8,
              "ranges": (job_count + image_count) * 8,
              "points": job_count * 3 * 8,
              "intervals": interval_count * 8, "status": interval_count}
    padded = {"jobs": capacity * 4, "expected": capacity * 8,
              "bridges": capacity * 8, "suffixes": (capacity + image_count) * 8,
              "ranges": (capacity + image_count) * 8, "points": capacity * 3 * 8,
              "intervals": (capacity * 5 + image_count) * 8,
              "status": capacity * 5 + image_count}
    guard = array.array("I", [17] * 8).tobytes()
    bindings = []
    byte_counts = {}
    for line in (base / "bindings.txt").read_text().splitlines():
        name, is_input, width_text, count_text, relative = line.split()
        width, count = int(width_text), int(count_text)
        source = base / relative
        target = directory / relative
        if name in unchanged:
            shutil.copyfile(source, target)
        elif name in ("entropy", "pixels", "rgb"):
            data = payload(source)
            count *= replicas
            write_array(target, width, count, (data for _ in range(replicas)))
        elif name in active:
            data = words(source)
            assert len(data) == padded[name] + 8
            assert all(value == 17 for value in data[active[name]:])
            data = data[:active[name]].tobytes()
            tail = array.array("I", [17] * ((padded[name] - active[name]) * replicas + 8)).tobytes()
            count = padded[name] * replicas + 8
            write_array(target, width, count, [data] * replicas + [tail])
        else:
            original = words(source)
            assert original[-8:].tobytes() == guard
            original = original[:-8]
            result = array.array("I")
            if name == "schedule":
                jobs = job_count * replicas
                intervals = interval_count * replicas
                images = image_count * replicas
                result.extend([jobs, (jobs + 127) // 128, 1, 1,
                               (intervals + 32 * images - 1) // (32 * images),
                               images, 1, intervals])
            elif name == "color_schedule":
                assert len(original) == 1 and original[0] * replicas <= 1048576
                result.append(original[0] * replicas)
            else:
                if name == "jobs":
                    assert all(value == 17 for value in original[job_count * 4:])
                    original = original[:job_count * 4]
                for replica in range(replicas):
                    data = array.array("I", original)
                    if name == "headers":
                        assert len(data) == image_count * 18
                        for image in range(image_count):
                            for field, stride in ((3, pixel_words), (5, entropy_words),
                                                  (6, tile_count), (14, rgb_bytes)):
                                data[image * 18 + field] += replica * stride
                    elif name == "segments":
                        assert len(data) == image_count * 8
                        for image in range(image_count):
                            for field, stride in ((0, entropy_words), (2, job_count),
                                                  (5, job_count + image_count), (7, pixel_words)):
                                data[image * 8 + field] += replica * stride
                    elif name == "jobs":
                        for job in range(job_count):
                            data[job * 4] += replica * entropy_words
                            data[job * 4 + 3] += replica * image_count
                    elif name == "color_tiles":
                        for tile in range(len(data) // 3):
                            data[tile * 3] += replica * image_count
                    else:
                        assert name in {"blocks", "records", "prefixes", "errors", "validity"}, name
                    result.extend(data)
                if name == "jobs":
                    result.extend([17] * ((capacity - job_count) * 4 * replicas))
            result.extend([17] * 8)
            count = len(result)
            write_array(target, width, count, [result.tobytes()])
        byte_counts[name] = count * width
        bindings.append(f"{name} {is_input} {width} {count} {relative}")
        print(json.dumps({"array": name, "bytes": count * width}), flush=True)
    assert sum(byte_counts.values()) < 4 * 1024**3
    (directory / "bindings.txt").write_text("\n".join(bindings) + "\n")
    images = []
    headers = words(directory / "headers.npy")
    for replica in range(replicas):
        for original in stage["images"]:
            image = dict(original)
            image["ordinal"] += replica * image_count
            image["header"] = list(headers[image["ordinal"] * 18:(image["ordinal"] + 1) * 18])
            images.append(image)
    files = {name: digest(directory / name) for name in stage["files"]}
    result = {**stage, "cohort": "wide-primary", "images": images,
              "files": files, "bytes": byte_counts,
              "baseline_stage_sha256": digest(base / "stage.json"),
              "generator_sha256": digest(Path(__file__)), "replicas": replicas,
              "scope": f"Each decode contains {image_count * replicas} images; the authored batch repeats it {8 // replicas} times. Immutable compressed/table/geometry inputs shared; output and scratch disjoint within each decode and reused between serial decodes. Expectations derive only from the qualified independent baseline."}
    (directory / "stage.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"fixture_bytes": sum(byte_counts.values()), "images": len(images),
                      "jobs": job_count * replicas}), flush=True)


def stage(image_count):
    notes = Path(__file__).resolve().parent
    root = Path(json.loads((notes / "device-active.json").read_text())["directory"])
    base, directory = root / "mixed-current", root / "mixed-wide"
    baseline = json.loads((base / "stage.json").read_text())
    checked = json.loads((notes / "gorgon4-mixed-primary-access.json").read_text())
    assert checked["returncode"] == 0 and checked["stage"] == baseline
    directory.mkdir(exist_ok=True)
    metadata = ["library.loom", "mixed_pipeline.cxx", "mixed_image.h", "mixed_cursor.h"]
    for name in metadata:
        assert digest(base / name) == baseline["files"][name]
        shutil.copyfile(base / name, directory / name)
    program = (base / "summary.loom").read_text()
    assert program.count("%eight = index.constant 8 : index") == 1
    program = program.replace("%eight = index.constant 8 : index", f"%limit = index.constant {128 // image_count} : index")
    program = program.replace("to %eight step", "to %limit step")
    (directory / "summary.loom").write_text(program)
    configuration = json.loads((base / "config.json").read_text())
    assert configuration["jpeg"]["segments"] == 16
    configuration["jpeg"]["segments"] = image_count
    (directory / "config.json").write_text(json.dumps(configuration, indent=2) + "\n")
    tag = Path(json.loads(os.environ["BUREAU_TAG_ROOTS"])["codec-jpeg-rebased-tools"])
    linker = tag / "loom/src/loom/tools/loom-link/loom-link"
    subprocess.run([str(linker), str(directory / "summary.loom"), str(directory / "library.loom"),
                    "--to=bc", "--output=" + str(directory / "summary.loombc")], check=True)
    metadata += ["summary.loom", "summary.loombc", "config.json"]
    control = {"baseline": baseline, "images_per_cohort": image_count, "files": {name: digest(directory / name) for name in metadata},
               "linker_sha256": digest(linker)}
    (directory / "control.json").write_text(json.dumps(control, indent=2) + "\n")
    metadata.append("control.json")
    files = {"mixed-wide/" + name: directory / name for name in metadata}
    files["wide_fixture.py"] = Path(__file__).resolve()
    process = subprocess.Popen(["ssh", "hrx-gorgon-4", "tar -xf - -C " + shlex.quote(str(root))], stdin=subprocess.PIPE)
    with tarfile.open(fileobj=process.stdin, mode="w|", dereference=True) as archive:
        for name, path in files.items(): archive.add(path, arcname=name, recursive=False)
    process.stdin.close()
    assert process.wait() == 0
    subprocess.run(["ssh", "hrx-gorgon-4", shlex.join(["python3", "-B", str(root / "wide_fixture.py"), "--remote", str(root)])], check=True)
    result = subprocess.check_output(["ssh", "hrx-gorgon-4", "cat " + shlex.quote(str(directory / "stage.json"))])
    (directory / "stage.json").write_bytes(result)
    (notes / f"mixed-{image_count}-stage.json").write_bytes(result)


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "--remote": generate(Path(sys.argv[2]))
    else:
        parser = argparse.ArgumentParser()
        parser.add_argument('--images', type=int, choices=(32, 64, 128), required=True)
        stage(parser.parse_args().images)
