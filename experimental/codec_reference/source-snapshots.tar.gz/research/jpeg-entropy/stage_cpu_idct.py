"""Pin and stage the two public CPU alternatives, including complete IDCT ISA."""
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import tarfile

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
tag = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['codec-jpeg-cpu-idct']) / 'experimental/codec_reference/research/jpeg-entropy'
files = {'cpu-idct/comparison.py': notes / 'cpu_idct_comparison.py',
         'cpu-idct/source.json': notes / 'cpu-idct-source.json'}
record = {}
for name, symbol in (('cpu_float_baseline', 'jsimd_idct_float_sse2'), ('cpu_fast_baseline', 'jsimd_idct_ifast_sse2')):
    binary = tag / name
    files['cpu-idct/' + name] = binary
    symbols = subprocess.check_output(['/home/ben/tools/llvm/latest/bin/llvm-nm', '--numeric-sort', '--defined-only', str(binary)], text=True).splitlines()
    index = next(index for index, row in enumerate(symbols) if row.split()[-1] == symbol)
    start = int(symbols[index].split()[0], 16)
    end = next(int(row.split()[0], 16) for row in symbols[index + 1:] if
               not row.split()[-1].startswith(symbol + '.') and int(row.split()[0], 16) > start)
    assembly = subprocess.check_output(['/home/ben/tools/llvm/latest/bin/llvm-objdump', '-d',
        '--start-address=' + str(start), '--stop-address=' + str(end), str(binary)], text=True)
    (notes / (name + '.native.s')).write_text(assembly)
    record[name] = {'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
                    'symbol': symbol, 'start': start, 'end': end,
                    'native_sha256': hashlib.sha256(assembly.encode()).hexdigest()}
(notes / 'cpu-idct-native.json').write_text(json.dumps(record, indent=2) + '\n')
process = subprocess.Popen(['ssh', 'hrx-gorgon-4', 'tar -xf - -C ' + shlex.quote(str(root))], stdin=subprocess.PIPE)
with tarfile.open(fileobj=process.stdin, mode='w|', dereference=True) as archive:
    for name, path in files.items(): archive.add(path, arcname=name, recursive=False)
process.stdin.close()
assert process.wait() == 0
verification = {'files': {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in files.items()}}
code = 'import hashlib,json,pathlib,sys; root=pathlib.Path(sys.argv[1]); pairs=json.loads(sys.argv[2]); assert all(hashlib.sha256((root/name).read_bytes()).hexdigest()==digest for name,digest in pairs.items())'
subprocess.run(['ssh', 'hrx-gorgon-4', shlex.join(['python3', '-B', '-c', code, str(root), json.dumps(verification['files'])])], check=True)
(notes / 'cpu-idct-stage.json').write_text(json.dumps(verification, indent=2) + '\n')
print('CPU variants and comparator staged and verified.', flush=True)
