"""Matched table-placement windows; every sample queues eight batch dispatches."""
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
assert os.environ['BENCHMARK_LOCK_LEASE_ID']
tools = json.loads((root / 'unsigned-tools.json').read_text())
programs = {row['program']: row['sha256']
            for row in json.loads((root / 'tables-linked.json').read_text())}
forward = [('4k-global', 'batch16', 0), ('4k-shared', 'batch16', 1),
           ('1k-global', 'batch16-1024', 0), ('1k-shared', 'batch16-1024', 1)]
for window, cases in [('forward', forward), ('reverse', list(reversed(forward)))]:
    for name, fixture, cache in cases:
        program = fixture + '/tables-summary.loombc'
        command = [sys.executable, str(root / 'device_batch_benchmark.py'),
                   '--fixture=' + fixture,
                   '--result-name=entropy-tables-' + name + '-' + window,
                   '--runner=iree-benchmark-loom-unsigned',
                   '--runner-sha256=' + tools['files']['iree-benchmark-loom-unsigned'],
                   '--program=' + program, '--program-sha256=' + programs[program],
                   '--cache-tables=' + str(cache)]
        subprocess.run(command, check=True)
