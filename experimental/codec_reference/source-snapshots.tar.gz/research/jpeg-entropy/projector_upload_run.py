"""Remote bounded correctness execution; the caller owns the foreground lease."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

directory = Path(sys.argv[1])
record = {"cases": []}
for name, compressed in (("control", False), ("candidate", True)):
    command = ["stdbuf", "-oL", "-eL", str(directory / "codec_projector_upload_probe"),
               "--jpeg_fixture=" + str(directory), "--compressed=" + str(compressed).lower(),
               "--gtest_filter=ProjectorUploadTest.TrainedFeaturesAndPeers",
               "--amdgpu_asan=true", "--amdgpu_asan_report_policy=fail-device"]
    print("Starting " + name, flush=True)
    start = time.monotonic()
    with (directory / (name + ".log")).open("w") as stream:
        result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT)
    log = (directory / (name + ".log")).read_bytes()
    record["cases"].append({"name": name, "command": command, "returncode": result.returncode,
                            "correctness_wall_seconds": time.monotonic() - start,
                            "log_sha256": hashlib.sha256(log).hexdigest(),
                            "rows": [json.loads(line) for line in log.decode().splitlines() if line.startswith('{"phase":')]})
    (directory / "execution.json").write_text(json.dumps(record, indent=2) + "\n")
    print(log.decode()[-4000:], flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
baseline = directory / "baseline.features"
candidate = directory / "candidate.features"
assert baseline.stat().st_size == candidate.stat().st_size == 19906560
assert baseline.read_bytes() == candidate.read_bytes()
record["features"] = {path.name: {"bytes": path.stat().st_size,
    "sha256": hashlib.file_digest(path.open("rb"), "sha256").hexdigest()} for path in (baseline, candidate)}
record["passed"] = True
(directory / "execution.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"passed": True, "features": record["features"]}), flush=True)
