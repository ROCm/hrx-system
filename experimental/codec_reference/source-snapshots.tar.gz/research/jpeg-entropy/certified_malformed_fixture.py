"""Exercise the certificate consumer at real malformed entropy boundaries."""
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import struct

from device_fixture import input_bytes, read_words, table_words, write_words
from sequential import decode, InvalidJPEG, parse

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes/'device-active.json').read_text())['directory'])
directory = root/'certified-malformed'
directory.mkdir(exist_ok=True)
source = root/'partitions4-small'
pattern = re.compile(r'%([a-z_]+) = check.file.read.npy path\("([^"]+)"\) : tensor<(\d+)xi32>')
cases = []
all_files = set()
declarations = [
    ('jpeg_speculate',('entropy','jobs','tables','blocks','expected','points')),
    ('jpeg_bridge',('entropy','jobs','tables','blocks','expected','bridges')),
    ('jpeg_index',('segments','expected','suffixes','ranges','intervals')),
    ('jpeg_certify',('segments','expected','bridges','suffixes','ranges','intervals')),
    ('jpeg_intervals',('segments','expected','suffixes','ranges','points','intervals')),
    ('jpeg_reconstruct',('entropy','segments','tables','blocks','intervals','geometry','quantization','zigzag','pixels','status')),
]
outputs = ('expected','points','bridges','suffixes','ranges','intervals','pixels','status')

def emit(name,mutation,frame,expected_error):
    try:
        decode(frame)
    except InvalidJPEG as error:
        assert str(error)==expected_error,(name,mutation,str(error),expected_error)
    else:
        raise AssertionError((name,mutation,'independent decoder accepted malformed input'))
    assert len(frame.scans)==1
    scan=frame.scans[0]
    key=name+'-'+mutation
    template=source/(name+'-scan0-chunk256.loom')
    paths={m[1]:(source/m[2]).resolve() for m in pattern.finditer(template.read_text())}
    sizes={m[1]:int(m[3]) for m in pattern.finditer(template.read_text())}
    tables=[];table_indices={};blocks=[]
    for block in scan.blocks:
        indices=[]
        for table in (block.dc,block.ac):
            identity=tuple(sorted(table.symbols.items()))
            if identity not in table_indices:
                table_indices[identity]=len(tables)//832
                tables.extend(table_words(table))
            indices.append(table_indices[identity])
        blocks.append(block.component|(indices[0]<<8)|(indices[1]<<16))
    entropy=[];jobs=[];segments=[];records=0
    for segment in scan.segments:
        offset=len(entropy)
        padded=segment.data+bytes((-len(segment.data))%4+8)
        entropy.extend(struct.unpack('>'+'I'*(len(padded)//4),padded))
        count=(len(segment.data)+255)//256
        assert count>0
        first_job=len(jobs)//3
        segments.extend((offset,len(segment.data)*8,first_job,count,
                         segment.mcu_count*len(blocks),records,segment.first_mcu,0))
        records+=count+1
        for index in range(count):jobs.extend((offset,len(segment.data)*8,index))
    count=len(jobs)//3
    components=len(frame.components)
    sizes.update(expected=count*((5+components+3)&~3),
                 points=count*3*((3+components+3)&~3),
                 bridges=count*((2+components+3)&~3),
                 suffixes=records*((2+components+3)&~3),
                 ranges=records*((2+components+3)&~3),
                 intervals=(count*5+len(scan.segments))*((4+components+3)&~3),
                 status=count*5+len(scan.segments))
    for variable,values in {'entropy':entropy,'jobs':jobs,'tables':tables,'blocks':blocks,'segments':segments}.items():
        paths[variable]=directory/(key+'-'+variable+'.npy')
        write_words(paths[variable],values)
        sizes[variable]=len(values)
    inputs=('entropy','jobs','tables','blocks','segments','geometry','quantization','zigzag')
    lines=['kernel.decl @'+entry+'() launch('+', '.join('%'+name+': buffer' for name in names)+')'
           for entry,names in declarations]
    lines+=['','check.case @malformed {']
    for variable in inputs:
        lines.append(f'  %{variable} = check.file.read.npy path("{os.path.relpath(paths[variable],directory)}") : tensor<{sizes[variable]}xi32>')
        all_files.add(paths[variable])
    for variable in outputs:
        lines.append(f'  %{variable}_output = check.generate.fill value(17) : tensor<{sizes[variable]}xi32>')
    for entry,names in declarations:
        arguments=', '.join('%'+name+('_output' if name in outputs else '') for name in names)
        types=', '.join(f'tensor<{sizes[name]}xi32>' for name in names)
        lines.append(f'  kernel.launch @{entry}({arguments}) : ({types})')
    for variable in ('pixels','status','intervals'):
        lines.append(f'  check.file.write.npy value(%{variable}_output) path("{key}-{variable}.npy") mode(always) : tensor<{sizes[variable]}xi32>')
    lines+=['  check.return','}']
    (directory/(key+'.loom')).write_text('\n'.join(lines)+'\n')
    config={'jpeg':{'chunks':count,'chunk_bytes':256,'blocks':len(blocks),'components':components,
                    'segments':len(scan.segments),'table_count':len(tables)//832,'cache_tables':0,
                    'mcu_width':scan.mcu_width,'output_partitions':4}}
    (directory/(key+'.json')).write_text(json.dumps(config,indent=2)+'\n')
    cases.append({'key':key,'independent_error':expected_error,'components':components,
                  'jobs':count,'segments':len(scan.segments),'sizes':sizes,
                  'source_sha256':hashlib.sha256(input_bytes(name)).hexdigest()})

for name in ('ycbcr_420','rgb_sequential','cmyk_sequential'):
    original=parse(input_bytes(name))
    segment=original.scans[0].segments[0]
    for divisor in (2,10):
        frame=copy.deepcopy(original)
        target=frame.scans[0].segments[0]
        target.data=target.data[:len(target.data)-len(target.data)//divisor]
        emit(name,'truncate-'+str(divisor),frame,'truncated entropy/amplitude')
    for offset,label in ((0,'first'),(len(segment.data)*3//4,'late')):
        frame=copy.deepcopy(original)
        target=frame.scans[0].segments[0]
        target.data=target.data[:offset]+bytes([255]*8)+target.data[offset+8:]
        # The independent parser determines whether the damaged run or its
        # absolute predictor fails first; either is an actual entropy error.
        try:decode(frame)
        except InvalidJPEG as error:expected=str(error)
        else:raise AssertionError((name,label,'mutation remained valid'))
        emit(name,'ones-'+label,frame,expected)
for name in ('ycbcr_420','grayscale'):
    frame=parse(input_bytes(name));target=frame.scans[0].segments[-1]
    target.data=target.data[:-1]+bytes([target.data[-1]&254])
    emit(name,'padding',frame,'non-ones entropy padding')
for value,label in ((0xF1,'ac-run'),(0xF0,'zrl-run')):
    frame=parse(input_bytes('dense-periodic'))
    for block in frame.scans[0].blocks:block.ac.symbols={2:value}
    emit('dense-periodic',label,frame,'AC run exceeds block' if value==0xF1 else 'ZRL exceeds block')
frame=parse(input_bytes('dense-periodic'))
for block in frame.scans[0].blocks:block.dc.symbols={2:11}
emit('dense-periodic','dc-range',frame,'DC outside 8-bit DCT range')
all_files.update(p for p in directory.iterdir() if p.is_file())
result={'cases':cases,'files':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in all_files},
        'sources':{name:hashlib.sha256((notes/name).read_bytes()).hexdigest() for name in
                   ('certified_malformed_fixture.py','sequential.py','device_fixture.py')},
        'scope':'Seventeen independently rejected entropy mutations; all six GPU stages execute on header-derived records. Compare every produced pixel, status, and interval against the checked consumer. Header-marker admission is outside this witness.'}
(directory/'stage.json').write_text(json.dumps(result,indent=2)+'\n')
(notes/'certified-malformed-stage.json').write_text(json.dumps(result,indent=2)+'\n')
print(len(cases),'independently rejected entropy cases',flush=True)
