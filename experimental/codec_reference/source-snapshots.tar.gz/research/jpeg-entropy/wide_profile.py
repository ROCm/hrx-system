"""Pair dispatch timestamps for both qualified GPU submission shapes."""
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys


def qualify_retirement(record):
    # KFD can retain a sysfs entry after waitpid has reaped its owning process.
    # Only our completed, absent children qualify; a foreign/live owner fails.
    owned = {str(row["pid"]) for row in record["rows"]}
    assert not record["after"]["drm"]
    assert set(record["after"]["kfd_processes"]) <= owned
    assert all(record["after_processes"][process_id] is None
               for process_id in record["after"]["kfd_processes"])


def run(root):
    assert os.environ["BENCHMARK_LOCK_LEASE_ID"]
    directory = root / "wide-comparison"
    manifest = json.loads((directory / "manifest.json").read_text())
    for name, expected in manifest["files"].items():
        with (root / name).open("rb") as stream:
            assert hashlib.file_digest(stream, "sha256").hexdigest() == expected, name
    tree = ast.parse((root / "cpu-current/machine-state.py").read_text())
    node = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "state")
    namespace = dict(globals())
    exec(compile(ast.Module(body=[node], type_ignores=[]), "machine-state.py", "exec"), namespace)
    state = namespace["state"]
    before = state()
    assert before["governor"] == "performance" and before["gpu_policy"] == "high"
    assert not before["kfd_processes"] and not before["drm"] and before["gpu_busy"] == 0
    record = {"before": before, "rows": [], "scope": "Separate diagnostic profiles; 128 images per replay, one completion. All timestamps normalized per sixteen images."}
    output = directory / "profiles.json"
    for ordinal, shape in enumerate(("serial", "wide", "wide", "serial")):
        repetitions = 8 if shape == "serial" else 1
        fixture = "mixed-current" if shape == "serial" else "mixed-wide"
        command = [str(root / "codec_command_probe"), "--jpeg_fixture=" + str(root / fixture),
                   "--gtest_filter=JpegCommandTest.CompressedToRgb", "--jpeg_profile=true",
                   "--jpeg_repetitions=" + str(repetitions)]
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        stdout, stderr = process.communicate()
        result = subprocess.CompletedProcess(command, process.returncode, stdout, stderr)
        (directory / ("profile-" + str(ordinal) + "-" + shape + ".log")).write_text(result.stdout + result.stderr)
        assert result.returncode == 0, result.stdout + result.stderr
        rows = [json.loads(line) for line in result.stdout.splitlines() if line.startswith('{"phase":')]
        assert sum(row["phase"] == "exact" for row in rows) == 52
        profiles = [row for row in rows if row["phase"] == "profile"]
        for row in profiles:
            if not row["function"].startswith("__"):
                assert row["samples"] == repetitions
        stage_ms = {row["function"]: row["total_ns"] / 8e6 for row in profiles if not row["function"].startswith("__")}
        record["rows"].append({"shape": shape, "pid": process.pid, "command": command, "result": rows, "stage_ms": stage_ms})
        output.write_text(json.dumps(record, indent=2) + "\n")
        print(json.dumps({"shape": shape, "stage_ms": stage_ms}), flush=True)
    record["after"] = state()
    record["after_processes"] = {}
    for process_id in record["after"]["kfd_processes"]:
        path = Path('/proc') / process_id / 'comm'
        try:
            record["after_processes"][process_id] = path.read_text().strip()
        except FileNotFoundError:
            record["after_processes"][process_id] = None
    output.write_text(json.dumps(record, indent=2) + "\n")
    qualify_retirement(record)


def stage():
    notes = Path(__file__).resolve().parent
    root = Path(json.loads((notes / "device-active.json").read_text())["directory"])
    source = Path(__file__).resolve()
    destination = root / "wide-comparison/profile.py"
    subprocess.run(["scp", str(source), "hrx-gorgon-4:" + str(destination)], check=True)
    remote_hash = subprocess.check_output(["ssh", "hrx-gorgon-4", "sha256sum " + shlex.quote(str(destination))], text=True).split()[0]
    assert remote_hash == hashlib.sha256(source.read_bytes()).hexdigest()
    command = ["/home/benvanik/.dotfiles/bin/benchmark-lock", "--label=codec-jpeg-wide-profiles", "--",
               "timeout", "--signal=INT", "--kill-after=10s", "300s", "env", "LD_LIBRARY_PATH=/opt/rocm/lib",
               "python3", "-B", str(destination), "--remote", str(root)]
    with (notes / "gorgon4-wide-profiles.log").open("w") as stream:
        result = subprocess.run(["ssh", "hrx-gorgon-4", shlex.join(command)], stdout=stream, stderr=subprocess.STDOUT)
    status = subprocess.run(["ssh", "hrx-gorgon-4", "~/.dotfiles/bin/benchmark-lock --status"], capture_output=True, text=True)
    receipt = {"command": command, "returncode": result.returncode, "broker_status_after": status.stdout + status.stderr,
               "source_sha256": remote_hash}
    (notes / "gorgon4-wide-profiles-run.json").write_text(json.dumps(receipt, indent=2) + "\n")
    output = subprocess.check_output(["ssh", "hrx-gorgon-4", "cat " + shlex.quote(str(root / "wide-comparison/profiles.json"))])
    (notes / "gorgon4-wide-profiles.json").write_bytes(output)
    assert result.returncode == 0 and status.returncode == 0
    print((notes / "gorgon4-wide-profiles.log").read_text(), end="")
    print(status.stdout + status.stderr, end="", flush=True)


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "--remote": run(Path(sys.argv[2]))
    else:
        assert len(sys.argv) == 1
        stage()
