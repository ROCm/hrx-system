"""Compare per-block entropy rendezvous with continuous symbol advancement."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
tags = json.loads(os.environ['BUREAU_TAG_ROOTS'])
base = Path(tags['codec-jpeg-rebased-tools'])
native = Path(tags['codec-jpeg-unsigned-opt'])
source = (notes / 'device_reconstruct_wide_store_checksum.cxx').read_text()
first = source.index('      while (cursor.blocks < total_blocks')
last = source.index('    if (interval == count * 2', first)
source = source[:first] + '''      unsigned checksum = 0;
      while (cursor.blocks < total_blocks && cursor.error == 0 &&
             (cursor.position < entry[1] || cursor.block_index != 0 || cursor.coefficient != 0)) {
        unsigned block = cursor.block_index;
        unsigned completed = cursor.blocks;
        Symbol symbol = output_symbol(words, tables, blocks, bit_limit, cursor);
        cursor = symbol.cursor;
        if (symbol.index != 0xffffffffu && cursor.error == 0) {
          unsigned natural = zigzag[symbol.index];
          unsigned component = blocks[block] & 255;
          unsigned components = component_count;
          loom::assume(natural < 64u);
          loom::assume(component < components);
          unsigned step = quantization[component * 64 + natural];
          loom::assume(step <= 65535u);
          checksum ^= static_cast<unsigned>(symbol.value * static_cast<int>(step));
        }
        if (cursor.coefficient == 0 && cursor.error == 0) {
          unsigned mcu = descriptor[6] + completed / blocks_per_mcu;
          unsigned mcu_row = mcu / scan_mcu_width;
          unsigned mcu_column = mcu % scan_mcu_width;
          const unsigned* shape = geometry + block * 8;
          unsigned column = mcu_column * shape[3] + shape[5];
          unsigned row = mcu_row * shape[4] + shape[6];
          if (column < shape[1] && row < shape[2]) {
            unsigned offset = descriptor[7] + shape[0] + (row * shape[1] + column) * 16;
            [[loom::unroll]]
            for (unsigned index = 0; index < 4; ++index) {
              reinterpret_cast<PackedOutput*>(pixels + offset)[index] = {checksum, checksum, checksum, checksum};
            }
          }
          checksum = 0;
        }
      }
    }
''' + source[last:]
name = 'continuous-checksum'
(notes / 'device_reconstruct_continuous_checksum.cxx').write_text(source)
pipeline = (notes / 'device_output_pipeline.cxx').read_text().replace(
    'device_reconstruct.cxx', 'device_reconstruct_continuous_checksum.cxx')
(notes / 'device_continuous_checksum_pipeline.cxx').write_text(pipeline)
library = root / ('entropy-' + name + '.loombc')
commands = [
    [str(base / 'loom/src/loom/tools/loom-import-cxx/loom-import-cxx'),
     str(notes / 'device_continuous_checksum_pipeline.cxx'), '--output=' + str(root / ('entropy-' + name + '.loom'))],
    [str(base / 'loom/src/loom/tools/loom-link/loom-link'), str(root / ('entropy-' + name + '.loom')),
     '--to=bc', '--output=' + str(library)],
    [str(native / 'loom/src/loom/tools/loom-compile/loom-compile'), str(library),
     '--root=jpeg_reconstruct', '--target=amdgpu:gfx1151',
     '--config-file=' + str(root / 'output-config.json'),
     '--output=' + str(root / ('jpeg_reconstruct-' + name + '.hsaco')),
     '--compile-report=details', '--compile-report-output=' + str(root / (name + '-report.json'))]]
for command in commands:
    subprocess.run(command, check=True)
metrics = json.loads((root / (name + '-report.json')).read_text())['entries']['rows'][0]
metrics = {key: metrics[key] for key in ('instruction_count', 'code_byte_count',
           'private_memory_bytes', 'local_memory_bytes', 'target_resources')}
print(json.dumps(metrics), flush=True)
original = root / 'wide-store-checksum-batch16-1024'
fixture = root / (name + '-batch16-1024')
fixture.mkdir(exist_ok=True)
text = (original / 'summary.loom').read_text()
paths = {}
def relocate(match):
    path = (original / match[1]).resolve()
    relative = os.path.relpath(path, fixture)
    paths[relative] = path
    return 'check.file.read.npy path("' + relative + '")'
text = re.sub(r'check.file.read.npy path\("([^"]+)"\)', relocate, text)
(fixture / 'summary.loom').write_text(text)
(fixture / 'config.json').write_bytes((original / 'config.json').read_bytes())
command = [str(base / 'loom/src/loom/tools/loom-link/loom-link'), str(fixture / 'summary.loom'),
           str(library), '--to=bc', '--output=' + str(fixture / 'summary.loombc')]
subprocess.run(command, check=True)
commands.append(command)
stage = json.loads((original / 'stage.json').read_text())
stage['files'] = {relative: hashlib.sha256(path.read_bytes()).hexdigest() for relative, path in paths.items()}
stage['files'].update({path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                      for path in fixture.iterdir() if path.is_file() and path.name != 'stage.json'})
stage['library'] = {'path': library.name, 'sha256': hashlib.sha256(library.read_bytes()).hexdigest()}
stage['scope'] = 'Diagnostic only: exact wide-store checksums with a continuous symbol loop instead of a per-block parsing loop. Same owned MCUs and bytes; not JPEG samples.'
stage['link_command'] = command
(fixture / 'stage.json').write_text(json.dumps(stage, indent=2) + '\n')
record = {'commands': commands, 'stage': stage, 'metrics': metrics,
          'native_sha256': hashlib.sha256((root / ('jpeg_reconstruct-' + name + '.hsaco')).read_bytes()).hexdigest(),
          'sources': {filename: hashlib.sha256((notes / filename).read_bytes()).hexdigest() for filename in
                      ('device_output_continuous.py', 'device_reconstruct_continuous_checksum.cxx',
                       'device_continuous_checksum_pipeline.cxx', 'device_entropy_cursor.h')}}
(notes / ('device-output-' + name + '.json')).write_text(json.dumps(record, indent=2) + '\n')
print('Continuous-symbol diagnostic ready', flush=True)
