#include "device_entropy_cursor_twolevel.h"
static LOOM_FORCE_INLINE Codeword reference_codeword(const unsigned* words,
                                         const unsigned* table, unsigned limit,
                                         Cursor cursor) {
  Read input = peek(words, cursor);
  cursor = input.cursor;
  unsigned bits = input.value;
  unsigned packed = table[bits >> 23];
  unsigned length = packed >> 8;
  unsigned symbol = packed & 255;
  if (length == 0) {
    unsigned prefix = bits >> 16;
    for (unsigned candidate = 10; candidate <= 16 && length == 0; ++candidate) {
      unsigned value = prefix >> (16 - candidate);
      unsigned first = table[512 + candidate * 3];
      unsigned count = table[513 + candidate * 3];
      if (value >= first && value - first < count) {
        unsigned base = table[514 + candidate * 3];
        unsigned symbol_index = base + value - first;
        // Verified canonical tables contain at most 256 symbols.
        loom::assume(symbol_index < 256u);
        symbol = table[563 + symbol_index];
        length = candidate;
      }
    }
  }
  unsigned consumed = length ? length : 16;
  unsigned available = limit - cursor.position;
  unsigned remaining = cursor.budget - cursor.reads;
  if (consumed > available || consumed > remaining) {
    unsigned taken = minimum(consumed, minimum(available, remaining));
    cursor.position += taken;
    cursor.reads += taken;
    cursor.error = remaining <= available ? 2 : 1;
  } else {
    cursor.position += consumed;
    cursor.reads += consumed;
    if (length == 0) cursor.error = 1;
  }
  return {cursor, symbol, bits, length};
}

static LOOM_FORCE_INLINE Symbol reference_advance(const unsigned* words,
                                     const unsigned* tables,
                                     const unsigned* blocks, unsigned limit,
                                     Cursor cursor) {
  unsigned output_index = 0xffffffffu;
  int output_value = 0;
  // The cursor advances cyclically through the scan's verified block order.
  unsigned block_index = cursor.block_index;
  unsigned block_count = blocks_per_mcu;
  loom::assume(block_index < block_count);
  unsigned descriptor = blocks[block_index];
  unsigned table_index = cursor.coefficient == 0 ? (descriptor >> 8) & 255
                                               : descriptor >> 16;
  // Header preparation resolves every block to a table in this allocation.
  unsigned available_tables = table_count;
  loom::assume(table_index < available_tables);
  Codeword decoded = reference_codeword(words, tables + table_index * 832, limit, cursor);
  cursor = decoded.cursor;
  unsigned symbol = decoded.value;
  if (cursor.error == 0) {
    if (cursor.coefficient == 0) {
      Read value = amplitude(decoded.lookahead, decoded.length, symbol, limit, cursor);
      cursor = value.cursor;
      if (cursor.error == 0) {
        unsigned component = descriptor & 255;
        cursor.predictors[component] += static_cast<int>(value.value);
        cursor.coefficient = 1;
        output_index = 0;
        output_value = cursor.predictors[component];
      }
    } else {
      unsigned category = symbol & 15;
      unsigned run = symbol >> 4;
      if (category == 0) {
        if (run == 0) {
          cursor.coefficient = 0;
        } else {
          unsigned next = cursor.coefficient + 16;
          if (next > 64) cursor.error = 1;
          cursor.coefficient = next & 63;
        }
      } else {
        unsigned index = cursor.coefficient + run;
        if (index >= 64) {
          cursor.error = 1;
        } else {
          Read value = amplitude(decoded.lookahead, decoded.length, category, limit, cursor);
          cursor = value.cursor;
          cursor.coefficient = (index + 1) & 63;
          if (cursor.error == 0) {
            output_index = index;
            output_value = static_cast<int>(value.value);
          }
        }
      }
      if (cursor.error == 0 && cursor.coefficient == 0) {
        ++cursor.blocks;
        ++cursor.block_index;
        if (cursor.block_index == blocks_per_mcu) cursor.block_index = 0;
      }
    }
  }
  return {cursor, output_index, output_value};
}




[[loom::config("jpeg.probes")]]
extern const unsigned probe_count;

static loom::kernel::configuration configure_probe() {
  return {{(probe_count + 127) / 128, 1, 1}, {128, 1, 1}};
}

static LOOM_FORCE_INLINE unsigned difference(Cursor left, Cursor right) {
  unsigned result = 0;
  result |= static_cast<unsigned>(left.position != right.position);
  result |= static_cast<unsigned>(left.reads != right.reads) << 1;
  result |= static_cast<unsigned>(left.budget != right.budget) << 2;
  result |= static_cast<unsigned>(left.blocks != right.blocks) << 3;
  result |= static_cast<unsigned>(left.block_index != right.block_index) << 4;
  result |= static_cast<unsigned>(left.coefficient != right.coefficient) << 5;
  result |= static_cast<unsigned>(left.error != right.error) << 6;
  result |= static_cast<unsigned>(left.cached_word != right.cached_word) << 7;
  result |= static_cast<unsigned>(left.cached_bits != right.cached_bits) << 8;
  [[loom::unroll]]
  for (unsigned component = 0; component < 4; ++component) {
    result |= static_cast<unsigned>(left.predictors[component] != right.predictors[component]) << (9 + component);
  }
  return result;
}

[[loom::kernel(configure_probe)]]
void transition_probe(const unsigned* entropy, const unsigned* tables,
    const unsigned* blocks, const unsigned* states, const unsigned* twolevel_tables, unsigned* output) {
  unsigned index = loom::kernel::workgroup::id.x * 128 + loom::kernel::workitem::id.x;
  if (index >= probe_count) return;
  const unsigned* state = states + index * 12;
  Cursor left = {};
  left.position = state[0];
  unsigned limit = state[1];
  left.reads = state[2];
  left.budget = state[3];
  left.blocks = state[4];
  left.block_index = state[5];
  left.coefficient = state[6];
  [[loom::unroll]]
  for (unsigned component = 0; component < 4; ++component) {
    left.predictors[component] = static_cast<int>(state[7 + component]);
  }
  left.cached_word = 0xffffffffu;
  Cursor right = left;
  unsigned result = 0;
  for (unsigned iteration = 0; iteration < state[11] && left.error == 0 && right.error == 0; ++iteration) {
    Symbol original = reference_advance(entropy, tables, blocks, limit, left);
    Symbol candidate = advance_symbol(entropy, twolevel_tables, blocks, limit, right);
    left = original.cursor;
    right = candidate.cursor;
    result |= difference(left, right);
    result |= static_cast<unsigned>(original.index != candidate.index) << 13;
    result |= static_cast<unsigned>(original.value != candidate.value) << 14;
  }
  output[index] = result;
}
