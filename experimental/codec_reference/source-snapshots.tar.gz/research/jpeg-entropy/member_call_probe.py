"""Inventory the CXX call forms exposed by the per-image color helper."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

notes = Path(__file__).resolve().parent
directory = notes / "member-call-probe"
directory.mkdir(exist_ok=True)
tag = Path(json.loads(os.environ["BUREAU_TAG_ROOTS"])["codec-jpeg-rebased-tools"])
tool = tag / "loom/src/loom/tools/loom-import-cxx/loom-import-cxx"
output = Path(json.loads((notes / "device-active.json").read_text())["directory"]) / "member-call-probe.loom"
cases = {
    "const-value": ("struct Value { unsigned value; unsigned get() const { return value + 1; } };", "Value value{input[0]}; output[0] = value.get();"),
    "mutable-value": ("struct Value { unsigned value; unsigned next() { return ++value; } };", "Value value{input[0]}; output[0] = value.next(); output[1] = value.value;"),
    "mutable-void": ("struct Value { unsigned value; void next() { ++value; } };", "Value value{input[0]}; value.next(); output[0] = value.value;"),
    "const-arrow": ("struct Value { unsigned value; unsigned get() const { return value + 1; } };", "const Value* value = reinterpret_cast<const Value*>(input); output[0] = value->get();"),
    "template-value": ("template<unsigned Bias> struct Value { unsigned value; unsigned get() const { return value + Bias; } };", "Value<3> value{input[0]}; output[0] = value.get();"),
    "static-qualified": ("struct Value { static unsigned get(unsigned value) { return value + 1; } };", "output[0] = Value::get(input[0]);"),
    "free-reference": ("struct Value { unsigned value; }; static unsigned get(const Value& value) { return value.value + 1; }", "Value value{input[0]}; output[0] = get(value);"),
}
rows = []
for name, (declaration, body) in cases.items():
    source = '''#include <loomcxx/kernel.h>
''' + declaration + '''
static loom::kernel::configuration configure() { return {{1, 1, 1}, {32, 1, 1}}; }
[[loom::kernel(configure)]] void root(const unsigned* input, unsigned* output) {
''' + body + "\n}\n"
    filename = directory / (name + ".cxx")
    filename.write_text(source)
    result = subprocess.run([str(tool), str(filename), "--output=" + str(output)], capture_output=True, text=True)
    rows.append({"name": name, "source_sha256": hashlib.sha256(source.encode()).hexdigest(),
                 "returncode": result.returncode, "diagnostic": result.stdout + result.stderr})
record = {"compiler_sha256": hashlib.sha256(tool.read_bytes()).hexdigest(), "rows": rows,
          "observed_callsite": "translation.cc::expression and expression_statement resolve ordinary callees only through IdExpressionAST; ordinary_call passes explicit expressionList arguments and has no implicit object parameter."}
(directory / "results.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(rows, indent=2))
