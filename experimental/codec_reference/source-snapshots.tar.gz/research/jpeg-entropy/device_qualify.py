"""Execute complete summary comparisons under a remote benchmark lease."""
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import struct
import sys

root = Path(__file__).resolve().parent
assert os.environ['BENCHMARK_LOCK_LEASE_ID']
parser = argparse.ArgumentParser()
parser.add_argument('--stage', default='stage.json')
parser.add_argument('--fixtures', default='fixtures.json')
parser.add_argument('--runner', default='iree-test-loom')
parser.add_argument('--runner-sha256')
parser.add_argument('--library', default='entropy.loombc')
parser.add_argument('--library-sha256')
parser.add_argument('--cache-tables', type=int, choices=(0, 1))
parser.add_argument('--output-directory', default='actual')
parser.add_argument('cases', nargs='*')
arguments = parser.parse_args()
stage = json.loads((root / arguments.stage).read_text())
fixtures = root / arguments.fixtures
input_directory = fixtures.parent
expected_runner_sha256 = arguments.runner_sha256 or stage['check_tool_sha256']
runner = root / arguments.runner
library = root / arguments.library
output_directory = root / arguments.output_directory
output_directory.mkdir(exist_ok=True)
for name, expected in stage['files'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
assert hashlib.sha256(runner.read_bytes()).hexdigest() == expected_runner_sha256
library_sha256 = hashlib.sha256(library.read_bytes()).hexdigest()
expected_library_sha256 = arguments.library_sha256 or stage['files'][arguments.library]
assert library_sha256 == expected_library_sha256
state = {'host': os.uname().nodename, 'lease': os.environ['BENCHMARK_LOCK_LEASE_ID'],
         'runner': str(runner), 'runner_sha256': expected_runner_sha256,
         'library': str(library), 'library_sha256': library_sha256,
         'cache_tables': arguments.cache_tables,
         'kfd_processes': [p.name for p in Path('/sys/class/kfd/kfd/proc').iterdir()],
         'gpu_busy': Path('/sys/class/drm/card0/device/gpu_busy_percent').read_text().strip()}
assert not state['kfd_processes'], state
rows = []
for case in json.loads(fixtures.read_text())['cases']:
    key = case['key']
    if arguments.cases and key not in arguments.cases:
        continue
    command = [str(runner), str(input_directory / (key + '.loom')),
               '--library=' + str(library),
               '--config-file=' + str(input_directory / (key + '.json')),
               '--device=amdgpu', '--target=amdgpu:gfx1151', '--sanitizer=access',
               '--file-output-root=' + str(output_directory)]
    if arguments.cache_tables is not None:
        with (input_directory / (key + '-tables.npy')).open('rb') as stream:
            assert stream.read(8) == b'\x93NUMPY\x01\x00'
            header_length = struct.unpack('<H', stream.read(2))[0]
            header = ast.literal_eval(stream.read(header_length).decode('ascii'))
        assert header['descr'] == '<i4' and not header['fortran_order']
        assert len(header['shape']) == 1 and header['shape'][0] % 832 == 0
        table_count = header['shape'][0] // 832
        assert 1 <= table_count <= 8
        command.extend(['--config=jpeg.table_count=' + str(table_count),
                        '--config=jpeg.cache_tables=' + str(arguments.cache_tables)])
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    (output_directory / (key + '.log')).write_text(result.stdout + result.stderr)
    if result.returncode:
        print(result.stdout + result.stderr, flush=True)
        raise SystemExit(result.returncode)
    report = json.loads(result.stdout)
    assert report['failed_sample_count'] == 0 and report['sample_count'] > 0, report
    rows.append({'case': case, 'command': command, 'report': report})
    (output_directory / 'qualified.json').write_text(json.dumps({'state': state, 'rows': rows}, indent=2) + '\n')
    print(json.dumps({'case': key, 'jobs': case['jobs'], 'exact': True}), flush=True)
