"""Attach exact public RGB to the existing sixteen-image component operation."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--arrays-only', action='store_true')
parser.add_argument('--root')
arguments = parser.parse_args()
notes = Path(__file__).resolve().parent
root = Path(arguments.root) if arguments.root else Path(json.loads((notes / 'device-active.json').read_text())['directory'])
original = root / 'layout-batch16-1024'
output = root / 'rgb-batch16-1024'
output.mkdir(exist_ok=True)
payload = (root / 'public-rgb/012mp-bus.jpg.r0.jpg.rgb').read_bytes()
assert len(payload) == 4032 * 3024 * 3
count = len(payload) * 16 + 32
header = repr({'descr': '|i1', 'fortran_order': False, 'shape': (count,)}).encode()
header += b' ' * ((64 - ((10 + len(header) + 1) % 64)) % 64) + b'\n'
with (output / 'rgb.npy').open('wb') as stream:
    stream.write(b'\x93NUMPY\x01\x00' + struct.pack('<H', len(header)) + header)
    for image in range(16):
        stream.write(payload)
    stream.write(bytes([17]) * 32)
if arguments.arrays_only:
    print('RGB expectation', count, hashlib.sha256((output / 'rgb.npy').read_bytes()).hexdigest(), flush=True)
    raise SystemExit(0)

tags = json.loads(os.environ['BUREAU_TAG_ROOTS'])
base = Path(tags['codec-jpeg-rebased-tools']) / 'loom/src/loom/tools'
native = Path(tags['codec-jpeg-unsigned-opt']) / 'loom/src/loom/tools'
paths = {}
def relocate(match):
    path = (original / match[1]).resolve()
    relative = os.path.relpath(path, output)
    paths[relative] = path
    return 'check.file.read.npy path("' + relative + '")'
text = re.sub(r'check.file.read.npy path\("([^"]+)"\)', relocate, (original / 'summary.loom').read_text())
text = 'kernel.decl @jpeg_color() launch(%components: buffer, %rgb: buffer)\n' + text
position = text.index('  kernel.launch @jpeg_speculate')
text = text[:position] + f'''  %rgb = check.file.read.npy path("rgb.npy") : tensor<{count}xi8>
  %rgb_output = check.generate.fill value(17) : tensor<{count}xi8>
''' + text[position:]
position = text.index('  check.expect.bitwise')
text = text[:position] + f'  kernel.launch @jpeg_color(%pixels_output, %rgb_output) : (tensor<73156608xi32>, tensor<{count}xi8>)\n' + text[position:]
text = text.replace('  check.return', f'  check.expect.bitwise actual(%rgb_output) expected(%rgb) : tensor<{count}xi8>\n  check.return')
(output / 'summary.loom').write_text(text)
config = json.loads((original / 'config.json').read_text())
config.update(json.loads((root / 'color-config.json').read_text()))
(output / 'config.json').write_text(json.dumps(config, indent=2) + '\n')
library = root / 'entropy-rgb.loombc'
commands = [
    [str(base / 'loom-link/loom-link'), str(root / 'entropy-layout.loombc'), str(root / 'color.loombc'), '--to=bc', '--output=' + str(library)],
    [str(base / 'loom-link/loom-link'), str(output / 'summary.loom'), str(library), '--to=bc', '--output=' + str(output / 'summary.loombc')],
    [str(native / 'loom-compile/loom-compile'), str(library), '--root=jpeg_reconstruct', '--target=amdgpu:gfx1151',
     '--config-file=' + str(output / 'config.json'), '--output=' + str(root / 'jpeg_reconstruct-rgb.hsaco')]]
for command in commands:
    subprocess.run(command, check=True)
assert (root / 'jpeg_reconstruct-rgb.hsaco').read_bytes() == (root / 'jpeg_reconstruct-layout.hsaco').read_bytes()
stage = json.loads((original / 'stage.json').read_text())
stage['sizes']['rgb'] = count
stage['files'] = {relative: hashlib.sha256(path.read_bytes()).hexdigest() for relative, path in paths.items()}
stage['files'].update({path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                      for path in output.iterdir() if path.is_file() and path.name != 'stage.json'})
stage['library'] = {'path': library.name, 'sha256': hashlib.sha256(library.read_bytes()).hexdigest()}
stage['scope'] = 'Seven GPU dispatches through exact public RGB8: existing entropy discovery/certification/integer IDCT, then shared-chroma upsampling/RGB. Sixteen distinct outputs, eight queued operations per sample and one final wait. CPU-provided unstuffed entropy/job records remain outside timing; not complete compressed-input JPEG or serving ownership.'
stage['retention'] = 'One reusable 585252896-byte RGB expectation under /tmp, alongside the shared component expectation; no coefficient image. Retire RGB expectation at this experiment checkpoint.'
stage['commands'] = commands
stage['rgb_reference_sha256'] = hashlib.sha256(payload).hexdigest()
(output / 'stage.json').write_text(json.dumps(stage, indent=2) + '\n')
(notes / 'rgb-batch-stage.json').write_text(json.dumps(stage, indent=2) + '\n')
print('RGB batch ready', count, 'bytes; reconstruction artifact unchanged', flush=True)
