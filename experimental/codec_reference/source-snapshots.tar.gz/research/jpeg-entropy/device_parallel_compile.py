"""Compile the connected certificate experiment using the qualified tools."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
tags = json.loads(os.environ['BUREAU_TAG_ROOTS'])
base = Path(tags['codec-jpeg-rebased-tools'])
candidate = Path(tags['codec-jpeg-unsigned-opt'])
importer = base / 'loom/src/loom/tools/loom-import-cxx/loom-import-cxx'
linker = base / 'loom/src/loom/tools/loom-link/loom-link'
compiler = candidate / 'loom/src/loom/tools/loom-compile/loom-compile'
commands = [
    [str(importer), str(notes / 'device_parallel_pipeline.cxx'), '--output=' + str(root / 'entropy-parallel.loom')],
    [str(linker), str(root / 'entropy-parallel.loom'), '--to=bc', '--output=' + str(root / 'entropy-parallel.loombc')]]
for command in commands:
    subprocess.run(command, check=True)
entries = []
for entry in ('jpeg_index', 'jpeg_certify', 'jpeg_intervals'):
    output = root / (entry + '.hsaco')
    report = root / (entry + '-report.json')
    command = [str(compiler), str(root / 'entropy-parallel.loombc'), '--root=' + entry,
               '--target=amdgpu:gfx1151', '--config-file=' + str(root / 'anchor-batch16-1024/config.json'),
               '--output=' + str(output), '--compile-report=details',
               '--compile-report-output=' + str(report)]
    subprocess.run(command, check=True)
    commands.append(command)
    metrics = json.loads(report.read_text())['entries']['rows'][0]
    record = {'entry': entry, 'artifact_sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
              'metrics': {key: metrics[key] for key in ('instruction_count', 'code_byte_count',
                          'private_memory_bytes', 'local_memory_bytes', 'target_resources')}}
    entries.append(record)
    print(json.dumps(record), flush=True)
record = {'commands': commands, 'entries': entries,
          'bytecode_sha256': hashlib.sha256((root / 'entropy-parallel.loombc').read_bytes()).hexdigest(),
          'compiler_sha256': hashlib.sha256(compiler.read_bytes()).hexdigest(),
          'sources': {name: hashlib.sha256((notes / name).read_bytes()).hexdigest() for name in
                      ('device_entropy_cursor.h', 'device_entropy_tables.cxx', 'device_bridge.cxx',
                       'device_certify.cxx', 'device_parallel_pipeline.cxx')}}
(notes / 'device-parallel-code.json').write_text(json.dumps(record, indent=2) + '\n')
