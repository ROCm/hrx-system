#include "device_entropy_cursor_short.h"

[[loom::config("jpeg.probes")]]
extern const unsigned probe_count;

static loom::kernel::configuration configure_probe() {
  return {{(probe_count + 127) / 128, 1, 1}, {128, 1, 1}};
}

static LOOM_FORCE_INLINE unsigned difference(Cursor left, Cursor right) {
  unsigned result = 0;
  result |= static_cast<unsigned>(left.position != right.position);
  result |= static_cast<unsigned>(left.reads != right.reads) << 1;
  result |= static_cast<unsigned>(left.budget != right.budget) << 2;
  result |= static_cast<unsigned>(left.blocks != right.blocks) << 3;
  result |= static_cast<unsigned>(left.block_index != right.block_index) << 4;
  result |= static_cast<unsigned>(left.coefficient != right.coefficient) << 5;
  result |= static_cast<unsigned>(left.error != right.error) << 6;
  result |= static_cast<unsigned>(left.cached_word != right.cached_word) << 7;
  result |= static_cast<unsigned>(left.cached_bits != right.cached_bits) << 8;
  [[loom::unroll]]
  for (unsigned component = 0; component < 4; ++component) {
    result |= static_cast<unsigned>(left.predictors[component] != right.predictors[component]) << (9 + component);
  }
  return result;
}

[[loom::kernel(configure_probe)]]
void transition_probe(const unsigned* entropy, const unsigned* tables,
    const unsigned* blocks, const unsigned* states, unsigned* output) {
  unsigned index = loom::kernel::workgroup::id.x * 128 + loom::kernel::workitem::id.x;
  if (index >= probe_count) return;
  const unsigned* state = states + index * 12;
  Cursor left = {};
  left.position = state[0];
  unsigned limit = state[1];
  left.reads = state[2];
  left.budget = state[3];
  left.blocks = state[4];
  left.block_index = state[5];
  left.coefficient = state[6];
  [[loom::unroll]]
  for (unsigned component = 0; component < 4; ++component) {
    left.predictors[component] = static_cast<int>(state[7 + component]);
  }
  left.cached_word = 0xffffffffu;
  Cursor right = left;
  unsigned result = 0;
  for (unsigned iteration = 0; iteration < state[11] && left.error == 0 && right.error == 0; ++iteration) {
    Symbol original = advance_symbol_slow(entropy, tables, blocks, limit, left);
    Symbol candidate = advance_symbol(entropy, tables, blocks, limit, right);
    left = original.cursor;
    right = candidate.cursor;
    result |= difference(left, right);
    result |= static_cast<unsigned>(original.index != candidate.index) << 13;
    result |= static_cast<unsigned>(original.value != candidate.value) << 14;
  }
  output[index] = result;
}
