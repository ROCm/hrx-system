"""Compile the compressed-byte boundary without running GPU work."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

from device_fixture import input_bytes

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
tags = json.loads(os.environ['BUREAU_TAG_ROOTS'])
base = Path(tags['codec-jpeg-rebased-tools']) / 'loom/src/loom/tools'
native = Path(tags['codec-jpeg-unsigned-opt']) / 'loom/src/loom/tools'
config = {'input': {'tiles': (len(input_bytes('012mp-bus.jpg.r0.jpg')) + 4095) // 4096,
                    'batch': 16, 'chunk_bytes': 1024}}
(root / 'unstuff-config.json').write_text(json.dumps(config, indent=2) + '\n')
commands = [
    [str(base / 'loom-import-cxx/loom-import-cxx'), str(notes / 'device_unstuff.cxx'),
     '--output=' + str(root / 'unstuff.loom')],
    [str(base / 'loom-link/loom-link'), str(root / 'unstuff.loom'), '--to=bc',
     '--output=' + str(root / 'entropy-unstuff.loombc')]]
for command in commands:
    subprocess.run(command, check=True)
metrics = {}
for name in ('jpeg_classify_bytes', 'jpeg_prefix_bytes', 'jpeg_compact_bytes'):
    command = [str(native / 'loom-compile/loom-compile'), str(root / 'entropy-unstuff.loombc'),
               '--root=' + name, '--target=amdgpu:gfx1151',
               '--config-file=' + str(root / 'unstuff-config.json'),
               '--output=' + str(root / (name + '.hsaco')),
               '--compile-report=details', '--compile-report-output=' + str(root / (name + '-report.json'))]
    commands.append(command)
    subprocess.run(command, check=True)
    row = json.loads((root / (name + '-report.json')).read_text())['entries']['rows'][0]
    metrics[name] = {key: row[key] for key in ('instruction_count', 'code_byte_count',
                     'private_memory_bytes', 'local_memory_bytes', 'target_resources')}
    with (root / (name + '.native.s')).open('w') as output:
        subprocess.run(['/home/ben/tools/llvm/latest/bin/llvm-objdump', '-d', '--mcpu=gfx1151',
                        str(root / (name + '.hsaco'))], stdout=output, check=True)
    print(name, json.dumps(metrics[name]), flush=True)
record = {'commands': commands, 'configuration': config, 'metrics': metrics,
          'source_sha256': hashlib.sha256((notes / 'device_unstuff.cxx').read_bytes()).hexdigest(),
          'library_sha256': hashlib.sha256((root / 'entropy-unstuff.loombc').read_bytes()).hexdigest()}
(notes / 'unstuff-native.json').write_text(json.dumps(record, indent=2) + '\n')
