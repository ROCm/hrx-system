// Bounded native compressed-input experiment through the serving queue owner.
#include <algorithm>
#include <condition_variable>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <mutex>
#include <string>
#include <vector>

#include "native_upload.h"
#include "iree/base/tooling/flags.h"
#include "iree/testing/gtest.h"
#include "iree/testing/status_matchers.h"
#include "loom/serve/runtime/device/device.h"
#include "loom/serve/runtime/execution/execution.h"
#include "loom/serve/runtime/program/jit.h"
#include "loom/serve/testing/compiler.h"
#include "loom/serve/testing/device.h"

IREE_FLAG(string, jpeg_fixture, "", "Native JPEG inputs and independent GPU expectations.");

namespace {

struct Compilation {
  // Protects publication of the completed asynchronous compiler result.
  std::mutex mutex;
  // Outer harness readiness; no worker blocks on another worker.
  std::condition_variable condition;
  // Callback has stopped borrowing the operation.
  bool complete = false;
  // Owned compilation outcome transferred to the harness.
  iree_status_t status = iree_ok_status();
  // Owned stage, released after recording the command.
  loom_serve_jit_stage_t* stage = nullptr;

  static void Complete(void* pointer, iree_status_t status, loom_serve_jit_stage_t* stage) {
    auto& self = *static_cast<Compilation*>(pointer);
    std::lock_guard<std::mutex> lock(self.mutex);
    self.status = status;
    self.stage = stage;
    self.complete = true;
    self.condition.notify_one();
  }
};

struct ExpectedBinding {
  // Name in the independent, previously qualified fixture.
  std::string name;
  // Original input/output ownership, checked against the native layout.
  bool input;
  // Scalar element width used to initialize untouched output sentinels.
  size_t width;
  // Complete expected bytes, including preserved guards.
  std::vector<uint8_t> bytes;
  // Independently specified readable ranges; rejected partial output is absent.
  struct Region {
    // Byte offset within this logical binding.
    size_t offset;
    // Checked byte extent.
    size_t length;
    // The range is one defined nonzero terminal body-error word.
    bool body_error;
  };
  // Exact regions from the preserved failure-isolation oracle.
  std::vector<Region> regions;
};

class NativeUploadDeviceTest : public ::testing::Test {
 protected:
  void SetUp() override {
    directory_ = FLAG_jpeg_fixture;
    IREE_ASSERT_OK(loom_serve_test_host_create(4, allocator_, &host_));
    iree_hal_driver_t* driver = nullptr;
    IREE_ASSERT_OK(loom_serve_test_driver_create(host_, allocator_, &driver));
    const loom_serve_device_options_t options = {
        .driver = driver, .uri = IREE_SV("amdgpu"),
        .backing = LOOM_SERVE_DEVICE_BACKING_FIXED};
    auto status = loom_serve_device_group_allocate(host_, 1, &options, allocator_, &group_);
    iree_hal_driver_release(driver);
    IREE_ASSERT_OK(status);
    owner_ = loom_serve_device_group_at(group_, 0);
    IREE_ASSERT_OK(loom_serve_device_create_execution(owner_, &execution_));
    const iree_string_view_t source = IREE_SV("summary.loombc");
    const loom_serve_sources_t sources = {
        .base_directory = iree_make_cstring_view(directory_.c_str()),
        .count = 1, .values = &source};
    const loomc_sanitizer_options_t sanitizer = {
        .type = LOOMC_STRUCTURE_TYPE_SANITIZER_OPTIONS,
        .structure_size = sizeof(loomc_sanitizer_options_t),
        .checks = LOOMC_SANITIZER_CHECK_ACCESS};
    IREE_ASSERT_OK(loom_serve_jit_create(
        loom_serve_device_handle(owner_), loom_serve_device_dispatch_queue(owner_),
        host_, &sources, &sanitizer, &report_, allocator_, &jit_));
  }

  void TearDown() override {
    if (execution_) IREE_EXPECT_OK(loom_serve_execution_drain(execution_));
    iree_hal_command_buffer_release(command_);
    for (auto* root : roots_) iree_hal_buffer_release(root);
    iree_hal_buffer_release(transient_);
    loom_serve_jit_release(jit_);
    loom_serve_execution_release(execution_);
    if (owner_) IREE_EXPECT_OK(loom_serve_test_device_trim_and_drain(owner_, 0));
    IREE_EXPECT_OK(loom_serve_device_group_free(group_));
    loom_serve_host_release(host_);
    jpeg_upload_deinitialize(&upload_);
  }

  void Prepare(const std::filesystem::path& fixture) {
    std::ifstream inputs(fixture / "inputs.txt");
    ASSERT_TRUE(inputs.good());
    std::vector<std::vector<uint8_t>> originals;
    std::string filename;
    while (inputs >> filename) {
      std::ifstream file(fixture / filename, std::ios::binary);
      ASSERT_TRUE(file.good());
      originals.emplace_back(std::istreambuf_iterator<char>(file), std::istreambuf_iterator<char>());
    }
    ASSERT_EQ(originals.size(), 16u);
    std::vector<jpeg_upload_image_t> images(originals.size());
    for (size_t i = 0; i < images.size(); ++i) {
      IREE_ASSERT_OK(jpeg_upload_image_initialize(
          iree_make_const_byte_span(originals[i].data(), originals[i].size()), &images[i]));
    }
    IREE_ASSERT_OK(jpeg_upload_create(images.size(), images.data(), allocator_, &upload_));
    originals.clear();
    images.clear();
    std::printf("{\"phase\":\"native_upload\",\"input_bytes\":%zu,\"output_bytes\":%u}\n",
                upload_.input.data_length, upload_.output_length);
    std::ifstream manifest(fixture / "bindings.txt");
    ASSERT_TRUE(manifest.good());
    std::string name;
    unsigned input = 0;
    size_t width = 0, count = 0;
    while (manifest >> name >> input >> width >> count >> filename) {
      ASSERT_TRUE(width == 1 || width == 4);
      std::ifstream file(fixture / filename, std::ios::binary);
      ASSERT_TRUE(file.good());
      char numpy_header[10];
      file.read(numpy_header, sizeof(numpy_header));
      ASSERT_EQ(size_t(file.gcount()), sizeof(numpy_header));
      ASSERT_EQ(std::memcmp(numpy_header, "\x93NUMPY\x01\x00", 8), 0);
      unsigned header_length = static_cast<uint8_t>(numpy_header[8]) |
                               (static_cast<uint8_t>(numpy_header[9]) << 8);
      file.ignore(header_length);
      ASSERT_LT(width * count, 2u * 1024 * 1024);
      ExpectedBinding expected{name, input != 0, width, std::vector<uint8_t>(width * count), {}};
      file.read(reinterpret_cast<char*>(expected.bytes.data()), expected.bytes.size());
      ASSERT_EQ(size_t(file.gcount()), expected.bytes.size());
      expected_.push_back(std::move(expected));
    }
    ASSERT_EQ(expected_.size(), JPEG_BUFFER_COUNT);
    std::ifstream regions(fixture / "verification.txt");
    has_regions_ = regions.good();
    if (has_regions_) {
      size_t offset = 0, length = 0;
      std::string mode;
      while (regions >> name >> offset >> length >> mode) {
        auto found = std::find_if(expected_.begin(), expected_.end(),
            [&](const auto& binding) { return binding.name == name; });
        ASSERT_NE(found, expected_.end());
        ASSERT_LE(offset, found->bytes.size());
        ASSERT_GT(length, 0u);
        ASSERT_LE(length, found->bytes.size() - offset);
        ASSERT_TRUE(mode == "exact" || mode == "body_error");
        if (mode == "body_error") {
          ASSERT_EQ(name, "validity");
          ASSERT_EQ(length, 4u);
        }
        found->regions.push_back({offset, length, mode == "body_error"});
      }
      for (const auto& binding : expected_) ASSERT_FALSE(binding.regions.empty()) << binding.name;
    } else {
      for (auto& binding : expected_) binding.regions.push_back({0, binding.bytes.size(), false});
    }
    initial_output_.resize(upload_.output_length);
    for (size_t i = 0; i < initial_output_.size(); i += 4) initial_output_[i] = 17;
    for (unsigned i = 0; i < JPEG_BUFFER_COUNT; ++i) {
      ASSERT_EQ(expected_[i].input, jpeg_upload_is_input(static_cast<JpegBuffer>(i)));
      ASSERT_EQ(expected_[i].bytes.size(), upload_.lengths[i]);
      if (expected_[i].input) {
        ASSERT_EQ(std::memcmp(upload_.input.data + upload_.offsets[i],
                              expected_[i].bytes.data(), upload_.lengths[i]), 0) << expected_[i].name;
      } else if (expected_[i].width == 1) {
        std::memset(initial_output_.data() + upload_.offsets[i], 17, upload_.lengths[i]);
      }
    }
    const size_t lengths[] = {upload_.input.data_length, upload_.output_length};
    for (size_t i = 0; i < 2; ++i) {
      IREE_ASSERT_OK(iree_hal_pool_allocate_buffer(
          loom_serve_device_storage_pool(owner_),
          iree_hal_make_pool_reservation_request(lengths[i], 16),
          iree_infinite_timeout(), &roots_[i]));
      table_.push_back({roots_[i], 0, lengths[i]});
    }
    if (transient_) table_.push_back({transient_, 0, transient_length_});
  }

  void Compile() {
    std::ifstream file(std::filesystem::path(directory_) / "config.json");
    ASSERT_TRUE(file.good());
    const std::string configuration(std::istreambuf_iterator<char>(file), {});
    const loomc_config_options_t options = {.json_object = loomc_make_cstring_view(configuration.c_str())};
    Compilation compilation;
    IREE_ASSERT_OK(loom_serve_jit_compile_async(jit_, IREE_SV("jpeg_upload_decode"),
        &options, Compilation::Complete, &compilation));
    {
      std::unique_lock<std::mutex> lock(compilation.mutex);
      compilation.condition.wait(lock, [&] { return compilation.complete; });
    }
    IREE_ASSERT_OK(compilation.status);
    const auto* program = loom_serve_jit_stage_program(compilation.stage);
    const size_t scratch_bytes = program->requirements.transient.required_byte_length;
    transient_length_ = scratch_bytes;
    std::printf("{\"phase\":\"command\",\"commands\":%u,\"entries\":%u,\"scratch_bytes\":%zu,\"bindings\":%u}\n",
        program->commands.count, program->requirements.entry_count, scratch_bytes,
        program->requirements.rebindable_binding_count);
    EXPECT_EQ(program->commands.count, 16u);
    EXPECT_EQ(program->requirements.rebindable_binding_count, 2u + (scratch_bytes ? 1u : 0u));
    iree_status_t status = iree_ok_status();
    if (scratch_bytes) {
      EXPECT_EQ(program->requirements.transient.binding_index, 2u);
      status = iree_hal_pool_allocate_buffer(loom_serve_device_storage_pool(owner_),
          iree_hal_make_pool_reservation_request(scratch_bytes, program->requirements.transient.minimum_alignment),
          iree_infinite_timeout(), &transient_);
      if (iree_status_is_ok(status)) table_.push_back({transient_, 0, scratch_bytes});
    }
    if (iree_status_is_ok(status)) {
      status = loom_serve_jit_stage_record(compilation.stage,
          iree_hal_queue_family(loom_serve_device_dispatch_queue(owner_)),
          IREE_HAL_COMMAND_BUFFER_MODE_DEFAULT, nullptr, nullptr, &command_);
    }
    loom_serve_jit_stage_free(compilation.stage);
    IREE_ASSERT_OK(status);
  }

  void ExecuteAndVerify() {
    iree_hal_transfer_operation_t transfers[2] = {};
    for (unsigned i = 0; i < 2; ++i) {
      transfers[i].type = IREE_HAL_TRANSFER_OPERATION_TYPE_UPLOAD;
      transfers[i].upload.source = i ? initial_output_.data() : upload_.input.data;
      transfers[i].upload.target_buffer = roots_[i];
      transfers[i].upload.length = table_[i].length;
    }
    uint64_t completion = 0;
    IREE_ASSERT_OK(loom_serve_execution_transfer(execution_, 2, transfers, &completion));
    // Queue order carries upload -> every decode stage; there is no host wait
    // or body-derived readback between upload and the final output.
    IREE_ASSERT_OK(loom_serve_execution_execute(execution_, command_,
        {table_.size(), table_.data()}, &completion));
    std::vector<uint8_t> actual[2];
    for (unsigned i = 0; i < 2; ++i) {
      actual[i].resize(table_[i].length);
      transfers[i] = {};
      transfers[i].type = IREE_HAL_TRANSFER_OPERATION_TYPE_DOWNLOAD;
      transfers[i].download.source_buffer = roots_[i];
      transfers[i].download.target = actual[i].data();
      transfers[i].download.length = actual[i].size();
    }
    IREE_ASSERT_OK(loom_serve_execution_feedback(execution_, 2, transfers, &completion));
    IREE_ASSERT_OK(loom_serve_execution_feedback_wait(execution_, completion));
    ASSERT_EQ(std::memcmp(actual[0].data(), upload_.input.data, actual[0].size()), 0);
    for (unsigned i = 0; i < JPEG_BUFFER_COUNT; ++i) {
      const auto& expected = expected_[i];
      const auto* begin = actual[expected.input ? 0 : 1].data() + upload_.offsets[i];
      size_t checked_bytes = 0;
      for (const auto& region : expected.regions) {
        if (region.body_error) {
          const uint32_t value = iree_unaligned_load_le_u32(begin + region.offset);
          ASSERT_TRUE(value == 256 || value == 512 || value == 768 || value == 1024 || value == 1280)
              << expected.name << " ordinal " << region.offset / 4 << " value " << value;
          std::printf("{\"phase\":\"body_error\",\"ordinal\":%zu,\"value\":%u}\n", region.offset / 4, value);
        } else {
          const auto* end = begin + region.offset + region.length;
          const auto mismatch = std::mismatch(begin + region.offset, end, expected.bytes.begin() + region.offset);
          ASSERT_EQ(mismatch.first, end) << expected.name << " byte " << (mismatch.first - begin);
        }
        checked_bytes += region.length;
      }
      std::printf("{\"phase\":\"%s\",\"binding\":\"%s\",\"bytes\":%zu,\"checked_bytes\":%zu}\n",
                  has_regions_ ? "regions" : "exact", expected.name.c_str(), expected.bytes.size(), checked_bytes);
    }
  }

  void ReleaseCase() {
    for (auto*& root : roots_) {
      iree_hal_buffer_release(root);
      root = nullptr;
    }
    jpeg_upload_deinitialize(&upload_);
    table_.clear();
    expected_.clear();
    initial_output_.clear();
  }

  void RunCases() {
    std::ifstream cases(std::filesystem::path(directory_) / "cases.txt");
    ASSERT_TRUE(cases.good());
    std::string name;
    unsigned count = 0;
    while (cases >> name) {
      SCOPED_TRACE(name);
      std::printf("{\"phase\":\"case\",\"name\":\"%s\"}\n", name.c_str());
      ASSERT_NO_FATAL_FAILURE(Prepare(std::filesystem::path(directory_) / name));
      if (!command_) ASSERT_NO_FATAL_FAILURE(Compile());
      ASSERT_NO_FATAL_FAILURE(ExecuteAndVerify());
      ReleaseCase();
      ++count;
    }
    EXPECT_EQ(count, 28u);
    std::printf("{\"phase\":\"complete\",\"cases\":%u,\"compilations\":1}\n", count);
  }

  // Host allocator retained through final upload and device retirement.
  iree_allocator_t allocator_ = iree_allocator_system();
  // Shared host compiler/task services.
  loom_serve_host_t* host_ = nullptr;
  // Device group owning the queue and pool.
  loom_serve_device_group_t* group_ = nullptr;
  // Borrowed group member.
  loom_serve_device_t* owner_ = nullptr;
  // Ordered upload, command, feedback, and retirement owner.
  loom_serve_execution_t* execution_ = nullptr;
  // Captured command compiler with explicit device access checking.
  loom_serve_jit_t* jit_ = nullptr;
  // Compilation evidence retained through the compiler callback.
  loom_serve_compilation_report_t report_ = {};
  // Owned command buffer recorded from the captured program.
  iree_hal_command_buffer_t* command_ = nullptr;
  // Immutable input and disjoint device output allocations.
  iree_hal_buffer_t* roots_[2] = {};
  // Command compiler's reflected indirect-packet workspace.
  iree_hal_buffer_t* transient_ = nullptr;
  // Reflected extent reused across all data-only input variations.
  size_t transient_length_ = 0;
  // Stable issued bindings, captured by the queue at submission.
  std::vector<iree_hal_buffer_binding_t> table_;
  // Native compressed upload, independent of original image storage.
  jpeg_upload_t upload_ = {};
  // Device fixture used only as an independent output/input comparator.
  std::vector<ExpectedBinding> expected_;
  // Whether this case uses the explicit partial-output rejection contract.
  bool has_regions_ = false;
  // Test sentinel initialization, outside the decoder's production inputs.
  std::vector<uint8_t> initial_output_;
  // Immutable experiment source/input location.
  std::string directory_;
};

TEST_F(NativeUploadDeviceTest, OriginalBytesThroughTwoRoots) {
  ASSERT_NO_FATAL_FAILURE(RunCases());
}

}  // namespace
