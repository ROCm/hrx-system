"""Batch independent entropy jobs without changing the qualified CXX kernel."""
import ast
import argparse
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess

from device_fixture import write_words

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
source = root / 'large'
parser = argparse.ArgumentParser()
parser.add_argument('--chunk-bytes', type=int, choices=(1024, 4096), default=4096)
arguments = parser.parse_args()
key = f'012mp-bus.jpg.r0.jpg-scan0-chunk{arguments.chunk_bytes}'
batch = 16
directory_name = 'batch16' if arguments.chunk_bytes == 4096 else 'batch16-1024'
output = root / directory_name
output.mkdir(exist_ok=True)


def read_payload(path):
    data = path.read_bytes()
    assert data[:8] == b'\x93NUMPY\x01\x00'
    size = struct.unpack_from('<H', data, 8)[0]
    header = ast.literal_eval(data[10:10 + size].decode())
    assert header['descr'] == '<i4' and not header['fortran_order']
    payload = data[10 + size:]
    assert len(header['shape']) == 1 and len(payload) == header['shape'][0] * 4
    return header['shape'][0], payload


def write_repeated(path, count, payload, repetitions):
    header = repr({'descr': '<i4', 'fortran_order': False,
                   'shape': (count * repetitions,)}).encode('ascii')
    header += b' ' * ((64 - ((10 + len(header) + 1) % 64)) % 64) + b'\n'
    with path.open('wb') as stream:
        stream.write(b'\x93NUMPY\x01\x00' + struct.pack('<H', len(header)) + header)
        for _ in range(repetitions):
            stream.write(payload)


sizes = {}
inputs = {}
for name in ('entropy', 'tables', 'blocks', 'expected', 'jobs'):
    path = source / (key + '-' + name + '.npy')
    count, payload = read_payload(path)
    inputs[name] = {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    if name == 'jobs':
        original = struct.unpack('<' + 'I' * count, payload)
        words = []
        entropy_count = sizes['entropy'] // batch
        for image in range(batch):
            for index in range(0, count, 3):
                words.extend((original[index] + image * entropy_count,
                              original[index + 1], original[index + 2]))
        write_words(output / 'jobs.npy', words)
        sizes[name] = len(words)
    else:
        repetitions = batch if name in ('entropy', 'expected') else 1
        write_repeated(output / (name + '.npy'), count, payload, repetitions)
        sizes[name] = count * repetitions

lines = ['kernel.decl @jpeg_speculate() launch(%entropy: buffer, %jobs: buffer, '
         '%tables: buffer, %blocks: buffer, %summaries: buffer)', '',
         'check.case @summary {']
for name in ('entropy', 'jobs', 'tables', 'blocks', 'expected'):
    lines.append(f'  %{name} = check.file.read.npy path("{name}.npy") : tensor<{sizes[name]}xi32>')
lines.append(f'  %output = check.generate.fill value(17) : tensor<{sizes["expected"]}xi32>')
lines.append('  kernel.launch @jpeg_speculate(%entropy, %jobs, %tables, %blocks, %output) : (' +
             ', '.join(f'tensor<{sizes[name]}xi32>' for name in
                       ('entropy', 'jobs', 'tables', 'blocks', 'expected')) + ')')
lines.append(f'  check.expect.bitwise actual(%output) expected(%expected) : tensor<{sizes["expected"]}xi32>')
lines.extend(['  check.return', '}', '', 'check.benchmark<@summary> @summary_latency'])
(output / 'summary.loom').write_text('\n'.join(lines) + '\n')
config = json.loads((source / (key + '.json')).read_text())
config['jpeg']['chunks'] *= batch
(output / 'config.json').write_text(json.dumps(config, indent=2) + '\n')
tool_root = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])['codec-jpeg-rebased-tools'])
linker = tool_root / 'loom/src/loom/tools/loom-link/loom-link'
link_command = [str(linker), str(output / 'summary.loom'), str(root / 'entropy.loombc'),
                '--to=bc', '--output=' + str(output / 'summary.loombc')]
subprocess.run(link_command, check=True)
files = {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
         for path in sorted(output.iterdir()) if path.is_file() and path.name != 'stage.json'}
receipt = {'batch': batch, 'jobs': config['jpeg']['chunks'], 'sizes': sizes,
           'inputs': inputs, 'files': files,
           'link_command': link_command,
           'linker_sha256': hashlib.sha256(linker.read_bytes()).hexdigest(),
           'entropy_loombc_sha256': hashlib.sha256((root / 'entropy.loombc').read_bytes()).hexdigest(),
           'source': key,
           'layout': 'sixteen disjoint entropy regions, job records, and summary regions; shared read-only Huffman tables and block descriptors for identical images; one launch covers all sixteen images'}
(output / 'stage.json').write_text(json.dumps(receipt, indent=2) + '\n')
(notes / ('device-' + directory_name + '-stage.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'directory': str(output), 'batch': batch, 'jobs': config['jpeg']['chunks'],
                  'binding_bytes': sum(sizes[n] * 4 for n in ('entropy', 'jobs', 'tables', 'blocks', 'expected'))}))
