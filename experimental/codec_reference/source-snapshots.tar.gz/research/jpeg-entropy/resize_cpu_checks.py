"""Bounded CPU memory checks and executed SIMD route evidence; no timing claims."""
import hashlib
import json
import os
from pathlib import Path
import re
import sys

import persistent_window as harness

root=Path(__file__).resolve().parent
assert os.environ['BENCHMARK_LOCK_LEASE_ID']
record={'scope':'ASAN output and actual SIMD route checks; durations are not benchmarks.',
        'lease':os.environ['BENCHMARK_LOCK_LEASE_ID'],'before':harness.state(),'rows':[]}
assert harness.excluded(record['before'])
manifest=json.loads((root/'cpu-manifest.json').read_text())
asan=json.loads((root/'cpu-asan-manifest.json').read_text())
for name,metadata in list(manifest['files'].items())+[('jpeg_resize_islow_asan',asan)]:
    p=root/name
    assert p.stat().st_size==metadata['bytes']
    assert hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==metadata['sha256']
record['manifest']=manifest;record['asan']=asan
images=['012mp-bus.jpg.r0.jpg','006mp-cathedral.jpg.r0.jpg','synthetic-1024.jpg.r0.jpg','synthetic-256.jpg.r0.jpg']
output=root/'cpu/bus-asan.rgb'
commands=[('asan-capture',[str(root/'jpeg_resize_islow_asan'),'capture',str(root/'cpu'/images[0]),str(output)]),
          ('asan-cohort',['taskset','-c','0-15',str(root/'jpeg_resize_islow_asan'),'bench','16','16','1']+[str(root/'cpu'/name) for name in images])]
for policy,route in [('islow','jsimd_idct_islow_avx2'),('ifast','jsimd_idct_ifast_sse2')]:
    commands.append((route,['/opt/rocm/bin/rocgdb','--batch','-ex','set pagination off','-ex','set confirm off',
        '-ex','break '+route,'-ex','run','-ex','bt','-ex','quit','--args',
        str(root/('jpeg_resize_'+policy)),'capture',str(root/'cpu'/images[0]),str(root/('cpu/route-'+policy+'.rgb'))]))
if sys.argv[1:]==['routes']:
    commands=[(name,command) for name,command in commands if name.startswith('jsimd')]
path=root/('cpu-routes-result.json' if sys.argv[1:]==['routes'] else 'cpu-checks-result.json')
for name,command in commands:
    result=harness.run_group(command,60)
    record['rows'].append({'name':name,'result':result})
    path.write_text(json.dumps(record,indent=2)+'\n')
    assert result['returncode']==0 and not result.get('harness_timeout'),result
    if name=='asan-capture':
        digest=hashlib.file_digest(output.open('rb'),'sha256').hexdigest()
        assert digest=='c0b103d5cfe5ae41dac990e7f5c81b4c314bd0fde8bc4d853a2ef75a18e1e05e'
        record['rows'][-1]['output_sha256']=digest
    elif name=='asan-cohort':
        value,=[json.loads(line) for line in result['output'].splitlines() if line.startswith('{')]
        assert value['full_rgb_and_guards'] and value['batch']==16 and value['repeats_per_job']==8
    else:
        assert re.search(r'^Breakpoint 1, (?:0x[0-9a-f]+ in )?'+re.escape(name)+r' \(\)',result['output'],re.M),result
    print(name,'PASS',flush=True)
record['after']=harness.state()
path.write_text(json.dumps(record,indent=2)+'\n')
