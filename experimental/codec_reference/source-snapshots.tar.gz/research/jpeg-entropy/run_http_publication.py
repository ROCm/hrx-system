"""Hold only a bounded foreground GPU run, then collect compact evidence."""
import argparse
import json
from pathlib import Path
import shlex
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument("--mode", choices=("control", "candidate", "lifecycle"), required=True)
arguments = parser.parse_args()
notes = Path(__file__).resolve().parent
source = json.loads((notes / "http-publication-source.json").read_text())
stage = json.loads((notes / "http-publication-stage.json").read_text())
assert stage["verification_returncode"] == 0
directory = Path(source["directory"])
mode = arguments.mode
prefix = "gorgon3-http-publication-" + mode
machine = stage["machine"]
command = ["/home/benvanik/.dotfiles/bin/benchmark-lock", "--label=codec-jpeg-http-" + mode, "--",
           "timeout", "--signal=INT", "--kill-after=15s", "240s", "env", "LD_LIBRARY_PATH=/opt/rocm/lib",
           "python3", "-B", str(directory / "run.py"), str(directory), "--mode=" + mode]
with (notes / (prefix + "-run.log")).open("w") as log:
    process = subprocess.Popen(["ssh", machine, shlex.join(command)], stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, text=True)
    for line in process.stdout:
        log.write(line)
        log.flush()
        print(line, end="", flush=True)
    returncode = process.wait()
status = subprocess.run(["ssh", machine, "/home/benvanik/.dotfiles/bin/benchmark-lock --status"],
                        capture_output=True, text=True)
receipt = {"command": command, "returncode": returncode,
           "broker_status_returncode": status.returncode,
           "broker_status_after": status.stdout + status.stderr, "copies": []}
for name in (mode + ".log", mode + "-result.json"):
    result = subprocess.run(["ssh", machine, "cat " + shlex.quote(str(directory / name))], capture_output=True)
    receipt["copies"].append({"name": name, "returncode": result.returncode})
    if result.returncode == 0:
        (notes / ("gorgon3-http-publication-" + name)).write_bytes(result.stdout)
    else:
        receipt["copies"][-1]["error"] = result.stderr.decode()
(notes / (prefix + "-receipt.json")).write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt), flush=True)
raise SystemExit(returncode or status.returncode or any(item["returncode"] for item in receipt["copies"]))
