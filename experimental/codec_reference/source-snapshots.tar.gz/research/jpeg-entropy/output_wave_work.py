"""Count logical wave work from qualified intervals and an exact syntax trace."""
from bisect import bisect_left
import hashlib
import json
from pathlib import Path

from device_fixture import input_bytes, read_words
from sequential import decode, parse

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
name = '012mp-bus.jpg.r0.jpg'
data = input_bytes(name)
frame = parse(data)
planes, traces = decode(frame, record_trace=True)
scan = frame.scans[0]
assert len(scan.segments) == len(traces) == 1
trace = traces[0]
block_count = scan.segments[0].mcu_count * len(scan.blocks)
block_symbols = [bisect_left(trace.blocks, block) for block in range(block_count + 1)]
mcu_positions = [trace.positions[block_symbols[block]] for block in range(0, block_count, 6)]
path = root / 'parallel-large' / (name + '-scan0-chunk1024-intervals.npy')
intervals = read_words(path)
assert len(intervals) % 8 == 0
workers = []
for base in range(0, len(intervals), 8):
    start, end = intervals[base:base + 2]
    counts = []
    skip = 0
    if start < end:
        first = bisect_left(mcu_positions, start)
        last = bisect_left(mcu_positions, end)
        first_symbol = block_symbols[first * 6]
        start_symbol = bisect_left(trace.positions, start)
        assert trace.positions[start_symbol] == start
        skip = first_symbol - start_symbol
        counts = [block_symbols[index + 1] - block_symbols[index]
                  for index in range(first * 6, last * 6)]
    workers.append((counts, skip))
blocked = continuous = prefix = transform_rounds = useful_blocks = useful_symbols = 0
waves = []
for offset in range(0, len(workers), 32):
    group = workers[offset:offset + 32]
    rounds = max(len(counts) for counts, skip in group)
    wave_blocked = sum(max((counts[index] if index < len(counts) else 0)
                           for counts, skip in group) for index in range(rounds))
    wave_continuous = max(sum(counts) for counts, skip in group)
    wave_prefix = max(skip for counts, skip in group)
    blocked += wave_blocked
    continuous += wave_continuous
    prefix += wave_prefix
    transform_rounds += rounds
    useful_blocks += sum(len(counts) for counts, skip in group)
    useful_symbols += sum(sum(counts) for counts, skip in group)
    waves.append({'first_interval': offset, 'blocked_iterations': wave_blocked,
                  'continuous_iterations': wave_continuous, 'leading_skip_iterations': wave_prefix,
                  'block_rounds': rounds})
assert useful_blocks == block_count
result = {'input_sha256': hashlib.sha256(data).hexdigest(),
          'interval_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
          'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'scope': 'Logical wave iteration counts from actual qualified intervals; not timing, occupancy, or memory-controller evidence.',
          'blocks': block_count, 'useful_output_symbols': useful_symbols,
          'blocked_wave_iterations': blocked, 'continuous_wave_iterations': continuous,
          'leading_skip_wave_iterations': prefix, 'transform_rounds': transform_rounds,
          'block_lane_utilization': useful_blocks / (transform_rounds * 32),
          'blocked_symbol_lane_utilization': useful_symbols / (blocked * 32),
          'continuous_symbol_lane_utilization': useful_symbols / (continuous * 32),
          'blocked_to_continuous_iterations': blocked / continuous, 'waves': waves}
(notes / 'output-wave-work.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'waves'}), flush=True)
