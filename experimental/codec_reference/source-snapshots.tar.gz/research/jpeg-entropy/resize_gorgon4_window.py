"""Bound one idle native worker's exclusion inside a broker lease and resume."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import persistent_window as harness
import sharkbox_window as control

root=Path(__file__).resolve().parent
phase=sys.argv[1]
assert phase in ('check','cpu','routes','compare')
assert os.environ['BENCHMARK_LOCK_LEASE_ID']
control.OWNER='codec-jpeg-resize-20261019'
observed=harness.state();assert not observed['live_kfd'],observed
assert len(observed['native_workers'])==1,observed
pid=observed['native_workers'][0];process=Path('/proc')/str(pid)
arguments=(process/'cmdline').read_bytes().split(b'\0')
assert arguments[0]==b'/run/bureau/package/teleport-capture-runtime/bin/bureau-build-cell'
storage='/run/bureau/volume/teleport-corporate-worker/storage'
assert ('--storage='+storage).encode() in arguments
entry={'kind':'gorgon4-native','pid':pid,'binary':str(process/'root'/arguments[0].decode().lstrip('/')),
       'storage':str(process/'root'/storage.lstrip('/'))}
record={'phase':phase,'worker':entry,'before':observed,'controls':[]}
path=root/('window-'+phase+'.json');started=time.monotonic();attempted=False
try:
    state=control.control(entry,'status',timeout=5)
    assert state['State']=='accepting' and not state['Owner'] and state['Active']==0,state
    attempted=True
    state=control.control(entry,'hold',timeout=45);record['controls'].append({'hold':state})
    assert state['Owner']==control.OWNER and state['Active']==0,state
    env=os.environ.copy();env['CODEC_BENCHMARK_OWNER']=control.OWNER
    env['CODEC_BENCHMARK_WORKERS']=json.dumps([entry]);env['LD_LIBRARY_PATH']=str(root/'lib')
    script={'check':'execute.py','cpu':'resize_cpu_checks.py','routes':'resize_cpu_checks.py','compare':'resize_polling_compare.py'}[phase]
    command=['python3','-B',str(root/script)]+(['routes'] if phase=='routes' else [])
    result=subprocess.run(command,env=env,timeout=230 if phase=='compare' else 120)
    record['returncode']=result.returncode
    assert result.returncode==0
finally:
    if attempted:
        status=control.control(entry,'status',timeout=5)
        if status['Owner']==control.OWNER:
            record['controls'].append({'resume':control.control(entry,'resume',timeout=5)})
        else:
            assert not status['Owner'],status
        status=control.control(entry,'status',timeout=5)
        assert status['State']=='accepting' and not status['Owner'],status
        record['after_worker']=status
    record['wall_seconds']=time.monotonic()-started;record['after']=harness.state()
    path.write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({'phase':phase,'wall_seconds':record['wall_seconds'],'after_worker':record.get('after_worker')}),flush=True)
