#include <loomcxx/buffer.h>
#include <loomcxx/kernel.h>
#include <loomcxx/predicate.h>
#include <loomcxx/vector.h>

[[loom::config("image.width"), loom::where(loom::predicate::range(1u, 65535u))]]
extern const unsigned image_width;
[[loom::config("image.height"), loom::where(loom::predicate::range(1u, 65535u))]]
extern const unsigned image_height;
[[loom::config("image.batch"), loom::where(loom::predicate::range(1u, 65535u))]]
extern const unsigned image_batch;
[[loom::config("image.color_space"), loom::where(loom::predicate::range(1u, 3u))]]
extern const unsigned image_color_space;
[[loom::config("image.horizontal0"), loom::where(loom::predicate::range(1u, 4u))]]
extern const unsigned horizontal0;
[[loom::config("image.vertical0"), loom::where(loom::predicate::range(1u, 4u))]]
extern const unsigned vertical0;
[[loom::config("image.horizontal1"), loom::where(loom::predicate::range(1u, 4u))]]
extern const unsigned horizontal1;
[[loom::config("image.vertical1"), loom::where(loom::predicate::range(1u, 4u))]]
extern const unsigned vertical1;
[[loom::config("image.horizontal2"), loom::where(loom::predicate::range(1u, 4u))]]
extern const unsigned horizontal2;
[[loom::config("image.vertical2"), loom::where(loom::predicate::range(1u, 4u))]]
extern const unsigned vertical2;

using ColorSamples = int __attribute__((ext_vector_type(4)));

static LOOM_FORCE_INLINE unsigned color_divide_up(unsigned value, unsigned divisor) {
  return (value + divisor - 1) / divisor;
}

static LOOM_FORCE_INLINE unsigned color_plane_bytes(unsigned horizontal, unsigned vertical) {
  return color_divide_up(color_divide_up(image_width, horizontal), 8) *
         color_divide_up(color_divide_up(image_height, vertical), 8) * 64;
}

static LOOM_FORCE_INLINE unsigned color_address(unsigned column, unsigned row, unsigned width) {
  return ((row >> 3) * color_divide_up(width, 8) + (column >> 3)) * 64 +
         (row & 7u) * 8 + (column & 7u);
}

static LOOM_FORCE_INLINE unsigned color_edge(int value, unsigned extent) {
  if (value < 0) return 0;
  unsigned positive = static_cast<unsigned>(value);
  return positive < extent ? positive : extent - 1;
}

static LOOM_FORCE_INLINE bool color_horizontal_halo(unsigned horizontal, unsigned vertical) {
  unsigned width = color_divide_up(image_width, horizontal);
  return horizontal == 2 && (vertical == 1 || vertical == 2) && width > 2;
}

static LOOM_FORCE_INLINE bool color_vertical_halo(unsigned horizontal, unsigned vertical) {
  return vertical == 2 && (horizontal == 1 || color_horizontal_halo(horizontal, vertical));
}

static LOOM_FORCE_INLINE unsigned color_cache_columns(unsigned horizontal, unsigned vertical) {
  return color_divide_up(64, horizontal) + 2 * color_horizontal_halo(horizontal, vertical);
}

static LOOM_FORCE_INLINE unsigned color_cache_rows(unsigned horizontal, unsigned vertical) {
  return color_divide_up(16, vertical) + 2 * color_vertical_halo(horizontal, vertical);
}

static LOOM_FORCE_INLINE unsigned color_cache_size(unsigned horizontal, unsigned vertical) {
  return horizontal == 1 && vertical == 1 ? 1 :
      color_cache_columns(horizontal, vertical) * color_cache_rows(horizontal, vertical);
}

// One copy of each reduced-plane sample, including only the interpolation halo,
// feeds every four-pixel consumer in this output tile.
static LOOM_FORCE_INLINE void color_stage(const unsigned char* plane, unsigned* cache,
    unsigned horizontal, unsigned vertical, unsigned first_x, unsigned first_y) {
  if (horizontal == 1 && vertical == 1) return;
  unsigned width = color_divide_up(image_width, horizontal);
  unsigned height = color_divide_up(image_height, vertical);
  unsigned columns = color_cache_columns(horizontal, vertical);
  unsigned count = columns * color_cache_rows(horizontal, vertical);
  int first_column = static_cast<int>(first_x / horizontal) - color_horizontal_halo(horizontal, vertical);
  int first_row = static_cast<int>(first_y / vertical) - color_vertical_halo(horizontal, vertical);
  unsigned threads = loom::kernel::workgroup::size.x;
  for (unsigned index = loom::kernel::workitem::id.x; index < count;
       index += threads) {
    unsigned column = color_edge(first_column + static_cast<int>(index % columns), width);
    unsigned row = color_edge(first_row + static_cast<int>(index / columns), height);
    cache[index] = plane[color_address(column, row, width)];
  }
}

static LOOM_FORCE_INLINE ColorSamples color_samples(const unsigned char* plane,
    const unsigned* cache, unsigned horizontal, unsigned vertical,
    unsigned first_x, unsigned first_y, unsigned x, unsigned y) {
  ColorSamples result = {};
  if (horizontal == 1 && vertical == 1) {
    unsigned address = color_address(x, y, image_width);
    unsigned packed = *reinterpret_cast<const unsigned*>(plane + address);
    [[loom::unroll]]
    for (unsigned index = 0; index < 4; ++index) result[index] = (packed >> (index * 8)) & 255u;
    return result;
  }
  unsigned columns = color_cache_columns(horizontal, vertical);
  unsigned cache_count = columns * color_cache_rows(horizontal, vertical);
  unsigned column = x / horizontal - first_x / horizontal + color_horizontal_halo(horizontal, vertical);
  unsigned row = y / vertical - first_y / vertical + color_vertical_halo(horizontal, vertical);
  if (color_horizontal_halo(horizontal, vertical)) {
    ColorSamples weighted = {};
    [[loom::unroll]]
    for (unsigned index = 0; index < 4; ++index) {
      unsigned position = row * columns + column + index - 1;
      // The four-pixel owner lies inside the tile; staged halos include both
      // neighbors. Retain that geometric bound across global/local division.
      loom::assume(position < cache_count);
      unsigned value = cache[position];
      if (vertical == 2) {
        unsigned neighbor = (y & 1u) ? position + columns : position - columns;
        loom::assume(neighbor < cache_count);
        value = 3 * value + cache[neighbor];
      }
      weighted[index] = value;
    }
    unsigned shift = vertical == 2 ? 4 : 2;
    unsigned even_bias = vertical == 2 ? 8 : 1;
    unsigned odd_bias = vertical == 2 ? 7 : 2;
    result[0] = (3 * weighted[1] + weighted[0] + even_bias) >> shift;
    result[1] = (3 * weighted[1] + weighted[2] + odd_bias) >> shift;
    result[2] = (3 * weighted[2] + weighted[1] + even_bias) >> shift;
    result[3] = (3 * weighted[2] + weighted[3] + odd_bias) >> shift;
  } else {
    [[loom::unroll]]
    for (unsigned index = 0; index < 4; ++index) {
      unsigned current_column = (x + index) / horizontal - first_x / horizontal;
      unsigned position = row * columns + current_column;
      loom::assume(position < cache_count);
      unsigned value = cache[position];
      if (color_vertical_halo(horizontal, vertical)) {
        unsigned neighbor = (y & 1u) ? position + columns : position - columns;
        loom::assume(neighbor < cache_count);
        value = (3 * value + cache[neighbor] + ((y & 1u) ? 2 : 1)) >> 2;
      }
      result[index] = value;
    }
  }
  return result;
}

static LOOM_FORCE_INLINE unsigned color_clamp(int value) {
  unsigned positive = static_cast<unsigned>(value & ~(value >> 31));
  return (positive | (0u - static_cast<unsigned>(positive > 255u))) & 255u;
}

static loom::kernel::configuration configure_color() {
  return {{color_divide_up(image_width, 64), color_divide_up(image_height, 16), image_batch},
          {256, 1, 1}};
}

[[loom::kernel(configure_color)]]
void jpeg_color(const unsigned char* components, unsigned char* rgb) {
  unsigned bytes0 = color_plane_bytes(horizontal0, vertical0);
  unsigned bytes1 = color_plane_bytes(horizontal1, vertical1);
  unsigned bytes2 = color_plane_bytes(horizontal2, vertical2);
  unsigned stride = image_color_space == 1 ? bytes0 : bytes0 + bytes1 + bytes2;
  const unsigned char* plane0 = components + loom::kernel::workgroup::id.z * stride;
  const unsigned char* plane1 = plane0 + bytes0;
  const unsigned char* plane2 = plane1 + bytes1;
  auto* cache0 = loom::buffer::alloca<unsigned, loom::memory_space::workgroup, 16>(color_cache_size(horizontal0, vertical0));
  auto* cache1 = loom::buffer::alloca<unsigned, loom::memory_space::workgroup, 16>(color_cache_size(horizontal1, vertical1));
  auto* cache2 = loom::buffer::alloca<unsigned, loom::memory_space::workgroup, 16>(color_cache_size(horizontal2, vertical2));
  unsigned first_x = loom::kernel::workgroup::id.x * 64;
  unsigned first_y = loom::kernel::workgroup::id.y * 16;
  color_stage(plane0, cache0, horizontal0, vertical0, first_x, first_y);
  if (image_color_space != 1) {
    color_stage(plane1, cache1, horizontal1, vertical1, first_x, first_y);
    color_stage(plane2, cache2, horizontal2, vertical2, first_x, first_y);
  }
  loom::kernel::workgroup::barrier();
  unsigned lane = loom::kernel::workitem::id.x;
  unsigned x = first_x + (lane & 15u) * 4;
  unsigned y = first_y + (lane >> 4);
  if (x >= image_width || y >= image_height) return;
  ColorSamples values0 = color_samples(plane0, cache0, horizontal0, vertical0, first_x, first_y, x, y);
  ColorSamples values1 = {};
  ColorSamples values2 = {};
  if (image_color_space != 1) {
    values1 = color_samples(plane1, cache1, horizontal1, vertical1, first_x, first_y, x, y);
    values2 = color_samples(plane2, cache2, horizontal2, vertical2, first_x, first_y, x, y);
  }
  ColorSamples red = values0;
  ColorSamples green = image_color_space == 1 ? values0 : values1;
  ColorSamples blue = image_color_space == 1 ? values0 : values2;
  if (image_color_space == 3) {
    [[loom::unroll]]
    for (unsigned index = 0; index < 4; ++index) {
      int cb = values1[index] - 128;
      int cr = values2[index] - 128;
      red[index] = values0[index] + ((91881 * cr + 32768) >> 16);
      green[index] = values0[index] + ((-22554 * cb - 46802 * cr + 32768) >> 16);
      blue[index] = values0[index] + ((116130 * cb + 32768) >> 16);
    }
  }
  ColorSamples packed = {};
  [[loom::unroll]]
  for (unsigned index = 0; index < 4; ++index) {
    packed[index] = color_clamp(red[index]) | (color_clamp(green[index]) << 8) |
                    (color_clamp(blue[index]) << 16);
  }
  unsigned offset = ((loom::kernel::workgroup::id.z * image_height + y) * image_width + x) * 3;
  if ((image_width & 3u) == 0) {
    unsigned* output = reinterpret_cast<unsigned*>(rgb + offset);
    using Words = unsigned __attribute__((ext_vector_type(4)));
    using Triple = loom::type::vector<loom::type::shape<3>, unsigned>;
    Words words = {
        static_cast<unsigned>(packed[0]) | (static_cast<unsigned>(packed[1]) << 24),
        (static_cast<unsigned>(packed[1]) >> 8) | (static_cast<unsigned>(packed[2]) << 16),
        (static_cast<unsigned>(packed[2]) >> 16) | (static_cast<unsigned>(packed[3]) << 8), 0};
    auto destination = loom::buffer::view<3>(output, {}, loom::encoding::layout::dense<1>());
    loom::vector::store(loom::vector::slice<Triple>(words, 0), destination, {0});
  } else {
    [[loom::unroll]]
    for (unsigned index = 0; index < 4; ++index) {
      if (x + index < image_width) {
        rgb[offset + index * 3] = static_cast<unsigned char>(packed[index]);
        rgb[offset + index * 3 + 1] = static_cast<unsigned char>(static_cast<unsigned>(packed[index]) >> 8);
        rgb[offset + index * 3 + 2] = static_cast<unsigned char>(static_cast<unsigned>(packed[index]) >> 16);
      }
    }
  }
}
