"""Compare optimized compiler processes; no GPU submission or counter calls."""
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import time

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'manifest.json').read_text())
for relative, expected in manifest['files'].items():
    assert hashlib.sha256((root / relative).read_bytes()).hexdigest() == expected
state = {'host': os.uname().nodename,
         'lease': os.environ['BENCHMARK_LOCK_LEASE_ID'],
         'load_average': os.getloadavg(),
         'cpu_affinity': sorted(os.sched_getaffinity(0)),
         'governors': sorted({p.read_text().strip() for p in
                             Path('/sys/devices/system/cpu').glob('cpu*/cpufreq/scaling_governor')})}
rows = []
for source in ('entropy.loombc', 'entropy-tables.loombc'):
    commands = {}
    for variant in ('baseline', 'candidate'):
        commands[variant] = [str(root / ('loom-compile-' + variant)),
                             str(root / source), '--root=jpeg_speculate',
                             '--target=amdgpu:gfx1151', '--output=/dev/null',
                             '--config-file=' + str(root / 'config.json')]
        if source == 'entropy-tables.loombc':
            commands[variant] += ['--config=jpeg.table_count=4',
                                   '--config=jpeg.cache_tables=0']
    for _ in range(2):
        for command in commands.values():
            subprocess.run(command, check=True, stdout=subprocess.DEVNULL)
    samples = []
    for index in range(41):
        for variant in (('baseline', 'candidate') if index % 2 == 0
                        else ('candidate', 'baseline')):
            start = time.perf_counter_ns()
            subprocess.run(commands[variant], check=True,
                           stdout=subprocess.DEVNULL)
            samples.append({'index': index, 'variant': variant,
                            'wall_ns': time.perf_counter_ns() - start})
    medians = {variant: statistics.median(s['wall_ns'] for s in samples
                                         if s['variant'] == variant)
               for variant in commands}
    rows.append({'source': source, 'commands': commands, 'samples': samples,
                 'median_wall_ns': medians,
                 'candidate_over_baseline': medians['candidate'] / medians['baseline']})
    print(json.dumps({key: value for key, value in rows[-1].items()
                      if key not in ('commands', 'samples')}), flush=True)
result = {'state_before': state, 'manifest': manifest,
          'boundary': 'CLI startup + parsing + compilation + emission to /dev/null; warm filesystem; no reports; no device execution',
          'order': '41 AB/BA pairs per source after two warmups per variant',
          'state_after': {'load_average': os.getloadavg()}, 'rows': rows}
(root / 'timing.json').write_text(json.dumps(result, indent=2) + '\n')
