#include <loomcxx/scalar.h>

struct ResizePlan {
  // Final RGB width in pixels.
  unsigned width;
  // Final RGB height in pixels.
  unsigned height;
  // First float in the image's bounded horizontal-filter ring.
  unsigned horizontal_word_offset;
  // Source rows retained until all vertical readers finish.
  unsigned horizontal_rows;
  // First source-column entry in the shared index table.
  unsigned horizontal_starts;
  // First prefix-offset entry in the shared index table.
  unsigned horizontal_offsets;
  // First normalized horizontal coefficient in the shared weight table.
  unsigned horizontal_weights;
  // First source-row entry in the shared index table.
  unsigned vertical_starts;
  // First vertical prefix-offset entry in the shared index table.
  unsigned vertical_offsets;
  // First normalized vertical coefficient in the shared weight table.
  unsigned vertical_weights;
  // First four-word source-span/output-span tile in the shared tile table.
  unsigned tile_offset;
  // Horizontal workgroups per source row.
  unsigned tile_count;
  // First destination-row completion counter.
  unsigned row_offset;
  // First byte of private resized output, not published on input failure.
  unsigned output_offset;
};

static LOOM_FORCE_INLINE unsigned mcu_height(Image image) {
  return image.color_kind == 5 || image.color_kind == 6 || image.color_kind == 8 ? 16u : 8u;
}

[[loom::kernel(configure_stream_init)]]
void jpeg_resize_init(const unsigned* segments, const unsigned* intervals,
    const Image* images, const unsigned* blocks, const Stream* plans, Stream* streams,
    unsigned* heads, unsigned* pending, unsigned* decoded, unsigned* color_claimed,
    unsigned* color_done, unsigned* links, unsigned* cursors,
    const unsigned* errors, const ResizePlan* resize_plans,
    unsigned* resize_rows, unsigned* resize_claimed, unsigned* resize_done) {
  jpeg_stream_init_body(segments, intervals, images, blocks, plans, streams,
      heads, pending, decoded, color_claimed, color_done, links, cursors);
  unsigned image = loom::kernel::workgroup::id.x;
  unsigned lane = loom::kernel::workitem::id.x;
  ResizePlan plan = resize_plans[image];
  if (lane == 0) {
    resize_rows[image] = 0;
    streams[image].error = errors[image * 4] ? 256u + errors[image * 4] : 0u;
  }
  for (unsigned row = lane; row < plan.height; row += 256) {
    resize_claimed[plan.row_offset + row] = 0;
    resize_done[plan.row_offset + row] = 0;
  }
}

// The geometry plan admits at most 32 outputs within one aligned 128-pixel
// source span. Each converted source value is shared by all its filter taps.
template<unsigned image_color_space, unsigned horizontal0, unsigned vertical0,
         unsigned horizontal1, unsigned vertical1, unsigned horizontal2, unsigned vertical2>
static LOOM_FORCE_INLINE void resize_horizontal(const unsigned char* components,
    Image image, ResizePlan plan, const unsigned* indices, const float* weights,
    const unsigned* tile, unsigned y, float* horizontal, unsigned* cache) {
  StreamColorGeometry dimensions{image.width, image.height, mcu_height(image)};
  unsigned first_x = tile[2];
  const unsigned char* plane0 = components + image.component_word_offset * 4;
  const unsigned char* plane1 = plane0 + image.first_plane_bytes;
  const unsigned char* plane2 = plane1 + image.second_plane_bytes;
  filter_color_stage(dimensions, plane0, cache, horizontal0, vertical0, first_x, y);
  if (image_color_space != 1) {
    filter_color_stage(dimensions, plane1, cache, horizontal1, vertical1, first_x, y);
    filter_color_stage(dimensions, plane2, cache + 512, horizontal2, vertical2, first_x, y);
  }
  loom::kernel::barrier<loom::memory_space::workgroup,
      loom::atomic::scope::subgroup, loom::atomic::ordering::acq_rel>();
  unsigned lane = loom::kernel::workitem::id.x;
  unsigned x = first_x + lane * 4;
  ColorSamples packed = {};
  if (x < image.width) {
    ColorSamples values0 = filter_color_samples(dimensions, plane0, cache,
        horizontal0, vertical0, first_x, y, x, y);
    ColorSamples values1 = {};
    ColorSamples values2 = {};
    if (image_color_space != 1) {
      values1 = filter_color_samples(dimensions, plane1, cache,
          horizontal1, vertical1, first_x, y, x, y);
      values2 = filter_color_samples(dimensions, plane2, cache + 512,
          horizontal2, vertical2, first_x, y, x, y);
    }
    [[loom::unroll]]
    for (unsigned item = 0; item < 4; ++item) {
      int red = values0[item];
      int green = image_color_space == 1 ? red : values1[item];
      int blue = image_color_space == 1 ? red : values2[item];
      if (image_color_space == 3) {
        int cb = values1[item] - 128;
        int cr = values2[item] - 128;
        red += (91881 * cr + 32768) >> 16;
        green = values0[item] + ((-22554 * cb - 46802 * cr + 32768) >> 16);
        blue = values0[item] + ((116130 * cb + 32768) >> 16);
      }
      packed[item] = filter_color_clamp(dimensions, red) |
          (filter_color_clamp(dimensions, green) << 8) |
          (filter_color_clamp(dimensions, blue) << 16);
    }
  }
  // All chroma readers finish before the same LDS allocation becomes RGB.
  loom::kernel::barrier<loom::memory_space::workgroup,
      loom::atomic::scope::subgroup, loom::atomic::ordering::acq_rel>();
  [[loom::unroll]]
  for (unsigned item = 0; item < 4; ++item) cache[lane * 4 + item] = packed[item];
  loom::kernel::barrier<loom::memory_space::workgroup,
      loom::atomic::scope::subgroup, loom::atomic::ordering::acq_rel>();
  unsigned output_x = tile[0] + lane;
  if (output_x < tile[1]) {
    unsigned start = indices[plan.horizontal_starts + output_x];
    unsigned begin = indices[plan.horizontal_offsets + output_x];
    unsigned end = indices[plan.horizontal_offsets + output_x + 1];
    float red = 0.0f, green = 0.0f, blue = 0.0f;
    for (unsigned tap = begin; tap < end; ++tap) {
      unsigned local = start + tap - begin - first_x;
      loom::assume(local < 128u);
      unsigned value = cache[local];
      float weight = weights[plan.horizontal_weights + tap];
      red += static_cast<float>(value & 255u) * weight;
      green += static_cast<float>((value >> 8) & 255u) * weight;
      blue += static_cast<float>(value >> 16) * weight;
    }
    unsigned offset = plan.horizontal_word_offset + ((y % plan.horizontal_rows) * plan.width + output_x) * 3;
    horizontal[offset] = red;
    horizontal[offset + 1] = green;
    horizontal[offset + 2] = blue;
  }
}

static LOOM_FORCE_INLINE void resize_horizontal_select(const unsigned char* components,
    Image image, ResizePlan plan, const unsigned* indices, const float* weights,
    const unsigned* tile, unsigned y, float* horizontal, unsigned* storage) {
  // The same eight admitted color/sampling families as the decoded-pixel control.
  RESIZE_COLOR_SPECIALIZATIONS
}

static LOOM_FORCE_INLINE void resize_vertical(ResizePlan plan,
    const unsigned* indices, const float* weights, const float* horizontal,
    unsigned char* provisional, unsigned row, unsigned tile) {
  unsigned x = tile * 32 + loom::kernel::workitem::id.x;
  if (x < plan.width) {
    unsigned start = indices[plan.vertical_starts + row];
    unsigned begin = indices[plan.vertical_offsets + row];
    unsigned end = indices[plan.vertical_offsets + row + 1];
    float red = 0.0f, green = 0.0f, blue = 0.0f;
    for (unsigned tap = begin; tap < end; ++tap) {
      unsigned source_row = (start + tap - begin) % plan.horizontal_rows;
      unsigned offset = plan.horizontal_word_offset + (source_row * plan.width + x) * 3;
      float weight = weights[plan.vertical_weights + tap];
      red += horizontal[offset] * weight;
      green += horizontal[offset + 1] * weight;
      blue += horizontal[offset + 2] * weight;
    }
    unsigned offset = plan.output_offset + (row * plan.width + x) * 3;
    float values[3] = {red, green, blue};
    [[loom::unroll]]
    for (unsigned channel = 0; channel < 3; ++channel) {
      float value = loom::scalar::roundevenf(values[channel]);
      value = value < 0.0f ? 0.0f : value > 255.0f ? 255.0f : value;
      provisional[offset + channel] = static_cast<unsigned char>(value);
    }
  }
}

static loom::kernel::configuration configure_resize_workers() {
  return {{stream_workers, 1, 1}, {32, 1, 1}};
}

[[loom::kernel(configure_resize_workers)]]
void jpeg_resize_stream(const unsigned* entropy, const unsigned* segments,
    const unsigned* tables, const unsigned* blocks, const unsigned* intervals,
    const unsigned* geometry, const unsigned* quantization, const unsigned* zigzag,
    unsigned* pixels, const Image* images, Stream* streams,
    unsigned* heads, unsigned* pending, unsigned* decoded, unsigned* color_claimed,
    unsigned* color_done, unsigned* links, unsigned* cursors,
    const ResizePlan* resize_plans, const unsigned* filter_indices,
    const float* filter_weights, const unsigned* filter_tiles,
    float* horizontal, unsigned char* provisional, unsigned* resize_rows,
    unsigned* resize_claimed, unsigned* resize_done) {
  unsigned lane = loom::kernel::workitem::id.x;
  unsigned search = loom::kernel::workgroup::id.x % certification_segments;
  auto* storage = loom::buffer::alloca<unsigned, loom::memory_space::workgroup, 16>(1024);
  while (true) {
    unsigned role = 0, selected_image = 0, selected_row = 0, selected_tile = 0, done_count = 0;
    if (lane == 0) {
      for (unsigned attempt = 0; attempt < certification_segments && role == 0; ++attempt) {
        unsigned image_index = (search + attempt) % certification_segments;
        Stream* stream = streams + image_index;
        Image image = images[image_index];
        ResizePlan plan = resize_plans[image_index];
        unsigned row = observe(&stream->color_row);
        unsigned output_row = observe(resize_rows + image_index);
        unsigned rows = stream->row_count;
        if (observe(&stream->error) != 0 ||
            (row == rows && output_row == plan.height &&
             observe(&stream->interval_done) == stream->interval_count)) {
          ++done_count;
          continue;
        }
        unsigned height = mcu_height(image);
        unsigned first_live = image.height;
        if (output_row < plan.height) {
          first_live = filter_indices[plan.vertical_starts + output_row];
          unsigned begin = filter_indices[plan.vertical_offsets + output_row];
          unsigned end = filter_indices[plan.vertical_offsets + output_row + 1];
          if (first_live + end - begin <= row * height) {
            unsigned tile = observe(row_address(resize_claimed, plan.row_offset + output_row));
            if (tile < (plan.width + 31) / 32 &&
                compare(row_address(resize_claimed, plan.row_offset + output_row), tile, tile + 1) == tile) {
              role = 3; selected_image = image_index;
              selected_row = output_row; selected_tile = tile;
            }
          }
        }
        unsigned row_offset = stream->row_offset;
        unsigned previous = row ? row - 1 : 0;
        unsigned next = row + 1 < rows ? row + 1 : rows - 1;
        unsigned last = (row + 1) * height;
        last = last < image.height ? last : image.height;
        if (role == 0 && row < rows && last <= first_live + plan.horizontal_rows &&
            observe(row_address(pending, row_offset + previous)) == 0 &&
            observe(row_address(pending, row_offset + row)) == 0 &&
            observe(row_address(pending, row_offset + next)) == 0 &&
            observe(row_address(decoded, row_offset + previous)) == image.mcu_columns &&
            observe(row_address(decoded, row_offset + row)) == image.mcu_columns &&
            observe(row_address(decoded, row_offset + next)) == image.mcu_columns) {
          unsigned tiles = plan.tile_count * (last - row * height);
          unsigned tile = observe(row_address(color_claimed, row_offset + row));
          if (tile < tiles && compare(row_address(color_claimed, row_offset + row), tile, tile + 1) == tile) {
            role = 2; selected_image = image_index; selected_row = row; selected_tile = tile;
          }
        }
        unsigned first_row = row ? row - 1 : 0;
        for (unsigned relative = 0; relative < stream_rows && role == 0; ++relative) {
          unsigned candidate = first_row + relative;
          if (candidate < rows && claim_decode(row_address(heads, row_offset + candidate), links, storage)) {
            role = 1; selected_image = image_index; selected_row = candidate;
          }
        }
      }
    }
    role = loom::kernel::subgroup::broadcast(role, 0);
    selected_image = loom::kernel::subgroup::broadcast(selected_image, 0);
    unsigned available_images = certification_segments;
    loom::assume(selected_image < available_images);
    selected_row = loom::kernel::subgroup::broadcast(selected_row, 0);
    selected_tile = loom::kernel::subgroup::broadcast(selected_tile, 0);
    done_count = loom::kernel::subgroup::broadcast(done_count, 0);
    if (done_count == certification_segments) break;
    loom::kernel::barrier<loom::memory_space::global,
        loom::atomic::scope::subgroup, loom::atomic::ordering::acq_rel>();
    loom::kernel::barrier<loom::memory_space::workgroup,
        loom::atomic::scope::subgroup, loom::atomic::ordering::acq_rel>();
    Stream* stream = streams + selected_image;
    Image image = images[selected_image];
    ResizePlan plan = resize_plans[selected_image];
    if (role == 1) {
      unsigned task = storage[lane];
      loom::kernel::barrier<loom::memory_space::workgroup,
          loom::atomic::scope::subgroup, loom::atomic::ordering::acq_rel>();
      unsigned produced = stream_decode(entropy, segments, tables, blocks, intervals,
          geometry, quantization, zigzag, pixels, images, selected_image,
          selected_row, task, reinterpret_cast<short*>(storage), cursors,
          streams, heads, pending, links);
      unsigned total = loom::kernel::subgroup::reduce::addi(produced);
      unsigned retired = loom::kernel::subgroup::reduce::addi(static_cast<unsigned>(task != absent));
      loom::kernel::barrier<loom::memory_space::global,
          loom::atomic::scope::subgroup, loom::atomic::ordering::acq_rel>();
      if (lane == 0) {
        if (total) add(row_address(decoded, stream->row_offset + selected_row), total);
        add(row_address(pending, stream->row_offset + selected_row), 0u - retired);
      }
    } else if (role == 2) {
      unsigned height = mcu_height(image);
      unsigned y = selected_row * height + selected_tile / plan.tile_count;
      const unsigned* tile = filter_tiles + (plan.tile_offset + selected_tile % plan.tile_count) * 4;
      resize_horizontal_select(reinterpret_cast<const unsigned char*>(pixels), image,
          plan, filter_indices, filter_weights, tile, y, horizontal, storage);
      loom::kernel::barrier<loom::memory_space::global,
          loom::atomic::scope::subgroup, loom::atomic::ordering::acq_rel>();
      if (lane == 0) {
        unsigned last = (selected_row + 1) * height;
        last = last < image.height ? last : image.height;
        unsigned tiles = plan.tile_count * (last - selected_row * height);
        if (add(row_address(color_done, stream->row_offset + selected_row), 1) + 1 == tiles)
          publish(&stream->color_row, selected_row + 1);
      }
    } else if (role == 3) {
      resize_vertical(plan, filter_indices, filter_weights, horizontal, provisional, selected_row, selected_tile);
      loom::kernel::barrier<loom::memory_space::global,
          loom::atomic::scope::subgroup, loom::atomic::ordering::acq_rel>();
      if (lane == 0 && add(row_address(resize_done, plan.row_offset + selected_row), 1) + 1 == (plan.width + 31) / 32)
        publish(resize_rows + selected_image, selected_row + 1);
    }
    search = (search + 1) % certification_segments;
  }
}

[[loom::kernel(configure_stream_init)]]
void jpeg_resize_publish(const Stream* streams, const ResizePlan* resize_plans,
    const unsigned* resize_rows, const unsigned char* provisional,
    unsigned char* resized, unsigned* validity) {
  unsigned image = loom::kernel::workgroup::id.x;
  unsigned lane = loom::kernel::workitem::id.x;
  ResizePlan plan = resize_plans[image];
  unsigned error = streams[image].error;
  if (lane == 0) validity[image] = error;
  if (error == 0) {
    unsigned count = plan.width * plan.height * 3;
    for (unsigned byte = lane; byte < count; byte += 256)
      resized[plan.output_offset + byte] = provisional[plan.output_offset + byte];
  }
}
