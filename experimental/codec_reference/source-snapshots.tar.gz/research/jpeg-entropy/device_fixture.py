"""Independent C2 summary fixtures, not deployment entropy preprocessing."""
import argparse
import ast
import base64
import hashlib
import json
from pathlib import Path
import struct

from recover_prefix import speculate
from sequential import parse


ROOT = Path(__file__).resolve().parent


def read_words(path):
    data = path.read_bytes()
    assert data[:8] == b'\x93NUMPY\x01\x00'
    size = struct.unpack_from('<H', data, 8)[0]
    header = ast.literal_eval(data[10:10 + size].decode('ascii'))
    assert header['descr'] == '<i4' and not header['fortran_order']
    count, = header['shape']
    assert len(data) == 10 + size + count * 4
    return struct.unpack_from('<' + 'I' * count, data, 10 + size)


def write_words(filename, words):
    header = repr({'descr': '<i4', 'fortran_order': False, 'shape': (len(words),)})
    header = header.encode('ascii')
    header += b' ' * ((64 - ((10 + len(header) + 1) % 64)) % 64) + b'\n'
    with filename.open('wb') as output:
        output.write(b'\x93NUMPY\x01\x00' + struct.pack('<H', len(header)) + header)
        for word in words:
            output.write(struct.pack('<I', word & 0xffffffff))


def input_bytes(name):
    if name == 'existing_exif_fixture':
        source = ROOT.parents[2] / 'loom/src/loom/serve/media/testdata/image_fuzz/jpeg.txt'
        return base64.b64decode(source.read_text().strip().split(',', 1)[1], validate=True)
    for line in (ROOT.parent / 'jpeg-reference/probe.log').read_text().splitlines():
        if line.startswith('{"kind":'):
            row = json.loads(line)
            if row['kind'] == 'input' and row['name'] == name:
                return bytes.fromhex(row['hex'])
    if name in ('dense-periodic', 'mcu-phase'):
        return (ROOT / (name + '.jpg')).read_bytes()
    return (ROOT.parent / 'jpeg-baseline/inputs' / name).read_bytes()


def table_words(table):
    words = [0] * 832
    ordered = sorted(table.symbols.items())
    base = 0
    for length in range(1, 17):
        entries = [(key - (1 << length), value) for key, value in ordered
                   if key.bit_length() == length + 1]
        words[512 + length * 3:515 + length * 3] = [
            entries[0][0] if entries else 0, len(entries), base]
        for code, value in entries:
            words[563 + base] = value
            base += 1
            if length <= 9:
                for prefix in range(code << (9 - length), (code + 1) << (9 - length)):
                    assert words[prefix] == 0
                    words[prefix] = (length << 8) | value
    return words


def fixture(name, chunk_bytes, directory):
    data = input_bytes(name)
    frame = parse(data)
    cases = []
    for scan_index, scan in enumerate(frame.scans):
        tables = []
        table_indices = {}
        blocks = []
        for block in scan.blocks:
            indices = []
            for table in (block.dc, block.ac):
                key = tuple(sorted(table.symbols.items()))
                if key not in table_indices:
                    table_indices[key] = len(tables) // 832
                    tables.extend(table_words(table))
                indices.append(table_indices[key])
            blocks.append(block.component | (indices[0] << 8) | (indices[1] << 16))
        entropy, jobs, expected = [], [], []
        counters = {}
        stride = (5 + len(frame.components) + 3) & ~3
        for segment in scan.segments:
            offset = len(entropy)
            padded = segment.data + bytes((-len(segment.data)) % 4 + 8)
            entropy.extend(struct.unpack('>' + 'I' * (len(padded) // 4), padded))
            intervals = (len(segment.data) + chunk_bytes - 1) // chunk_bytes
            summaries, counts = speculate(segment, scan, len(frame.components),
                                           chunk_bytes * 8, 1, intervals)
            for key, value in counts.items():
                counters[key] = counters.get(key, 0) + value
            for interval, summary in enumerate(summaries):
                jobs.extend([offset, len(segment.data) * 8, interval])
                words = [0xffffffff] + [0] * (stride - 1)
                if summary is not None:
                    first, last = summary.first, summary.last
                    words[:5] = [first.position,
                                 (first.blocks % len(scan.blocks)) * 64 + first.coefficient,
                                 last.position,
                                 (last.blocks % len(scan.blocks)) * 64 + last.coefficient,
                                 last.blocks - first.blocks]
                    for component in range(len(frame.components)):
                        words[5 + component] = last.predictors[component] - first.predictors[component]
                expected.extend(words)
        key = f'{name}-scan{scan_index}-chunk{chunk_bytes}'
        tensors = {'entropy': entropy, 'jobs': jobs, 'tables': tables,
                   'blocks': blocks, 'expected': expected}
        for tensor, words in tensors.items():
            write_words(directory / (key + '-' + tensor + '.npy'), words)
        lines = ['kernel.decl @jpeg_speculate() launch(%entropy: buffer, %jobs: buffer, '
                 '%tables: buffer, %blocks: buffer, %summaries: buffer)',
                 '', 'check.case @summary {']
        for tensor, words in tensors.items():
            lines.append(f'  %{tensor} = check.file.read.npy path("{key}-{tensor}.npy") : tensor<{len(words)}xi32>')
        lines.append(f'  %output = check.generate.fill value(17) : tensor<{len(expected)}xi32>')
        lines.append('  kernel.launch @jpeg_speculate(%entropy, %jobs, %tables, %blocks, %output) : (' +
                     ', '.join(f'tensor<{len(tensors[tensor])}xi32>' for tensor in
                               ('entropy', 'jobs', 'tables', 'blocks', 'expected')) + ')')
        lines.append(f'  check.file.write.npy value(%output) path("{key}.npy") mode(always) : tensor<{len(expected)}xi32>')
        lines.append(f'  check.expect.bitwise actual(%output) expected(%expected) : tensor<{len(expected)}xi32>')
        lines.extend(['  check.return', '}'])
        (directory / (key + '.loom')).write_text('\n'.join(lines) + '\n')
        config = {'jpeg': {'chunks': len(jobs) // 3, 'chunk_bytes': chunk_bytes,
                           'blocks': len(scan.blocks), 'components': len(frame.components)}}
        (directory / (key + '.json')).write_text(json.dumps(config, indent=2) + '\n')
        cases.append({'name': name, 'scan': scan_index, 'chunk_bytes': chunk_bytes,
                      'key': key, 'jobs': len(jobs) // 3, 'input_sha256': hashlib.sha256(data).hexdigest(),
                      'logical_summary_bytes': len(expected) * 4,
                      'counters': counters})
    return cases


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', action='append', required=True)
    parser.add_argument('--chunk-bytes', type=int, nargs='+', default=[1024, 4096])
    parser.add_argument('--directory', type=Path, required=True)
    arguments = parser.parse_args()
    arguments.directory.mkdir(parents=True, exist_ok=True)
    records = []
    for name in arguments.input:
        for count in arguments.chunk_bytes:
            records.extend(fixture(name, count, arguments.directory))
    receipt = {'sources': {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                           for name in ('device_entropy.cxx', 'device_fixture.py',
                                        'recover_prefix.py', 'sequential.py')}, 'cases': records}
    (arguments.directory / 'fixtures.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'cases': len(records), 'jobs': sum(row['jobs'] for row in records),
                      'directory': str(arguments.directory)}), flush=True)


if __name__ == '__main__':
    main()
