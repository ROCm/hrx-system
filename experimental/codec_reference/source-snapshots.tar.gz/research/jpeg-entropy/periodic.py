"""Independent T.81 fixtures and exact syntax-state observations, not timing."""
from pathlib import Path
import hashlib
import json
import struct

ROOT = Path(__file__).resolve().parent


def segment(marker, payload):
    return bytes([255, marker]) + struct.pack('>H', len(payload) + 2) + payload


def fixture(dense):
    # Canonical one-symbol DC and AC tables both assign code 0. The unused
    # code 1 obeys the JPEG prohibition on all-ones Huffman codewords.
    counts = bytes([1] + [0] * 15)
    dc = bytes([0]) + counts + bytes([0])
    ac = bytes([16]) + counts + bytes([1 if dense else 0])
    sof = struct.pack('>BHHB', 8, 64, 64, 3)
    sof += bytes([1, 0x22, 0, 2, 0x11, 0, 3, 0x11, 0])
    sos = bytes([3, 1, 0, 2, 0, 3, 0, 0, 63, 0])
    # Six blocks per MCU, sixteen MCUs. Dense blocks contain DC 0 then 63
    # nonzero AC values -1 (run/size 0/1, amplitude bit 0). Sparse blocks
    # contain DC 0 followed by EOB. No stuffing or padding is needed here.
    bits_per_block = 127 if dense else 2
    entropy_bits = 96 * bits_per_block
    assert entropy_bits % 8 == 0
    header = (b'\xff\xd8' + segment(0xdb, bytes([0] + [1] * 64)) +
              segment(0xc0, sof) + segment(0xc4, dc + ac) + segment(0xda, sos))
    data = header + bytes(entropy_bits // 8) + b'\xff\xd9'
    return data, len(header), entropy_bits


def states(start, end, dense):
    # State is immediately before a Huffman symbol. DC predictors are not
    # needed for syntax and remain zero in these witnesses.
    position, block, coefficient = start, 0, 0
    result = {}
    while position < end:
        result[position] = (block, coefficient)
        if dense:
            position += 1 if coefficient == 0 else 2
            coefficient += 1
            if coefficient == 64:
                coefficient = 0
                block = (block + 1) % 6
        else:
            position += 1
            if coefficient == 0:
                coefficient = 1
            else:
                coefficient = 0
                block = (block + 1) % 6
    return result


def component(block):
    return 0 if block < 4 else block - 3


rows = []
for dense in [True, False]:
    name = 'dense-periodic' if dense else 'mcu-phase'
    data, offset, bit_count = fixture(dense)
    (ROOT / (name + '.jpg')).write_bytes(data)
    start = 1024 if dense else 8
    anchored = states(0, bit_count, dense)
    speculative = states(start, bit_count, dense)
    matches = []
    partial_matches = []
    for position in sorted(anchored.keys() & speculative.keys()):
        left, right = anchored[position], speculative[position]
        if left == right:
            matches.append(position)
        if (component(left[0]), left[1]) == (component(right[0]), right[1]):
            partial_matches.append({'bit': position, 'anchored': left,
                                    'speculative': right})
    assert not matches
    if dense:
        assert not partial_matches
        # The phase is invariant for an arbitrarily repeated zero stream:
        # syntax positions repeat every 127 bits, full MCU state every 762.
        assert start % 127 != 0
    else:
        assert partial_matches[0] == {'bit': 12, 'anchored': (0, 0),
                                     'speculative': (2, 0)}
    rows.append({'name': name, 'bytes': len(data),
                 'sha256': hashlib.sha256(data).hexdigest(),
                 'entropy_offset_bytes': offset, 'entropy_bits': bit_count,
                 'speculative_start_bits': start, 'blocks': 96,
                 'full_state_matches': len(matches),
                 'component_only_matches': len(partial_matches),
                 'first_component_only_match': partial_matches[:1],
                 'expected_dc': 0, 'expected_ac': -1 if dense else 0})

(ROOT / 'syntax-observations.json').write_text(json.dumps(rows, indent=2) + '\n')
print(json.dumps(rows, indent=2))
