"""Stage the retained command caller, then take one foreground GPU lease."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import tarfile

parser = argparse.ArgumentParser()
parser.add_argument('--fixture', default='connected-small')
parser.add_argument('--benchmark', action='store_true')
parser.add_argument('--access', action='store_true')
parser.add_argument('--profile', action='store_true')
parser.add_argument('--repetitions', type=int)
parser.add_argument('--name')
parser.add_argument('--tool-tag', default='codec-jpeg-rebased-tools')
parser.add_argument('--build-receipt', type=Path, required=True)
parser.add_argument('--stage-limit-mib', type=int, default=128)
parser.add_argument('--staged-fixture', action='store_true')
arguments = parser.parse_args()
notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
fixture = root / arguments.fixture
stage = json.loads((fixture / 'stage.json').read_text())
build_record = json.loads(arguments.build_receipt.read_text())
assert build_record['restored'] and build_record['build_returncode'] == 0
assert build_record['tag'] == arguments.tool_tag
capture = json.loads(subprocess.check_output(
    ['bureau-bazel', 'tag', 'inspect', arguments.tool_tag, '--json'], text=True))
assert capture['capture'] == build_record['capture']['capture']
binary = Path(json.loads(os.environ['BUREAU_TAG_ROOTS'])[arguments.tool_tag]) / 'loom/src/loom/tooling/target/amdgpu/serve/codec_command_probe'
files = {str(path.relative_to(root)): path for path in fixture.iterdir()
         if path.is_file() and (path.name in stage['files'] or path.name == 'stage.json')}
if arguments.fixture.endswith('small'):
    for relative in stage['files']:
        path = (fixture / relative).resolve()
        files[str(path.relative_to(root))] = path
if arguments.staged_fixture:
    # Every remote fixture byte is still hash-checked below before execution.
    files = {}
files['codec_command_probe'] = binary
# The default stages the caller and small fixture; a larger retained reference
# cohort names its explicit bound in the owning experiment before transfer.
assert 0 < arguments.stage_limit_mib <= 768
assert sum(path.stat().st_size for path in files.values()) < arguments.stage_limit_mib * 1024 * 1024
process = subprocess.Popen(['ssh', 'hrx-gorgon-4', 'tar -xf - -C ' + shlex.quote(str(root))], stdin=subprocess.PIPE)
with tarfile.open(fileobj=process.stdin, mode='w|', dereference=True) as archive:
    for name, path in files.items():
        archive.add(path, arcname=name, recursive=False)
process.stdin.close()
assert process.wait() == 0
digest = hashlib.sha256(binary.read_bytes()).hexdigest()
verify = '''import hashlib,json,pathlib,sys
root=pathlib.Path(sys.argv[1]);fixture=root/sys.argv[2];stage=json.loads((fixture/'stage.json').read_text())
for name,digest in stage['files'].items():
 assert hashlib.sha256((fixture/name).read_bytes()).hexdigest()==digest,name
assert hashlib.sha256((root/'codec_command_probe').read_bytes()).hexdigest()==sys.argv[3]
assert not list(pathlib.Path('/sys/class/kfd/kfd/proc').iterdir())
'''
subprocess.run(['ssh', 'hrx-gorgon-4', shlex.join(['python3', '-B', '-c', verify, str(root), arguments.fixture, digest])], check=True)
name = arguments.name or arguments.fixture + ('-timing' if arguments.benchmark else '-check')
command = ['/home/benvanik/.dotfiles/bin/benchmark-lock', '--label=codec-jpeg-' + name,
           '--', 'timeout', '--signal=INT', '--kill-after=10s', '300s',
           'env', 'LD_LIBRARY_PATH=/opt/rocm/lib', 'stdbuf', '-oL', '-eL', str(root / 'codec_command_probe'),
           '--jpeg_fixture=' + str(fixture), '--gtest_filter=JpegCommandTest.CompressedToRgb']
if arguments.access:
    command.extend(['--jpeg_access=true', '--amdgpu_asan=true', '--amdgpu_asan_report_policy=fail-device'])
if arguments.benchmark:
    command.append('--jpeg_benchmark=true')
if arguments.profile:
    command.append('--jpeg_profile=true')
if arguments.repetitions is not None:
    command.append('--jpeg_repetitions=' + str(arguments.repetitions))
log = notes / ('gorgon4-' + name + '.log')
with log.open('w') as stream:
    result = subprocess.run(['ssh', 'hrx-gorgon-4', shlex.join(command)], stdout=stream, stderr=subprocess.STDOUT)
status = subprocess.run(['ssh', 'hrx-gorgon-4', '/home/benvanik/.dotfiles/bin/benchmark-lock --status'], capture_output=True, text=True)
receipt = {'command': command, 'returncode': result.returncode, 'broker_status_after': status.stdout + status.stderr,
           'tool_tag': arguments.tool_tag,
           'binary_sha256': digest,
           'source_sha256': build_record['source_sha256'],
           'build_commit': build_record['commit'],
           'build_configuration': build_record['configuration'],
           'build_capture': capture['capture'],
           'stage': stage, 'rows': [json.loads(line) for line in log.read_text().splitlines() if line.startswith('{"phase":')]}
(notes / ('gorgon4-' + name + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'returncode': result.returncode, 'broker_status_after': receipt['broker_status_after']}), flush=True)
print(log.read_text()[-10000:], flush=True)
raise SystemExit(result.returncode)
