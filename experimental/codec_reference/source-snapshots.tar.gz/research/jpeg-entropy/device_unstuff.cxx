#include <loomcxx/buffer.h>
#include <loomcxx/kernel.h>
#include <loomcxx/predicate.h>
#include <loomcxx/scalar.h>

[[loom::config("input.tiles"), loom::where(loom::predicate::range(1u, 1024u))]]
extern const unsigned tile_count;
[[loom::config("input.batch"), loom::where(loom::predicate::range(1u, 65536u))]]
extern const unsigned image_count;
[[loom::config("input.chunk_bytes"), loom::where(loom::predicate::range(1u, 65536u))]]
extern const unsigned entropy_chunk_bytes;

using PacketWords = unsigned __attribute__((ext_vector_type(4)));

struct Packet {
  // Original little-endian bytes in one aligned sixteen-byte input packet.
  PacketWords words;
  // Bit i retains byte i after removing stuffing and marker prefixes.
  unsigned keep;
  // First marker/fill prefix, or all ones when absent.
  unsigned marker_prefix;
  // First FF followed by a marker code, or all ones when absent.
  unsigned marker_code;
  // First fill-before-stuffed-zero error, or all ones when absent.
  unsigned invalid;
};

static LOOM_FORCE_INLINE unsigned byte_minimum(unsigned a, unsigned b) {
  return a < b ? a : b;
}

static LOOM_FORCE_INLINE Packet classify(const unsigned* source, unsigned first,
                                         unsigned length, unsigned start) {
  PacketWords words = *reinterpret_cast<const PacketWords*>(source + first / 4);
  unsigned previous = first ? source[first / 4 - 1] : 0;
  unsigned following = source[first / 4 + 4];
  unsigned keep = 0;
  unsigned prefix = 0xffffffffu;
  unsigned code = 0xffffffffu;
  unsigned invalid = 0xffffffffu;
  [[loom::unroll]]
  for (unsigned index = 0; index < 16; ++index) {
    unsigned position = first + index;
    unsigned value = (words[index / 4] >> ((index & 3u) * 8)) & 255u;
    unsigned before = index ? (words[(index - 1) / 4] >> (((index - 1) & 3u) * 8)) & 255u
                            : previous >> 24;
    unsigned before_previous = index >= 2 ? (words[(index - 2) / 4] >> (((index - 2) & 3u) * 8)) & 255u
                                         : (previous >> ((index + 2) * 8)) & 255u;
    unsigned after = index < 15 ? (words[(index + 1) / 4] >> (((index + 1) & 3u) * 8)) & 255u
                               : following & 255u;
    if (position >= start && position < length) {
      if (position + 1 == length) after = 255;
      if (value == 255) {
        if (after == 0) {
          keep |= 1u << index;
        } else {
          prefix = byte_minimum(prefix, position);
          if (after != 255) code = byte_minimum(code, position);
        }
      } else if (value == 0 && position > start && before == 255) {
        if (position > start + 1 && before_previous == 255) invalid = byte_minimum(invalid, position);
      } else {
        keep |= 1u << index;
      }
    }
  }
  return {words, keep, prefix, code, invalid};
}

static LOOM_FORCE_INLINE unsigned before_marker(unsigned mask, unsigned first,
                                                unsigned marker) {
  if (marker <= first) return 0;
  unsigned available = marker - first;
  if (available < 16) mask &= (1u << available) - 1;
  return mask;
}

static loom::kernel::configuration configure_tiles() {
  return {{tile_count, image_count, 1}, {256, 1, 1}};
}

static loom::kernel::configuration configure_images() {
  return {{image_count, 1, 1}, {256, 1, 1}};
}

// Headers contain original byte length, SOS payload end, MCU block count, and
// destination component-word base. The input allocation has one guard packet.
[[loom::kernel(configure_tiles)]]
void jpeg_classify_bytes(const unsigned* compressed, const unsigned* headers,
                         unsigned* records) {
  unsigned image = loom::kernel::workgroup::id.y;
  unsigned tile = loom::kernel::workgroup::id.x;
  unsigned lane = loom::kernel::workitem::id.x;
  const unsigned* source = compressed + image * (tile_count * 1024 + 4);
  unsigned first = tile * 4096 + lane * 16;
  Packet packet = classify(source, first, headers[image * 4], headers[image * 4 + 1]);
  unsigned prefix = loom::kernel::workgroup::reduce::minui(packet.marker_prefix);
  unsigned code = loom::kernel::workgroup::reduce::minui(packet.marker_code);
  unsigned invalid = loom::kernel::workgroup::reduce::minui(packet.invalid);
  unsigned mask = before_marker(packet.keep, first, prefix);
  unsigned count = loom::kernel::workgroup::reduce::addi(loom::scalar::ctpopi(mask));
  if (lane == 0) {
    unsigned* record = records + (image * tile_count + tile) * 4;
    record[0] = count;
    record[1] = prefix;
    record[2] = code;
    record[3] = invalid;
  }
}

[[loom::kernel(configure_images)]]
void jpeg_prefix_bytes(const unsigned* compressed, const unsigned* headers,
                       const unsigned* records, unsigned* prefixes,
                       unsigned* segments, unsigned* jobs, unsigned* errors) {
  unsigned image = loom::kernel::workgroup::id.x;
  unsigned lane = loom::kernel::workitem::id.x;
  unsigned marker = 0xffffffffu;
  unsigned code = 0xffffffffu;
  unsigned invalid = 0xffffffffu;
  PacketWords counts = {};
  [[loom::unroll]]
  for (unsigned item = 0; item < 4; ++item) {
    unsigned tile = lane * 4 + item;
    if (tile < tile_count) {
      const unsigned* record = records + (image * tile_count + tile) * 4;
      counts[item] = record[0];
      marker = byte_minimum(marker, record[1]);
      code = byte_minimum(code, record[2]);
      invalid = byte_minimum(invalid, record[3]);
    }
  }
  marker = loom::kernel::workgroup::reduce::minui(marker);
  code = loom::kernel::workgroup::reduce::minui(code);
  invalid = loom::kernel::workgroup::reduce::minui(invalid);
  unsigned error = 0;
  if (code == 0xffffffffu) {
    error = 1;
  } else {
    const unsigned char* source = reinterpret_cast<const unsigned char*>(
        compressed + image * (tile_count * 1024 + 4));
    if (source[code + 1] != 0xd9) error = 2;
    if (code + 2 != headers[image * 4] || invalid < code) error = 1;
  }
  unsigned count = 0;
  [[loom::unroll]]
  for (unsigned item = 0; item < 4; ++item) {
    unsigned tile = lane * 4 + item;
    if (tile * 4096 > marker || error) counts[item] = 0;
    count += counts[item];
  }
  unsigned prefix = loom::kernel::workgroup::scan::addi<loom::kernel::scan_mode::exclusive>(count);
  unsigned total = loom::kernel::workgroup::reduce::addi(count);
  [[loom::unroll]]
  for (unsigned item = 0; item < 4; ++item) {
    unsigned tile = lane * 4 + item;
    if (tile < tile_count) prefixes[image * tile_count + tile] = prefix;
    prefix += counts[item];
  }
  unsigned capacity = (tile_count * 4096 + entropy_chunk_bytes - 1) / entropy_chunk_bytes;
  unsigned job_count = (total + entropy_chunk_bytes - 1) / entropy_chunk_bytes;
  unsigned word_base = image * (tile_count * 1024 + 2);
  for (unsigned job = lane; job < capacity; job += 256) {
    unsigned* output = jobs + (image * capacity + job) * 3;
    output[0] = word_base;
    output[1] = job < job_count ? total * 8 : 0;
    output[2] = job < job_count ? job : 0;
  }
  if (lane == 0) {
    unsigned* segment = segments + image * 8;
    segment[0] = word_base;
    segment[1] = total * 8;
    segment[2] = image * capacity;
    segment[3] = job_count;
    segment[4] = headers[image * 4 + 2];
    segment[5] = 0;
    segment[6] = 0;
    segment[7] = headers[image * 4 + 3];
    errors[image * 4] = error;
    errors[image * 4 + 1] = marker;
    errors[image * 4 + 2] = code;
    errors[image * 4 + 3] = total;
  }
}

[[loom::kernel(configure_tiles)]]
void jpeg_compact_bytes(const unsigned* compressed, const unsigned* headers,
                        const unsigned* records, const unsigned* prefixes,
                        const unsigned* segments, const unsigned* errors,
                        unsigned* entropy) {
  unsigned image = loom::kernel::workgroup::id.y;
  unsigned tile = loom::kernel::workgroup::id.x;
  unsigned lane = loom::kernel::workitem::id.x;
  unsigned total = errors[image * 4 + 3];
  unsigned* destination = entropy + segments[image * 8];
  unsigned rounded = (total + 3) / 4;
  // One group owns the tail padding, including the unused bytes of its last
  // logical word. Partial tile stores below overwrite only valid byte lanes.
  if (tile == 0 && lane == 0) {
    unsigned char* bytes = reinterpret_cast<unsigned char*>(destination);
    for (unsigned byte = total; byte < rounded * 4; ++byte) bytes[(byte & ~3u) + 3 - (byte & 3u)] = 0;
    destination[rounded] = 0;
    destination[rounded + 1] = 0;
  }
  if (errors[image * 4] != 0 || tile * 4096 > errors[image * 4 + 1]) return;
  unsigned count = records[(image * tile_count + tile) * 4];
  unsigned output_start = prefixes[image * tile_count + tile];
  unsigned bias = output_start & 3u;
  auto* storage = loom::buffer::alloca<unsigned, loom::memory_space::workgroup, 16>(1025);
  unsigned char* bytes = reinterpret_cast<unsigned char*>(storage);
  const unsigned* source = compressed + image * (tile_count * 1024 + 4);
  unsigned first = tile * 4096 + lane * 16;
  Packet packet = classify(source, first, headers[image * 4], headers[image * 4 + 1]);
  unsigned mask = before_marker(packet.keep, first, records[(image * tile_count + tile) * 4 + 1]);
  unsigned offset = loom::kernel::workgroup::scan::addi<loom::kernel::scan_mode::exclusive>(loom::scalar::ctpopi(mask));
  [[loom::unroll]]
  for (unsigned index = 0; index < 16; ++index) {
    if ((mask & (1u << index)) != 0) {
      unsigned local_byte = (bias + offset) ^ 3u;
      // The exclusive packet count plus this packet's retained prefix owns
      // one of at most4096 payload bytes, with at most three alignment bytes.
      loom::assume(local_byte < 4100u);
      bytes[local_byte] = static_cast<unsigned char>(packet.words[index / 4] >> ((index & 3u) * 8));
      ++offset;
    }
  }
  loom::kernel::workgroup::barrier();
  unsigned first_word = (output_start + 3) / 4;
  unsigned final_word = (output_start + count) / 4;
  for (unsigned word = first_word + lane; word < final_word; word += 256) {
    unsigned local_word = word - output_start / 4;
    loom::assume(local_word < 1025u);
    unsigned value = storage[local_word];
    destination[word] = value;
  }
  if (lane == 0) {
    unsigned char* output_bytes = reinterpret_cast<unsigned char*>(destination);
    for (unsigned index = 0; index < count; ++index) {
      unsigned position = output_start + index;
      if (position >= first_word * 4 && position < final_word * 4) {
        index = final_word * 4 - output_start - 1;
      } else {
        unsigned local_byte = (bias + index) ^ 3u;
        loom::assume(local_byte < 4100u);
        output_bytes[(position & ~3u) + 3 - (position & 3u)] = bytes[local_byte];
      }
    }
  }
}
