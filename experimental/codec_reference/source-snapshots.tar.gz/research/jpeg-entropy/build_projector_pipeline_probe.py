"""Capture a bounded production-API probe and restore its exact source overlay."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument("--configuration", choices=("asan", "opt"), required=True)
options = parser.parse_args()
notes = Path(__file__).resolve().parent
assert not subprocess.check_output(["git", "status", "--porcelain"], text=True)
manifest = json.loads((notes / "http-publication-source.json").read_text())
directory = Path(manifest["directory"])
prefix = "loom/src/loom/serve/"
selected = [prefix + name for name in [
    "service/finite/result.c", "service/finite/result.h", "service/finite/model.h",
    "media/image_request.c", "media/BUILD.bazel",
    "media/native_upload.c", "media/native_upload.h", "media/device_upload.h",
    "media/native_header.c", "media/native_header.h", "media/native_metadata.c",
    "media/native_metadata.h", "media/native_color.c", "media/native_color.h",
]]
if options.configuration == "asan":
    selected.append(prefix + "service/finite/model.c")
originals = {}
overlays = {}
for name in selected:
    data = (directory / "overlays" / name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == manifest["overlays"][name]
    overlays[name] = data
    if name in manifest["originals"]:
        originals[name] = Path(name).read_bytes()
        assert hashlib.sha256(originals[name]).hexdigest() == manifest["originals"][name]
    else:
        assert not Path(name).exists(), name
build = "loom/src/loom/tooling/target/amdgpu/serve/BUILD.bazel"
originals[build] = Path(build).read_bytes()
probe = str(Path(build).parent / "projector_pipeline_probe.cc")
assert not Path(probe).exists()
overlays[probe] = (notes / "projector_pipeline_probe.cc").read_bytes()
overlays[build] = originals[build] + b'''
loom_cc_binary(
    name = "codec_projector_pipeline_probe",
    testonly = True,
    srcs = ["projector_pipeline_probe.cc"],
    deps = [
        ":test_compiler", ":test_device",
        "//loom/src/loom/serve/media:image_request",
        "//loom/src/loom/serve/runtime/device",
        "//loom/src/loom/serve/runtime/execution",
        "//loom/src/loom/serve/runtime/host",
        "//loom/src/loom/serve/runtime/host:wake",
        "//loom/src/loom/serve/runtime/parameter:residency",
        "//loom/src/loom/serve/service/finite:model",
        "//loom/src/loom/serve/service/finite:result",
        "//loom/src/loom/serve/testing:compiler",
        "//loom/src/loom/serve/testing:device",
        "//loom/src/loom/serve/testing:model",
        "//runtime/src/iree/base",
        "//runtime/src/iree/base/internal:base64",
        "//runtime/src/iree/base/tooling:flags",
        "//runtime/src/iree/hal",
        "//runtime/src/iree/testing:gtest",
        "//runtime/src/iree/testing:gtest_main",
        "//runtime/src/iree/vm",
    ],
)
'''
tag = "codec-jpeg-pipeline-" + options.configuration
command = ["bureau-bazel", "build", "--tag=" + tag,
           "--config=" + options.configuration,
           "//loom/src/loom/tooling/target/amdgpu/serve:codec_projector_pipeline_probe"]
receipt = notes / ("projector-pipeline-" + options.configuration + "-build.json")
record = {
    "commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
    "command": command, "configuration": options.configuration,
    "gpu_access_checks": options.configuration == "asan", "restored": False,
    "source_manifest_sha256": hashlib.sha256((notes / "http-publication-source.json").read_bytes()).hexdigest(),
    "source_sha256": {name: hashlib.sha256(data).hexdigest() for name, data in overlays.items()},
    "original_sha256": {name: hashlib.sha256(data).hexdigest() for name, data in originals.items()},
}
receipt.write_text(json.dumps(record, indent=2) + "\n")
applied = []
try:
    for name, data in overlays.items():
        Path(name).write_bytes(data)
        applied.append(name)
    result = subprocess.run(command)
    record["returncode"] = result.returncode
finally:
    for name in applied:
        assert Path(name).read_bytes() == overlays[name], name
    for name in applied:
        if name in originals:
            Path(name).write_bytes(originals[name])
        else:
            Path(name).unlink()
    record["restored"] = True
    receipt.write_text(json.dumps(record, indent=2) + "\n")
assert not subprocess.check_output(["git", "status", "--porcelain"], text=True)
if result.returncode:
    raise SystemExit(result.returncode)
record["capture"] = json.loads(subprocess.check_output(
    ["bureau-bazel", "tag", "inspect", tag, "--json"], text=True))
receipt.write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"restored": True, "capture": record["capture"]["capture"]}))
