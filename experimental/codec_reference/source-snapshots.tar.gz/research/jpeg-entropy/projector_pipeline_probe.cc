// Bounded real image preparation and trained-projector comparison.
#include <array>
#include <atomic>
#include <condition_variable>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <mutex>
#include <string>
#include <vector>

#include "iree/base/internal/base64.h"
#include "iree/base/tooling/flags.h"
#include "iree/testing/gtest.h"
#include "iree/testing/status_matchers.h"
#include "iree/vm/buffer.h"
#include "loom/serve/media/image_request.h"
#include "loom/serve/runtime/device/device.h"
#include "loom/serve/runtime/execution/execution.h"
#include "loom/serve/runtime/host/wake.h"
#include "loom/serve/runtime/parameter/residency.h"
#include "loom/serve/service/finite/model.h"
#include "loom/serve/service/finite/result.h"
#include "loom/serve/testing/compiler.h"
#include "loom/serve/testing/device.h"
#include "loom/serve/testing/model.h"

IREE_FLAG(string, jpeg_fixture, "", "Pinned source and original compressed input.");
IREE_FLAG(bool, compressed, false, "Select the qualified compressed model source.");
IREE_FLAG(int32_t, pipeline_samples, 0, "Measured samples after numerical warmups.");
IREE_FLAG(int32_t, pipeline_iterations, 2, "Completed cohorts per measured sample.");

namespace {

struct Request {
  // Encoded image bytes and inspected metadata, owned through packet creation.
  loom_serve_media_image_input_t image = {};
  // Native packet, owned through source preparation and producer completion.
  iree_vm_buffer_t* packet = nullptr;
  // Source-prepared immutable packet and compatibility facts.
  loom_serve_finite_prepared_t prepared = {};

  ~Request() {
    iree_vm_buffer_release(prepared.bytes);
    iree_vm_buffer_release(packet);
    loom_serve_media_image_input_deinitialize(&image);
  }
};

struct Measurement {
  // Base64 decoding and native header inspection, in milliseconds.
  double inspect_ms = 0;
  // CPU pixel decode or compressed native packet construction, in milliseconds.
  double packet_ms = 0;
  // Source request/batch preparation and cached command resolution, in milliseconds.
  double prepare_ms = 0;
  // Residency admission, allocation/upload/execute submission, in milliseconds.
  double submit_ms = 0;
  // Remaining time until producer/status readiness, in milliseconds.
  double complete_ms = 0;
  // Native prepared input extent summed across this cohort, in bytes.
  size_t prepared_bytes = 0;
  // Physical device output root extent, including retained decoder scratch.
  size_t output_bytes = 0;
};

class ProjectorPipelineTest : public ::testing::Test {
 protected:
  void SetUp() override {
    ASSERT_GE(FLAG_pipeline_samples, 0);
    ASSERT_GT(FLAG_pipeline_iterations, 0);
    directory_ = FLAG_jpeg_fixture;
    std::ifstream stream(directory_ / "original.jpg", std::ios::binary);
    ASSERT_TRUE(stream.good());
    const std::vector<uint8_t> encoded(std::istreambuf_iterator<char>(stream), {});
    url_ = "data:image/jpeg;base64,";
    const size_t prefix = url_.size();
    const size_t length = iree_base64_encoded_size(encoded.size());
    url_.resize(prefix + length);
    size_t written = 0;
    IREE_ASSERT_OK(iree_base64_encode(
        iree_make_const_byte_span(encoded.data(), encoded.size()),
        {url_.data() + prefix, length}, &written));
    ASSERT_EQ(written, length);

    IREE_ASSERT_OK(document_.Load((directory_ /
        (FLAG_compressed ? "deployment.json" : "control-deployment.json")).string()));
    IREE_ASSERT_OK(loom_serve_test_host_create(16, allocator_, &host_));
    iree_hal_driver_t* driver = nullptr;
    IREE_ASSERT_OK(loom_serve_test_driver_create(host_, allocator_, &driver));
    const loom_serve_device_options_t options = {
        .driver = driver, .uri = IREE_SV("amdgpu"),
        .backing = LOOM_SERVE_DEVICE_BACKING_FIXED};
    auto status = loom_serve_device_group_allocate(host_, 1, &options, allocator_, &group_);
    iree_hal_driver_release(driver);
    IREE_ASSERT_OK(status);
    device_ = loom_serve_device_group_at(group_, 0);
    auto sources = document_.value().sources;
    const auto& image = document_.value().text.image;
    sources.prepare = image.prepare;
    sources.control = image.control;
    const loom_serve_finite_model_options_t model_options = {
        .sources = sources, .asset_directory = image.assets,
        .options = image.options, .specialization_cache = image.specialization_cache};
    IREE_ASSERT_OK(loom_serve_finite_model_allocate(device_, &model_options, allocator_, &model_));
    loom_serve_finite_model_set_observer(model_, {Wake, this});
  }

  void TearDown() override {
    if (batch_pending_) {
      IREE_EXPECT_OK(Resolve(true));
      loom_serve_finite_model_release_batch(model_);
    }
    IREE_EXPECT_OK(loom_serve_finite_model_free(model_));
    loom_serve_finite_statuses_release(statuses_);
    loom_serve_finite_snapshot_release(snapshot_);
    loom_serve_finite_result_release(result_);
    if (device_) IREE_EXPECT_OK(loom_serve_test_device_trim_and_drain(device_, 0));
    IREE_EXPECT_OK(loom_serve_device_group_free(group_));
    loom_serve_host_release(host_);
  }

  static void Wake(void* pointer) {
    auto* self = static_cast<ProjectorPipelineTest*>(pointer);
    std::lock_guard<std::mutex> lock(self->mutex_);
    ++self->wakes_;
    self->condition_.notify_all();
  }

  iree_status_t Resolve(bool cancel = false) {
    bool complete = false;
    while (!complete) {
      const auto previous = wakes_.load();
      IREE_RETURN_IF_ERROR(loom_serve_finite_model_advance_batch(model_, cancel, &complete));
      if (!complete) {
        std::unique_lock<std::mutex> lock(mutex_);
        condition_.wait(lock, [&] { return wakes_.load() != previous; });
      }
    }
    return iree_ok_status();
  }

  void Await(const loom_serve_execution_frontier_t& ready) {
    for (size_t i = 0; i < IREE_ARRAYSIZE(ready.semaphores); ++i) {
      IREE_ASSERT_OK(iree_hal_semaphore_wait(ready.semaphores[i], ready.values[i],
          iree_infinite_timeout(), IREE_ASYNC_WAIT_FLAG_NONE));
    }
  }

  void Observe(unsigned count, bool capture, Measurement& measurement) {
    std::array<Request, 4> requests;
    std::array<loom_serve_media_image_request_t, 4> image_requests = {};
    std::array<iree_vm_buffer_t*, 4> packets = {};
    std::array<iree_status_t, 4> image_statuses = {};
    std::array<loom_serve_finite_prepared_t, 4> prepared = {};
    std::array<iree_host_size_t, 4> rows = {};
    const std::array<uint32_t, 2> geometry = {1152, 864};
    const loom_serve_media_image_limits_t limits = {67108864, 4096, 4096, 16777216};
    const iree_time_t begin = iree_time_now();
    for (unsigned i = 0; i < count; ++i) {
      IREE_ASSERT_OK(loom_serve_media_image_input_initialize(
          iree_make_string_view(url_.data(), url_.size()), &limits,
          allocator_, &requests[i].image));
      image_requests[i] = {
          .image = &requests[i].image,
          .metadata = iree_make_const_byte_span(geometry.data(), sizeof(geometry)),
          .output_rows = kRows};
    }
    const iree_time_t inspected = iree_time_now();
    auto status = loom_serve_media_image_request_create_batch(
        count, image_requests.data(), allocator_, packets.data(), image_statuses.data());
    for (unsigned i = 0; i < count; ++i) {
      requests[i].packet = packets[i];
      status = iree_status_join(status, image_statuses[i]);
      loom_serve_media_image_input_deinitialize(&requests[i].image);
    }
    IREE_ASSERT_OK(status);
    const iree_time_t materialized = iree_time_now();
    for (unsigned i = 0; i < count; ++i) {
      IREE_ASSERT_OK(loom_serve_finite_model_prepare_request(
          model_, requests[i].packet, &requests[i].prepared));
      prepared[i] = requests[i].prepared;
      rows[i] = kRows;
      measurement.prepared_bytes += iree_vm_buffer_length(prepared[i].bytes);
    }
    IREE_ASSERT_OK(loom_serve_finite_model_prepare_batch(
        model_, count, prepared.data(), rows.data()));
    batch_pending_ = true;
    IREE_ASSERT_OK(Resolve());
    const iree_time_t resolved = iree_time_now();
    loom_serve_residency_admission_t admission;
    IREE_ASSERT_OK(loom_serve_residency_try_admit(
        loom_serve_finite_model_residency(model_), &admission));
    ASSERT_EQ(admission, LOOM_SERVE_RESIDENCY_ADMISSION_ACQUIRED);
    loom_serve_execution_frontier_t ready;
    batch_pending_ = false;
    IREE_ASSERT_OK(loom_serve_finite_model_submit(model_, &result_, &ready));
    IREE_ASSERT_OK(loom_serve_finite_result_download_statuses(result_, &statuses_, &ready));
    const iree_time_t submitted = iree_time_now();
    ASSERT_NO_FATAL_FAILURE(Await(ready));
    const iree_time_t completed = iree_time_now();
    measurement.inspect_ms = (inspected - begin) * 1e-6;
    measurement.packet_ms = (materialized - inspected) * 1e-6;
    measurement.prepare_ms = (resolved - materialized) * 1e-6;
    measurement.submit_ms = (submitted - resolved) * 1e-6;
    measurement.complete_ms = (completed - submitted) * 1e-6;
    measurement.output_bytes = loom_serve_finite_result_output_length(result_);
    ASSERT_EQ(loom_serve_finite_result_length(result_), count * kRows * kRowBytes);
    ASSERT_EQ(statuses_ != nullptr, FLAG_compressed);
    for (unsigned i = 0; i < count; ++i) {
      IREE_ASSERT_OK(loom_serve_finite_statuses_request(statuses_, i));
    }
    if (capture) {
      IREE_ASSERT_OK(loom_serve_finite_result_download(result_, &snapshot_, &ready));
      ASSERT_NO_FATAL_FAILURE(Await(ready));
      std::vector<uint8_t> first(kRows * kRowBytes);
      for (size_t row = 0; row < kRows; ++row) {
        const auto values = loom_serve_finite_snapshot_row(snapshot_, 0, row);
        ASSERT_EQ(values.data_length, kRowBytes);
        std::memcpy(first.data() + row * kRowBytes, values.data, kRowBytes);
      }
      for (unsigned i = 1; i < count; ++i) {
        for (size_t row = 0; row < kRows; ++row) {
          const auto values = loom_serve_finite_snapshot_row(snapshot_, i, row);
          ASSERT_EQ(values.data_length, kRowBytes);
          ASSERT_EQ(std::memcmp(first.data() + row * kRowBytes, values.data, kRowBytes), 0);
        }
      }
      if (reference_.empty()) {
        reference_ = first;
      } else {
        ASSERT_EQ(first, reference_);
      }
      std::ofstream output(directory_ /
          (FLAG_compressed ? "pipeline-gpu.features" : "pipeline-cpu.features"),
          std::ios::binary);
      output.write(reinterpret_cast<const char*>(first.data()), first.size());
      output.close();
      ASSERT_TRUE(output.good());
      std::printf("{\"phase\":\"verified_features\",\"images\":%u,\"feature_bytes\":%zu,\"prepared_bytes\":%zu,\"physical_output_bytes\":%zu}\n",
          count, first.size(), measurement.prepared_bytes, measurement.output_bytes);
    }
    loom_serve_finite_model_complete(model_);
    loom_serve_finite_statuses_release(statuses_); statuses_ = nullptr;
    loom_serve_finite_snapshot_release(snapshot_); snapshot_ = nullptr;
    loom_serve_finite_result_release(result_); result_ = nullptr;
  }

  void Measure(unsigned count) {
    Measurement warmup;
    ASSERT_NO_FATAL_FAILURE(Observe(count, true, warmup));
    std::vector<Measurement> measurements(FLAG_pipeline_samples * FLAG_pipeline_iterations);
    std::vector<double> elapsed(FLAG_pipeline_samples);
    for (int sample = 0; sample < FLAG_pipeline_samples; ++sample) {
      const iree_time_t begin = iree_time_now();
      for (int iteration = 0; iteration < FLAG_pipeline_iterations; ++iteration) {
        ASSERT_NO_FATAL_FAILURE(Observe(count, false,
            measurements[sample * FLAG_pipeline_iterations + iteration]));
      }
      elapsed[sample] = (iree_time_now() - begin) * 1e-6;
    }
    for (int sample = 0; sample < FLAG_pipeline_samples; ++sample) {
      std::printf("{\"phase\":\"sample\",\"compressed\":%s,\"images_per_cohort\":%u,\"cohorts\":%d,\"sample\":%d,\"elapsed_ms\":%.9f}\n",
          FLAG_compressed ? "true" : "false", count, FLAG_pipeline_iterations, sample, elapsed[sample]);
      for (int iteration = 0; iteration < FLAG_pipeline_iterations; ++iteration) {
        const auto& value = measurements[sample * FLAG_pipeline_iterations + iteration];
        std::printf("{\"phase\":\"cohort\",\"sample\":%d,\"iteration\":%d,\"inspect_ms\":%.9f,\"packet_ms\":%.9f,\"prepare_ms\":%.9f,\"submit_ms\":%.9f,\"complete_ms\":%.9f}\n",
            sample, iteration, value.inspect_ms, value.packet_ms, value.prepare_ms,
            value.submit_ms, value.complete_ms);
      }
    }
  }

  // Pinned target geometry merges four patches into each output feature row.
  static constexpr size_t kRows = (1152 / 32) * (864 / 32);
  // The real projector emits 5120 F32 values per row.
  static constexpr size_t kRowBytes = 5120 * sizeof(float);
  // Allocator retained through all native owners.
  iree_allocator_t allocator_ = iree_allocator_system();
  // Shared source/input staging with one CPU/GPU feature pair.
  std::filesystem::path directory_;
  // Same incoming data URL for every request, constructed outside timing.
  std::string url_;
  // Parsed deployment owns source and checkpoint paths.
  loom_serve::testing::ModelDocument document_;
  // Shared host services used by the actual JIT/model owners.
  loom_serve_host_t* host_ = nullptr;
  // Device group owns the queues and pools.
  loom_serve_device_group_t* group_ = nullptr;
  // Borrowed sole device owner.
  loom_serve_device_t* device_ = nullptr;
  // Actual finite image component and trained parameter ownership.
  loom_serve_finite_model_t* model_ = nullptr;
  // One published result retained through readiness and optional checking.
  loom_serve_finite_result_t* result_ = nullptr;
  // Queue-retained input validity destination.
  loom_serve_finite_statuses_t* statuses_ = nullptr;
  // Full host feature snapshot used only by numerical warmups.
  loom_serve_finite_snapshot_t* snapshot_ = nullptr;
  // First numerical warmup's complete feature bytes.
  std::vector<uint8_t> reference_;
  // An unsubmitted batch must retire its compilation on error.
  bool batch_pending_ = false;
  // Serializes asynchronous compiler wake publication.
  std::mutex mutex_;
  // Outer caller completion, never a waiting shared task worker.
  std::condition_variable condition_;
  // Generation closes the compiler check-to-wait race.
  std::atomic<uint64_t> wakes_ = 0;
};

TEST_F(ProjectorPipelineTest, OriginalBytesToReadyFeatures) {
  ASSERT_NO_FATAL_FAILURE(Measure(1));
  ASSERT_NO_FATAL_FAILURE(Measure(4));
}
}  // namespace
