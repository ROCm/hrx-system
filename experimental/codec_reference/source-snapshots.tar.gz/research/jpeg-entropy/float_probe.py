"""Exercise every numerical-model block through the actual cooperative leaf."""
import array
import hashlib
import json
import math
import os
from pathlib import Path
import struct
import subprocess

from device_fixture import write_words
from float_idct import library, reconstructed

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
directory = root / 'float-probe'
directory.mkdir(exist_ok=True)
coefficients = array.array('h')
quantization = []
pixels = bytearray()
for step in (1, 255, 256, 65535):
    cases = json.loads((root / ('float-idct-cases-' + str(step) + '.json')).read_text())
    for values in cases:
        coefficients.extend(values)
        quantization.extend([step] * 64)
        if not any(values[1:]):
            pixel = min(255, max(0, ((values[0] * step + 4) >> 3) + 128))
            pixels.extend([pixel] * 64)
        else:
            pixels.extend(min(255, max(0, math.floor(library.fmaf(value * 8, 0.125, 128.5))))
                          for value in reconstructed([value * step for value in values]))
count = len(coefficients) // 64
assert count % 32 == 0
pixels.extend(struct.pack('<I', 17) * 8)
header = repr({'descr': '<i2', 'fortran_order': False, 'shape': (len(coefficients),)}).encode()
header += b' ' * ((64 - (10 + len(header) + 1) % 64) % 64) + b'\n'
with (directory / 'coefficients.npy').open('wb') as stream:
    stream.write(b'\x93NUMPY\x01\x00' + struct.pack('<H', len(header)) + header)
    coefficients.tofile(stream)
write_words(directory / 'quantization.npy', quantization)
write_words(directory / 'pixels.npy', struct.unpack('<' + 'I' * (len(pixels) // 4), pixels))
(directory / 'check.loom').write_text(f'''kernel.decl @idct_probe() launch(%input: buffer, %quantization: buffer, %pixels: buffer)
check.case @float32_idct {{
  %input = check.file.read.npy path("coefficients.npy") : tensor<{len(coefficients)}xi16>
  %quantization = check.file.read.npy path("quantization.npy") : tensor<{len(quantization)}xi32>
  %expected = check.file.read.npy path("pixels.npy") : tensor<{len(pixels) // 4}xi32>
  %output = check.generate.fill value(17) : tensor<{len(pixels) // 4}xi32>
  kernel.launch @idct_probe(%input, %quantization, %output) : (tensor<{len(coefficients)}xi16>, tensor<{len(quantization)}xi32>, tensor<{len(pixels) // 4}xi32>)
  check.expect.bitwise actual(%output) expected(%expected) : tensor<{len(pixels) // 4}xi32>
  check.return
}}
''')
(directory / 'config.json').write_text(json.dumps({'jpeg': {'probe_blocks': count}}) + '\n')
tags = json.loads(os.environ['BUREAU_TAG_ROOTS'])
base = Path(tags['codec-jpeg-rebased-tools']) / 'loom/src/loom/tools'
subprocess.run([str(base / 'loom-import-cxx/loom-import-cxx'), str(notes / 'float_probe.cxx'),
                '--output=' + str(directory / 'library.loom')], check=True)
subprocess.run([str(base / 'loom-link/loom-link'), str(directory / 'library.loom'),
                '--to=bc', '--output=' + str(directory / 'library.loombc')], check=True)
stage = {'blocks': count, 'files': {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
          for path in directory.iterdir() if path.name != 'stage.json'},
         'source_sha256': hashlib.sha256((notes / 'float_probe.cxx').read_bytes()).hexdigest()}
(directory / 'stage.json').write_text(json.dumps(stage, indent=2) + '\n')
(notes / 'float-probe-stage.json').write_text(json.dumps(stage, indent=2) + '\n')
print(json.dumps({'blocks': count, 'pixels': len(pixels) - 32}), flush=True)
