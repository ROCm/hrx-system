"""Exact connected GPU interval assertions from the qualified root model."""
import argparse
import hashlib
import json
import os
from pathlib import Path

from bounded import State, Summary
from device_fixture import input_bytes, read_words, write_words
from parallel_bridges import construct, phase
from sequential import parse

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
parser = argparse.ArgumentParser()
parser.add_argument('--fixtures', default='fixtures.json')
parser.add_argument('--output', default='parallel-small')
arguments = parser.parse_args()
source = root / arguments.fixtures
output = root / arguments.output
output.mkdir(exist_ok=True)
frames = {}
cases = []
all_paths = set()


def signed(value):
    return value if value < 0x80000000 else value - 0x100000000


for case in json.loads(source.read_text())['cases']:
    name, key = case['name'], case['key']
    if name not in frames:
        data = input_bytes(name)
        assert hashlib.sha256(data).hexdigest() == case['input_sha256']
        frames[name] = parse(data)
    frame = frames[name]
    scan = frame.scans[case['scan']]
    components = len(frame.components)
    summary_stride = (5 + components + 3) & ~3
    stride = (2 + components + 3) & ~3
    interval_stride = (4 + components + 3) & ~3
    small = source.parent.name != 'large'
    paths = {name: source.parent / (key + '-' + name + '.npy')
             for name in ('entropy', 'jobs', 'tables', 'blocks', 'expected')}
    paths['segments'] = root / ('anchor-small' if small else 'anchor-large') / (key + '-segments.npy')
    paths['bridges'] = root / ('bridge-small' if small else 'bridge-large') / (key + '-bridges.npy')
    words = {name: read_words(path) for name, path in paths.items()}
    suffixes, ranges, intervals = [], [], []
    for segment_index, segment in enumerate(scan.segments):
        descriptor = words['segments'][segment_index * 8:(segment_index + 1) * 8]
        first_job, count, total_blocks, first_record = descriptor[2:6]
        assert len(suffixes) == first_record * stride
        assert len(intervals) == (2 * first_job + segment_index) * interval_stride
        summaries = []
        for index in range(first_job, first_job + count):
            record = words['expected'][index * summary_stride:(index + 1) * summary_stride]
            if record[0] == 0xffffffff:
                summaries.append(None)
            else:
                blocks = record[1] // 64
                first = State(record[0], blocks, record[1] & 63, (0,) * components)
                last = State(record[2], blocks + record[4], record[3] & 63,
                             tuple(signed(value) for value in record[5:5 + components]))
                summaries.append(Summary(first, last))
        trace = {}
        checkpoints, counts, transitions = construct(segment, scan, components, summaries,
            case['chunk_bytes'] * 8, case['chunk_bytes'] * 32, trace)
        suffix = [[0] * stride for _ in range(count + 1)]
        suffix[count][0] = count
        for index in range(count - 1, -1, -1):
            current = summaries[index]
            following = summaries[index + 1] if index + 1 < count else None
            connected = (current is not None and following is not None and
                         current.last.position == following.first.position and
                         phase(current.last, len(scan.blocks)) == phase(following.first, len(scan.blocks)))
            suffix[index][0] = suffix[index + 1][0] if connected else index + 1
            suffix[index][1:] = suffix[index + 1][1:]
            if current is not None:
                suffix[index][1] += current.last.blocks - current.first.blocks
                for component in range(components):
                    suffix[index][2 + component] += current.last.predictors[component]
        selected = [[0xffffffff] + [0] * (stride - 1) for _ in range(count + 1)]
        segments_output = [[0] * interval_stride for _ in range(2 * count + 1)]

        def interval_record(first, last):
            record = [first.position, last, first.blocks, phase(first, len(scan.blocks)), *first.predictors]
            return record + [0] * (interval_stride - len(record))

        for target, (limit, state) in trace['ranges'].items():
            selected[target][0:2 + components] = [limit, state.blocks, *state.predictors]
            for index in range(target, limit):
                summary = summaries[index]
                assert (state.position, phase(state, len(scan.blocks))) == (
                    summary.first.position, phase(summary.first, len(scan.blocks)))
                segments_output[index] = interval_record(state, summary.last.position)
                state = State(summary.last.position,
                    state.blocks + summary.last.blocks - summary.first.blocks, summary.last.coefficient,
                    tuple(left + right for left, right in zip(state.predictors, summary.last.predictors, strict=True)))
        for index, (first, last) in trace['bridges'].items():
            assert index < count
            segments_output[count + index] = interval_record(first, last.position)
        segments_output[2 * count] = interval_record(trace['tail'], len(segment.data) * 8)
        actual = sorted((record for record in segments_output if record[1] > record[0]), key=lambda row: row[0])
        expected = [interval_record(first, last.position) for first, last in zip(checkpoints, checkpoints[1:])]
        expected[-1][1] = len(segment.data) * 8
        assert actual == expected, (key, segment_index)
        suffixes.extend(value for record in suffix for value in record)
        ranges.extend(value for record in selected for value in record)
        intervals.extend(value for record in segments_output for value in record)
    values = {'suffixes': suffixes, 'ranges': ranges, 'intervals': intervals}
    for name, value in values.items():
        write_words(output / (key + '-' + name + '.npy'), value)
    sizes = {name: len(value) for name, value in words.items()}
    sizes.update({name: len(value) for name, value in values.items()})
    declarations = [
        ('jpeg_speculate', ('entropy', 'jobs', 'tables', 'blocks', 'expected')),
        ('jpeg_bridge', ('entropy', 'jobs', 'tables', 'blocks', 'expected', 'bridges')),
        ('jpeg_index', ('segments', 'expected', 'suffixes', 'ranges', 'intervals')),
        ('jpeg_certify', ('segments', 'expected', 'bridges', 'suffixes', 'ranges', 'intervals')),
        ('jpeg_intervals', ('segments', 'expected', 'suffixes', 'ranges', 'intervals'))]
    lines = ['kernel.decl @' + entry + '() launch(' + ', '.join('%' + name + ': buffer' for name in names) + ')'
             for entry, names in declarations]
    lines.extend(('', 'check.case @summary {'))
    for name, path in paths.items():
        lines.append(f'  %{name} = check.file.read.npy path("{os.path.relpath(path, output)}") : tensor<{sizes[name]}xi32>')
        all_paths.add(path)
    for name in values:
        lines.append(f'  %{name} = check.file.read.npy path("{key}-{name}.npy") : tensor<{sizes[name]}xi32>')
    outputs = ('expected', 'bridges', 'suffixes', 'ranges', 'intervals')
    for name in outputs:
        lines.append(f'  %{name}_output = check.generate.fill value(17) : tensor<{sizes[name]}xi32>')
    for entry, names in declarations:
        names = tuple(name + '_output' if name in outputs else name for name in names)
        types = ', '.join(f'tensor<{sizes[name.removesuffix("_output")]}xi32>' for name in names)
        lines.append(f'  kernel.launch @{entry}(' + ', '.join('%' + name for name in names) + f') : ({types})')
    for name in outputs:
        lines.append(f'  check.expect.bitwise actual(%{name}_output) expected(%{name}) : tensor<{sizes[name]}xi32>')
    lines.extend(('  check.return', '}', '', 'check.benchmark<@summary> @summary_latency'))
    (output / (key + '.loom')).write_text('\n'.join(lines) + '\n')
    config = json.loads((source.parent / (key + '.json')).read_text())
    config['jpeg'].update({'segments': len(scan.segments), 'table_count': sizes['tables'] // 832, 'cache_tables': 0})
    (output / (key + '.json')).write_text(json.dumps(config, indent=2) + '\n')
    cases.append({**case, 'sizes': sizes, 'segments': len(scan.segments), 'model_intervals_exact': True})
    print(json.dumps({'case': key, 'intervals': len(intervals) // interval_stride}), flush=True)
receipt = {'cases': cases, 'sources': {name: hashlib.sha256((notes / name).read_bytes()).hexdigest()
    for name in ('device_parallel_fixture.py', 'device_fixture.py', 'parallel_bridges.py', 'device_certify.cxx')}}
(output / 'fixtures.json').write_text(json.dumps(receipt, indent=2) + '\n')
all_paths.update(path for path in output.iterdir() if path.is_file())
files = {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest() for path in all_paths}
(root / (arguments.output + '-stage.json')).write_text(json.dumps({'files': files}, indent=2) + '\n')
(notes / (arguments.output + '-fixtures.json')).write_text(json.dumps(receipt, indent=2) + '\n')
