// Queue-retained host input outcomes; NULL denotes source-validated input.
typedef struct loom_serve_finite_statuses_t loom_serve_finite_statuses_t;

// Downloads only the declared outcomes on the producer's feedback branch.
// No-status results return NULL and their existing producer frontier unchanged.
iree_status_t loom_serve_finite_result_download_statuses(
    loom_serve_finite_result_t* result,
    loom_serve_finite_statuses_t** out_statuses,
    loom_serve_execution_frontier_t* out_frontier);

// Caller release never waits; accepted queue captures preserve the destination.
void loom_serve_finite_statuses_release(loom_serve_finite_statuses_t* statuses);

// Called after successful download readiness, using an original request ordinal.
// Nonzero source outcomes become request rejection, never queue/model failure.
iree_status_t loom_serve_finite_statuses_request(
    const loom_serve_finite_statuses_t* statuses, iree_host_size_t request);

// Full feature snapshots carry the same request outcomes in their download.
iree_status_t loom_serve_finite_snapshot_status(
    const loom_serve_finite_snapshot_t* snapshot, iree_host_size_t request);
