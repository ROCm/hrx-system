"""Retain one lookahead window for both Huffman and amplitude consumption."""
from pathlib import Path

notes = Path(__file__).resolve().parent
header = (notes / 'device_entropy_cursor.h').read_text()
header = header.replace('static LOOM_FORCE_INLINE Read codeword(', '''struct Codeword {
  // Cursor after Huffman bits; amplitude extent checking remains separate.
  Cursor cursor;
  // Decoded Huffman symbol.
  unsigned value;
  // Original 32-bit lookahead, including the symbol's amplitude bits.
  unsigned lookahead;
  // Huffman code length, no more than sixteen bits for a validated table.
  unsigned length;
};

static LOOM_FORCE_INLINE Codeword codeword(''')
header = header.replace('  return {cursor, symbol};', '  return {cursor, symbol, bits, length};')
header = header.replace('static LOOM_FORCE_INLINE Read amplitude(const unsigned* words, unsigned count,',
    'static LOOM_FORCE_INLINE Read amplitude(unsigned lookahead, unsigned length, unsigned count,')
header = header.replace('      Read input = peek(words, cursor);\n      cursor = input.cursor;\n      unsigned value = input.value >> (32 - count);',
    '      // A codeword (<=16 bits) and its amplitude (<=11 bits) fit in the\n      // already loaded window. Preserve the existing extent/read-cap errors.\n      loom::assume(length <= 16u);\n      unsigned value = (lookahead << length) >> (32 - count);')
header = header.replace('  Read decoded = codeword(', '  Codeword decoded = codeword(')
header = header.replace('amplitude(words, symbol, limit, cursor)', 'amplitude(decoded.lookahead, decoded.length, symbol, limit, cursor)')
header = header.replace('amplitude(words, category, limit, cursor)', 'amplitude(decoded.lookahead, decoded.length, category, limit, cursor)')
assert 'amplitude(words' not in header
(notes / 'device_entropy_cursor_fused.h').write_text(header)
pipeline = '#include "device_entropy_cursor_fused.h"\n'
for name in ('device_entropy_tables.cxx', 'device_bridge.cxx', 'device_certify.cxx', 'device_reconstruct.cxx'):
    source = (notes / name).read_text().replace('#include "device_entropy_cursor.h"', '')
    pipeline += '\n' + source + '\n'
(notes / 'device_fused_pipeline.cxx').write_text(pipeline)
