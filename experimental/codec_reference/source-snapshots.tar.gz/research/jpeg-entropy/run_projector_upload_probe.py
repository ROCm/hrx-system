"""Stage pinned inputs before one foreground lease, retaining exact evidence."""
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import tarfile

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / "device-active.json").read_text())["directory"])
directory = root / "native-projector"
tag = "codec-jpeg-projector-upload"
binary = Path(json.loads(os.environ["BUREAU_TAG_ROOTS"])[tag]) / "loom/src/loom/tooling/target/amdgpu/serve/codec_projector_upload_probe"
build = json.loads((notes / "projector-upload-probe-build.json").read_text())
assert build["restored"] and build["build_returncode"] == 0
capture = json.loads(subprocess.check_output(["bureau-bazel", "tag", "inspect", tag, "--json"], text=True))
assert capture["capture"] == build["capture"]["capture"]
for name, expected in build["sources"].items():
    assert hashlib.sha256((notes / name).read_bytes()).hexdigest() == expected, name
source = json.loads((notes / "projector-upload-source.json").read_text())
compiled = json.loads((notes / "projector-upload-compile.json").read_text())
assert compiled["source_receipt_sha256"] == hashlib.sha256((notes / "projector-upload-source.json").read_bytes()).hexdigest()
assert all(command["returncode"] == 0 for command in compiled["commands"])
files = {"codec_projector_upload_probe": binary, "run.py": notes / "projector_upload_run.py"}
for name, expected in source["files"].items():
    path = directory / name
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, name
    files[name] = path
for name, expected in compiled["artifacts"].items():
    path = directory / name
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, name
files["decoder.loombc"] = directory / "decoder.loombc"
controls = json.loads((notes / "model-accuracy-stage.json").read_text())
for name in ("original.jpg", "loom-float32.pam"):
    path = root / "vision-accuracy/inputs" / name
    assert hashlib.sha256(path.read_bytes()).hexdigest() == controls["files"]["inputs/" + name]
    files[name] = path
staged_bytes = sum(path.stat().st_size for path in files.values())
assert staged_bytes + 2 * 19906560 < 256 * 1024**2
manifest = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in files.items()}
(directory / "stage-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
files["stage-manifest.json"] = directory / "stage-manifest.json"
machine = "hrx-gorgon-3"
subprocess.run(["ssh", machine, "mkdir -p " + shlex.quote(str(directory))], check=True)
print(json.dumps({"staged_bytes": staged_bytes, "lease_held": False}), flush=True)
process = subprocess.Popen(["ssh", "-o", "ConnectTimeout=15", machine, "tar -xzf - -C " + shlex.quote(str(directory))], stdin=subprocess.PIPE)
with tarfile.open(fileobj=process.stdin, mode="w|gz", dereference=True) as archive:
    for name, path in files.items():
        archive.add(path, arcname=name, recursive=False)
process.stdin.close()
assert process.wait() == 0
verify = '''import hashlib,json,pathlib,sys
root=pathlib.Path(sys.argv[1]);files=json.loads((root/'stage-manifest.json').read_text())
for name,digest in files.items():
 assert hashlib.file_digest((root/name).open('rb'),'sha256').hexdigest()==digest,name
weights=pathlib.Path('/home/benvanik/models/unsloth/Qwen3.8-27B-GGUF/be8e54148befbe990c6daeed4aecf9ac4540b840/mmproj-F16.gguf')
assert hashlib.file_digest(weights.open('rb'),'sha256').hexdigest()=='cbb841a9ee0636b2ec172f5bb8df2ea8dfeb01e90fe7c6126581d662a0b4e43e'
assert not list(pathlib.Path('/sys/class/kfd/kfd/proc').iterdir())
print('Pinned inputs and checkpoint verified; no GPU process.',flush=True)
'''
subprocess.run(["ssh", machine, shlex.join(["python3", "-B", "-c", verify, str(directory)])], check=True)
command = ["/home/benvanik/.dotfiles/bin/benchmark-lock", "--label=codec-jpeg-trained-projector-access", "--",
           "timeout", "--signal=INT", "--kill-after=15s", "180s", "env", "LD_LIBRARY_PATH=/opt/rocm/lib",
           "python3", "-B", str(directory / "run.py"), str(directory)]
with (notes / "gorgon3-projector-upload-run.log").open("w") as stream:
    result = subprocess.run(["ssh", machine, shlex.join(command)], stdout=stream, stderr=subprocess.STDOUT)
status = subprocess.run(["ssh", machine, "/home/benvanik/.dotfiles/bin/benchmark-lock --status"], capture_output=True, text=True)
for name in ("control.log", "candidate.log", "execution.json"):
    result_file = subprocess.run(["ssh", machine, "cat " + shlex.quote(str(directory / name))], capture_output=True)
    if result_file.returncode == 0:
        (notes / ("gorgon3-projector-upload-" + name)).write_bytes(result_file.stdout)
    elif name != "candidate.log":
        raise RuntimeError(result_file.stderr.decode())
record = {"command": command, "returncode": result.returncode, "build": build,
          "source_receipt_sha256": hashlib.sha256((notes / "projector-upload-source.json").read_bytes()).hexdigest(),
          "compile_receipt_sha256": hashlib.sha256((notes / "projector-upload-compile.json").read_bytes()).hexdigest(),
          "manifest": manifest, "staged_bytes": staged_bytes,
          "broker_status_returncode": status.returncode, "broker_status_after": status.stdout + status.stderr,
          "scope": "Actual finite-model native compressed input through trained features, exact independent pixel control, shared decoder scratch across peers, per-image GPU validity, host ASAN/GPU access checks. No HTTP publication or performance qualification."}
(notes / "gorgon3-projector-upload-receipt.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"returncode": result.returncode, "broker_status_after": record["broker_status_after"]}), flush=True)
print((notes / "gorgon3-projector-upload-run.log").read_text()[-6000:], flush=True)
assert result.returncode == 0
