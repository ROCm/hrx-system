"""Replace padding with a row-local permutation of coefficient owners."""
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path

notes = Path(__file__).resolve().parent
source = (notes / 'device_reconstruct_block_certificate.cxx').read_text()
marker = '// All lanes enter; each group of eight consumes one producer\'s block.'
helper = '''// Row-local owner permutation preserves the payload while distributing
// each eight-lane consumer's column across independent LDS banks.
static LOOM_FORCE_INLINE unsigned coefficient_index(unsigned natural,
    unsigned owner, unsigned stride) {
  return natural * stride + (owner ^ ((natural & 7u) * 2u));
}

'''
assert source.count(marker) == 1
source = source.replace(marker, helper + marker)
old = '''  // A two-halfword skew gives distinct bank words to the eight consumers.
  unsigned coefficient_stride = threads + 2;'''
new = '''  // The row-local permutation avoids padding the coefficient payload.
  unsigned coefficient_stride = threads;'''
assert source.count(old) == 1
source = source.replace(old, new)
replacements = {
    'coefficients[natural * coefficient_stride + owner]':
        'coefficients[coefficient_index(natural, owner, coefficient_stride)]',
    'coefficients[index * coefficient_stride + lane]':
        'coefficients[coefficient_index(index, lane, coefficient_stride)]',
    'coefficients[natural * coefficient_stride + lane]':
        'coefficients[coefficient_index(natural, lane, coefficient_stride)]',
}
for old, new in replacements.items():
    assert old in source
    source = source.replace(old, new)
(notes / 'device_reconstruct_compact.cxx').write_text(source)
pipeline = '#include "device_entropy_cursor_certified.h"\n'
pipeline += '''[[loom::config("jpeg.output_partitions"), loom::where(loom::predicate::range(2u, 8u))]]
extern const unsigned output_partitions;
'''
for name in ('device_entropy_partitioned.cxx', 'device_bridge.cxx',
             'device_certify_partitioned.cxx', 'device_reconstruct_compact.cxx'):
    pipeline += '\n' + (notes / name).read_text().replace('#include "device_entropy_cursor.h"', '') + '\n'
(notes / 'device_compact_pipeline.cxx').write_text(pipeline)

rows = []
for threads in (32, 64):
    for natural in range(64):
        offsets = {natural * threads + (owner ^ ((natural & 7) * 2)) for owner in range(threads)}
        assert offsets == set(range(natural * threads, (natural + 1) * threads))
    for layout in ('padded', 'xor'):
        conflicts = Counter()
        for round in range(8):
            for row in range(8):
                banks = defaultdict(set)
                for lane in range(threads):
                    owner = round * (threads // 8) + lane // 8
                    natural = row * 8 + lane % 8
                    offset = (natural * (threads + 2) + owner if layout == 'padded' else
                              natural * threads + (owner ^ ((natural & 7) * 2)))
                    word = offset // 2
                    banks[word % 32].add(word)
                conflicts[max(map(len, banks.values()))] += 1
        rows.append({'threads': threads, 'layout': layout, 'distinct_words_per_bank': dict(conflicts)})
(notes / 'compact-coefficients-layout.json').write_text(json.dumps({
    'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'rows': rows,
    'scope': 'Logical 32-bank/dword addressing model, not measured LDS conflicts or occupancy. Wave32 is the measured candidate; wave64 enumeration checks representation only.'}, indent=2) + '\n')
