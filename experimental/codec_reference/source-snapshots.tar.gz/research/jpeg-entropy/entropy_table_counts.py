"""Count decoder-table work in the qualified C2 model; this is not timing."""
from collections import Counter
import hashlib
import json
from pathlib import Path

from device_fixture import input_bytes
from recover_prefix import speculate
from sequential import Huffman, parse

notes = Path(__file__).resolve().parent
data = input_bytes('012mp-bus.jpg.r0.jpg')
frame = parse(data)
decode = Huffman.decode
lengths = Counter()
failures = Counter()
tables = {}
table_roles = {}
for scan in frame.scans:
    for block in scan.blocks:
        for role, table in (('dc', block.dc), ('ac', block.ac)):
            key = id(table)
            if key not in tables:
                tables[key] = len(tables)
                table_roles[key] = role


def counted_decode(self, reader):
    before = reader.position
    try:
        value = decode(self, reader)
    except Exception as error:
        failures[type(error).__name__] += 1
        raise
    lengths[(tables[id(self)], table_roles[id(self)], reader.position - before)] += 1
    return value


Huffman.decode = counted_decode
rows = []
for chunk_bytes in (4096, 1024):
    lengths.clear()
    failures.clear()
    counters = Counter()
    for scan in frame.scans:
        for segment in scan.segments:
            intervals = (len(segment.data) + chunk_bytes - 1) // chunk_bytes
            _, counts = speculate(segment, scan, len(frame.components), chunk_bytes * 8, 1, intervals)
            counters.update(counts)
    symbols = sum(lengths.values())
    fast = sum(count for (_, _, length), count in lengths.items() if length <= 9)
    dc = sum(count for (_, role, _), count in lengths.items() if role == 'dc')
    long_iterations = sum(max(0, length - 9) * count
                          for (_, _, length), count in lengths.items())
    row = {'chunk_bytes': chunk_bytes, 'symbols': symbols, 'fast_symbols': fast,
           'long_symbols': symbols - fast, 'long_code_loop_iterations': long_iterations,
           'dc_symbols': dc, 'descriptor_loads_if_reused_within_block': dc,
           'descriptor_loads_current_per_successful_symbol': symbols,
           'short_table_loads_per_successful_symbol': symbols,
           'long_code_first_count_loads': long_iterations * 2,
           'long_code_base_symbol_loads': (symbols - fast) * 2,
           'failed_attempts': dict(failures), 'counters': dict(counters),
           'length_counts': [{'table': table, 'role': role, 'length': length, 'count': count}
                             for (table, role, length), count in sorted(lengths.items())]}
    rows.append(row)
    print(json.dumps({k: v for k, v in row.items() if k not in ('length_counts', 'counters')}), flush=True)
    (notes / 'entropy-table-counts.json').write_text(json.dumps({
        'input_sha256': hashlib.sha256(data).hexdigest(),
        'source_sha256': {name: hashlib.sha256((notes / name).read_bytes()).hexdigest()
                          for name in ('sequential.py', 'bounded.py', 'recover_prefix.py', 'entropy_table_counts.py')},
        'scope': 'Successful Huffman transitions in the independent model, per image. Logical scalar table accesses implied by current CXX code, not GPU transactions or DRAM traffic. Failure-path partial reads are listed separately.',
        'rows': rows}, indent=2) + '\n')
