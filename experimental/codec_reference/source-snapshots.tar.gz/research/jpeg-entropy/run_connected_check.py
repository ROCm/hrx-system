"""Short foreground correctness leases for the original-byte command."""
import argparse
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import tarfile

from device_fixture import read_words, write_words

parser = argparse.ArgumentParser()
parser.add_argument('--small', action='store_true')
arguments = parser.parse_args()
notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
name = 'connected-small' if arguments.small else 'connected-batch16'
fixture = root / name
stage = json.loads((fixture / 'stage.json').read_text())
files = {str(path.relative_to(root)): path for path in fixture.iterdir() if path.is_file()}
library = root / 'entropy-connected.loombc'
files[library.name] = library
if arguments.small:
    for relative in stage['files']:
        path = (fixture / relative).resolve()
        files[str(path.relative_to(root))] = path
    bad = list(read_words(fixture / 'schedule.npy'))
    bad[0] += 1
    write_words(fixture / 'bad-schedule.npy', bad)
    (fixture / 'negative.loom').write_text((fixture / 'summary.loom').read_text().replace(
        'path("schedule.npy")', 'path("bad-schedule.npy")'))
    files[name + '/bad-schedule.npy'] = fixture / 'bad-schedule.npy'
    files[name + '/negative.loom'] = fixture / 'negative.loom'
assert sum(path.stat().st_size for path in files.values()) < 64 * 1024 * 1024
process = subprocess.Popen(['ssh', 'hrx-gorgon-4', 'tar -xf - -C ' + shlex.quote(str(root))], stdin=subprocess.PIPE)
with tarfile.open(fileobj=process.stdin, mode='w|') as archive:
    for relative, path in files.items():
        archive.add(path, arcname=relative, recursive=False)
process.stdin.close()
assert process.wait() == 0
verify = '''import hashlib,json,pathlib,sys
root=pathlib.Path(sys.argv[1]);fixture=root/sys.argv[2];stage=json.loads((fixture/'stage.json').read_text())
for name,digest in stage['files'].items():
 assert hashlib.sha256((fixture/name).read_bytes()).hexdigest()==digest,name
assert hashlib.sha256((root/stage['library']['path']).read_bytes()).hexdigest()==stage['library']['sha256']
assert hashlib.sha256((root/'iree-test-loom-unsigned').read_bytes()).hexdigest()=='5e267978d7e937b1009f64a2e005913a4cc36c002b1f24eef44776cc4683a632'
'''
subprocess.run(['ssh', 'hrx-gorgon-4', shlex.join(['python3', '-B', '-c', verify, str(root), name])], check=True)
script = '''import json,os,pathlib,subprocess,sys
root=pathlib.Path(sys.argv[1]);fixture=root/sys.argv[2]
assert os.environ['BENCHMARK_LOCK_LEASE_ID']
assert not list(pathlib.Path('/sys/class/kfd/kfd/proc').iterdir())
record={'host':os.uname().nodename,'lease':os.environ['BENCHMARK_LOCK_LEASE_ID'],'runs':[]}
names=['summary.loombc']+(['negative.loom'] if sys.argv[2]=='connected-small' else [])
for name in names:
 command=[str(root/'iree-test-loom-unsigned'),str(fixture/name),'--config-file='+str(fixture/'config.json'),'--device=amdgpu','--target=amdgpu:gfx1151','--sanitizer=access']
 if name.endswith('.loom'): command.append('--library='+str(root/'entropy-connected.loombc'))
 result=subprocess.run(command,capture_output=True,text=True)
 (fixture/(name+'-check.log')).write_text(result.stdout+result.stderr)
 record['runs'].append({'command':command,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
 (fixture/'qualified.json').write_text(json.dumps(record,indent=2)+'\\n')
 if name=='summary.loombc':
  if result.returncode:
   print((result.stdout+result.stderr)[-8000:],flush=True);raise SystemExit(result.returncode)
  report=json.loads(result.stdout)
  assert report['failed_sample_count']==0 and report['sample_count']>0,report
  print(json.dumps({'case':name,'passed':True,'report':report}),flush=True)
 else:
  assert result.returncode!=0,'Negative expectation was not detected'
  report=json.loads(result.stdout)
  assert report['failed_sample_count']==1,report
  print(json.dumps({'case':name,'expected_failure_detected':True,'report':report}),flush=True)
'''
command = ['/home/benvanik/.dotfiles/bin/benchmark-lock', '--label=codec-jpeg-' + name,
           '--', 'env', 'LD_LIBRARY_PATH=/opt/rocm/lib', 'python3', '-B', '-c', script, str(root), name]
log = notes / ('gorgon4-' + name + '-check.log')
with log.open('w') as stream:
    result = subprocess.run(['ssh', 'hrx-gorgon-4', shlex.join(command)], stdout=stream, stderr=subprocess.STDOUT)
status = subprocess.run(['ssh', 'hrx-gorgon-4', '/home/benvanik/.dotfiles/bin/benchmark-lock --status'], capture_output=True, text=True)
receipt = {'command': command, 'returncode': result.returncode, 'broker_status_after': status.stdout + status.stderr,
           'staged_files': {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in files.items()}}
(notes / ('gorgon4-' + name + '-check-lease.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key:value for key,value in receipt.items() if key != 'staged_files'}), flush=True)
subprocess.run(['scp', 'hrx-gorgon-4:' + str(fixture / 'qualified.json'),
                str(notes / ('gorgon4-' + name + '-qualified.json'))], check=True)
print(log.read_text()[-9000:], flush=True)
raise SystemExit(result.returncode)
