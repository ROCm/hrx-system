"""Candidate C2: retry invalid speculative prefixes within a strict read cap.

Only the untrusted prefix before the first saved checkpoint may reset. Once
that checkpoint exists, any invalid syntax rejects the summary. Acceptance
still requires the established anchor's exact bit/block/coefficient state.
"""

from bounded import Cursor, Summary
from sequential import Bits, InvalidJPEG


class ReadBudgetExceeded(Exception):
    """The speculative branch consumed its explicit entropy-read allowance."""


class CountedBits(Bits):
    def __init__(self, data, position, budget):
        super().__init__(data, position)
        # Total bit reads, including bytes revisited after a prefix reset.
        self.read_bits = 0
        # Fixed per-trajectory read ceiling, independent of convergence.
        self.budget = budget

    def take(self, count):
        if self.read_bits + count > self.budget:
            raise ReadBudgetExceeded()
        value = super().take(count)
        self.read_bits += count
        return value


def speculate(segment, scan, components, chunk_bits, lookbehind, intervals):
    summaries = []
    symbols = 0
    attempts = 0
    consumed_bits = 0
    overlap_symbols = 0
    overlap_bits = 0
    rejected = 0
    resets = 0
    exhausted = 0
    # C2 admits up to twice C1's nominal bit span, including all revisits.
    # The 26-bit slop admits one longest possible syntax transition.
    budget = 2 * (lookbehind + 1) * chunk_bits + 26
    for interval in range(intervals):
        start = max(0, interval - lookbehind) * chunk_bits
        cursor = Cursor(segment, scan, components)
        cursor.reader = CountedBits(segment.data, start, budget)
        first = None
        prefix_symbols = 0
        prefix_bits = 0
        try:
            while cursor.reader.position < interval * chunk_bits:
                position = cursor.reader.position
                try:
                    cursor.advance()
                except InvalidJPEG:
                    # This trajectory has never been certified. Try the next
                    # bit in DC/block-zero state; all repeated reads are charged.
                    cursor.reader.position = position + 1
                    cursor.blocks = 0
                    cursor.coefficient = 0
                    cursor.predictors = [0] * components
                    resets += 1
            first = cursor.state()
            prefix_symbols = cursor.reader.huffman_symbols
            prefix_bits = cursor.reader.read_bits
            while cursor.reader.position < (interval + 1) * chunk_bits:
                cursor.advance()
            summaries.append(Summary(first, cursor.state()))
        except InvalidJPEG:
            summaries.append(None)
            rejected += 1
        except ReadBudgetExceeded:
            summaries.append(None)
            rejected += 1
            exhausted += 1
        assert cursor.reader.read_bits <= budget
        symbols += cursor.reader.huffman_symbols
        attempts += cursor.reader.huffman_attempts
        consumed_bits += cursor.reader.read_bits
        overlap_symbols += prefix_symbols if first else cursor.reader.huffman_symbols
        overlap_bits += prefix_bits if first else cursor.reader.read_bits
    return summaries, {"speculative_symbols": symbols,
                       "speculative_symbol_attempts": attempts,
                       "speculative_bits": consumed_bits,
                       "speculative_overlap_symbols": overlap_symbols,
                       "speculative_overlap_bits": overlap_bits,
                       "invalid_speculations": rejected,
                       "prefix_resets": resets,
                       "budget_exhaustions": exhausted,
                       "speculative_bit_bound": intervals * budget}
