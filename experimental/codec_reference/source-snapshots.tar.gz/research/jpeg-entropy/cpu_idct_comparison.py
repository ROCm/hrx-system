"""Compare public CPU IDCT policies with the qualified resident float pipeline."""
import ast
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys

root = Path(sys.argv[1])
assert os.environ['BENCHMARK_LOCK_LEASE_ID']
tree = ast.parse((root / 'cpu-current/machine-state.py').read_text())
node = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'state')
exec(compile(ast.Module(body=[node], type_ignores=[]), 'machine-state.py', 'exec'))
before = state()
assert before['governor'] == 'performance' and before['gpu_policy'] == 'high'
assert int(before['personality'], 16) & 0x40000
assert before['gpu_busy'] == 0 and not before['kfd_processes'] and not before['drm']
image = root / 'cpu-current/012mp-bus.jpg.r0.jpg'
binaries = {'islow': root / 'cpu-current/jpeg_baseline',
            'float': root / 'cpu-idct/cpu_float_baseline',
            'ifast': root / 'cpu-idct/cpu_fast_baseline',
            'gpu': root / 'codec_command_probe'}
record = {'before': before, 'source': json.loads((root / 'cpu-idct/source.json').read_text()),
          'binaries': {key: hashlib.sha256(path.read_bytes()).hexdigest() for key, path in binaries.items()},
          'fixture': json.loads((root / 'connected-float/stage.json').read_text()), 'rows': [], 'native_routes': {},
          'scope': {'batch': 16, 'cpu_workers': 16, 'cpu_affinity': '0-15', 'warmups': 2, 'samples': 9,
            'cpu_input': 'One shared immutable compressed image; sixteen preallocated disjoint RGB outputs.',
            'cpu_timed': 'Task submission through all decode completions, including codec create/header/start/read/finish/destroy and internal codec allocations.',
            'gpu_timed': 'Eight original-JPEG-to-RGB operations per submission and one completion, divided by eight. Header parsing, JIT, allocation, upload, and verification downloads excluded.',
            'accuracy': 'IDCT policies have different pixels; independent cosine/complete image errors recorded separately.'}}
for name, symbol in (('float', 'jsimd_idct_float_sse2'), ('ifast', 'jsimd_idct_ifast_sse2')):
    command = ['/opt/rocm/bin/rocgdb', '-q', '-batch', '-ex', 'set pagination off', '-ex', 'set confirm off',
               '-ex', 'break ' + symbol, '-ex', 'run qualify ' + str(image), '-ex', 'bt 3', '-ex', 'quit', str(binaries[name])]
    result = subprocess.run(command, capture_output=True, text=True)
    assert result.returncode == 0 and 'Breakpoint 1,' in result.stdout and symbol in result.stdout, result.stdout + result.stderr
    record['native_routes'][name] = {'command': command, 'output': result.stdout + result.stderr}
for ordinal, name in enumerate(('islow', 'gpu', 'float', 'gpu', 'ifast', 'gpu', 'float', 'islow', 'ifast')):
    if name == 'gpu':
        command = [str(binaries[name]), '--jpeg_fixture=' + str(root / 'connected-float'),
                   '--gtest_filter=JpegCommandTest.CompressedToRgb', '--jpeg_benchmark=true']
    else:
        command = ['taskset', '-c', '0-15', str(binaries[name]), 'bench', '16', '16', '9', str(image)]
    result = subprocess.run(command, capture_output=True, text=True)
    (root / 'cpu-idct' / (str(ordinal) + '-' + name + '.log')).write_text(result.stdout + result.stderr)
    assert result.returncode == 0, result.stdout + result.stderr
    rows = [json.loads(line) for line in result.stdout.splitlines() if line.startswith('{')]
    if name == 'gpu':
        measurement, = [row for row in rows if row['phase'] == 'measurement']
        duration = measurement['median_operation_ns']
    else:
        row, = rows
        assert row['full_rgb_and_guards']
        duration = statistics.median(row['batch_ns'])
    record['rows'].append({'name': name, 'median_batch_ns': duration, 'command': command, 'rows': rows})
    (root / 'cpu-idct/comparison.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'name': name, 'median_batch_ms': duration / 1e6}), flush=True)
record['after'] = state()
assert not record['after']['kfd_processes'] and not record['after']['drm']
(root / 'cpu-idct/comparison.json').write_text(json.dumps(record, indent=2) + '\n')
