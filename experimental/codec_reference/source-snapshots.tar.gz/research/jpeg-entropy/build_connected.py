"""Build the bounded original-byte command leaves using retained Fabric tools."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

notes = Path(__file__).resolve().parent
root = Path(json.loads((notes / 'device-active.json').read_text())['directory'])
tags = json.loads(os.environ['BUREAU_TAG_ROOTS'])
base = Path(tags['codec-jpeg-rebased-tools']) / 'loom/src/loom/tools'
native = Path(tags['codec-jpeg-unsigned-opt']) / 'loom/src/loom/tools'
configuration = json.loads((root / 'twolevel-batch16-1024/config.json').read_text())
configuration['input'] = {'tiles': 821}
configuration['jpeg']['chunks'] = 821 * 4 * 16
(root / 'connected-config.json').write_text(json.dumps(configuration, indent=2) + '\n')
commands = [
    ['python3', '-B', str(notes / 'connected_source.py')],
    [str(base / 'loom-import-cxx/loom-import-cxx'), str(notes / 'device_connected_pipeline.cxx'),
     '--output=' + str(root / 'connected.loom')],
    [str(base / 'loom-link/loom-link'), str(root / 'connected.loom'), '--to=bc',
     '--output=' + str(root / 'entropy-connected.loombc')]]
for command in commands:
    subprocess.run(command, check=True)
metrics = {}
for name in ('jpeg_classify_bytes', 'jpeg_prefix_bytes', 'jpeg_plan_jobs', 'jpeg_compact_bytes',
             'jpeg_speculate', 'jpeg_bridge', 'jpeg_reconstruct'):
    command = [str(native / 'loom-compile/loom-compile'), str(root / 'entropy-connected.loombc'),
               '--root=' + name, '--target=amdgpu:gfx1151',
               '--config-file=' + str(root / 'connected-config.json'),
               '--output=' + str(root / (name + '-connected.hsaco')),
               '--compile-report=details', '--compile-report-output=' + str(root / (name + '-connected-report.json'))]
    commands.append(command)
    subprocess.run(command, check=True)
    row = json.loads((root / (name + '-connected-report.json')).read_text())['entries']['rows'][0]
    metrics[name] = {key: row[key] for key in ('instruction_count', 'code_byte_count',
                     'private_memory_bytes', 'local_memory_bytes', 'target_resources')}
    with (root / (name + '-connected.native.s')).open('w') as output:
        subprocess.run(['/home/ben/tools/llvm/latest/bin/llvm-objdump', '-d', '--mcpu=gfx1151',
                        str(root / (name + '-connected.hsaco'))], stdout=output, check=True)
    print(name, json.dumps(metrics[name]), flush=True)
record = {'commands': commands, 'configuration': configuration, 'metrics': metrics,
          'source_sha256': hashlib.sha256((notes / 'device_connected_pipeline.cxx').read_bytes()).hexdigest(),
          'library_sha256': hashlib.sha256((root / 'entropy-connected.loombc').read_bytes()).hexdigest()}
(notes / 'connected-native.json').write_text(json.dumps(record, indent=2) + '\n')
