"""Reuse the two owned tagged output slots for additional codec omissions."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

notes = Path(__file__).resolve().parent
assert Path.cwd() == notes.parents[2]
identity = json.loads((notes / 'binary-cost-source.json').read_text())
assert json.loads((notes / 'binary-cost-result.json').read_text())['savings_bytes']['stripped'] == 385864
for variant, codecs in [('without_png', 'jpeg,gif,webp'), ('without_gif', 'png,jpeg,webp'),
                        ('without_webp', 'png,jpeg,gif'), ('pam_only', '')]:
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == identity['head']
    assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True)
    for row in identity['files']:
        assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest() == row['sha256'], row['path']
    destination = notes / f'binary-cost-{variant}-build.log'
    assert not destination.exists(), 'preserve prior attempts'
    arguments = ['bureau-bazel', 'build', '--tag=codec-image-deps-candidate', '--json',
                 '--config=opt', '--//loom/config/serve:image_input=true',
                 f'--//loom/config/serve:image_codecs={codecs}',
                 '//loom/src/loom/tools/loom-serve:loom-serve']
    (notes / f'binary-cost-{variant}-invocation.json').write_text(json.dumps({
        'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'arguments': arguments, 'source_identity': identity,
    }, indent=2) + '\n')
    with destination.open('w') as output:
        child = subprocess.Popen(arguments, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        for line in child.stdout:
            output.write(line)
            output.flush()
            print(line, end='', flush=True)
        status = child.wait()
    (notes / f'binary-cost-{variant}-exit.json').write_text(json.dumps({'exit_code': status}) + '\n')
    if status:
        sys.exit(status)
    inspection = ['bureau-bazel', 'tag', 'session', 'codec-image-deps-baseline',
                  'codec-image-deps-candidate', '--', 'python3',
                  str(notes / 'inspect_size_pair.py'), variant]
    subprocess.run(inspection, check=True)
