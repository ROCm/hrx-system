"""Inspect leased immutable binaries; never execute a serving process."""
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import sys
import tempfile

notes = Path(__file__).resolve().parent
roots = json.loads(os.environ['BUREAU_TAG_ROOTS'])
expected_tags = {f'codec-image-deps-{variant}' for variant in ['baseline', 'candidate']}
assert set(roots) == expected_tags
relative = Path('loom/src/loom/tools/loom-serve/loom-serve')
candidate_name = sys.argv[1] if len(sys.argv) == 2 else 'candidate'
removed = {'candidate': {'jpeg'}, 'without_png': {'png'}, 'without_gif': {'gif'},
           'without_webp': {'webp'}, 'pam_only': {'jpeg', 'png', 'gif', 'webp'}}[candidate_name]
result = {'state': 'Complete executable size comparison; no execution or performance test.',
          'strip_version': subprocess.check_output(['strip', '--version'], text=True).splitlines()[0],
          'variants': {}}
jpeg_pattern = re.compile(r'^(?:_?jpeg|_?jsimd|_?jinit|_?jcopy|_?jzero|_?jdiv_round_up|_?jround_up|loom_serve_media_jpeg|loom_serve_media_image_codec_jpeg)')
codec_patterns = {'jpeg': jpeg_pattern,
                  'png': re.compile(r'^(?:png_|loom_serve_media_png|loom_serve_media_image_codec_png)'),
                  'gif': re.compile(r'^(?:DGif|EGif|Gif|loom_serve_media_gif|loom_serve_media_image_codec_gif)'),
                  'webp': re.compile(r'^(?:WebP|VP8|loom_serve_media_webp|loom_serve_media_image_codec_webp)')}


def inspect(path):
    data = path.read_bytes()
    header = struct.unpack_from('<16sHHIQQQIHHHHHH', data)
    assert header[0][:6] == b'\x7fELF\x02\x01' and header[2] == 62
    assert header[11] == 64 and header[12] > 0
    entries = [struct.unpack_from('<IIQQQQIIQQ', data, header[6] + i * header[11])
               for i in range(header[12])]
    string_entry = entries[header[13]]
    strings = data[string_entry[4]:string_entry[4] + string_entry[5]]
    sections = []
    for entry in entries:
        name = strings[entry[0]:].split(b'\0', 1)[0].decode()
        if entry[2] & 2:
            sections.append({'name': name, 'type': entry[1], 'flags': entry[2],
                             'bytes': entry[5], 'alignment': entry[8]})
    loads = []
    for index in range(header[10]):
        entry = struct.unpack_from('<IIQQQQQQ', data, header[5] + index * header[9])
        if entry[0] == 1:
            loads.append({'flags': entry[1], 'file_bytes': entry[5], 'memory_bytes': entry[6],
                          'alignment': entry[7]})
    symbols = subprocess.check_output(['nm', '-S', '--defined-only', '--format=posix', str(path)], text=True)
    codec_symbols = {name: [] for name in codec_patterns}
    for line in symbols.splitlines():
        fields = line.split()
        if len(fields) == 4:
            for name, pattern in codec_patterns.items():
                if pattern.match(fields[0]):
                    codec_symbols[name].append({'name': fields[0], 'type': fields[1], 'bytes': int(fields[3], 16)})
    with tempfile.TemporaryDirectory(prefix='codec-jpeg-size-', dir='/tmp') as directory:
        stripped = Path(directory) / 'loom-serve'
        subprocess.run(['strip', '--strip-all', '-o', str(stripped), str(path)], check=True)
        stripped_bytes = stripped.read_bytes()
        stripped_record = {'bytes': len(stripped_bytes), 'sha256': hashlib.sha256(stripped_bytes).hexdigest()}
    return {
        'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
        'stripped': stripped_record, 'allocated_sections': sections, 'load_segments': loads,
        'text_bytes': sum(s['bytes'] for s in sections if s['name'] == '.text'),
        'rodata_bytes': sum(s['bytes'] for s in sections if s['name'].startswith('.rodata')),
        'allocated_file_bytes': sum(s['bytes'] for s in sections if s['type'] != 8),
        'allocated_zerofill_bytes': sum(s['bytes'] for s in sections if s['type'] == 8),
        'load_segment_file_bytes': sum(s['file_bytes'] for s in loads),
        'jpeg_named_symbols': codec_symbols['jpeg'],
        'codec_named_symbols': codec_symbols,
        'dynamic_section': subprocess.check_output(['readelf', '--dynamic', str(path)], text=True),
    }


for variant in ['baseline', 'candidate']:
    recorded_name = 'baseline' if variant == 'baseline' else candidate_name
    assert json.loads((notes / f'binary-cost-{recorded_name}-exit.json').read_text())['exit_code'] == 0
    invocation = json.loads((notes / f'binary-cost-{recorded_name}-invocation.json').read_text())
    result['variants'][variant] = {'invocation': invocation,
                                   **inspect(Path(roots[f'codec-image-deps-{variant}']) / relative)}
baseline = result['variants']['baseline']
candidate = result['variants']['candidate']
assert baseline['invocation']['source_identity'] == candidate['invocation']['source_identity']
for name in codec_patterns:
    assert baseline['codec_named_symbols'][name], name
    assert bool(candidate['codec_named_symbols'][name]) == (name not in removed), name
result['savings_bytes'] = {key: baseline[key] - candidate[key]
                          for key in ['bytes', 'text_bytes', 'rodata_bytes', 'allocated_file_bytes',
                                      'allocated_zerofill_bytes', 'load_segment_file_bytes']}
result['savings_bytes']['stripped'] = baseline['stripped']['bytes'] - candidate['stripped']['bytes']
result['section_deltas'] = []
baseline_sections = {s['name']: s for s in baseline['allocated_sections']}
candidate_sections = {s['name']: s for s in candidate['allocated_sections']}
for name in sorted(set(baseline_sections) | set(candidate_sections)):
    before = baseline_sections.get(name, {}).get('bytes', 0)
    after = candidate_sections.get(name, {}).get('bytes', 0)
    if before != after:
        result['section_deltas'].append({'name': name, 'baseline': before, 'candidate': after, 'savings': before - after})
output_name = 'binary-cost-result.json' if candidate_name == 'candidate' else f'binary-cost-{candidate_name}-result.json'
assert not (notes / output_name).exists(), 'preserve completed comparison receipts'
(notes / output_name).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'savings_bytes': result['savings_bytes'],
                  'stripped_baseline_bytes': baseline['stripped']['bytes'],
                  'stripped_candidate_bytes': candidate['stripped']['bytes'],
                  'baseline_jpeg_named_symbol_count': len(baseline['jpeg_named_symbols']),
                  'candidate_jpeg_named_symbol_count': len(candidate['jpeg_named_symbols']),
                  'candidate_name': candidate_name,
                  'candidate_codec_symbol_counts': {name: len(symbols) for name, symbols in candidate['codec_named_symbols'].items()},
                  'section_deltas': result['section_deltas']}, indent=2))
