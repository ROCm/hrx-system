"""Build exactly two immutable loom-serve artifacts without editing config."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
assert Path.cwd() == root.parents[2]
identity = json.loads((root / 'binary-cost-source.json').read_text())
for variant, codecs in [('baseline', 'png,jpeg,gif,webp'), ('candidate', 'png,gif,webp')]:
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == identity['head']
    assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True)
    for row in identity['files']:
        assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest() == row['sha256'], row['path']
    destination = root / f'binary-cost-{variant}-build.log'
    assert not destination.exists(), 'retain original build attempts'
    arguments = ['bureau-bazel', 'build', f'--tag=codec-image-deps-{variant}', '--json',
                 '--config=opt', '--//loom/config/serve:image_input=true',
                 f'--//loom/config/serve:image_codecs={codecs}',
                 '//loom/src/loom/tools/loom-serve:loom-serve']
    (root / f'binary-cost-{variant}-invocation.json').write_text(json.dumps({
        'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'arguments': arguments, 'source_identity': identity,
    }, indent=2) + '\n')
    with destination.open('w') as output:
        child = subprocess.Popen(arguments, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        for line in child.stdout:
            output.write(line)
            output.flush()
            print(line, end='', flush=True)
        status = child.wait()
    (root / f'binary-cost-{variant}-exit.json').write_text(json.dumps({'exit_code': status}) + '\n')
    if status:
        sys.exit(status)
