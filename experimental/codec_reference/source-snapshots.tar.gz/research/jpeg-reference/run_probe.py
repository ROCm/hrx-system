"""Run the bounded CPU oracle through Fabric, preserving exact inputs and logs."""
import base64
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
repository = root.parents[2]
assert repository == Path.cwd()
log_path = root / 'probe.log'
assert not log_path.exists(), 'preserve prior attempts before any revised invocation'
fixture_path = Path('loom/src/loom/serve/media/testdata/image_fuzz/jpeg.txt')
fixture = base64.b64decode(fixture_path.read_text().strip().split(',', 1)[1], validate=True)
sources = json.loads((root / 'source-identity.json').read_text())
assert all('error' not in row for row in sources['sources'])
lock = json.loads(Path('MODULE.bazel.lock').read_text())
source_url = 'https://bcr.bazel.build/modules/libjpeg_turbo/3.1.3.bcr.6/source.json'
assert lock['registryFileHashes'][source_url] == hashlib.sha256((root / 'bcr-source.json').read_bytes()).hexdigest()
arguments = [
    '.venv/bin/bazel', 'try', '--config=asan', '--features=layering_check',
    '--dep=@libjpeg_turbo//:jpeg', str(root.relative_to(repository) / 'jpeg_probe.c'),
    '--', fixture.hex(),
]
paths = [
    'loom/src/loom/serve/media/image_jpeg.c',
    'loom/src/loom/serve/media/image_test.cc',
    'loom/src/loom/serve/media/image_types.h',
    'loom/src/loom/serve/media/image_codec.h',
    'loom/src/loom/serve/service/text/media_projector.c',
    'build_tools/third_party/deps.MODULE.bazel',
    str(fixture_path),
]
identity = {
    'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'arguments': arguments,
    'source_sha256': hashlib.sha256((root / 'jpeg_probe.c').read_bytes()).hexdigest(),
    'fixture_sha256': hashlib.sha256(fixture).hexdigest(),
    'fixture_bytes': len(fixture),
    'source_inputs': [{'path': str(path), 'sha256': hashlib.sha256(Path(path).read_bytes()).hexdigest()} for path in paths],
    'boundary': 'Public libjpeg calls with serving RGB8 settings; no private facade, model, or performance execution.',
}
(root / 'invocation.json').write_text(json.dumps(identity, indent=2) + '\n')
with log_path.open('w') as output:
    child = subprocess.Popen(arguments, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    for line in child.stdout:
        output.write(line)
        output.flush()
        if not line.startswith('{"kind":'):
            print(line, end='', flush=True)
    status = child.wait()
(root / 'exit.json').write_text(json.dumps({'exit_code': status}) + '\n')
print(json.dumps({'exit_code': status, 'log': str(log_path)}), flush=True)
sys.exit(status)
