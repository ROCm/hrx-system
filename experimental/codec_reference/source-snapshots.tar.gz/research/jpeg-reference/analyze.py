"""Validate the pinned CPU observations and inventory actual JPEG markers."""
import base64
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import struct

root = Path(__file__).resolve().parent
repository = root.parents[2]
assert json.loads((root / 'exit.json').read_text())['exit_code'] == 0
invocation = json.loads((root / 'invocation.json').read_text())
assert hashlib.sha256((root / 'jpeg_probe.c').read_bytes()).hexdigest() == invocation['source_sha256']
rows = [json.loads(line) for line in (root / 'probe.log').read_text().splitlines()
        if line.startswith('{"kind":')]
assert Counter(row['kind'] for row in rows) == {'library': 1, 'input': 23, 'result': 70}
library, = [row for row in rows if row['kind'] == 'library']
assert library['sample_bytes'] == 1
inputs = {row['name']: row for row in rows if row['kind'] == 'input'}
results = {(row['name'], row['mode']): row for row in rows if row['kind'] == 'result'}
assert len(inputs) == 23 and len(results) == 70


def digest(data):
    return hashlib.sha256(data).hexdigest()


def inspect_markers(data):
    """Bounded inventory of these generated, valid streams; no entropy decode."""
    assert data[:2] == b'\xff\xd8'
    position = 2
    frame = None
    scans = []
    markers = []
    quantization = []
    restart_interval = 0
    exif_orientation = None
    while position < len(data):
        start = position
        assert data[position] == 255, position
        while data[position] == 255:
            position += 1
        marker = data[position]
        position += 1
        markers.append({'marker': f'{marker:02x}', 'offset': start})
        if marker == 0xd9:
            assert position == len(data)
            assert frame is not None and scans
            return {'frame': frame, 'scans': scans, 'markers': markers,
                    'quantization_tables': quantization, 'exif_orientation': exif_orientation}
        assert marker not in [0, 1, 0xd8, *range(0xd0, 0xd8)]
        length = int.from_bytes(data[position:position + 2], 'big')
        assert length >= 2 and position + length <= len(data)
        payload = data[position + 2:position + length]
        position += length
        if marker in [0xc0, 0xc1, 0xc2, 0xc3, 0xc9, 0xca, 0xcb]:
            assert frame is None and len(payload) == 6 + 3 * payload[5]
            frame = {'sof': f'{marker:02x}', 'precision': payload[0],
                     'height': int.from_bytes(payload[1:3], 'big'),
                     'width': int.from_bytes(payload[3:5], 'big'),
                     'components': [{'id': payload[i], 'horizontal': payload[i + 1] >> 4,
                                     'vertical': payload[i + 1] & 15, 'quantization': payload[i + 2]}
                                    for i in range(6, len(payload), 3)]}
        elif marker == 0xdd:
            assert len(payload) == 2
            restart_interval = int.from_bytes(payload, 'big')
        elif marker == 0xdb:
            offset = 0
            while offset < len(payload):
                descriptor = payload[offset]
                width = (descriptor >> 4) + 1
                assert width in [1, 2]
                extent = 64 * width
                assert offset + 1 + extent <= len(payload)
                values = [int.from_bytes(payload[i:i + width], 'big')
                          for i in range(offset + 1, offset + 1 + extent, width)]
                quantization.append({'id': descriptor & 15, 'precision': width * 8,
                                     'minimum': min(values), 'maximum': max(values)})
                offset += 1 + extent
        elif marker == 0xe1 and payload.startswith(b'Exif\0\0'):
            tiff = payload[6:]
            assert tiff[:2] in [b'MM', b'II']
            endian = 'big' if tiff[:2] == b'MM' else 'little'
            assert int.from_bytes(tiff[2:4], endian) == 42
            offset = int.from_bytes(tiff[4:8], endian)
            count = int.from_bytes(tiff[offset:offset + 2], endian)
            for index in range(count):
                entry = tiff[offset + 2 + index * 12:offset + 14 + index * 12]
                assert len(entry) == 12
                if int.from_bytes(entry[:2], endian) == 0x112:
                    assert int.from_bytes(entry[2:4], endian) == 3
                    assert int.from_bytes(entry[4:8], endian) == 1
                    exif_orientation = int.from_bytes(entry[8:10], endian)
        elif marker == 0xda:
            count = payload[0]
            assert len(payload) == 1 + 2 * count + 3
            scan = {'components': [payload[1 + 2 * i] for i in range(count)],
                    'spectral_start': payload[-3], 'spectral_end': payload[-2],
                    'successive_high': payload[-1] >> 4, 'successive_low': payload[-1] & 15,
                    'restart_interval': restart_interval, 'entropy_start': position,
                    'restarts': [], 'stuffed_bytes': 0}
            while position < len(data):
                if data[position] != 255:
                    position += 1
                    continue
                marker_start = position
                position += 1
                while data[position] == 255:
                    position += 1
                value = data[position]
                if value == 0:
                    scan['stuffed_bytes'] += 1
                    position += 1
                elif 0xd0 <= value <= 0xd7:
                    scan['restarts'].append({'offset': marker_start, 'index': value - 0xd0})
                    position += 1
                else:
                    position = marker_start
                    break
            scan['entropy_end'] = position
            scans.append(scan)
    raise AssertionError('valid reference input has no EOI')


unsupported = {'cmyk_sequential', 'ycck_sequential', 'gray_lossless_8',
               'gray_dct_12', 'rgb_lossless_12', 'gray_lossless_16'}
summary = {'state': 'Untimed CPU reference; no decoder or image ABI selected.',
           'library': library, 'cases': [], 'equivalent_420_variants': [],
           'warning_recovery': []}
for name, source in inputs.items():
    assert source['success'] and not source['warnings'] and not source['error'], source
    data = bytes.fromhex(source['hex'])
    structure = inspect_markers(data)
    frame = structure['frame']
    original = results[name, 1]
    simple = results[name, 2]
    assert original['header_ok'] and simple['header_ok']
    assert original['complete'] == (name not in unsupported), (name, original)
    assert simple['complete'] == original['complete']
    assert not original['warnings'] and not simple['warnings']
    assert frame['precision'] == source['precision'] == original['precision']
    assert (frame['width'], frame['height']) == (original['width'], original['height']) == (35, 19)
    assert [(x['id'], x['horizontal'], x['vertical']) for x in frame['components']] == [
        (x['id'], x['horizontal'], x['vertical']) for x in original['components']]
    row = {'name': name, 'compressed_bytes': len(data), 'sha256': digest(data),
           'structure': structure, 'header_ok': True, 'rgb8_complete': original['complete'],
           'rgb8_error': original['error'], 'color_space': original['color_space']}
    for scan in structure['scans']:
        assert [x['index'] for x in scan['restarts']] == [i % 8 for i in range(len(scan['restarts']))]
        if scan['restart_interval']:
            # The generated restart cases are DCT streams. Interleaved scans
            # count MCUs; single-component scans count component blocks.
            assert frame['sof'] != 'c3'
            maximum_h = max(c['horizontal'] for c in frame['components'])
            maximum_v = max(c['vertical'] for c in frame['components'])
            if len(scan['components']) > 1:
                mcus = math.ceil(frame['width'] / (8 * maximum_h)) * math.ceil(frame['height'] / (8 * maximum_v))
            else:
                component, = [c for c in frame['components'] if c['id'] == scan['components'][0]]
                mcus = math.ceil(frame['width'] * component['horizontal'] / (8 * maximum_h)) * math.ceil(frame['height'] * component['vertical'] / (8 * maximum_v))
            assert len(scan['restarts']) == (mcus - 1) // scan['restart_interval']
    if not source['lossless']:
        coefficients = results[name, 0]
        assert coefficients['complete'] and not coefficients['warnings']
        row['coefficient_planes'] = []
        for component, values in zip(coefficients['components'], coefficients['coefficients'], strict=True):
            assert len(values['values']) == component['block_width'] * component['block_height'] * 64
            row['coefficient_planes'].append({
                **component, 'count': len(values['values']),
                'coefficients_sha256': digest(struct.pack('<' + 'h' * len(values['values']), *values['values'])),
                'quantization_sha256': digest(struct.pack('<64H', *values['quantization'])),
            })
    if original['complete']:
        pixels = bytes.fromhex(original['rgb_hex'])
        alternative = bytes.fromhex(simple['rgb_hex'])
        assert len(pixels) == len(alternative) == 35 * 19 * 3
        differences = [abs(a - b) for a, b in zip(pixels, alternative, strict=True)]
        row['rgb8_sha256'] = digest(pixels)
        row['default_dct_method'] = original['dct_method']
        row['fancy_vs_simple'] = {'different_samples': sum(x != 0 for x in differences),
                                 'total_samples': len(differences), 'maximum': max(differences),
                                 'mean_absolute': sum(differences) / len(differences)}
        if name == 'rgb_lossless_8':
            expected = bytes((x * 17 + y * 37 + channel * 71 + ((x ^ y) & 7) * 19) & 255
                             for y in range(19) for x in range(35) for channel in range(3))
            assert pixels == expected
            row['exact_original_rgb'] = True
    summary['cases'].append(row)

base_coefficients = results['ycbcr_420', 0]['coefficients']
base_rgb = results['ycbcr_420', 1]['rgb_hex']
for name in ['ycbcr_420_restart_1', 'ycbcr_420_restart_3', 'ycbcr_420_progressive',
             'ycbcr_420_progressive_restart_1', 'ycbcr_420_separate_scans',
             'ycbcr_420_arithmetic', 'ycbcr_420_arithmetic_progressive']:
    assert results[name, 0]['coefficients'] == base_coefficients
    assert results[name, 1]['rgb_hex'] == base_rgb
    summary['equivalent_420_variants'].append(name)

for name in ['missing_eoi', 'truncated_entropy']:
    row = results[name, 1]
    assert row['header_ok'] and row['complete'] and row['warnings']
    assert len(bytes.fromhex(row['rgb_hex'])) == 35 * 19 * 3
    summary['warning_recovery'].append({'name': name, 'header_ok': True, 'complete': True,
                                        'warnings': row['warnings'],
                                        'same_pixels_as_intact': row['rgb_hex'] == base_rgb})
fixture = base64.b64decode((repository / 'loom/src/loom/serve/media/testdata/image_fuzz/jpeg.txt').read_text().strip().split(',', 1)[1], validate=True)
assert digest(fixture) == invocation['fixture_sha256']
fixture_structure = inspect_markers(fixture)
assert fixture_structure['exif_orientation'] == 6
assert (fixture_structure['frame']['width'], fixture_structure['frame']['height']) == (2, 3)
assert all(results['existing_exif_fixture', mode]['complete'] for mode in range(3))
summary['existing_fixture'] = {'sha256': digest(fixture), 'structure': fixture_structure,
                              'rgb8_sha256': digest(bytes.fromhex(results['existing_exif_fixture', 1]['rgb_hex']))}
summary['probe_log_sha256'] = digest((root / 'probe.log').read_bytes())
(root / 'qualified.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'cases': len(summary['cases']), 'rgb8_successes': sum(r['rgb8_complete'] for r in summary['cases']),
                  'rgb8_rejections': len(unsupported), 'equivalent_variants': len(summary['equivalent_420_variants']),
                  'coefficient_planes': sum(len(r.get('coefficient_planes', [])) for r in summary['cases']),
                  'warning_recovery': summary['warning_recovery']}, indent=2))
